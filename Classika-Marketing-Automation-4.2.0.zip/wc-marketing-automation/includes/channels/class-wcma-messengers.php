<?php
/**
 * پیام‌رسان‌ها: تلگرام، بله، ایتا، روبیکا و واتساپ.
 *
 * همه‌ی این سرویس‌ها الگوی مشابهی دارند (توکن ربات + شناسه‌ی چت + متن)، بنابراین
 * در یک لایه‌ی مشترک مدیریت می‌شوند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Messengers
 */
class WCMA_Messengers {

	/**
	 * تعریف پیام‌رسان‌های پشتیبانی‌شده.
	 *
	 * @return array
	 */
	public static function all() {
		return array(
			'whatsapp' => array(
				'label'        => 'واتساپ',
				'icon'         => 'whatsapp',
				'token_key'    => 'whatsapp_token',
				'chat_key'     => 'whatsapp_phone_id',
				'enabled_key'  => 'whatsapp_enabled',
				'token_label'  => 'توکن دسترسی (Access Token)',
				'chat_label'   => 'شناسه‌ی شماره فرستنده (Phone Number ID)',
				'chat_holder'  => '1234567890123456',
				'token_holder' => 'EAAG...',
				'help'         => 'از WhatsApp Cloud API متعلق به متا استفاده می‌کند. توکن و Phone Number ID را از پیشخوان Meta for Developers بگیرید.',
				'per_customer' => true,
			),
			'telegram' => array(
				'label'        => 'تلگرام',
				'icon'         => 'admin-site-alt3',
				// کلیدهای قدیمی برای حفظ سازگاری با نسخه‌ی قبلی حفظ شده‌اند.
				'token_key'    => 'telegram_bot_token',
				'chat_key'     => 'telegram_channel_id',
				'enabled_key'  => 'telegram_enabled',
				'token_label'  => 'توکن ربات تلگرام',
				'chat_label'   => 'شناسه‌ی کانال یا چت',
				'chat_holder'  => '@my_channel یا -1001234567890',
				'token_holder' => '123456:ABC-DEF...',
				'help'         => 'توکن را از ربات @BotFather بگیرید و ربات را در کانال خود ادمین کنید.',
				'per_customer' => false,
			),
			'bale'     => array(
				'label'        => 'بله',
				'icon'         => 'format-chat',
				'token_key'    => 'bale_bot_token',
				'chat_key'     => 'bale_chat_id',
				'enabled_key'  => 'bale_enabled',
				'token_label'  => 'توکن ربات بله',
				'chat_label'   => 'شناسه‌ی کانال یا چت بله',
				'chat_holder'  => '@my_channel یا 1234567890',
				'token_holder' => '123456:ABC-DEF...',
				'help'         => 'ربات را در «بله» از طریق @BotFather بسازید. ساختار API بله مشابه تلگرام است.',
				'per_customer' => false,
			),
			'eitaa'    => array(
				'label'        => 'ایتا',
				'icon'         => 'format-status',
				'token_key'    => 'eitaa_token',
				'chat_key'     => 'eitaa_chat_id',
				'enabled_key'  => 'eitaa_enabled',
				'token_label'  => 'توکن ایتایار (Eitaa Yar)',
				'chat_label'   => 'شناسه‌ی کانال ایتا',
				'chat_holder'  => '@my_channel',
				'token_holder' => 'توکن دریافتی از eitaayar.ir',
				'help'         => 'از سرویس «ایتایار» در نشانی eitaayar.ir توکن بگیرید و ربات را در کانال ادمین کنید.',
				'per_customer' => false,
			),
			'rubika'   => array(
				'label'        => 'روبیکا',
				'icon'         => 'format-aside',
				'token_key'    => 'rubika_token',
				'chat_key'     => 'rubika_chat_id',
				'enabled_key'  => 'rubika_enabled',
				'token_label'  => 'توکن ربات روبیکا',
				'chat_label'   => 'شناسه‌ی چت یا کانال روبیکا',
				'chat_holder'  => 'b0Q...  یا  @my_channel',
				'token_holder' => 'توکن دریافتی از @BotFather روبیکا',
				'help'         => 'ربات را در روبیکا بسازید و توکن آن را وارد کنید (Rubika Bot API نسخه ۳).',
				'per_customer' => false,
			),
		);
	}

	/**
	 * دریافت تعریف یک پیام‌رسان.
	 *
	 * @param string $key کلید.
	 * @return array|null
	 */
	/**
	 * نام نمایشی یک پیام‌رسان.
	 *
	 * @param string $key کلید.
	 * @return string
	 */
	public static function label( $key ) {
		$def = self::get( $key );

		return $def ? $def['label'] : $key;
	}

	public static function get( $key ) {
		$all = self::all();
		return $all[ $key ] ?? null;
	}

	/**
	 * آیا این کلید یک پیام‌رسان است؟
	 *
	 * @param string $key کلید.
	 * @return bool
	 */
	public static function is_messenger( $key ) {
		return (bool) self::get( $key );
	}

	/**
	 * آیا پیام‌رسان فعال و پیکربندی شده است؟
	 *
	 * @param string $key کلید.
	 * @return bool
	 */
	public static function is_ready( $key ) {
		$def = self::get( $key );

		if ( ! $def ) {
			return false;
		}

		return WCMA_Settings::is( $def['enabled_key'] ) && WCMA_Settings::get( $def['token_key'] );
	}

	/**
	 * پیام‌رسان‌هایی که می‌توانند مستقیم به شماره‌ی خود مشتری پیام بدهند.
	 *
	 * @return array
	 */
	public static function per_customer_keys() {
		$keys = array();

		foreach ( self::all() as $key => $def ) {
			if ( ! empty( $def['per_customer'] ) ) {
				$keys[] = $key;
			}
		}

		return $keys;
	}

	/**
	 * یافتن مقصد پیام برای یک گیرنده.
	 *
	 * برای واتساپ شماره‌ی موبایل خود مشتری استفاده می‌شود. برای بقیه، اگر شناسه‌ی چت
	 * اختصاصی مشتری ذخیره شده باشد از آن، وگرنه از کانال پیش‌فرض تنظیمات استفاده می‌شود.
	 *
	 * @param string $key  کلید پیام‌رسان.
	 * @param array  $args پارامترهای ارسال.
	 * @return string
	 */
	public static function resolve_target( $key, array $args ) {
		$def = self::get( $key );

		if ( ! $def ) {
			return '';
		}

		// مقصد صریح (مثلاً در تست ارسال).
		if ( ! empty( $args['messenger_target'] ) ) {
			return (string) $args['messenger_target'];
		}

		// واتساپ مستقیماً به شماره‌ی مشتری پیام می‌دهد.
		if ( 'whatsapp' === $key ) {
			if ( ! empty( $args['phone'] ) ) {
				return self::to_international( $args['phone'] );
			}

			return '';
		}

		// ۱) شناسه‌ی چت اختصاصی مشتری در صورت وجود.
		if ( ! empty( $args['user_id'] ) ) {
			$saved = get_user_meta( (int) $args['user_id'], 'wcma_' . $key . '_chat_id', true );

			if ( $saved ) {
				return (string) $saved;
			}
		}

		// ۲) مشتری مهمان: از روی شماره‌ی موبایل، حساب متصل را پیدا کن.
		if ( empty( $args['user_id'] ) && ! empty( $args['phone'] ) && class_exists( 'WCMA_Bot_Link' ) ) {
			$matched = WCMA_Bot_Link::find_user_by_phone( $args['phone'] );

			if ( $matched ) {
				$saved = get_user_meta( $matched, 'wcma_' . $key . '_chat_id', true );

				if ( $saved ) {
					return (string) $saved;
				}
			}
		}

		// ۳) در نبود اتصال اختصاصی، کانال عمومی فروشگاه.
		return (string) WCMA_Settings::get( $def['chat_key'] );
	}

	/**
	 * تبدیل شماره‌ی ایرانی به قالب بین‌المللی بدون علامت مثبت.
	 *
	 * @param string $phone شماره.
	 * @return string
	 */
	public static function to_international( $phone ) {
		$normalized = WCMA_SMS_Gateways::normalize_phone( $phone );

		if ( '' === $normalized ) {
			return '';
		}

		return '98' . substr( $normalized, 1 );
	}

	/**
	 * ارسال پیام از طریق یک پیام‌رسان.
	 *
	 * @param string $key     کلید پیام‌رسان.
	 * @param string $target  مقصد (شناسه‌ی چت یا شماره).
	 * @param string $text    متن پیام.
	 * @param string $html    نسخه‌ی HTML (در صورت پشتیبانی).
	 * @return array{success:bool,message:string}
	 */
	public static function send( $key, $target, $text, $html = '' ) {
		$def = self::get( $key );

		if ( ! $def ) {
			return self::error( 'پیام‌رسان انتخاب‌شده پشتیبانی نمی‌شود.' );
		}

		if ( ! WCMA_Settings::is( $def['enabled_key'] ) ) {
			return self::error( sprintf( 'کانال %s فعال نیست.', $def['label'] ) );
		}

		$token = WCMA_Settings::get( $def['token_key'] );

		if ( ! $token ) {
			return self::error( sprintf( 'توکن %s وارد نشده است.', $def['label'] ) );
		}

		if ( '' === trim( (string) $target ) ) {
			return self::error( sprintf( 'مقصد پیام در %s مشخص نیست.', $def['label'] ) );
		}

		$text = trim( (string) $text );

		if ( '' === $text ) {
			return self::error( 'متن پیام خالی است.' );
		}

		/**
		 * امکان پیاده‌سازی دلخواه ارسال پیام‌رسان توسط توسعه‌دهنده.
		 *
		 * @param array|null $result نتیجه.
		 * @param string     $key    پیام‌رسان.
		 * @param string     $target مقصد.
		 * @param string     $text   متن.
		 */
		$pre = apply_filters( 'wcma_pre_send_messenger', null, $key, $target, $text );

		if ( is_array( $pre ) ) {
			return $pre;
		}

		switch ( $key ) {
			case 'telegram':
				$body = $html ? self::to_telegram_html( $html ) : $text;

				return self::send_telegram_like( 'https://api.telegram.org/bot' . $token . '/sendMessage', $target, $body, true );
			case 'bale':
				return self::send_telegram_like( 'https://tapi.bale.ai/bot' . $token . '/sendMessage', $target, $text, false );
			case 'eitaa':
				return self::send_eitaa( $token, $target, $text );
			case 'rubika':
				return self::send_rubika( $token, $target, $text );
			case 'whatsapp':
				return self::send_whatsapp( $token, $target, $text );
		}

		return self::error( 'پیام‌رسان انتخاب‌شده پشتیبانی نمی‌شود.' );
	}

	/**
	 * آدرس پایه‌ی API برای پیام‌رسان‌های سازگار با تلگرام.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return string خالی اگر پشتیبانی نشود.
	 */
	public static function api_base( $messenger ) {
		$def = self::get( $messenger );

		if ( ! $def ) {
			return '';
		}

		$token = WCMA_Settings::get( $def['token_key'] );

		if ( ! $token ) {
			return '';
		}

		if ( 'telegram' === $messenger ) {
			return 'https://api.telegram.org/bot' . $token . '/';
		}

		if ( 'bale' === $messenger ) {
			return 'https://tapi.bale.ai/bot' . $token . '/';
		}

		return '';
	}

	/**
	 * انواع محتوایی که ربات می‌تواند بفرستد.
	 *
	 * @return array
	 */
	public static function content_types() {
		return array(
			'text'     => array( 'label' => 'متن', 'method' => 'sendMessage', 'field' => '', 'icon' => 'editor-alignright' ),
			'photo'    => array( 'label' => 'عکس', 'method' => 'sendPhoto', 'field' => 'photo', 'icon' => 'format-image' ),
			'video'    => array( 'label' => 'ویدیو', 'method' => 'sendVideo', 'field' => 'video', 'icon' => 'video-alt3' ),
			'audio'    => array( 'label' => 'صوت (موزیک)', 'method' => 'sendAudio', 'field' => 'audio', 'icon' => 'format-audio' ),
			'voice'    => array( 'label' => 'ویس', 'method' => 'sendVoice', 'field' => 'voice', 'icon' => 'microphone' ),
			'document' => array( 'label' => 'فایل', 'method' => 'sendDocument', 'field' => 'document', 'icon' => 'media-default' ),
		);
	}

	/**
	 * ارسال محتوا (متن یا رسانه) با امکان دکمه و کیبورد.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   شناسه‌ی چت.
	 * @param array  $args      نوع، متن، فایل و نشانه‌گذاری.
	 * @return array{success:bool,message:string}
	 */
	public static function send_content( $messenger, $chat_id, array $args ) {
		$base = self::api_base( $messenger );

		if ( ! $base ) {
			return self::error( 'این پیام‌رسان از ارسال رسانه پشتیبانی نمی‌کند یا توکن آن وارد نشده است.' );
		}

		$types = self::content_types();
		$type  = isset( $args['type'], $types[ $args['type'] ] ) ? $args['type'] : 'text';
		$def   = $types[ $type ];
		$text  = trim( (string) ( $args['text'] ?? '' ) );
		$file  = trim( (string) ( $args['file'] ?? '' ) );

		// بدون فایل، رسانه معنا ندارد؛ به متن برمی‌گردیم تا پیام از دست نرود.
		if ( 'text' !== $type && ! $file ) {
			$type = 'text';
			$def  = $types['text'];
		}

		if ( 'text' === $type && '' === $text ) {
			return self::error( 'متن پیام خالی است.' );
		}

		$body = array( 'chat_id' => $chat_id );

		/*
		 * متن دست‌نویس مدیر ممکن است < یا & داشته باشد؛ با parse_mode=HTML تلگرام
		 * خطای can't parse entities می‌داد و پیام اصلاً نمی‌رسید — از بیرون دقیقاً
		 * شبیه «دکمه کار نمی‌کند» دیده می‌شد.
		 *
		 * متنی که در خود ربات تایپ شده (plain) HTML نیست: «<500 هزار» باید همان
		 * بماند، نه اینکه برچسبِ ناتمام حساب شود و بقیه‌ی پیام حذف شود.
		 */
		$text = ! empty( $args['plain'] )
			// مقدار متغیرها (مثل نام سایت که وردپرس با &amp; نگه می‌دارد) یک‌بار باز و بعد کدگذاری می‌شود.
			? str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), html_entity_decode( $text, ENT_QUOTES, 'UTF-8' ) )
			: self::to_telegram_html( $text );

		if ( 'text' === $type ) {
			$body['text']       = $text;
			$body['parse_mode'] = 'HTML';
		} else {
			$body[ $def['field'] ] = $file;

			if ( '' !== $text ) {
				$body['caption']    = mb_substr( $text, 0, 1024 );
				$body['parse_mode'] = 'HTML';
			}
		}

		if ( ! empty( $args['reply_markup'] ) ) {
			$body['reply_markup'] = is_string( $args['reply_markup'] )
				? $args['reply_markup']
				: wp_json_encode( $args['reply_markup'] );
		}

		$response = wp_remote_post(
			$base . $def['method'],
			array(
				'timeout' => 12,
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $decoded['ok'] ) ) {
			return self::success();
		}

		return self::error( $decoded['description'] ?? 'ارسال ناموفق بود.' );
	}

	/**
	 * تبدیل HTML به زیرمجموعه‌ی مجاز تلگرام.
	 *
	 * تلگرام فقط تعداد کمی تگ را می‌پذیرد و با دیدن تگ‌هایی مانند <p> خطای
	 * «can't parse entities» برمی‌گرداند. بنابراین ابتدا تگ‌های بلوکی به خط جدید
	 * تبدیل و سپس فقط تگ‌های مجاز نگه داشته می‌شوند.
	 *
	 * @param string $html محتوای ورودی.
	 * @return string
	 */
	public static function to_telegram_html( $html ) {
		$text = (string) $html;

		// بلوک‌های اسکریپت و استایل باید کامل حذف شوند؛ strip_tags خودِ تگ را
		// برمی‌دارد ولی محتوای داخل آن را در متن باقی می‌گذارد.
		$text = preg_replace( '#<(script|style|head)\b[^>]*>.*?</\1>#is', '', $text );

		// تگ‌های بلوکی به خط جدید.
		$text = preg_replace( '#<br\s*/?>#i', "\n", $text );
		$text = preg_replace( '#</(p|div|tr|li|h[1-6])>#i', "\n", $text );
		$text = preg_replace( '#<li[^>]*>#i', '• ', $text );
		$text = preg_replace( '#</td>\s*#i', ' ', $text );

		// فقط تگ‌هایی که تلگرام می‌شناسد.
		$text = strip_tags( $text, '<b><strong><i><em><u><s><a><code><pre>' );

		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );

		/*
		 * حالا متن، مخلوطی از تگ‌های مجاز و نوشته‌ی خام است. تلگرام روی هر & یا <
		 * که جزو تگ نباشد خطای can't parse entities می‌دهد و پیام را نمی‌فرستد،
		 * پس فقط بخش‌های متنی را کدگذاری می‌کنیم و تگ‌ها را دست‌نخورده می‌گذاریم.
		 */
		$parts = preg_split( '#(</?(?:b|strong|i|em|u|s|a|code|pre)(?:\s[^<>]*)?>)#i', $text, -1, PREG_SPLIT_DELIM_CAPTURE );

		if ( $parts ) {
			$out = '';

			foreach ( $parts as $index => $part ) {
				$out .= ( $index % 2 ) ? $part : str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), $part );
			}

			$text = $out;
		}

		$text = preg_replace( "/\n{3,}/", "\n\n", $text );

		return trim( $text );
	}

	/**
	 * ارسال به سرویس‌هایی با API سازگار با تلگرام (تلگرام و بله).
	 *
	 * @param string $url        نشانی متد sendMessage.
	 * @param string $chat_id    شناسه‌ی چت.
	 * @param string $text       متن.
	 * @param bool   $allow_html پشتیبانی از parse_mode.
	 * @return array
	 */
	protected static function send_telegram_like( $url, $chat_id, $text, $allow_html = true ) {
		$body = array(
			'chat_id' => $chat_id,
			'text'    => $allow_html ? $text : WCMA_Placeholders::to_plain( $text ),
		);

		if ( $allow_html ) {
			$body['parse_mode'] = 'HTML';
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 12,
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $decoded['ok'] ) ) {
			return self::success();
		}

		return self::error( $decoded['description'] ?? 'ارسال پیام ناموفق بود.' );
	}

	/**
	 * ارسال از طریق ایتا (سرویس ایتایار).
	 *
	 * @param string $token   توکن.
	 * @param string $chat_id شناسه‌ی کانال.
	 * @param string $text    متن.
	 * @return array
	 */
	protected static function send_eitaa( $token, $chat_id, $text ) {
		$response = wp_remote_post(
			'https://eitaayar.ir/api/' . rawurlencode( $token ) . '/sendMessage',
			array(
				'timeout' => 12,
				'body'    => array(
					'chat_id' => $chat_id,
					'text'    => WCMA_Placeholders::to_plain( $text ),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $decoded['ok'] ) ) {
			return self::success();
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 === $code && null === $decoded ) {
			return self::success();
		}

		return self::error( $decoded['description'] ?? sprintf( 'ارسال ایتا ناموفق بود (کد %d).', $code ) );
	}

	/**
	 * ارسال از طریق روبیکا (Bot API نسخه ۳).
	 *
	 * @param string $token   توکن.
	 * @param string $chat_id شناسه‌ی چت.
	 * @param string $text    متن.
	 * @return array
	 */
	protected static function send_rubika( $token, $chat_id, $text ) {
		$response = wp_remote_post(
			'https://botapi.rubika.ir/v3/' . rawurlencode( $token ) . '/sendMessage',
			array(
				'timeout' => 12,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'chat_id' => $chat_id,
						'text'    => WCMA_Placeholders::to_plain( $text ),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		$status  = isset( $decoded['status'] ) ? strtoupper( (string) $decoded['status'] ) : '';

		if ( 'OK' === $status ) {
			return self::success();
		}

		return self::error( $decoded['status_det'] ?? ( $decoded['status'] ?? 'ارسال روبیکا ناموفق بود.' ) );
	}

	/**
	 * ارسال از طریق واتساپ (WhatsApp Cloud API).
	 *
	 * @param string $token    توکن دسترسی.
	 * @param string $to       شماره‌ی گیرنده به قالب بین‌المللی.
	 * @param string $text     متن.
	 * @return array
	 */
	protected static function send_whatsapp( $token, $to, $text ) {
		$phone_id = WCMA_Settings::get( 'whatsapp_phone_id' );

		if ( ! $phone_id ) {
			return self::error( 'شناسه‌ی شماره فرستنده (Phone Number ID) واتساپ وارد نشده است.' );
		}

		$to = preg_replace( '/[^0-9]/', '', (string) $to );

		if ( '' === $to ) {
			return self::error( 'شماره‌ی گیرنده‌ی واتساپ معتبر نیست.' );
		}

		$version  = WCMA_Settings::get( 'whatsapp_api_version', 'v21.0' );
		$template = trim( (string) WCMA_Settings::get( 'whatsapp_template' ) );
		$text     = WCMA_Placeholders::to_plain( $text );

		if ( $template ) {
			// پیام‌های آغازشده از سمت کسب‌وکار باید قالب تأییدشده داشته باشند.
			$payload = array(
				'messaging_product' => 'whatsapp',
				'to'                => $to,
				'type'              => 'template',
				'template'          => array(
					'name'       => $template,
					'language'   => array( 'code' => WCMA_Settings::get( 'whatsapp_template_lang', 'fa' ) ),
					'components' => array(
						array(
							'type'       => 'body',
							'parameters' => array(
								array(
									'type' => 'text',
									'text' => $text,
								),
							),
						),
					),
				),
			);
		} else {
			$payload = array(
				'messaging_product' => 'whatsapp',
				'to'                => $to,
				'type'              => 'text',
				'text'              => array(
					'preview_url' => true,
					'body'        => $text,
				),
			);
		}

		$response = wp_remote_post(
			sprintf( 'https://graph.facebook.com/%s/%s/messages', $version, $phone_id ),
			array(
				'timeout' => 12,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $token,
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $decoded['messages'] ) ) {
			return self::success();
		}

		$message = $decoded['error']['message'] ?? 'ارسال واتساپ ناموفق بود.';

		// راهنمایی برای رایج‌ترین خطای واتساپ.
		if ( false !== stripos( $message, 're-engagement' ) || false !== stripos( $message, '24' ) ) {
			$message .= ' — برای پیام‌های تبلیغاتی باید یک «قالب تأییدشده» در تنظیمات واتساپ وارد کنید.';
		}

		return self::error( $message );
	}

	/**
	 * خروجی موفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function success( $message = 'پیام با موفقیت ارسال شد.' ) {
		return array(
			'success' => true,
			'message' => $message,
		);
	}

	/**
	 * خروجی ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function error( $message ) {
		return array(
			'success' => false,
			'message' => (string) $message,
		);
	}
}
