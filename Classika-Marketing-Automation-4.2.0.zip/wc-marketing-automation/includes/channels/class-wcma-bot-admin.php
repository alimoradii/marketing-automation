<?php
/**
 * مدیریت ربات از درون خود تلگرام (یا بله).
 *
 * مدیر سایت یک یا چند حساب تلگرام را «مدیر ربات» می‌کند. آن حساب‌ها در همان
 * ربات یک منوی مدیریتی می‌بینند: آمار، ارسال پیام همگانی (متن، عکس، ویدیو،
 * فایل)، ارسال پیام آماده، پیگیری و لغو ارسال‌ها، جستجو و پیام مستقیم به
 * مشترک، ورود مخاطبان با فرستادن فایل اکسل و چند تنظیم ساده. خبر عضو تازه و
 * شماره‌ی تازه هم برایشان می‌رسد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Admin
 */
class WCMA_Bot_Admin {

	/**
	 * فهرست مدیران ربات.
	 */
	const OPTION = 'wcma_bot_admins';

	/**
	 * لینک‌های دعوتِ مصرف‌نشده.
	 */
	const INVITES = 'wcma_bot_admin_invites';

	/**
	 * اعتبار لینک دعوت، به ثانیه.
	 */
	const INVITE_TTL = 86400;

	/**
	 * پیشوند پارامتر شروعِ لینک دعوت.
	 */
	const START_PREFIX = 'adm-';

	/**
	 * پیشوند داده‌ی دکمه‌های شیشه‌ای مدیریتی.
	 */
	const CB = 'wcma:a:';

	/**
	 * پیشوند گفتگوی چندمرحله‌ای و پیش‌نویس هر مدیر.
	 */
	const FLOW  = 'wcma_bot_admin_flow_';
	const DRAFT = 'wcma_bot_admin_draft_';

	/**
	 * مهلت گفتگوی چندمرحله‌ای و پیش‌نویس، به ثانیه.
	 */
	const FLOW_TTL = 1800;

	/**
	 * دکمه‌ای که مدیر در منوی عادیِ ربات می‌بیند.
	 */
	const ENTRY = '🛠 پنل مدیریت';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		// پیش از کنسول کارکنان (۱) و مدیریت ربات (۵ و ۱۰).
		add_action( 'wcma_bot_started', array( __CLASS__, 'on_start' ), 0, 2 );
		add_action( 'wcma_bot_message', array( __CLASS__, 'on_message' ), 0, 2 );
		add_action( 'wcma_bot_callback', array( __CLASS__, 'on_callback' ), 5, 2 );

		add_action( 'wcma_bot_subscribed', array( __CLASS__, 'notify_subscribed' ) );
		add_action( 'wcma_bot_phone_shared', array( __CLASS__, 'notify_phone' ), 10, 2 );
		add_action( 'wcma_bot_broadcast_closed', array( __CLASS__, 'notify_broadcast' ) );

		add_filter( 'wcma_bot_keyboard_rows', array( __CLASS__, 'keyboard_rows' ), 10, 2 );
	}

	/**
	 * دکمه‌های منوی مدیریت.
	 *
	 * @return array
	 */
	public static function buttons() {
		return array(
			'stats'    => '📊 آمار ربات',
			'compose'  => '✍️ پیام همگانی تازه',
			'prepared' => '📨 ارسال پیام آماده',
			'jobs'     => '📋 ارسال‌های اخیر',
			'search'   => '🔎 جستجوی مشترک',
			'recent'   => '👥 مشترکان تازه',
			'import'   => '📥 ورود مخاطبان از اکسل',
			'settings' => '⚙️ تنظیمات',
			'exit'     => '🏠 منوی عادی',
		);
	}

	/**
	 * برچسب کوتاه گروه‌های مخاطب برای دکمه‌های ربات.
	 *
	 * @return array
	 */
	public static function audience_labels() {
		return array(
			'subscribed' => 'همه‌ی مشترکان',
			'phone'      => 'فقط دارای شماره',
			'no_phone'   => 'فقط بدون شماره',
			'sequence'   => 'در حال دریافت دنباله',
			'done'       => 'دنباله‌ی تمام‌شده',
			'all'        => 'همه، حتی لغوکرده‌ها',
		);
	}

	/* ------------------------------------------------------------------ */
	/* فهرست مدیران                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * پیام‌رسانی که ربات روی آن است.
	 *
	 * @return string
	 */
	public static function channel() {
		return WCMA_Bot_Manager::channel();
	}

	/**
	 * کلید یکتای یک مدیر.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   چت.
	 * @return string
	 */
	protected static function key( $messenger, $chat_id ) {
		return sanitize_key( $messenger ) . ':' . trim( (string) $chat_id );
	}

	/**
	 * همه‌ی مدیران.
	 *
	 * @return array کلید ⇐ {channel, chat_id, name, added_at}.
	 */
	public static function admins() {
		$list = get_option( self::OPTION, array() );

		return is_array( $list ) ? $list : array();
	}

	/**
	 * مدیرانِ پیام‌رسانِ فعلی ربات.
	 *
	 * @return array
	 */
	public static function current_admins() {
		$channel = self::channel();

		return array_filter(
			self::admins(),
			static function ( $admin ) use ( $channel ) {
				return is_array( $admin ) && ( $admin['channel'] ?? '' ) === $channel;
			}
		);
	}

	/**
	 * آیا این چت مدیر ربات است؟
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   چت.
	 * @return bool
	 */
	public static function is_admin( $messenger, $chat_id ) {
		$chat_id = trim( (string) $chat_id );

		return '' !== $chat_id && isset( self::admins()[ self::key( $messenger, $chat_id ) ] );
	}

	/**
	 * مدیر کردن یک چت.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   چت.
	 * @param string $name      نام نمایشی.
	 * @param bool   $welcome   فرستادن پیام خوش‌آمد و منوی مدیریت.
	 * @param string $telegram  نام و نام کاربریِ تلگرامی (برای اینکه معلوم باشد دسترسی به کدام حساب رسیده).
	 * @return bool
	 */
	public static function add( $messenger, $chat_id, $name = '', $welcome = true, $telegram = '' ) {
		$chat_id = trim( (string) $chat_id );

		if ( ! preg_match( '/^-?\d{1,20}$/', $chat_id ) ) {
			return false;
		}

		$list = self::admins();
		$key  = self::key( $messenger, $chat_id );
		$new  = ! isset( $list[ $key ] );

		$list[ $key ] = array(
			'channel'  => sanitize_key( $messenger ),
			'chat_id'  => $chat_id,
			'name'     => mb_substr( sanitize_text_field( (string) $name ), 0, 120 ),
			'telegram' => mb_substr( sanitize_text_field( (string) $telegram ), 0, 160 ),
			'added_at' => $new ? current_time( 'mysql' ) : ( $list[ $key ]['added_at'] ?? current_time( 'mysql' ) ),
		);

		update_option( self::OPTION, $list, false );

		if ( $new && $welcome ) {
			self::menu(
				$chat_id,
				"🛠 شما مدیر این ربات شدید.\nاز همین منو می‌توانید آمار ببینید، برای مشترکان پیام بفرستید و مخاطب وارد کنید. هر وقت خواستید، /admin را بزنید."
			);
		}

		return true;
	}

	/**
	 * برداشتن یک مدیر.
	 *
	 * @param string $key کلید (پیام‌رسان:چت).
	 * @return bool
	 */
	public static function remove( $key ) {
		$list = self::admins();

		if ( ! isset( $list[ $key ] ) ) {
			return false;
		}

		$admin = $list[ $key ];

		unset( $list[ $key ] );
		update_option( self::OPTION, $list, false );

		self::clear_flow( $admin['chat_id'] );
		delete_transient( self::DRAFT . md5( self::key( $admin['channel'], $admin['chat_id'] ) ) );

		// منوی عادی جای منوی مدیریت را می‌گیرد تا دکمه‌های بی‌اثر روی صفحه نمانند.
		if ( ( $admin['channel'] ?? '' ) === self::channel() ) {
			$sub    = WCMA_Bot_Manager::guest_sub( $admin['channel'], $admin['chat_id'] );
			$markup = WCMA_Bot_Manager::keyboard( true, $sub );

			WCMA_Messengers::send_content(
				$admin['channel'],
				$admin['chat_id'],
				array(
					'text'         => 'دسترسی مدیریت ربات از حساب شما برداشته شد.',
					// بی‌منو هم کیبورد مدیریت باید از صفحه برود.
					'reply_markup' => $markup ? $markup : array( 'remove_keyboard' => true ),
				)
			);
		}

		return true;
	}

	/**
	 * پیدا کردن چت از روی شماره‌ی موبایل، شناسه‌ی چت یا نام کاربری.
	 *
	 * @param string $who ورودی مدیر سایت.
	 * @return array{success:bool,message:string,chat_id?:string,name?:string,known?:bool}
	 */
	public static function resolve( $who ) {
		global $wpdb;

		$who     = trim( WCMA_Date::to_latin_digits( (string) $who ) );
		$channel = self::channel();
		$table   = WCMA_Bot_Manager::table();
		$ready   = WCMA_Install::table_exists( 'wcma_bot_subs' );
		$numeric = (bool) preg_match( '/^-?\d{4,20}$/', $who );

		if ( '' === $who ) {
			return array( 'success' => false, 'message' => 'شماره‌ی موبایل یا شناسه‌ی چت را وارد کنید.' );
		}

		if ( ! $ready ) {
			return $numeric
				? array( 'success' => true, 'chat_id' => $who, 'name' => '', 'telegram' => '', 'known' => false, 'message' => '' )
				: array( 'success' => false, 'message' => 'جدول مشترکان ربات ساخته نشده است.' );
		}

		// نام کاربری پیش از شماره: رقم‌های درون «@sara0912…» شماره نیستند.
		if ( 0 === strpos( $who, '@' ) ) {
			$username = ltrim( $who, '@' );

			// «@» تنها همه‌ی مشترکانِ بی‌نام‌کاربری را می‌گرفت و تازه‌ترینشان مدیر می‌شد.
			if ( ! preg_match( '/^[A-Za-z0-9_]{3,32}$/', $username ) ) {
				return array( 'success' => false, 'message' => 'نام کاربری معتبر نیست؛ مثل ‎@my_name بنویسید.' );
			}

			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND username = %s ORDER BY id DESC LIMIT 2", $channel, $username ), ARRAY_A ); // phpcs:ignore WordPress.DB

			if ( count( (array) $rows ) > 1 ) {
				return array( 'success' => false, 'message' => 'بیش از یک مشترک این نام کاربری را دارند. با شناسه‌ی چت یا «لینک دعوت» مدیر کنید.' );
			}

			return $rows ? self::resolved( $rows[0] ) : array( 'success' => false, 'message' => 'مشترکی با این نام کاربری پیدا نشد.' );
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( $who );

		if ( $phone ) {
			/*
			 * فقط شماره‌ای که خودِ صاحبش با دکمه‌ی اشتراک داده (تأییدشده). دادنِ
			 * دسترسی مدیریت با شماره هم فقط وقتی امن است که یک و تنها یک حساب آن
			 * را ثبت کرده باشد؛ وگرنه معلوم نیست کدام، صاحب واقعی شماره است.
			 */
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND phone = %s AND phone_verified = 1 ORDER BY id DESC LIMIT 2", $channel, $phone ), ARRAY_A ); // phpcs:ignore WordPress.DB
			$chat = $numeric && self::chat_exists( $who );

			if ( count( (array) $rows ) > 1 ) {
				return array( 'success' => false, 'message' => 'بیش از یک حساب در ربات این شماره را ثبت کرده‌اند. برای اطمینان، با شناسه‌ی چت یا «لینک دعوت» مدیر کنید.' );
			}

			// شناسه‌ی چتِ ده‌رقمیِ آغازشده با ۹ شبیه شماره است؛ اگر هر دو معنا ممکن است، حدس نمی‌زنیم.
			if ( $rows && $chat && (string) $rows[0]['chat_id'] !== $who ) {
				return array( 'success' => false, 'message' => 'این عدد هم شماره‌ی موبایل یک مشترک است و هم شناسه‌ی چت مشترکی دیگر. از جدول مشترکان «مدیر کن» را بزنید یا از «لینک دعوت» استفاده کنید.' );
			}

			if ( $rows ) {
				return self::resolved( $rows[0] );
			}

			if ( ! $chat ) {
				return array( 'success' => false, 'message' => 'کسی با این شماره هنوز ربات را باز نکرده یا شماره‌اش را با دکمه‌ی اشتراک نداده است. از او بخواهید ربات را باز کند و دکمه‌ی «اشتراک‌گذاری شماره» را بزند، یا از «لینک دعوت» استفاده کنید.' );
			}
		}

		if ( $numeric ) {
			$sub = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s LIMIT 1", $channel, $who ), ARRAY_A ); // phpcs:ignore WordPress.DB

			return $sub ? self::resolved( $sub ) : array( 'success' => true, 'chat_id' => $who, 'name' => '', 'telegram' => '', 'known' => false, 'message' => '' );
		}

		return array( 'success' => false, 'message' => 'ورودی شناخته نشد؛ شماره‌ی موبایل (مثل 09121234567)، شناسه‌ی چت (عدد) یا @نام‌کاربری بنویسید.' );
	}

	/**
	 * پیدا کردن یک چت فقط با شناسه‌ی چت (دکمه‌ی «مدیر کن» جدول مشترکان).
	 *
	 * شناسه‌ی چت هرگز شماره‌ی موبایل خوانده نمی‌شود؛ وگرنه شناسه‌ی ده‌رقمیِ
	 * آغازشده با ۹ به مشترکِ دیگری می‌رسید که همان «شماره» را دارد.
	 *
	 * @param string $chat_id شناسه‌ی چت.
	 * @return array
	 */
	public static function resolve_chat( $chat_id ) {
		global $wpdb;

		$chat_id = trim( (string) $chat_id );

		if ( ! preg_match( '/^-?\d{1,20}$/', $chat_id ) || ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return array( 'success' => false, 'message' => 'شناسه‌ی چت معتبر نیست.' );
		}

		$table = WCMA_Bot_Manager::table();
		$sub   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s LIMIT 1", self::channel(), $chat_id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $sub ? self::resolved( $sub ) : array( 'success' => false, 'message' => 'این مشترک پیدا نشد.' );
	}

	/**
	 * نتیجه‌ی resolve برای یک مشترک پیداشده.
	 *
	 * نام تلگرامی و نام کاربری هم برگردانده می‌شود تا مدیر سایت ببیند دسترسی
	 * دقیقاً به کدام حساب تلگرام می‌رسد، نه فقط نامِ پرونده‌ی مشتری.
	 *
	 * @param array $sub مشترک.
	 * @return array
	 */
	protected static function resolved( array $sub ) {
		$telegram = trim( trim( (string) $sub['name'] ) . ( ! empty( $sub['username'] ) ? ' @' . $sub['username'] : '' ) );

		return array(
			'success'  => true,
			'chat_id'  => (string) $sub['chat_id'],
			'name'     => self::sub_name( $sub ),
			'telegram' => '' !== $telegram ? $telegram : (string) $sub['chat_id'],
			'known'    => true,
			'message'  => '',
		);
	}

	/**
	 * آیا چتی با این شناسه در ربات هست؟
	 *
	 * @param string $chat_id شناسه.
	 * @return bool
	 */
	protected static function chat_exists( $chat_id ) {
		global $wpdb;

		$table = WCMA_Bot_Manager::table();

		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE channel = %s AND chat_id = %s LIMIT 1", self::channel(), (string) $chat_id ) ); // phpcs:ignore WordPress.DB
	}

	/* ------------------------------------------------------------------ */
	/* لینک دعوت                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * ساختن لینک دعوتِ یک‌بارمصرف.
	 *
	 * @return array{code:string,link:string,expires:int}
	 */
	public static function new_invite() {
		$codes = self::invites();
		$code  = strtolower( wp_generate_password( 12, false, false ) );

		$codes[ $code ] = time() + self::INVITE_TTL;

		// دعوت‌های قدیمی‌تر کنار می‌روند تا فهرست بی‌پایان نشود.
		if ( count( $codes ) > 20 ) {
			$codes = array_slice( $codes, -20, null, true );
		}

		update_option( self::INVITES, $codes, false );

		return array(
			'code'    => $code,
			'link'    => self::invite_link( $code ),
			'expires' => $codes[ $code ],
		);
	}

	/**
	 * دعوت‌های معتبر.
	 *
	 * @return array کد ⇐ زمان انقضا.
	 */
	protected static function invites() {
		$codes = get_option( self::INVITES, array() );
		$codes = is_array( $codes ) ? $codes : array();
		$now   = time();

		return array_filter(
			$codes,
			static function ( $expires ) use ( $now ) {
				return (int) $expires > $now;
			}
		);
	}

	/**
	 * لینک شروع ربات با کد دعوت.
	 *
	 * @param string $code کد.
	 * @return string خالی اگر نام کاربری ربات وارد نشده باشد.
	 */
	public static function invite_link( $code ) {
		$channel  = self::channel();
		$patterns = WCMA_Bot_Link::linkable();
		$username = ltrim( trim( (string) WCMA_Settings::get( $channel . '_bot_username' ) ), '@' );

		if ( '' === $username || ! isset( $patterns[ $channel ] ) ) {
			return '';
		}

		return sprintf( $patterns[ $channel ], rawurlencode( $username ), rawurlencode( self::START_PREFIX . $code ) );
	}

	/**
	 * مصرف یک کد دعوت.
	 *
	 * @param string $code کد.
	 * @return bool
	 */
	protected static function redeem( $code ) {
		$codes = self::invites();
		$code  = strtolower( trim( (string) $code ) );

		foreach ( array_keys( $codes ) as $known ) {
			if ( hash_equals( (string) $known, $code ) ) {
				unset( $codes[ $known ] );
				update_option( self::INVITES, $codes, false );

				return true;
			}
		}

		return false;
	}

	/* ------------------------------------------------------------------ */
	/* ورودی‌های ربات                                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * آیا ربات روی این پیام‌رسان آماده است؟
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return bool
	 */
	protected static function ready( $messenger ) {
		return self::channel() === $messenger && '' !== WCMA_Messengers::api_base( $messenger );
	}

	/**
	 * آیا این پیام از خودِ مدیر و در گفتگوی خصوصی با ربات است؟
	 *
	 * فرمانِ مدیریتی در گروه پذیرفته نمی‌شود؛ وگرنه هر عضو گروهی که مدیر در آن
	 * است می‌توانست دکمه‌ها را بزند.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    پیام.
	 * @return bool
	 */
	protected static function from_admin( $messenger, array $parsed ) {
		$chat_id = (string) ( $parsed['chat_id'] ?? '' );
		$type    = (string) ( $parsed['chat_type'] ?? '' );
		$from    = (string) ( $parsed['from_id'] ?? '' );

		if ( '' !== $type && 'private' !== $type ) {
			return false;
		}

		if ( '' !== $from && $from !== $chat_id ) {
			return false;
		}

		return self::ready( $messenger ) && self::is_admin( $messenger, $chat_id );
	}

	/**
	 * دستور /start: مصرف لینک دعوت.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    پیام.
	 */
	public static function on_start( $messenger, array $parsed ) {
		if ( ! self::ready( $messenger ) ) {
			return;
		}

		$chat_id = (string) ( $parsed['chat_id'] ?? '' );
		$text    = trim( (string) ( $parsed['text'] ?? '' ) );

		if ( preg_match( '/^\/start\s+' . preg_quote( self::START_PREFIX, '/' ) . '(\S+)/i', $text, $m ) ) {
			self::mine();

			$private = in_array( (string) ( $parsed['chat_type'] ?? '' ), array( '', 'private' ), true );

			if ( $private && self::redeem( $m[1] ) ) {
				// ردیف مشترک ساخته می‌شود تا نام و آمارش در پیشخوان دیده شود.
				$sub = WCMA_Bot_Manager::touch( $messenger, $parsed );
				$was = self::is_admin( $messenger, $chat_id );

				$telegram = trim( (string) ( $parsed['name'] ?? '' ) . ( ! empty( $parsed['username'] ) ? ' @' . $parsed['username'] : '' ) );

				self::add( $messenger, $chat_id, $sub ? self::sub_name( $sub ) : (string) ( $parsed['name'] ?? '' ), ! $was, $telegram );

				// مدیرِ از پیش خوش‌آمد نمی‌گیرد، فقط منو.
				if ( $was ) {
					self::menu( $chat_id, '🛠 پنل مدیریت ربات' );
				}
			} else {
				self::say( $chat_id, 'این لینک دعوت معتبر نیست، مصرف شده یا منقضی شده است. از مدیر سایت یک لینک تازه بخواهید.' );
			}

			return;
		}

		// /start تازه، گفتگوی نیمه‌کاره‌ی مدیر را می‌بندد.
		if ( self::from_admin( $messenger, $parsed ) ) {
			self::clear_flow( $chat_id );
		}
	}

	/**
	 * پیام‌های مدیر.
	 *
	 * فقط پیامی که به مدیریت مربوط است گرفته می‌شود؛ بقیه‌ی پیام‌های مدیر مثل
	 * هر مشترک دیگری به منو و چت‌بات می‌رسند.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    پیام.
	 */
	public static function on_message( $messenger, array $parsed ) {
		if ( ! self::from_admin( $messenger, $parsed ) ) {
			return;
		}

		$chat_id = (string) $parsed['chat_id'];
		$text    = trim( (string) ( $parsed['text'] ?? '' ) );
		$command = self::command_of( $text );
		$flow    = self::flow( $chat_id );

		if ( '' !== $command ) {
			self::mine();
			self::clear_flow( $chat_id );
			self::command( $command, $chat_id, $parsed );

			return;
		}

		if ( $flow ) {
			self::mine();
			self::step( $flow, $chat_id, $parsed );
		}
	}

	/**
	 * دستورِ متناظر با یک متن، یا خالی.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	protected static function command_of( $text ) {
		if ( '' === $text ) {
			return '';
		}

		if ( preg_match( '/^\/(admin|panel)\b/i', $text ) ) {
			return 'menu';
		}

		if ( preg_match( '/^\/cancel\b/i', $text ) ) {
			return 'cancel';
		}

		$loose = WCMA_Bot_Manager::loose( $text );

		if ( '' === $loose ) {
			return '';
		}

		if ( WCMA_Bot_Manager::loose( self::ENTRY ) === $loose ) {
			return 'menu';
		}

		foreach ( self::buttons() as $key => $label ) {
			if ( WCMA_Bot_Manager::loose( $label ) === $loose ) {
				return $key;
			}
		}

		return '';
	}

	/**
	 * اجرای یک دستور منوی مدیریت.
	 *
	 * @param string $command دستور.
	 * @param string $chat_id چت.
	 * @param array  $parsed  پیام.
	 */
	protected static function command( $command, $chat_id, array $parsed ) {
		switch ( $command ) {
			case 'stats':
				self::menu( $chat_id, self::stats_text() );
				break;

			case 'compose':
				self::set_flow( $chat_id, array( 'step' => 'compose' ) );
				self::say(
					$chat_id,
					"✍️ پیامی را که می‌خواهید برای مشترکان برود، همین‌جا بفرستید:\nمتن، عکس، ویدیو، صوت، ویس یا فایل (همراه توضیح).\n\nپیش از ارسال، پیش‌نمایش و تعداد گیرندگان را می‌بینید.",
					self::inline( array( array( array( '❌ انصراف', 'x' ) ) ) )
				);
				break;

			case 'prepared':
				self::list_prepared( $chat_id );
				break;

			case 'jobs':
				self::list_jobs( $chat_id );
				break;

			case 'search':
				self::set_flow( $chat_id, array( 'step' => 'search' ) );
				self::say(
					$chat_id,
					'🔎 شماره‌ی موبایل، نام، @نام‌کاربری یا شناسه‌ی چتِ مشترک را بنویسید:',
					self::inline( array( array( array( '❌ انصراف', 'x' ) ) ) )
				);
				break;

			case 'recent':
				self::list_recent( $chat_id );
				break;

			case 'import':
				self::set_flow( $chat_id, array( 'step' => 'import' ) );
				self::say(
					$chat_id,
					"📥 فایل اکسل (xlsx) یا CSV مخاطبان را همین‌جا بفرستید.\nستون‌ها: نام، نام خانوادگی، موبایل. هر کس با همین شماره‌ها ربات را باز کند و شماره‌اش را بدهد، به نام شناخته می‌شود.",
					self::inline( array( array( array( '❌ انصراف', 'x' ) ) ) )
				);
				break;

			case 'settings':
				self::show_settings( $chat_id );
				break;

			case 'exit':
				$sub = WCMA_Bot_Manager::guest_sub( self::channel(), $chat_id );

				WCMA_Messengers::send_content(
					self::channel(),
					$chat_id,
					array(
						'text'         => 'منوی عادی ربات. برای برگشت به مدیریت، «' . self::ENTRY . '» یا /admin را بزنید.',
						'reply_markup' => WCMA_Bot_Manager::keyboard( true, $sub ),
					)
				);
				break;

			case 'cancel':
				self::forget( $chat_id );
				self::menu( $chat_id, 'لغو شد.' );
				break;

			default:
				self::menu( $chat_id, '🛠 پنل مدیریت ربات' );
		}
	}

	/**
	 * گام بعدیِ گفتگوی چندمرحله‌ای.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param array  $parsed  پیام.
	 */
	protected static function step( array $flow, $chat_id, array $parsed ) {
		$step = (string) ( $flow['step'] ?? '' );

		if ( 'compose' === $step ) {
			$content = self::content_of( $parsed );

			if ( ! $content ) {
				self::say( $chat_id, 'این نوع پیام را نمی‌شود فرستاد. متن، عکس، ویدیو، صوت، ویس یا فایل بفرستید، یا /cancel.' );

				return;
			}

			self::clear_flow( $chat_id );
			self::offer( $chat_id, array( 'content' => $content ) );

			return;
		}

		if ( 'search' === $step ) {
			$query = trim( (string) ( $parsed['text'] ?? '' ) );

			if ( '' === $query ) {
				self::say( $chat_id, 'عبارت جستجو را به‌شکل متن بنویسید، یا /cancel.' );

				return;
			}

			self::clear_flow( $chat_id );
			self::search( $chat_id, $query );

			return;
		}

		if ( 'dm' === $step ) {
			$content = self::content_of( $parsed );
			$sub     = self::sub( (int) ( $flow['sub'] ?? 0 ) );

			self::clear_flow( $chat_id );

			if ( ! $sub || ! $content ) {
				self::menu( $chat_id, 'پیام فرستاده نشد؛ مشترک پیدا نشد یا پیام خالی بود.' );

				return;
			}

			$message = WCMA_Bot_Broadcast::content_message( $content );
			$result  = $message ? WCMA_Bot_Manager::send_message( $message, $sub['channel'], $sub['chat_id'], $sub ) : array( 'success' => false, 'message' => 'پیام خالی است.' );

			self::menu(
				$chat_id,
				! empty( $result['success'] )
					? '✅ پیام برای ' . self::plain( self::sub_name( $sub ) ) . ' فرستاده شد.'
					: '❌ پیام نرسید: ' . self::plain( (string) ( $result['message'] ?? '' ) )
			);

			return;
		}

		if ( 'import' === $step ) {
			$media = $parsed['media'] ?? array();

			if ( empty( $media['file_id'] ) || 'document' !== ( $media['type'] ?? '' ) ) {
				self::say( $chat_id, 'لطفاً فایل اکسل (xlsx) یا CSV را به‌شکل «فایل» بفرستید، یا /cancel.' );

				return;
			}

			self::clear_flow( $chat_id );
			self::import_document( $chat_id, $media );
		}
	}

	/**
	 * محتوای قابل ارسال از پیامِ مدیر.
	 *
	 * @param array $parsed پیام.
	 * @return array|null
	 */
	protected static function content_of( array $parsed ) {
		$media = $parsed['media'] ?? array();

		if ( ! empty( $media['file_id'] ) && isset( WCMA_Messengers::content_types()[ $media['type'] ?? '' ] ) ) {
			return array(
				'type'  => $media['type'],
				'file'  => (string) $media['file_id'],
				'text'  => (string) ( $parsed['caption'] ?? '' ),
				'plain' => true,
			);
		}

		$text = trim( (string) ( $parsed['text'] ?? '' ) );

		// متنی که مدیر در تلگرام تایپ کرده HTML نیست؛ «<500 هزار» نباید بریده شود.
		return '' === $text ? null : array( 'type' => 'text', 'text' => $text, 'file' => '', 'plain' => true );
	}

	/**
	 * دکمه‌های شیشه‌ای مدیریت.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    پیام (callback و callback_id).
	 */
	public static function on_callback( $messenger, array $parsed ) {
		$data = (string) ( $parsed['callback'] ?? '' );

		if ( 0 !== strpos( $data, self::CB ) ) {
			return;
		}

		$callback_id = (string) ( $parsed['callback_id'] ?? '' );

		if ( ! self::from_admin( $messenger, $parsed ) ) {
			WCMA_Bot_Manager::answer_callback( $messenger, $callback_id, 'این دکمه فقط برای مدیران ربات است.' );

			return;
		}

		WCMA_Bot_Manager::answer_callback( $messenger, $callback_id );

		$chat_id = (string) $parsed['chat_id'];
		$parts   = explode( ':', substr( $data, strlen( self::CB ) ) );
		$action  = (string) ( $parts[0] ?? '' );

		switch ( $action ) {
			case 'x':
				self::forget( $chat_id );
				self::menu( $chat_id, 'لغو شد.' );
				break;

			case 'pm':
				$message = WCMA_Bot_Manager::get_message( $parts[1] ?? '' );

				if ( ! $message ) {
					self::say( $chat_id, 'این پیام آماده دیگر وجود ندارد.' );
					break;
				}

				self::offer( $chat_id, array( 'message' => $message['id'] ) );
				break;

			case 'aud':
				self::confirm( $chat_id, (string) ( $parts[1] ?? '' ), (string) ( $parts[2] ?? '' ) );
				break;

			case 'go':
				self::go( $chat_id, (string) ( $parts[1] ?? '' ), (string) ( $parts[2] ?? '' ) );
				break;

			case 'stop':
				$id = (int) ( $parts[1] ?? 0 );

				self::say(
					$chat_id,
					WCMA_Bot_Broadcast::cancel( $id )
						? '⛔️ ارسال لغو شد. پیام‌هایی که رفته‌اند برنمی‌گردند.'
						: 'این ارسال دیگر در جریان نیست.'
				);
				break;

			case 'u':
				self::show_sub( $chat_id, (int) ( $parts[1] ?? 0 ) );
				break;

			case 'dm':
				$sub = self::sub( (int) ( $parts[1] ?? 0 ) );

				if ( ! $sub ) {
					self::say( $chat_id, 'این مشترک پیدا نشد.' );
					break;
				}

				self::set_flow( $chat_id, array( 'step' => 'dm', 'sub' => (int) $sub['id'] ) );
				self::say(
					$chat_id,
					'✉️ پیام خود برای ' . self::plain( self::sub_name( $sub ) ) . " را بفرستید (متن، عکس، ویدیو، صوت، ویس یا فایل):",
					self::inline( array( array( array( '❌ انصراف', 'x' ) ) ) )
				);
				break;

			case 'seq':
				self::toggle_sub( $chat_id, (int) ( $parts[1] ?? 0 ), 'go' === ( $parts[2] ?? '' ) );
				break;

			case 't':
				self::toggle_setting( $chat_id, (string) ( $parts[1] ?? '' ), 'on' === ( $parts[2] ?? '' ) );
				break;
		}
	}

	/* ------------------------------------------------------------------ */
	/* ارسال همگانی                                                         */
	/* ------------------------------------------------------------------ */

	/**
	 * فهرست پیام‌های آماده برای انتخاب.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function list_prepared( $chat_id ) {
		$messages = WCMA_Bot_Manager::messages();

		if ( ! $messages ) {
			self::menu( $chat_id, 'هنوز پیام آماده‌ای ساخته نشده است. از پیشخوان سایت (برگه‌ی ربات تلگرام) بسازید، یا «' . self::buttons()['compose'] . '» را بزنید.' );

			return;
		}

		$rows = array();

		foreach ( $messages as $message ) {
			$rows[] = array( array( '📨 ' . mb_substr( WCMA_Bot_Manager::message_title( $message ), 0, 40 ), 'pm:' . $message['id'] ) );
		}

		$rows[] = array( array( '❌ انصراف', 'x' ) );

		self::say( $chat_id, 'کدام پیام آماده فرستاده شود؟', self::inline( $rows ) );
	}

	/**
	 * پیش‌نمایش پیام و پرسیدن گروه مخاطب.
	 *
	 * @param string $chat_id چت.
	 * @param array  $draft   content یا message.
	 */
	protected static function offer( $chat_id, array $draft ) {
		$message = self::draft_message( $draft );

		if ( ! $message ) {
			self::menu( $chat_id, 'پیام قابل ارسال نبود.' );

			return;
		}

		$draft['id'] = strtolower( wp_generate_password( 8, false, false ) );

		set_transient( self::DRAFT . md5( self::key( self::channel(), $chat_id ) ), $draft, self::FLOW_TTL );

		// پیش‌نمایش، دقیقاً همان چیزی که مشترکان می‌بینند.
		$preview = WCMA_Bot_Manager::send_message( $message, self::channel(), $chat_id, WCMA_Bot_Manager::guest_sub( self::channel(), $chat_id ) );

		if ( empty( $preview['success'] ) ) {
			self::menu( $chat_id, '❌ پیش‌نمایش فرستاده نشد: ' . self::plain( (string) ( $preview['message'] ?? '' ) ) );

			return;
		}

		$rows = array();

		foreach ( self::audience_labels() as $audience => $label ) {
			$count = WCMA_Bot_Broadcast::count( $audience, self::channel() );

			if ( $count ) {
				$rows[] = array( array( sprintf( '%s (%s نفر)', $label, WCMA_Date::number( $count ) ), 'aud:' . $draft['id'] . ':' . $audience ) );
			}
		}

		if ( ! $rows ) {
			self::menu( $chat_id, 'هنوز مشترکی در ربات نیست که پیام برایش برود.' );

			return;
		}

		$rows[] = array( array( '❌ انصراف', 'x' ) );

		self::say( $chat_id, '👆 این پیش‌نمایش است. برای چه کسانی فرستاده شود؟', self::inline( $rows ) );
	}

	/**
	 * پیامِ قابل ارسالِ یک پیش‌نویس.
	 *
	 * @param array $draft پیش‌نویس.
	 * @return array|null
	 */
	protected static function draft_message( array $draft ) {
		if ( ! empty( $draft['content'] ) && is_array( $draft['content'] ) ) {
			return WCMA_Bot_Broadcast::content_message( $draft['content'] );
		}

		return WCMA_Bot_Manager::get_message( $draft['message'] ?? '' );
	}

	/**
	 * پیش‌نویسِ معتبرِ یک مدیر.
	 *
	 * @param string $chat_id  چت.
	 * @param string $draft_id شناسه‌ی پیش‌نویس.
	 * @return array|null
	 */
	protected static function draft( $chat_id, $draft_id ) {
		$draft = get_transient( self::DRAFT . md5( self::key( self::channel(), $chat_id ) ) );

		if ( ! is_array( $draft ) || '' === $draft_id || ! hash_equals( (string) ( $draft['id'] ?? '' ), $draft_id ) ) {
			return null;
		}

		return $draft;
	}

	/**
	 * پرسیدن تأیید پیش از ارسال.
	 *
	 * @param string $chat_id  چت.
	 * @param string $draft_id پیش‌نویس.
	 * @param string $audience گروه.
	 */
	protected static function confirm( $chat_id, $draft_id, $audience ) {
		$labels = self::audience_labels();

		if ( ! self::draft( $chat_id, $draft_id ) || ! isset( $labels[ $audience ] ) ) {
			self::menu( $chat_id, 'این پیش‌نویس دیگر معتبر نیست. دوباره از منو شروع کنید.' );

			return;
		}

		$count = WCMA_Bot_Broadcast::count( $audience, self::channel() );

		self::say(
			$chat_id,
			sprintf( 'پیام برای «%s» — %s نفر — فرستاده شود؟', $labels[ $audience ], WCMA_Date::number( $count ) ),
			self::inline(
				array(
					array( array( '✅ بله، بفرست', 'go:' . $draft_id . ':' . $audience ) ),
					array( array( '❌ لغو', 'x' ) ),
				)
			)
		);
	}

	/**
	 * آغاز ارسال پس از تأیید.
	 *
	 * @param string $chat_id  چت.
	 * @param string $draft_id پیش‌نویس.
	 * @param string $audience گروه.
	 */
	protected static function go( $chat_id, $draft_id, $audience ) {
		$draft = self::draft( $chat_id, $draft_id );

		/*
		 * زدنِ دوباره‌ی «بفرست» (یا دو به‌روزرسانی همزمان از تلگرام) نباید دو
		 * ارسال بسازد؛ فقط نخستین درخواست این پیش‌نویس را برمی‌دارد.
		 */
		if ( ! $draft || ! self::once( 'go_' . $draft_id ) ) {
			self::say( $chat_id, 'این پیام پیش‌تر فرستاده شده یا پیش‌نویسش منقضی شده است.' );

			return;
		}

		delete_transient( self::DRAFT . md5( self::key( self::channel(), $chat_id ) ) );

		$args = array(
			'audience' => $audience,
			'notify'   => $chat_id,
		);

		if ( ! empty( $draft['content'] ) ) {
			$args['content'] = $draft['content'];
		} else {
			$args['message'] = $draft['message'] ?? '';
		}

		$result = WCMA_Bot_Broadcast::start( $args );

		if ( empty( $result['success'] ) ) {
			self::menu( $chat_id, '❌ ' . self::plain( (string) $result['message'] ) );

			return;
		}

		// اگر کلید اصلی خاموش باشد، خودِ پیام start() این را می‌گوید.
		self::menu( $chat_id, '🚀 ' . $result['message'] . "\nپایانش را همین‌جا خبر می‌دهم." );
		self::say( $chat_id, 'اگر پشیمان شدید:', self::inline( array( array( array( '⛔️ لغو این ارسال', 'stop:' . (int) $result['id'] ) ) ) ) );

		// پاسخ تلگرام بسته شده، پس می‌شود همین‌جا بخشی از ارسال را پیش برد.
		if ( WCMA_Bot_Link::is_detached() ) {
			WCMA_Bot_Broadcast::drain( 40 );
		}
	}

	/**
	 * ارسال‌های اخیر، با دکمه‌ی لغو برای آن‌هایی که در جریان‌اند.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function list_jobs( $chat_id ) {
		$jobs = WCMA_Bot_Broadcast::recent( 5 );

		if ( ! $jobs ) {
			self::menu( $chat_id, 'هنوز ارسال گروهی‌ای انجام نشده است.' );

			return;
		}

		$lines = array( '📋 ارسال‌های اخیر:' );
		$rows  = array();

		foreach ( $jobs as $job ) {
			$view    = WCMA_Bot_Broadcast::view( $job );
			$lines[] = sprintf(
				"\n• «%s»\n  %s — %s — رسید: %s، نرسید: %s\n  %s",
				self::plain( $view['title'] ),
				$view['label'],
				$view['progress'],
				$view['sent'],
				$view['failed'],
				$view['start']
			);

			if ( $view['active'] ) {
				$rows[] = array( array( '⛔️ لغو «' . mb_substr( $view['title'], 0, 25 ) . '»', 'stop:' . $view['id'] ) );
			}
		}

		self::say( $chat_id, implode( "\n", $lines ), $rows ? self::inline( $rows ) : self::menu_markup() );
	}

	/* ------------------------------------------------------------------ */
	/* مشترکان                                                              */
	/* ------------------------------------------------------------------ */

	/**
	 * یک مشترک.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	protected static function sub( $id ) {
		global $wpdb;

		if ( ! $id || ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return null;
		}

		$table = WCMA_Bot_Manager::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $row ? $row : null;
	}

	/**
	 * نام نمایشی یک مشترک: نام پرونده‌ی مشتری، وگرنه نام تلگرامی.
	 *
	 * @param array $sub مشترک.
	 * @return string
	 */
	public static function sub_name( array $sub ) {
		$names = WCMA_Bot_Manager::contact_names( $sub );
		$name  = $names ? trim( $names['first'] . ' ' . $names['last'] ) : '';

		if ( '' === $name ) {
			$name = trim( (string) ( $sub['name'] ?? '' ) );
		}

		if ( '' === $name && ! empty( $sub['username'] ) ) {
			$name = '@' . $sub['username'];
		}

		return '' !== $name ? $name : 'بی‌نام (' . ( $sub['chat_id'] ?? '' ) . ')';
	}

	/**
	 * وضعیت خوانای یک مشترک.
	 *
	 * @param string $status وضعیت.
	 * @return string
	 */
	protected static function status_label( $status ) {
		$labels = array(
			'active'  => '▶️ در حال دریافت دنباله',
			'done'    => '✅ دنباله تمام شده',
			'stopped' => '⏸ دریافت روزانه را لغو کرده',
			'blocked' => '🚫 ربات را بسته',
		);

		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * مشترکان تازه.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function list_recent( $chat_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			self::menu( $chat_id, 'جدول مشترکان ساخته نشده است.' );

			return;
		}

		$table = WCMA_Bot_Manager::table();
		$subs  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s ORDER BY id DESC LIMIT 10", self::channel() ), ARRAY_A ); // phpcs:ignore WordPress.DB

		if ( ! $subs ) {
			self::menu( $chat_id, 'هنوز کسی ربات را شروع نکرده است.' );

			return;
		}

		self::say( $chat_id, "👥 ده مشترک تازه (برای جزئیات روی هر نام بزنید):\n\n" . self::sub_lines( $subs ), self::sub_buttons( $subs ) );
	}

	/**
	 * خطوط فهرست مشترکان.
	 *
	 * @param array $subs مشترکان.
	 * @return string
	 */
	protected static function sub_lines( array $subs ) {
		$lines = array();

		foreach ( $subs as $sub ) {
			$lines[] = sprintf(
				'• %s%s — %s',
				self::plain( self::sub_name( $sub ) ),
				$sub['phone'] ? ' — ' . WCMA_Date::digits( $sub['phone'] ) : '',
				WCMA_Date::mysql( $sub['started_at'], 'date', '' )
			);
		}

		return implode( "\n", $lines );
	}

	/**
	 * دکمه‌های شیشه‌ای فهرست مشترکان.
	 *
	 * @param array $subs مشترکان.
	 * @return array
	 */
	protected static function sub_buttons( array $subs ) {
		$rows = array();
		$pair = array();

		foreach ( $subs as $sub ) {
			$pair[] = array( '👤 ' . mb_substr( self::sub_name( $sub ), 0, 24 ), 'u:' . (int) $sub['id'] );

			if ( 2 === count( $pair ) ) {
				$rows[] = $pair;
				$pair   = array();
			}
		}

		if ( $pair ) {
			$rows[] = $pair;
		}

		return self::inline( $rows );
	}

	/**
	 * جستجوی مشترک و مخاطب.
	 *
	 * @param string $chat_id چت.
	 * @param string $query   عبارت.
	 */
	protected static function search( $chat_id, $query ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			self::menu( $chat_id, 'جدول مشترکان ساخته نشده است.' );

			return;
		}

		$subs_table = WCMA_Bot_Manager::table();
		$crm        = WCMA_Install::table_exists( 'wcma_contacts' );
		$contacts   = WCMA_CRM::table();
		$channel    = self::channel();
		$latin      = trim( WCMA_Date::to_latin_digits( $query ) );
		$phone      = 0 === strpos( $latin, '@' ) ? '' : WCMA_SMS_Gateways::normalize_phone( $latin );
		$subs       = array();
		$people     = array();

		if ( $phone ) {
			$subs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$subs_table} WHERE channel = %s AND phone = %s LIMIT 8", $channel, $phone ), ARRAY_A ); // phpcs:ignore WordPress.DB

			if ( $crm ) {
				$people = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$contacts} WHERE phone = %s LIMIT 8", $phone ), ARRAY_A ); // phpcs:ignore WordPress.DB
			}
		}

		if ( ! $subs && ! $people && preg_match( '/^-?\d{4,20}$/', $latin ) ) {
			$subs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$subs_table} WHERE channel = %s AND chat_id = %s LIMIT 8", $channel, $latin ), ARRAY_A ); // phpcs:ignore WordPress.DB
		} elseif ( ! $phone && ! preg_match( '/^-?\d{4,20}$/', $latin ) ) {
			$like = '%' . $wpdb->esc_like( ltrim( $query, '@' ) ) . '%';

			if ( $crm ) {
				$subs = $wpdb->get_results( // phpcs:ignore WordPress.DB
					$wpdb->prepare(
						"SELECT s.* FROM {$subs_table} s LEFT JOIN {$contacts} c ON c.id = s.contact_id
						WHERE s.channel = %s AND ( s.name LIKE %s OR s.username LIKE %s OR CONCAT(c.first_name, ' ', c.last_name) LIKE %s )
						ORDER BY s.id DESC LIMIT 8", // phpcs:ignore WordPress.DB
						$channel,
						$like,
						$like,
						$like
					),
					ARRAY_A
				);

				$people = $wpdb->get_results( // phpcs:ignore WordPress.DB
					$wpdb->prepare( "SELECT * FROM {$contacts} WHERE CONCAT(first_name, ' ', last_name) LIKE %s ORDER BY id DESC LIMIT 8", $like ), // phpcs:ignore WordPress.DB
					ARRAY_A
				);
			} else {
				$subs = $wpdb->get_results( // phpcs:ignore WordPress.DB
					$wpdb->prepare( "SELECT * FROM {$subs_table} WHERE channel = %s AND ( name LIKE %s OR username LIKE %s ) ORDER BY id DESC LIMIT 8", $channel, $like, $like ), // phpcs:ignore WordPress.DB
					ARRAY_A
				);
			}
		}

		// مخاطبانی که در ربات‌اند، یک‌بار و در بخش مشترکان می‌آیند.
		$linked = array();

		foreach ( (array) $subs as $sub ) {
			$linked[ (int) $sub['contact_id'] ] = true;
			$linked[ 'p' . $sub['phone'] ]      = true;
		}

		$outside = array();

		foreach ( (array) $people as $person ) {
			if ( ! isset( $linked[ (int) $person['id'] ] ) && ! isset( $linked[ 'p' . $person['phone'] ] ) && ! self::phone_in_bot( $person['phone'] ) ) {
				$outside[] = $person;
			}
		}

		if ( ! $subs && ! $outside ) {
			self::menu( $chat_id, 'برای «' . self::plain( $query ) . '» چیزی پیدا نشد.' );

			return;
		}

		$text = '🔎 نتیجه برای «' . self::plain( $query ) . '»:';

		if ( $subs ) {
			$text .= "\n\nدر ربات:\n" . self::sub_lines( $subs );
		}

		if ( $outside ) {
			$lines = array();

			foreach ( $outside as $person ) {
				$lines[] = '• ' . self::plain( WCMA_CRM::display_name( $person ) ) . ( $person['phone'] ? ' — ' . WCMA_Date::digits( $person['phone'] ) : '' );
			}

			$text .= "\n\nدر پرونده‌ی مشتریان هست ولی هنوز ربات را باز نکرده (یا شماره نداده):\n" . implode( "\n", $lines );
		}

		self::say( $chat_id, $text, $subs ? self::sub_buttons( $subs ) : self::menu_markup() );
	}

	/**
	 * آیا مشترکی با این شماره در ربات هست؟
	 *
	 * @param string $phone شماره.
	 * @return bool
	 */
	protected static function phone_in_bot( $phone ) {
		global $wpdb;

		if ( '' === (string) $phone ) {
			return false;
		}

		$table = WCMA_Bot_Manager::table();

		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE channel = %s AND phone = %s LIMIT 1", self::channel(), $phone ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * جزئیات یک مشترک.
	 *
	 * @param string $chat_id چت.
	 * @param int    $id      مشترک.
	 */
	protected static function show_sub( $chat_id, $id ) {
		$sub = self::sub( $id );

		if ( ! $sub ) {
			self::say( $chat_id, 'این مشترک پیدا نشد.' );

			return;
		}

		$names = WCMA_Bot_Manager::contact_names( $sub );
		$lines = array( '👤 ' . self::plain( self::sub_name( $sub ) ) );

		if ( $names && '' !== trim( (string) $sub['name'] ) ) {
			$lines[] = 'نام در تلگرام: ' . self::plain( $sub['name'] );
		}

		$lines[] = '📱 ' . ( $sub['phone'] ? WCMA_Date::digits( $sub['phone'] ) : 'شماره نداده' );
		$lines[] = '🆔 ' . $sub['chat_id'] . ( $sub['username'] ? ' — @' . self::plain( $sub['username'] ) : '' );
		$lines[] = self::status_label( $sub['status'] ) . ( (int) $sub['day_sent'] ? ' — تا روز ' . WCMA_Date::number( (int) $sub['day_sent'] ) : '' );
		$lines[] = '🗓 عضویت: ' . WCMA_Date::mysql( $sub['started_at'], 'date', '—' );
		$lines[] = $names ? '🪪 در پرونده‌ی مشتریان شناخته شده است.' : '🪪 هنوز به پرونده‌ی مشتری‌ای وصل نیست.';

		if ( self::is_admin( $sub['channel'], $sub['chat_id'] ) ) {
			$lines[] = '🛠 مدیر ربات';
		}

		$rows = array( array( array( '✉️ پیام بده', 'dm:' . (int) $sub['id'] ) ) );

		// وضعیتِ مقصد در خود دکمه است تا زدنِ دوباره، کار را برنگرداند.
		if ( 'stopped' === $sub['status'] ) {
			$rows[] = array( array( '▶️ ادامه‌ی دنباله‌ی روزانه', 'seq:' . (int) $sub['id'] . ':go' ) );
		} elseif ( in_array( $sub['status'], array( 'active', 'done' ), true ) ) {
			$rows[] = array( array( '⏸ توقف دنباله‌ی روزانه', 'seq:' . (int) $sub['id'] . ':stop' ) );
		}

		self::say( $chat_id, implode( "\n", $lines ), self::inline( $rows ) );
	}

	/**
	 * توقف یا ادامه‌ی دنباله‌ی روزانه‌ی یک مشترک.
	 *
	 * @param string $chat_id چت مدیر.
	 * @param int    $id      مشترک.
	 * @param bool   $resume  ادامه (true) یا توقف (false).
	 */
	protected static function toggle_sub( $chat_id, $id, $resume ) {
		global $wpdb;

		$sub = self::sub( $id );

		if ( ! $sub || 'blocked' === $sub['status'] ) {
			self::say( $chat_id, 'این مشترک پیدا نشد یا ربات را بسته است.' );

			return;
		}

		$want = $resume ? 'active' : 'stopped';

		// فقط اگر واقعاً عوض می‌شود؛ ادامه‌ی کسی که دنباله را تمام کرده، او را «تمام‌شده» نگه می‌دارد.
		if ( $resume && 'stopped' === $sub['status'] ) {
			$wpdb->update( WCMA_Bot_Manager::table(), array( 'status' => $want ), array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB
		} elseif ( ! $resume && in_array( $sub['status'], array( 'active', 'done' ), true ) ) {
			$wpdb->update( WCMA_Bot_Manager::table(), array( 'status' => $want ), array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB
		}

		self::show_sub( $chat_id, (int) $sub['id'] );
	}

	/* ------------------------------------------------------------------ */
	/* ورود مخاطبان با فایل                                                */
	/* ------------------------------------------------------------------ */

	/**
	 * گرفتن فایلی که مدیر فرستاده و وارد کردن مخاطبانش.
	 *
	 * @param string $chat_id چت.
	 * @param array  $media   فایل.
	 */
	protected static function import_document( $chat_id, array $media ) {
		$name = (string) ( $media['name'] ?? '' );
		$ext  = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );

		if ( ! in_array( $ext, array( 'xlsx', 'csv', 'txt', 'xls' ), true ) ) {
			self::menu( $chat_id, 'فقط فایل اکسل (xlsx) یا CSV پذیرفته می‌شود.' );

			return;
		}

		if ( (int) ( $media['size'] ?? 0 ) > WCMA_Contacts_Import::MAX_BYTES ) {
			self::menu( $chat_id, 'حجم فایل بیش از حد است؛ آن را به چند بخش تقسیم کنید.' );

			return;
		}

		self::say( $chat_id, '⏳ در حال خواندن فایل…' );

		$path = self::download( (string) $media['file_id'] );

		if ( is_wp_error( $path ) ) {
			self::menu( $chat_id, '❌ فایل دریافت نشد: ' . self::plain( $path->get_error_message() ) );

			return;
		}

		$report = WCMA_Contacts_Import::import_file( $path, $name, array( 'tag' => 'ورود از ربات' ) );

		wp_delete_file( $path );

		if ( empty( $report['success'] ) ) {
			self::menu( $chat_id, '❌ ' . self::plain( (string) $report['message'] ) );

			return;
		}

		$text = '✅ ' . $report['message'];

		if ( ! empty( $report['samples'] ) ) {
			$text .= "\n\nنمونه‌ی ردیف‌های نامعتبر:";

			foreach ( array_slice( $report['samples'], 0, 5 ) as $sample ) {
				$text .= sprintf( "\n• ردیف %s: «%s»", WCMA_Date::number( $sample['row'] ), '' !== $sample['phone'] ? self::plain( $sample['phone'] ) : 'خالی' );
			}
		}

		self::menu( $chat_id, $text );
	}

	/**
	 * دریافت یک فایل از سرور پیام‌رسان.
	 *
	 * @param string $file_id شناسه‌ی فایل.
	 * @return string|WP_Error مسیر فایل موقت.
	 */
	protected static function download( $file_id ) {
		$base = WCMA_Messengers::api_base( self::channel() );

		if ( '' === $base ) {
			return new WP_Error( 'wcma_no_token', 'توکن ربات وارد نشده است.' );
		}

		$response = wp_remote_post( $base . 'getFile', array( 'timeout' => 15, 'body' => array( 'file_id' => $file_id ) ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$path = (string) ( $body['result']['file_path'] ?? '' );

		if ( empty( $body['ok'] ) || '' === $path ) {
			return new WP_Error( 'wcma_no_file', (string) ( $body['description'] ?? 'نشانی فایل گرفته نشد.' ) );
		}

		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$tmp = wp_tempnam( 'wcma-import' );
		$url = preg_replace( '#/bot([^/]+)/$#', '/file/bot$1/', $base ) . ltrim( $path, '/' );

		$response = wp_remote_get(
			$url,
			array(
				'timeout'             => 30,
				'stream'              => true,
				'filename'            => $tmp,
				'limit_response_size' => WCMA_Contacts_Import::MAX_BYTES + 1,
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			wp_delete_file( $tmp );

			return is_wp_error( $response ) ? $response : new WP_Error( 'wcma_download', 'دریافت فایل ناموفق بود.' );
		}

		// بعضی لایه‌های HTTP محتوا را به‌جای فایل، در بدنه‌ی پاسخ برمی‌گردانند.
		if ( ! filesize( $tmp ) && '' !== wp_remote_retrieve_body( $response ) ) {
			file_put_contents( $tmp, wp_remote_retrieve_body( $response ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		return $tmp;
	}

	/* ------------------------------------------------------------------ */
	/* آمار و تنظیمات                                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * متن آمار ربات.
	 *
	 * @return string
	 */
	public static function stats_text() {
		global $wpdb;

		$stats = WCMA_Bot_Manager::stats();
		$lines = array(
			'📊 آمار ربات',
			'',
			'👥 کل مشترکان: ' . WCMA_Date::number( $stats['total'] ),
			'▶️ در حال دریافت دنباله: ' . WCMA_Date::number( $stats['active'] ),
			'✅ دنباله تمام‌شده: ' . WCMA_Date::number( $stats['done'] ),
			'⏸ دریافت روزانه را لغو کرده: ' . WCMA_Date::number( $stats['stopped'] ),
			'🚫 ربات را بسته: ' . WCMA_Date::number( $stats['blocked'] ),
			'📱 شماره داده: ' . WCMA_Date::number( $stats['with_phone'] ),
		);

		if ( WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			$table = WCMA_Bot_Manager::table();
			$today = substr( current_time( 'mysql' ), 0, 10 ) . ' 00:00:00';
			$week  = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - 7 * DAY_IN_SECONDS );

			$lines[] = '🪪 شناخته‌شده در پرونده‌ی مشتریان: ' . WCMA_Date::number( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE contact_id > 0" ) ); // phpcs:ignore WordPress.DB
			$lines[] = '🆕 عضو امروز: ' . WCMA_Date::number( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE started_at >= %s", $today ) ) ) // phpcs:ignore WordPress.DB
				. ' — هفت روز اخیر: ' . WCMA_Date::number( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE started_at >= %s", $week ) ) ); // phpcs:ignore WordPress.DB
		}

		if ( WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			$contacts = WCMA_CRM::table();
			$lines[]  = '📇 مخاطبان دارای موبایل در پنل: ' . WCMA_Date::number( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$contacts} WHERE phone <> ''" ) ); // phpcs:ignore WordPress.DB
		}

		$last = WCMA_Bot_Broadcast::recent( 1 );

		if ( $last ) {
			$view    = WCMA_Bot_Broadcast::view( $last[0] );
			$lines[] = '';
			$lines[] = '📣 آخرین ارسال: «' . self::plain( $view['title'] ) . '» — ' . $view['label'] . ' — رسید: ' . $view['sent'] . ' از ' . $view['total'];
		}

		return implode( "\n", $lines );
	}

	/**
	 * نمایش تنظیمات قابل تغییر از ربات.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function show_settings( $chat_id ) {
		$seq    = WCMA_Settings::is( 'tg_seq_enabled' );
		$notify = WCMA_Settings::is( 'tg_admin_notify' );

		self::say(
			$chat_id,
			"⚙️ تنظیمات\n\n" .
			'دنباله‌ی روزانه: ' . ( $seq ? 'روشن ✅' : 'خاموش ⏸' ) . "\n" .
			'خبر عضو تازه و شماره‌ی تازه برای مدیران: ' . ( $notify ? 'روشن ✅' : 'خاموش ⏸' ),
			self::inline(
				array(
					array( array( $seq ? '⏸ خاموش کردن دنباله‌ی روزانه' : '▶️ روشن کردن دنباله‌ی روزانه', 't:seq:' . ( $seq ? 'off' : 'on' ) ) ),
					array( array( $notify ? '🔕 خاموش کردن خبرها' : '🔔 روشن کردن خبرها', 't:notify:' . ( $notify ? 'off' : 'on' ) ) ),
				)
			)
		);
	}

	/**
	 * تغییر یک تنظیم از ربات.
	 *
	 * @param string $chat_id چت.
	 * @param string $which   seq یا notify.
	 * @param bool   $on      وضعیت خواسته‌شده.
	 */
	protected static function toggle_setting( $chat_id, $which, $on ) {
		$keys = array(
			'seq'    => 'tg_seq_enabled',
			'notify' => 'tg_admin_notify',
		);

		// مقدار خواسته‌شده نوشته می‌شود، نه وارونه‌ی مقدار فعلی؛ زدن دوباره چیزی را برنمی‌گرداند.
		if ( isset( $keys[ $which ] ) ) {
			WCMA_Settings::update( array( $keys[ $which ] => $on ? 'yes' : 'no' ) );
		}

		self::show_settings( $chat_id );
	}

	/* ------------------------------------------------------------------ */
	/* خبر برای مدیران                                                      */
	/* ------------------------------------------------------------------ */

	/**
	 * فرستادن یک خبر برای همه‌ی مدیران.
	 *
	 * @param string $text   متن.
	 * @param string $except چتی که خبر برایش نمی‌رود (خودِ کسی که خبر درباره‌ی اوست).
	 */
	protected static function notify_all( $text, $except = '' ) {
		if ( ! WCMA_Settings::is( 'tg_admin_notify' ) || '' === WCMA_Messengers::api_base( self::channel() ) ) {
			return;
		}

		foreach ( self::current_admins() as $admin ) {
			if ( (string) $admin['chat_id'] !== (string) $except ) {
				self::say( $admin['chat_id'], $text );
			}
		}
	}

	/**
	 * خبر عضو تازه.
	 *
	 * @param array $sub مشترک.
	 */
	public static function notify_subscribed( $sub ) {
		if ( ! is_array( $sub ) || ( $sub['channel'] ?? '' ) !== self::channel() ) {
			return;
		}

		if ( ! WCMA_Settings::is( 'tg_admin_notify' ) || ! self::current_admins() ) {
			return;
		}

		$stats = WCMA_Bot_Manager::stats();

		self::notify_all(
			'🆕 عضو تازه در ربات: ' . self::plain( self::sub_name( $sub ) ) . ( ! empty( $sub['username'] ) ? ' (@' . self::plain( $sub['username'] ) . ')' : '' )
				. "\n👥 مجموع مشترکان: " . WCMA_Date::number( $stats['total'] ),
			(string) $sub['chat_id']
		);
	}

	/**
	 * خبر شماره‌ی تازه.
	 *
	 * @param array $sub   مشترک.
	 * @param bool  $known آیا در پرونده‌ی مشتریان شناخته شد؟
	 */
	public static function notify_phone( $sub, $known = false ) {
		if ( ! is_array( $sub ) || ( $sub['channel'] ?? '' ) !== self::channel() ) {
			return;
		}

		$text = '📱 ' . self::plain( (string) $sub['name'] ) . ' شماره‌اش را داد: ' . WCMA_Date::digits( (string) $sub['phone'] );

		if ( $known ) {
			$text .= "\n✅ شناخته شد: «" . self::plain( self::sub_name( $sub ) ) . '» از پرونده‌ی مشتریان.';
		}

		self::notify_all( $text, (string) $sub['chat_id'] );
	}

	/**
	 * خبر پایان ارسال برای مدیری که آن را آغاز کرد.
	 *
	 * @param array $row ارسال.
	 */
	public static function notify_broadcast( $row ) {
		$chat = (string) ( $row['notify_chat'] ?? '' );

		if ( '' === $chat || ! self::is_admin( (string) $row['channel'], $chat ) ) {
			return;
		}

		self::say(
			$chat,
			sprintf(
				"%s ارسال «%s» %s.\nرسید: %s — نرسید: %s — از %s",
				'done' === $row['status'] ? '✅' : '⚠️',
				self::plain( (string) $row['title'] ),
				'done' === $row['status'] ? 'تمام شد' : 'متوقف شد',
				WCMA_Date::number( (int) $row['sent'] ),
				WCMA_Date::number( (int) $row['failed'] + (int) $row['blocked'] ),
				WCMA_Date::number( (int) $row['total'] )
			)
		);
	}

	/**
	 * دکمه‌ی «پنل مدیریت» در منوی عادیِ مدیران.
	 *
	 * @param array      $rows ردیف‌ها.
	 * @param array|null $sub  مشترک.
	 * @return array
	 */
	public static function keyboard_rows( $rows, $sub ) {
		if ( is_array( $sub ) && ! empty( $sub['chat_id'] ) && self::is_admin( (string) ( $sub['channel'] ?? self::channel() ), (string) $sub['chat_id'] ) ) {
			$rows[] = array( array( 'text' => self::ENTRY ) );
		}

		return $rows;
	}

	/* ------------------------------------------------------------------ */
	/* ابزارها                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * کیبورد منوی مدیریت.
	 *
	 * @return array
	 */
	protected static function menu_markup() {
		$b = self::buttons();

		return array(
			'keyboard'        => array(
				array( array( 'text' => $b['stats'] ), array( 'text' => $b['compose'] ) ),
				array( array( 'text' => $b['prepared'] ), array( 'text' => $b['jobs'] ) ),
				array( array( 'text' => $b['search'] ), array( 'text' => $b['recent'] ) ),
				array( array( 'text' => $b['import'] ), array( 'text' => $b['settings'] ) ),
				array( array( 'text' => $b['exit'] ) ),
			),
			'resize_keyboard' => true,
			'is_persistent'   => true,
		);
	}

	/**
	 * فرستادن منوی مدیریت.
	 *
	 * @param string $chat_id چت.
	 * @param string $intro   متن همراه.
	 */
	public static function menu( $chat_id, $intro = '' ) {
		self::say( $chat_id, '' !== $intro ? $intro : '🛠 پنل مدیریت ربات', self::menu_markup() );
	}

	/**
	 * کیبورد شیشه‌ای از ردیف‌های [برچسب، داده].
	 *
	 * @param array $rows ردیف‌ها.
	 * @return array
	 */
	protected static function inline( array $rows ) {
		$out = array();

		foreach ( $rows as $row ) {
			$line = array();

			foreach ( $row as $button ) {
				$line[] = array(
					'text'          => (string) $button[0],
					'callback_data' => self::CB . $button[1],
				);
			}

			$out[] = $line;
		}

		return array( 'inline_keyboard' => $out );
	}

	/**
	 * فرستادن یک پیام متنی به مدیر.
	 *
	 * @param string     $chat_id چت.
	 * @param string     $text    متن.
	 * @param array|null $markup  کیبورد.
	 * @return array
	 */
	protected static function say( $chat_id, $text, $markup = null ) {
		$args = array( 'text' => $text );

		if ( $markup ) {
			$args['reply_markup'] = $markup;
		}

		return WCMA_Messengers::send_content( self::channel(), (string) $chat_id, $args );
	}

	/**
	 * متنی که از بیرون آمده (نام، نام کاربری، خطا)، بی‌خطر برای قالب HTML تلگرام.
	 *
	 * تبدیلِ HTML تلگرام، برچسب‌های مجاز را نگه می‌دارد؛ نامی مثل «<b>» آن را
	 * به‌هم می‌ریخت و پیام اصلاً نمی‌رسید.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	protected static function plain( $text ) {
		return str_replace( array( '<', '>', '&' ), array( '‹', '›', '＆' ), (string) $text );
	}

	/**
	 * کنار زدن بقیه‌ی پاسخ‌دهنده‌ها برای پیامی که مال مدیریت است.
	 */
	protected static function mine() {
		remove_action( 'wcma_bot_message', array( 'WCMA_Bot_Manager', 'on_message' ), 5 );
		remove_action( 'wcma_bot_started', array( 'WCMA_Bot_Manager', 'on_start' ), 10 );
		remove_action( 'wcma_bot_message', array( 'WCMA_Bot_Staff', 'on_message' ), 1 );
		remove_action( 'wcma_bot_started', array( 'WCMA_Bot_Staff', 'on_start' ), 1 );

		add_filter( 'wcma_chatbot_skip', '__return_true' );

		// خوش‌آمد عمومیِ ربات (وقتی مدیریت ربات خاموش است) جای منوی مدیریت را نمی‌گیرد.
		add_filter( 'wcma_bot_start_handled', '__return_true' );
	}

	/**
	 * یک‌بار مصرف بودنِ یک کار، حتی با درخواست‌های همزمان.
	 *
	 * INSERT IGNORE روی کلید یکتای option_name اتمی است.
	 *
	 * @param string $what کلید کار.
	 * @return bool آیا این نخستین بار است؟
	 */
	protected static function once( $what ) {
		global $wpdb;

		$name = '_wcma_once_' . md5( (string) $what );
		$now  = time();

		// ردهای کهنه پاک می‌شوند تا جدول تنظیمات پر نشود.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d", $wpdb->esc_like( '_wcma_once_' ) . '%', $now - DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $name, (string) $now ) ); // phpcs:ignore WordPress.DB

		return (int) $wpdb->rows_affected > 0;
	}

	/**
	 * گفتگوی جاری یک مدیر.
	 *
	 * @param string $chat_id چت.
	 * @return array|null
	 */
	protected static function flow( $chat_id ) {
		$flow = get_transient( self::FLOW . md5( self::key( self::channel(), $chat_id ) ) );

		return is_array( $flow ) ? $flow : null;
	}

	/**
	 * ثبت گفتگوی جاری.
	 *
	 * @param string $chat_id چت.
	 * @param array  $flow    وضعیت.
	 */
	protected static function set_flow( $chat_id, array $flow ) {
		set_transient( self::FLOW . md5( self::key( self::channel(), $chat_id ) ), $flow, self::FLOW_TTL );
	}

	/**
	 * پایان گفتگوی جاری.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function clear_flow( $chat_id ) {
		delete_transient( self::FLOW . md5( self::key( self::channel(), $chat_id ) ) );
	}

	/**
	 * فراموش کردن گفتگو و پیش‌نویس.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function forget( $chat_id ) {
		self::clear_flow( $chat_id );
		delete_transient( self::DRAFT . md5( self::key( self::channel(), $chat_id ) ) );
	}
}
