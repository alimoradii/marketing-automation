<?php
/**
 * نصب، ارتقا و حذف جدول‌های افزونه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Install
 */
class WCMA_Install {

	const DB_VERSION_OPTION = 'wcma_db_version';
	const BACKUP_OPTION     = 'wcma_settings_backup';
	const DB_VERSION        = '1.22.0';

	/**
	 * اجرا هنگام فعال‌سازی افزونه.
	 */
	public static function activate() {
		self::create_tables();

		// اگر افزونه قبلاً نصب و پاک شده بود، تنظیمات از نسخه‌ی پشتیبان برمی‌گردد.
		self::restore_settings_if_missing();

		self::add_default_settings();
		self::schedule_events();

		// نسخه فقط وقتی ثبت می‌شود که جدول‌ها واقعاً ساخته شده باشند؛ وگرنه یک شکست
		// گذرا برای همیشه ثبت می‌شد و دیگر تلاش دوباره‌ای رخ نمی‌داد.
		if ( ! self::missing_tables() ) {
			update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		}

		set_transient( 'wcma_activation_redirect', 1, 60 );
	}

	/**
	 * نگه‌داشتن نسخه‌ی پشتیبان از تنظیمات.
	 *
	 * این گزینه هنگام پاک کردن افزونه دست‌نخورده می‌ماند (مگر آنکه مدیر «حذف کامل
	 * داده‌ها» را خواسته باشد)، پس نصب دوباره‌ی افزونه تنظیمات را از دست نمی‌دهد.
	 *
	 * @param array $settings تنظیمات.
	 */
	public static function backup_settings( array $settings ) {
		if ( ! $settings ) {
			return;
		}

		update_option(
			self::BACKUP_OPTION,
			array(
				'version'  => WCMA_VERSION,
				'saved_at' => current_time( 'mysql' ),
				'settings' => $settings,
			),
			false
		);
	}

	/**
	 * بازگرداندن تنظیمات از پشتیبان، اگر تنظیمات فعلی وجود نداشته باشد.
	 *
	 * @return bool آیا بازگردانی انجام شد؟
	 */
	public static function restore_settings_if_missing() {
		$current = get_option( 'wcma_settings', null );

		if ( is_array( $current ) && $current ) {
			return false;
		}

		$backup = get_option( self::BACKUP_OPTION, array() );

		if ( ! is_array( $backup ) || empty( $backup['settings'] ) || ! is_array( $backup['settings'] ) ) {
			return false;
		}

		update_option( 'wcma_settings', $backup['settings'] );

		return true;
	}

	/**
	 * اطلاعات نسخه‌ی پشتیبان، برای نمایش در تنظیمات.
	 *
	 * @return array
	 */
	public static function backup_info() {
		$backup = get_option( self::BACKUP_OPTION, array() );

		if ( ! is_array( $backup ) || empty( $backup['settings'] ) ) {
			return array();
		}

		return array(
			'version'  => $backup['version'] ?? '',
			'saved_at' => $backup['saved_at'] ?? '',
			'count'    => count( (array) $backup['settings'] ),
		);
	}

	/**
	 * اجرا هنگام غیرفعال‌سازی افزونه.
	 */
	public static function deactivate() {
		foreach ( array( 'wcma_worker_event', 'wcma_daily_event' ) as $hook ) {
			$timestamp = wp_next_scheduled( $hook );
			while ( $timestamp ) {
				wp_unschedule_event( $timestamp, $hook );
				$timestamp = wp_next_scheduled( $hook );
			}
		}
	}

	/**
	 * بررسی نیاز به ارتقای جدول‌ها در هر بار بارگذاری.
	 */
	public static function maybe_upgrade() {
		if ( get_option( self::DB_VERSION_OPTION ) !== self::DB_VERSION ) {
			self::create_tables();
			self::add_default_settings();

			// نسخه فقط وقتی ثبت می‌شود که جدول‌ها واقعاً ساخته شده باشند؛ در غیر این
			// صورت یک شکست گذرا برای همیشه ثبت می‌شد و دیگر تلاش دوباره‌ای رخ نمی‌داد.
			if ( ! self::missing_tables() ) {
				update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
			}
		}

		self::schedule_events();
	}

	/**
	 * زمان‌بندی رویدادهای کرون.
	 */
	public static function schedule_events() {
		if ( ! wp_next_scheduled( 'wcma_worker_event' ) ) {
			wp_schedule_event( time() + 60, 'wcma_five_minutes', 'wcma_worker_event' );
		}
		if ( ! wp_next_scheduled( 'wcma_daily_event' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'wcma_daily_event' );
		}
	}

	/**
	 * ساخت جدول‌های افزونه.
	 */
	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$prefix  = $wpdb->prefix;

		$queries = array();

		// صف ارسال پیام‌ها.
		$queries[] = "CREATE TABLE {$prefix}wcma_queue (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			workflow VARCHAR(60) NOT NULL DEFAULT '',
			step VARCHAR(40) NOT NULL DEFAULT '',
			channel VARCHAR(20) NOT NULL DEFAULT 'email',
			object_type VARCHAR(20) NOT NULL DEFAULT 'order',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			recipient VARCHAR(190) NOT NULL DEFAULT '',
			payload LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			scheduled_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY status_scheduled (status, scheduled_at),
			KEY workflow_object (workflow(20), step(20), object_type(10), object_id)
		) {$charset};";

		// گزارش ارسال‌ها.
		$queries[] = "CREATE TABLE {$prefix}wcma_logs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			workflow VARCHAR(60) NOT NULL DEFAULT '',
			step VARCHAR(40) NOT NULL DEFAULT '',
			channel VARCHAR(20) NOT NULL DEFAULT 'email',
			object_type VARCHAR(20) NOT NULL DEFAULT 'order',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			recipient VARCHAR(190) NOT NULL DEFAULT '',
			subject VARCHAR(255) NOT NULL DEFAULT '',
			message LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'sent',
			error_message TEXT NULL,
			coupon_code VARCHAR(60) NOT NULL DEFAULT '',
			converted TINYINT(1) NOT NULL DEFAULT 0,
			revenue DECIMAL(18,4) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY workflow_idx (workflow(20)),
			KEY created_idx (created_at),
			KEY status_idx (status),
			KEY object_idx (object_type(10), object_id)
		) {$charset};";

		// سبدهای خرید رها شده.
		$queries[] = "CREATE TABLE {$prefix}wcma_carts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			session_key VARCHAR(64) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			first_name VARCHAR(120) NOT NULL DEFAULT '',
			cart_contents LONGTEXT NULL,
			cart_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			item_count INT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			recovery_token VARCHAR(64) NOT NULL DEFAULT '',
			recovered_order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY status_updated (status, updated_at),
			KEY session_key_idx (session_key),
			KEY token_idx (recovery_token),
			KEY user_idx (user_id)
		) {$charset};";

		// درخواست‌های «موجود شد خبرم کن».
		$queries[] = "CREATE TABLE {$prefix}wcma_stock_alerts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			email VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			first_name VARCHAR(120) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			token VARCHAR(64) NOT NULL DEFAULT '',
			notified_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY product_status (product_id, variation_id, status),
			KEY token_idx (token),
			KEY email_idx (email),
			KEY status_idx (status)
		) {$charset};";

		// اعضای باشگاه مشتریان.
		$queries[] = "CREATE TABLE {$prefix}wcma_vip_members (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			email VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			first_name VARCHAR(120) NOT NULL DEFAULT '',
			tier SMALLINT NOT NULL DEFAULT 0,
			previous_tier SMALLINT NOT NULL DEFAULT 0,
			total_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			order_count INT UNSIGNED NOT NULL DEFAULT 0,
			last_order_at DATETIME NULL,
			tier_since DATETIME NULL,
			last_reward_at DATETIME NULL,
			last_churn_at DATETIME NULL,
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY email_unique (email),
			KEY tier_idx (tier),
			KEY user_idx (user_id),
			KEY amount_idx (total_amount)
		) {$charset};";

		// کمپین‌ها.
		$queries[] = "CREATE TABLE {$prefix}wcma_campaigns (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			title VARCHAR(190) NOT NULL DEFAULT '',
			channel VARCHAR(20) NOT NULL DEFAULT 'email',
			subject VARCHAR(255) NOT NULL DEFAULT '',
			content LONGTEXT NULL,
			audience LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			total_recipients INT UNSIGNED NOT NULL DEFAULT 0,
			sent_count INT UNSIGNED NOT NULL DEFAULT 0,
			failed_count INT UNSIGNED NOT NULL DEFAULT 0,
			scheduled_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY status_idx (status)
		) {$charset};";

		// پرونده‌ی مشتریان (CRM).
		$queries[] = "CREATE TABLE {$prefix}wcma_contacts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			email VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			first_name VARCHAR(120) NOT NULL DEFAULT '',
			last_name VARCHAR(120) NOT NULL DEFAULT '',
			company VARCHAR(190) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			stage VARCHAR(30) NOT NULL DEFAULT 'lead',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			source VARCHAR(40) NOT NULL DEFAULT '',
			tags VARCHAR(255) NOT NULL DEFAULT '',
			owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			order_count INT UNSIGNED NOT NULL DEFAULT 0,
			total_spent DECIMAL(18,4) NOT NULL DEFAULT 0,
			first_order_at DATETIME NULL,
			last_order_at DATETIME NULL,
			last_contact_at DATETIME NULL,
			next_followup_at DATETIME NULL,
			followup_note VARCHAR(255) NOT NULL DEFAULT '',
			consent VARCHAR(10) NOT NULL DEFAULT 'yes',
			notes_count INT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY identity (email, phone),
			KEY user_idx (user_id),
			KEY stage_idx (stage),
			KEY owner_idx (owner_id),
			KEY followup_idx (next_followup_at),
			KEY spent_idx (total_spent),
			KEY phone_idx (phone)
		) {$charset};";

		// یادداشت‌ها و فعالیت‌های هر مشتری.
		$queries[] = "CREATE TABLE {$prefix}wcma_crm_notes (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			author_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			author_name VARCHAR(190) NOT NULL DEFAULT '',
			type VARCHAR(20) NOT NULL DEFAULT 'note',
			body TEXT NULL,
			due_at DATETIME NULL,
			done TINYINT(1) NOT NULL DEFAULT 0,
			reminded TINYINT(1) NOT NULL DEFAULT 0,
			assignee VARCHAR(64) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY contact_idx (contact_id),
			KEY type_idx (type),
			KEY due_idx (due_at, done),
			KEY assignee_idx (assignee)
		) {$charset};";

		// گفتگوهای ربات و اپراتور.
		$queries[] = "CREATE TABLE {$prefix}wcma_chats (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			channel VARCHAR(20) NOT NULL DEFAULT 'telegram',
			chat_id VARCHAR(64) NOT NULL DEFAULT '',
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(190) NOT NULL DEFAULT '',
			username VARCHAR(120) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			mode VARCHAR(20) NOT NULL DEFAULT 'bot',
			status VARCHAR(20) NOT NULL DEFAULT 'open',
			unread INT UNSIGNED NOT NULL DEFAULT 0,
			message_count INT UNSIGNED NOT NULL DEFAULT 0,
			last_message TEXT NULL,
			last_message_at DATETIME NULL,
			handled_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			page_url VARCHAR(255) NOT NULL DEFAULT '',
			page_title VARCHAR(190) NOT NULL DEFAULT '',
			referrer VARCHAR(255) NOT NULL DEFAULT '',
			browser VARCHAR(120) NOT NULL DEFAULT '',
			device VARCHAR(30) NOT NULL DEFAULT '',
			ip VARCHAR(60) NOT NULL DEFAULT '',
			pages_seen INT UNSIGNED NOT NULL DEFAULT 0,
			rating TINYINT NOT NULL DEFAULT 0,
			rating_note VARCHAR(255) NOT NULL DEFAULT '',
			visitor_seen_at DATETIME NULL,
			visitor_typing_at DATETIME NULL,
			agent_typing_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY conversation (channel, chat_id),
			KEY mode_idx (mode),
			KEY status_idx (status),
			KEY last_idx (last_message_at),
			KEY channel_idx (channel),
			KEY seen_idx (visitor_seen_at)
		) {$charset};";

		// پیام‌های هر گفتگو.
		$queries[] = "CREATE TABLE {$prefix}wcma_chat_messages (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			chat_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			direction VARCHAR(10) NOT NULL DEFAULT 'in',
			sender VARCHAR(20) NOT NULL DEFAULT 'customer',
			author_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			rule VARCHAR(60) NOT NULL DEFAULT '',
			body TEXT NULL,
			att_file VARCHAR(255) NOT NULL DEFAULT '',
			att_name VARCHAR(190) NOT NULL DEFAULT '',
			att_kind VARCHAR(20) NOT NULL DEFAULT '',
			att_mime VARCHAR(100) NOT NULL DEFAULT '',
			att_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
			att_ms INT UNSIGNED NOT NULL DEFAULT 0,
			reply_to BIGINT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'sent',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY chat_idx (chat_id),
			KEY created_idx (created_at)
		) {$charset};";

		// مشترکان ربات و جایگاه هرکدام در دنباله‌ی روزانه.
		$queries[] = "CREATE TABLE {$prefix}wcma_app_users (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			username VARCHAR(60) NOT NULL DEFAULT '',
			pass_hash VARCHAR(255) NOT NULL DEFAULT '',
			name VARCHAR(190) NOT NULL DEFAULT '',
			role VARCHAR(20) NOT NULL DEFAULT 'agent',
			active TINYINT(1) NOT NULL DEFAULT 1,
			wp_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			tg_chat_id VARCHAR(64) NOT NULL DEFAULT '',
			tg_channel VARCHAR(20) NOT NULL DEFAULT '',
			last_login_at DATETIME NULL,
			last_ip VARCHAR(45) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY username (username),
			KEY active_idx (active),
			KEY tg_idx (tg_channel, tg_chat_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$prefix}wcma_app_tokens (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			token_hash CHAR(64) NOT NULL DEFAULT '',
			device VARCHAR(190) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			expires_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			last_used_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY token_hash (token_hash),
			KEY user_idx (user_id),
			KEY expires_idx (expires_at)
		) {$charset};";

		$queries[] = "CREATE TABLE {$prefix}wcma_app_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			actor VARCHAR(190) NOT NULL DEFAULT '',
			action VARCHAR(40) NOT NULL DEFAULT '',
			object_type VARCHAR(20) NOT NULL DEFAULT '',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			detail TEXT NULL,
			ip VARCHAR(45) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY user_idx (user_id),
			KEY created_idx (created_at),
			KEY action_idx (action)
		) {$charset};";

		$queries[] = "CREATE TABLE {$prefix}wcma_bot_subs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			channel VARCHAR(20) NOT NULL DEFAULT 'telegram',
			chat_id VARCHAR(64) NOT NULL DEFAULT '',
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(190) NOT NULL DEFAULT '',
			username VARCHAR(120) NOT NULL DEFAULT '',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			day_sent INT UNSIGNED NOT NULL DEFAULT 0,
			sent_count INT UNSIGNED NOT NULL DEFAULT 0,
			last_sent_at DATETIME NULL,
			phone_at DATETIME NULL,
			phone_verified TINYINT UNSIGNED NOT NULL DEFAULT 0,
			sent_days VARCHAR(255) NOT NULL DEFAULT '',
			started_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY subscriber (channel, chat_id),
			KEY status_idx (status),
			KEY day_idx (day_sent),
			KEY started_idx (started_at)
		) {$charset};";

		// ارسال گروهی پیام‌های آماده به مشترکان ربات.
		$queries[] = "CREATE TABLE {$prefix}wcma_bot_broadcasts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			channel VARCHAR(20) NOT NULL DEFAULT 'telegram',
			title VARCHAR(190) NOT NULL DEFAULT '',
			message LONGTEXT NULL,
			audience VARCHAR(20) NOT NULL DEFAULT 'subscribed',
			status VARCHAR(20) NOT NULL DEFAULT 'running',
			total INT UNSIGNED NOT NULL DEFAULT 0,
			sent INT UNSIGNED NOT NULL DEFAULT 0,
			failed INT UNSIGNED NOT NULL DEFAULT 0,
			blocked INT UNSIGNED NOT NULL DEFAULT 0,
			cursor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			last_error VARCHAR(255) NOT NULL DEFAULT '',
			notify_chat VARCHAR(64) NOT NULL DEFAULT '',
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			start_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			finished_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY status_idx (status, start_at)
		) {$charset};";

		// کدهای یک‌بارمصرف ورود.
		$queries[] = "CREATE TABLE {$prefix}wcma_otp (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			phone VARCHAR(20) NOT NULL DEFAULT '',
			code_hash VARCHAR(64) NOT NULL DEFAULT '',
			purpose VARCHAR(20) NOT NULL DEFAULT 'login',
			attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
			used TINYINT(1) NOT NULL DEFAULT 0,
			ip VARCHAR(45) NOT NULL DEFAULT '',
			expires_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY phone_idx (phone, expires_at),
			KEY created_idx (created_at)
		) {$charset};";

		// دفتر کیف پول: هر ردیف یک تراکنش، و مانده‌ی پس از آن.
		$queries[] = "CREATE TABLE {$prefix}wcma_wallet (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			amount DECIMAL(18,2) NOT NULL DEFAULT 0,
			balance DECIMAL(18,2) NOT NULL DEFAULT 0,
			kind VARCHAR(20) NOT NULL DEFAULT 'credit',
			source VARCHAR(30) NOT NULL DEFAULT '',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			note VARCHAR(255) NOT NULL DEFAULT '',
			actor VARCHAR(190) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY user_idx (user_id, id),
			KEY source_idx (source, object_id)
		) {$charset};";

		// تیکت‌های پشتیبانی.
		$queries[] = "CREATE TABLE {$prefix}wcma_tickets (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			subject VARCHAR(190) NOT NULL DEFAULT '',
			department VARCHAR(40) NOT NULL DEFAULT '',
			priority VARCHAR(20) NOT NULL DEFAULT 'normal',
			status VARCHAR(20) NOT NULL DEFAULT 'open',
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			replies INT UNSIGNED NOT NULL DEFAULT 0,
			unread_staff TINYINT(1) NOT NULL DEFAULT 1,
			unread_user TINYINT(1) NOT NULL DEFAULT 0,
			last_reply_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY user_idx (user_id, id),
			KEY status_idx (status, last_reply_at)
		) {$charset};";

		// پیام‌های هر تیکت.
		$queries[] = "CREATE TABLE {$prefix}wcma_ticket_replies (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			ticket_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			author VARCHAR(20) NOT NULL DEFAULT 'user',
			author_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			author_name VARCHAR(190) NOT NULL DEFAULT '',
			body TEXT NULL,
			att_url VARCHAR(255) NOT NULL DEFAULT '',
			att_name VARCHAR(190) NOT NULL DEFAULT '',
			att_kind VARCHAR(20) NOT NULL DEFAULT '',
			att_mime VARCHAR(100) NOT NULL DEFAULT '',
			att_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY ticket_idx (ticket_id, id)
		) {$charset};";

		foreach ( $queries as $query ) {
			dbDelta( $query );
		}
	}

	/**
	 * درج تنظیمات پیش‌فرض در صورت نبودن.
	 */
	public static function add_default_settings() {
		$existing = get_option( 'wcma_settings', array() );
		if ( ! is_array( $existing ) ) {
			$existing = array();
		}

		require_once WCMA_PATH . 'includes/class-wcma-settings.php';
		$defaults = WCMA_Settings::defaults();

		update_option( 'wcma_settings', array_merge( $defaults, $existing ) );
	}

	/**
	 * فهرست جدول‌های افزونه.
	 *
	 * @return array
	 */
	public static function tables() {
		return array( 'wcma_queue', 'wcma_logs', 'wcma_carts', 'wcma_campaigns', 'wcma_stock_alerts', 'wcma_vip_members', 'wcma_contacts', 'wcma_crm_notes', 'wcma_chats', 'wcma_chat_messages', 'wcma_bot_subs', 'wcma_bot_broadcasts', 'wcma_app_users', 'wcma_app_tokens', 'wcma_app_log', 'wcma_otp', 'wcma_wallet', 'wcma_tickets', 'wcma_ticket_replies' );
	}

	/**
	 * آیا این جدول در دیتابیس وجود دارد؟
	 *
	 * @param string $table نام جدول بدون پیشوند.
	 * @return bool
	 */
	public static function table_exists( $table ) {
		global $wpdb;

		$full = $wpdb->prefix . $table;

		return (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $full ) )
		);
	}

	/**
	 * جدول‌های نداشته را گزارش می‌دهد و در صورت درخواست دوباره می‌سازد.
	 *
	 * نسخه‌ی دیتابیس حتی در صورت شکست ساخت جدول ذخیره می‌شد، بنابراین یک شکست
	 * گذرا باعث می‌شد جدول هرگز ساخته نشود. این متد آن حالت را قابل تشخیص و
	 * قابل ترمیم می‌کند.
	 *
	 * @param bool $repair ساخت دوباره‌ی جدول‌های نداشته.
	 * @return array فهرست جدول‌هایی که وجود نداشتند.
	 */
	public static function missing_tables( $repair = false ) {
		$missing = array();

		foreach ( self::tables() as $table ) {
			if ( ! self::table_exists( $table ) ) {
				$missing[] = $table;
			}
		}

		if ( $missing && $repair ) {
			self::create_tables();

			$still = array();

			foreach ( $missing as $table ) {
				if ( ! self::table_exists( $table ) ) {
					$still[] = $table;
				}
			}

			return $still;
		}

		return $missing;
	}

	/**
	 * حذف کامل داده‌ها (از uninstall.php فراخوانی می‌شود).
	 */
	public static function drop_data() {
		global $wpdb;

		foreach ( self::tables() as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" ); // phpcs:ignore WordPress.DB
		}

		delete_option( 'wcma_settings' );
		delete_option( self::BACKUP_OPTION );
		delete_option( self::DB_VERSION_OPTION );
		delete_option( 'wcma_crm_last_sync' );
		delete_option( 'wcma_agent_seen' );
		delete_option( 'wcma_bot_admins' );
		delete_option( 'wcma_bot_admin_invites' );
	}
}
