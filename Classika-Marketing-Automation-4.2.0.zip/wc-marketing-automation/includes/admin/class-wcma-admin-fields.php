<?php
/**
 * کمک‌کننده‌های رندر و پاک‌سازی فیلدهای فرم.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Admin_Fields
 */
class WCMA_Admin_Fields {

	/**
	 * کلیدهایی که آرایه هستند.
	 *
	 * @var array
	 */
	protected static $array_keys = array( 'ab_order_statuses', 'ab_steps', 'os_statuses' );

	/**
	 * کلیدهایی که HTML مجاز دارند.
	 *
	 * @var array
	 */
	protected static $html_keys = array(
		'ab_steps',
		'rr_email_text',
		'rw_email_text',
		'wb_email_text',
		'bd_email_text',
	);

	/**
	 * پاک‌سازی یک مقدار بر اساس کلید آن.
	 *
	 * @param string $key   کلید.
	 * @param mixed  $value مقدار.
	 * @return mixed
	 */
	public static function sanitize_value( $key, $value ) {
		if ( 'ab_steps' === $key ) {
			return self::sanitize_steps( $value );
		}

		if ( 'os_statuses' === $key ) {
			return self::sanitize_status_map( $value );
		}

		if ( 'vip_tiers' === $key ) {
			return self::sanitize_tiers( $value );
		}

		if ( 'chat_rules' === $key ) {
			return self::sanitize_chat_rules( $value );
		}

		if ( 'channel_priority' === $key ) {
			return self::sanitize_priority( $value );
		}

		if ( 'tg_menu' === $key ) {
			return self::sanitize_bot_menu( $value );
		}

		if ( 'tg_sequence' === $key ) {
			return self::sanitize_bot_sequence( $value );
		}

		if ( 'tg_messages' === $key ) {
			return self::sanitize_bot_messages( $value );
		}

		if ( 'tg_menu_cols' === $key ) {
			return max( 1, min( 3, (int) $value ) );
		}

		if ( is_array( $value ) ) {
			$value = array_map( 'sanitize_text_field', $value );

			// حذف نشانگر خالیِ چندانتخابی.
			return array_values(
				array_filter(
					$value,
					static function ( $item ) {
						return '' !== $item;
					}
				)
			);
		}

		if ( in_array( $key, self::$html_keys, true ) || false !== strpos( $key, '_email_text' ) ) {
			return wp_kses_post( $value );
		}

		if ( false !== strpos( $key, '_sms_text' ) || in_array( $key, array( 'sms_custom_body', 'sms_custom_headers', 'ai_business_context', 'os_admin_text', 'chat_welcome_text', 'chat_fallback_text', 'chat_handover_text', 'chat_hours_text', 'lc_welcome', 'lc_offline_text', 'lc_greeting', 'lc_quick_replies', 'tg_welcome_text', 'tg_phone_thanks', 'tg_known_text' ), true ) ) {
			return sanitize_textarea_field( $value );
		}

		if ( in_array( $key, array( 'error_report_email', 'from_email', 'smtp_from_email' ), true ) ) {
			return sanitize_email( $value );
		}

		/*
		 * رمز سرور ایمیل عمداً پاک‌سازی نمی‌شود: sanitize_text_field نویسه‌هایی
		 * مثل < را برمی‌دارد و رمز را بی‌سروصدا خراب می‌کند؛ آن‌وقت ارسال بدون
		 * دلیل روشن شکست می‌خورد. مقدار جایی چاپ نمی‌شود، فقط به سرور می‌رود.
		 */
		if ( 'smtp_pass' === $key ) {
			return (string) $value;
		}

		return sanitize_text_field( $value );
	}

	/**
	 * پاک‌سازی دکمه‌های منوی ربات.
	 *
	 * @param mixed $value ورودی.
	 * @return array
	 */
	protected static function sanitize_bot_menu( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$actions = array_keys( WCMA_Bot_Manager::button_actions() );
		$clean   = array();

		foreach ( $value as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$label = trim( sanitize_text_field( $item['label'] ?? '' ) );

			// دکمه‌ی بدون برچسب، دکمه نیست.
			if ( '' === $label ) {
				continue;
			}

			$action = $item['action'] ?? 'reply';
			$action = in_array( $action, $actions, true ) ? $action : 'reply';
			$raw    = (string) ( $item['value'] ?? '' );

			$clean[] = array(
				'label'   => mb_substr( $label, 0, 60 ),
				'action'  => $action,
				'value'   => 'link' === $action ? esc_url_raw( $raw ) : sanitize_textarea_field( $raw ),
				'message' => 'message' === $action ? WCMA_Bot_Manager::clean_message_id( $item['message'] ?? '' ) : '',
			);

			if ( count( $clean ) >= WCMA_Bot_Manager::MAX_BUTTONS ) {
				break;
			}
		}

		return $clean;
	}

	/**
	 * پاک‌سازی پیام‌های آماده‌ی ربات.
	 *
	 * @param mixed $value ورودی.
	 * @return array
	 */
	protected static function sanitize_bot_messages( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$types = array_keys( WCMA_Messengers::content_types() );
		$clean = array();
		$seen  = array();

		foreach ( $value as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$text = trim( sanitize_textarea_field( $item['text'] ?? '' ) );
			$file = esc_url_raw( (string) ( $item['file'] ?? '' ) );

			// پیامی که نه متن دارد نه فایل، ذخیره نمی‌شود.
			if ( '' === $text && '' === $file ) {
				continue;
			}

			$id = WCMA_Bot_Manager::clean_message_id( $item['id'] ?? '' );

			// شناسه‌ی تکراری یا خالی، دکمه‌ها را به پیام اشتباه می‌برد.
			if ( '' === $id || isset( $seen[ $id ] ) ) {
				$id = WCMA_Bot_Manager::new_message_id();
			}

			$seen[ $id ] = true;
			$type        = $item['type'] ?? 'text';

			$clean[] = array(
				'id'      => $id,
				'title'   => mb_substr( trim( sanitize_text_field( $item['title'] ?? '' ) ), 0, 80 ),
				'type'    => in_array( $type, $types, true ) ? $type : 'text',
				'text'    => $text,
				'file'    => $file,
				'cols'    => 2 === (int) ( $item['cols'] ?? 1 ) ? 2 : 1,
				'buttons' => self::sanitize_message_buttons( $item['buttons'] ?? array() ),
			);

			if ( count( $clean ) >= WCMA_Bot_Manager::MAX_MESSAGES ) {
				break;
			}
		}

		return $clean;
	}

	/**
	 * پاک‌سازی دکمه‌های شیشه‌ای یک پیام آماده.
	 *
	 * @param mixed $value ورودی.
	 * @return array
	 */
	protected static function sanitize_message_buttons( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();

		foreach ( $value as $button ) {
			if ( ! is_array( $button ) ) {
				continue;
			}

			$label   = mb_substr( trim( sanitize_text_field( $button['label'] ?? '' ) ), 0, 60 );
			$kind    = 'message' === ( $button['kind'] ?? 'url' ) ? 'message' : 'url';
			$url     = esc_url_raw( (string) ( $button['url'] ?? '' ) );
			$message = WCMA_Bot_Manager::clean_message_id( $button['message'] ?? '' );

			// دکمه‌ی بی‌برچسب یا بی‌مقصد، دکمه نیست.
			if ( '' === $label || ( 'url' === $kind && '' === $url ) || ( 'message' === $kind && '' === $message ) ) {
				continue;
			}

			$clean[] = array(
				'label'   => $label,
				'kind'    => $kind,
				'url'     => 'url' === $kind ? $url : '',
				'message' => 'message' === $kind ? $message : '',
			);

			if ( count( $clean ) >= WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS ) {
				break;
			}
		}

		return $clean;
	}

	/**
	 * پاک‌سازی دنباله‌ی روزانه‌ی ربات.
	 *
	 * @param mixed $value ورودی.
	 * @return array
	 */
	protected static function sanitize_bot_sequence( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$types = array_keys( WCMA_Messengers::content_types() );
		$clean = array();

		foreach ( $value as $index => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$text = trim( sanitize_textarea_field( $item['text'] ?? '' ) );
			$file = esc_url_raw( (string) ( $item['file'] ?? '' ) );

			// روزی که نه متن دارد نه فایل، ذخیره نمی‌شود.
			if ( '' === $text && '' === $file ) {
				continue;
			}

			$type = $item['type'] ?? 'text';

			$mode = ( isset( $item['mode'] ) && 'date' === $item['mode'] ) ? 'date' : 'offset';
			$date = WCMA_Bot_Manager::clean_date( $item['date'] ?? '' );

			$clean[] = array(
				'day'          => max( 1, min( WCMA_Bot_Manager::MAX_DAYS, (int) ( $item['day'] ?? ( $index + 1 ) ) ) ),
				'active'       => ! empty( $item['active'] ) && 'yes' === $item['active'],
				'mode'         => ( 'date' === $mode && '' !== $date ) ? 'date' : 'offset',
				'date'         => $date,
				'time'         => WCMA_Bot_Manager::clean_time( $item['time'] ?? '' ),
				'type'         => in_array( $type, $types, true ) ? $type : 'text',
				'text'         => $text,
				'file'         => $file,
				'button_label' => mb_substr( trim( sanitize_text_field( $item['button_label'] ?? '' ) ), 0, 60 ),
				'button_url'   => esc_url_raw( (string) ( $item['button_url'] ?? '' ) ),
				'buttons'      => self::sanitize_day_buttons( $item['buttons'] ?? array() ),
			);
		}

		return $clean;
	}

	/**
	 * پاک‌سازی دکمه‌های شیشه‌ای یک روز.
	 *
	 * @param mixed $value ورودی.
	 * @return array
	 */
	protected static function sanitize_day_buttons( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();

		foreach ( $value as $button ) {
			if ( ! is_array( $button ) ) {
				continue;
			}

			$label = mb_substr( trim( sanitize_text_field( $button['label'] ?? '' ) ), 0, 60 );
			$url   = esc_url_raw( (string) ( $button['url'] ?? '' ) );

			// دکمه‌ی بدون برچسب یا بدون نشانی، دکمه نیست.
			if ( '' === $label || '' === $url ) {
				continue;
			}

			$clean[] = array( 'label' => $label, 'url' => $url );

			if ( count( $clean ) >= WCMA_Bot_Manager::MAX_DAY_BUTTONS ) {
				break;
			}
		}

		return $clean;
	}

	/**
	 * پاک‌سازی ترتیب اولویت کانال‌ها.
	 *
	 * ورودی به‌شکل «کلید کانال => شماره‌ی ترتیب» می‌آید و خروجی، فهرست مرتب‌شده است.
	 *
	 * @param mixed $value ورودی.
	 * @return array
	 */
	protected static function sanitize_priority( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$valid = WCMA_Sender::priority_channels();
		$pairs = array();

		foreach ( $value as $key => $position ) {
			$key = sanitize_key( $key );

			if ( in_array( $key, $valid, true ) ) {
				$pairs[ $key ] = (int) $position;
			}
		}

		asort( $pairs );

		return array_keys( $pairs );
	}

	/**
	 * پاک‌سازی قاعده‌های چت‌بات.
	 *
	 * قاعده‌های خالی حذف می‌شوند تا فهرست تمیز بماند.
	 *
	 * @param mixed $rules قاعده‌ها.
	 * @return array
	 */
	protected static function sanitize_chat_rules( $rules ) {
		if ( ! is_array( $rules ) ) {
			return array();
		}

		$matches = array_keys( WCMA_Chatbot::match_types() );
		$clean   = array();

		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}

			$reply    = trim( sanitize_textarea_field( $rule['reply'] ?? '' ) );
			$keywords = trim( sanitize_text_field( $rule['keywords'] ?? '' ) );
			$match    = $rule['match'] ?? 'contains';
			$match    = in_array( $match, $matches, true ) ? $match : 'contains';

			// قاعده‌ای که نه پاسخ دارد و نه کلیدواژه، چیزی برای ذخیره ندارد.
			if ( '' === $reply && '' === $keywords ) {
				continue;
			}

			$clean[] = array(
				'enabled'  => ! empty( $rule['enabled'] ) && 'yes' === $rule['enabled'],
				'match'    => $match,
				'keywords' => $keywords,
				'reply'    => $reply,
				'handover' => ! empty( $rule['handover'] ) && 'yes' === $rule['handover'],
			);
		}

		return $clean;
	}

	/**
	 * پاک‌سازی مراحل سبد رها شده.
	 *
	 * @param mixed $steps مراحل.
	 * @return array
	 */
	protected static function sanitize_steps( $steps ) {
		if ( ! is_array( $steps ) ) {
			return array();
		}

		$clean = array();

		foreach ( $steps as $step ) {
			if ( ! is_array( $step ) ) {
				continue;
			}

			// مقادیر را ابتدا استخراج می‌کنیم تا کلید نبود، هشدار و مقدار null تولید نکند.
			$unit        = $step['unit'] ?? 'hour';
			$coupon_type = $step['coupon_type'] ?? 'percent';

			$clean[] = array(
				'active'        => ! empty( $step['active'] ) ? 'yes' : 'no',
				'delay'         => max( 0, (int) ( $step['delay'] ?? 0 ) ),
				'unit'          => in_array( $unit, array( 'minute', 'hour', 'day' ), true ) ? $unit : 'hour',
				'channel'       => in_array( $step['channel'] ?? '', array( 'sms', 'email', 'both', 'telegram' ), true ) ? $step['channel'] : 'email',
				'subject'       => sanitize_text_field( $step['subject'] ?? '' ),
				'sms_text'      => sanitize_textarea_field( $step['sms_text'] ?? '' ),
				'email_text'    => wp_kses_post( $step['email_text'] ?? '' ),
				'coupon'        => ! empty( $step['coupon'] ) ? 'yes' : 'no',
				'coupon_type'   => in_array( $coupon_type, array( 'percent', 'fixed' ), true ) ? $coupon_type : 'percent',
				'coupon_amount' => max( 0, (float) ( $step['coupon_amount'] ?? 0 ) ),
				'coupon_days'   => max( 0, (int) ( $step['coupon_days'] ?? 3 ) ),
			);
		}

		return $clean;
	}

	/**
	 * پاک‌سازی سطوح باشگاه مشتریان.
	 *
	 * @param mixed $tiers سطوح.
	 * @return array
	 */
	protected static function sanitize_tiers( $tiers ) {
		if ( ! is_array( $tiers ) ) {
			return array();
		}

		$clean = array();

		foreach ( $tiers as $tier ) {
			if ( ! is_array( $tier ) ) {
				continue;
			}

			$name = sanitize_text_field( $tier['name'] ?? '' );

			// سطح بدون نام معنایی ندارد و فقط رابط کاربری را شلوغ می‌کند.
			if ( '' === $name ) {
				continue;
			}

			$coupon_type = $tier['coupon_type'] ?? 'percent';

			$clean[] = array(
				'active'        => ! empty( $tier['active'] ) ? 'yes' : 'no',
				'name'          => $name,
				'min_amount'    => max( 0, (float) ( $tier['min_amount'] ?? 0 ) ),
				'min_orders'    => max( 0, (int) ( $tier['min_orders'] ?? 0 ) ),
				'color'         => sanitize_hex_color( $tier['color'] ?? '' ) ? sanitize_hex_color( $tier['color'] ) : '#6b7280',
				'perk'          => sanitize_text_field( $tier['perk'] ?? '' ),
				'coupon_type'   => in_array( $coupon_type, array( 'percent', 'fixed' ), true ) ? $coupon_type : 'percent',
				'coupon_amount' => max( 0, (float) ( $tier['coupon_amount'] ?? 0 ) ),
				'coupon_days'   => max( 1, (int) ( $tier['coupon_days'] ?? 30 ) ),
			);
		}

		return $clean;
	}

	/**
	 * پاک‌سازی نقشه‌ی وضعیت‌های سفارش.
	 *
	 * @param mixed $map نقشه.
	 * @return array
	 */
	protected static function sanitize_status_map( $map ) {
		if ( ! is_array( $map ) ) {
			return array();
		}

		$clean = array();

		foreach ( $map as $status => $config ) {
			$clean[ sanitize_key( $status ) ] = array(
				'active' => ! empty( $config['active'] ) ? 'yes' : 'no',
				'text'   => sanitize_textarea_field( $config['text'] ?? '' ),
			);
		}

		return $clean;
	}

	/**
	 * آیا مقدار این فیلد باید چپ‌به‌راست نمایش داده شود؟
	 *
	 * کلیدهای API، توکن‌ها، شماره‌ها و نشانی‌ها لاتین هستند و در فیلد راست‌چین
	 * وارونه به‌نظر می‌رسند (مثلاً کلید base64 با = شروع می‌شود)، که بررسی چشمی
	 * آن‌ها را برای مدیر ناممکن می‌کند.
	 *
	 * @param string $key کلید تنظیم.
	 * @return bool
	 */
	public static function is_ltr_field( $key ) {
		$patterns = array(
			'api_key', 'token', 'sender', 'phone', 'url', 'username', 'password',
			'chat_id', 'channel_id', 'phone_id', 'secret', 'model', 'api_version',
			'template', 'headers', 'body',
			// اطلاعات سرور ایمیل هم لاتین است و راست‌به‌چپ خوانا نمی‌ماند.
			'host', 'email', 'user', 'pass',
		);

		foreach ( $patterns as $pattern ) {
			if ( false !== strpos( $key, $pattern ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * رندر سوییچ روشن/خاموش.
	 *
	 * @param string $key         کلید تنظیم.
	 * @param string $label       برچسب.
	 * @param string $description توضیح.
	 */
	public static function toggle( $key, $label, $description = '', $help = '' ) {
		$value = WCMA_Settings::get( $key );
		?>
		<div class="wcma-field wcma-field--toggle">
			<div class="wcma-field__main">
				<label class="wcma-switch">
					<input type="hidden" name="wcma_checkboxes[]" value="<?php echo esc_attr( $key ); ?>" />
					<input type="checkbox" name="wcma[<?php echo esc_attr( $key ); ?>]" value="yes" <?php checked( 'yes', $value ); ?> />
					<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
				</label>
				<div class="wcma-field__text">
					<span class="wcma-field__label">
						<?php echo esc_html( $label ); ?>
						<?php self::help( $help ); ?>
					</span>
					<?php if ( $description ) : ?>
						<span class="wcma-field__desc"><?php echo wp_kses_post( $description ); ?></span>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * رندر فیلد متنی.
	 *
	 * @param string $key         کلید.
	 * @param string $label       برچسب.
	 * @param array  $args        آرگومان‌ها.
	 */
	public static function text( $key, $label, array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'type'        => 'text',
				'description' => '',
				'placeholder' => '',
				'min'         => null,
				'max'         => null,
				'step'        => null,
				'suffix'      => '',
				'value'       => null,
				'name'        => null,
				'attrs'       => array(),
			)
		);

		$attrs = '';

		foreach ( (array) $args['attrs'] as $attr_key => $attr_value ) {
			$attrs .= ' ' . esc_attr( $attr_key ) . '="' . esc_attr( $attr_value ) . '"';
		}

		$value = null !== $args['value'] ? $args['value'] : WCMA_Settings::get( $key );
		$name  = null !== $args['name'] ? $args['name'] : 'wcma[' . $key . ']';
		?>
		<div class="wcma-field">
			<label class="wcma-field__label" for="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_html( $label ); ?>
				<?php self::help( $args['help'] ?? '' ); ?>
			</label>
			<div class="wcma-field__input">
				<input
					type="<?php echo esc_attr( $args['type'] ); ?>"
					id="<?php echo esc_attr( $key ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					value="<?php echo esc_attr( $value ); ?>"
					placeholder="<?php echo esc_attr( $args['placeholder'] ); ?>"
					<?php echo self::is_ltr_field( $key ) ? 'dir="ltr" class="wcma-ltr-input"' : ''; ?>
					<?php echo null !== $args['min'] ? 'min="' . esc_attr( $args['min'] ) . '"' : ''; ?>
					<?php echo null !== $args['max'] ? 'max="' . esc_attr( $args['max'] ) . '"' : ''; ?>
					<?php echo null !== $args['step'] ? 'step="' . esc_attr( $args['step'] ) . '"' : ''; ?>
					<?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				/>
				<?php if ( $args['suffix'] ) : ?>
					<span class="wcma-field__suffix"><?php echo esc_html( $args['suffix'] ); ?></span>
				<?php endif; ?>
			</div>
			<?php if ( $args['description'] ) : ?>
				<p class="wcma-field__desc"><?php echo wp_kses_post( $args['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * رندر فیلد انتخابی.
	 *
	 * @param string $key     کلید.
	 * @param string $label   برچسب.
	 * @param array  $options گزینه‌ها.
	 * @param array  $args    آرگومان‌ها.
	 */
	public static function select( $key, $label, array $options, array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'description' => '',
				'value'       => null,
				'name'        => null,
				'multiple'    => false,
				'class'       => '',
			)
		);

		$value = null !== $args['value'] ? $args['value'] : WCMA_Settings::get( $key );
		$name  = null !== $args['name'] ? $args['name'] : 'wcma[' . $key . ']';

		if ( $args['multiple'] ) {
			$name  .= '[]';
			$value  = (array) $value;
		}
		?>
		<div class="wcma-field">
			<label class="wcma-field__label" for="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_html( $label ); ?>
				<?php self::help( $args['help'] ?? '' ); ?>
			</label>
			<div class="wcma-field__input">
				<?php if ( $args['multiple'] ) : ?>
					<?php /* تا اگر کاربر همه‌ی گزینه‌ها را بردارد، مقدار خالی ثبت شود. */ ?>
					<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="" />
				<?php endif; ?>
				<select
					id="<?php echo esc_attr( $key ); ?>"
					name="<?php echo esc_attr( $name ); ?>"
					class="<?php echo esc_attr( $args['class'] ); ?>"
					<?php echo $args['multiple'] ? 'multiple' : ''; ?>
				>
					<?php foreach ( $options as $option_value => $option_label ) : ?>
						<option
							value="<?php echo esc_attr( $option_value ); ?>"
							<?php
							if ( $args['multiple'] ) {
								selected( in_array( (string) $option_value, array_map( 'strval', $value ), true ), true );
							} else {
								selected( (string) $value, (string) $option_value );
							}
							?>
						><?php echo esc_html( $option_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<?php if ( $args['description'] ) : ?>
				<p class="wcma-field__desc"><?php echo wp_kses_post( $args['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * رندر ناحیه‌ی متنی.
	 *
	 * @param string $key   کلید.
	 * @param string $label برچسب.
	 * @param array  $args  آرگومان‌ها.
	 */
	public static function textarea( $key, $label, array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'description' => '',
				'rows'        => 4,
				'value'       => null,
				'name'        => null,
				'placeholder' => '',
				'counter'     => false,
			)
		);

		$value = null !== $args['value'] ? $args['value'] : WCMA_Settings::get( $key );
		$name  = null !== $args['name'] ? $args['name'] : 'wcma[' . $key . ']';
		?>
		<div class="wcma-field">
			<label class="wcma-field__label" for="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_html( $label ); ?>
				<?php self::help( $args['help'] ?? '' ); ?>
			</label>
			<textarea
				id="<?php echo esc_attr( $key ); ?>"
				name="<?php echo esc_attr( $name ); ?>"
				rows="<?php echo (int) $args['rows']; ?>"
				placeholder="<?php echo esc_attr( $args['placeholder'] ); ?>"
				<?php echo self::is_ltr_field( $key ) ? 'dir="ltr" class="wcma-ltr-input"' : ''; ?>
				<?php echo $args['counter'] ? 'data-sms-counter="1"' : ''; ?>
			><?php echo esc_textarea( $value ); ?></textarea>
			<?php if ( $args['counter'] ) : ?>
				<p class="wcma-field__desc wcma-sms-counter">تعداد کاراکتر: <strong>0</strong> — تعداد پیامک: <strong>0</strong></p>
			<?php endif; ?>
			<?php if ( $args['description'] ) : ?>
				<p class="wcma-field__desc"><?php echo wp_kses_post( $args['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * فیلد انتخاب تصویر از کتابخانه‌ی رسانه‌ی وردپرس.
	 *
	 * مقدار ذخیره‌شده نشانی تصویر است، پس اگر کسی قبلاً لینک وارد کرده باشد از بین نمی‌رود.
	 *
	 * @param string $key   کلید تنظیم.
	 * @param string $label برچسب.
	 * @param array  $args  پارامترها.
	 */
	public static function image( $key, $label, array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'description' => '',
				'button'      => 'انتخاب تصویر',
			)
		);

		$value = (string) WCMA_Settings::get( $key );
		?>
		<div class="wcma-field wcma-image" data-key="<?php echo esc_attr( $key ); ?>">
			<label class="wcma-field__label" for="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_html( $label ); ?>
				<?php self::help( $args['help'] ?? '' ); ?>
			</label>

			<div class="wcma-image__row">
				<div class="wcma-image__preview <?php echo $value ? 'has-image' : ''; ?>">
					<?php if ( $value ) : ?>
						<img src="<?php echo esc_url( $value ); ?>" alt="" />
					<?php else : ?>
						<span class="dashicons dashicons-format-image"></span>
					<?php endif; ?>
				</div>

				<div class="wcma-image__actions">
					<button type="button" class="wcma-btn wcma-btn--secondary wcma-image__pick">
						<span class="dashicons dashicons-upload"></span>
						<?php echo esc_html( $args['button'] ); ?>
					</button>

					<button type="button" class="wcma-btn wcma-btn--ghost wcma-image__clear" <?php echo $value ? '' : 'hidden'; ?>>
						حذف تصویر
					</button>

					<input
						type="url"
						id="<?php echo esc_attr( $key ); ?>"
						name="wcma[<?php echo esc_attr( $key ); ?>]"
						value="<?php echo esc_attr( $value ); ?>"
						class="wcma-image__url wcma-ltr-input"
						dir="ltr"
						placeholder="https://example.com/agent.jpg"
					/>
				</div>
			</div>

			<?php if ( $args['description'] ) : ?>
				<p class="wcma-field__desc"><?php echo wp_kses_post( $args['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * متغیرهایی که در هر بخشی معنا دارند و همه‌جا نمایش داده می‌شوند.
	 *
	 * @return array
	 */
	public static function common_placeholders() {
		return apply_filters(
			'wcma_common_placeholders',
			array(
				'first_name',
				'last_name',
				'full_name',
				'email',
				'phone',
				'customer_orders',
				'customer_total',
				'site_title',
				'site_url',
				'shop_phone',
				'today',
				'today_long',
				'weekday',
				'time',
			)
		);
	}

	/**
	 * نمایش راهنمای متغیرهای قابل استفاده.
	 *
	 * @param array $only        فقط این متغیرها (به‌علاوه‌ی متغیرهای عمومی).
	 * @param bool  $with_common افزودن متغیرهای عمومی مثل نام، تاریخ و اطلاعات فروشگاه.
	 */
	public static function placeholder_help( array $only = array(), $with_common = true ) {
		$groups = WCMA_Placeholders::groups();

		// اگر فهرست محدودی خواسته شده، فقط همان‌ها را نگه می‌داریم.
		if ( $only ) {
			if ( $with_common ) {
				$only = array_merge( $only, self::common_placeholders() );
			}

			$wanted = array();

			foreach ( array_unique( $only ) as $tag ) {
				$wanted[] = '{' . trim( $tag, '{}' ) . '}';
			}

			foreach ( $groups as $key => $group ) {
				$groups[ $key ]['items'] = array_intersect_key( $group['items'], array_flip( $wanted ) );

				if ( ! $groups[ $key ]['items'] ) {
					unset( $groups[ $key ] );
				}
			}
		}

		if ( ! $groups ) {
			return;
		}

		$count = 0;

		foreach ( $groups as $group ) {
			$count += count( $group['items'] );
		}
		?>
		<div class="wcma-placeholders">
			<div class="wcma-placeholders__bar">
				<span class="wcma-placeholders__title">
					متغیرهای قابل استفاده
					<span class="wcma-placeholders__count"><?php echo esc_html( number_format_i18n( $count ) ); ?></span>
				</span>
				<button type="button" class="wcma-ph-toggle">راهنمای کارکرد هر متغیر</button>
			</div>

			<div class="wcma-placeholders__list">
				<?php foreach ( $groups as $group ) : ?>
					<?php foreach ( $group['items'] as $tag => $meta ) : ?>
						<button
							type="button"
							class="wcma-tag"
							data-tag="<?php echo esc_attr( $tag ); ?>"
							title="<?php echo esc_attr( $meta['label'] . ' — ' . $meta['desc'] ); ?>"
						><?php echo esc_html( $tag ); ?></button>
					<?php endforeach; ?>
				<?php endforeach; ?>
			</div>

			<div class="wcma-placeholders__guide">
				<?php foreach ( $groups as $group ) : ?>
					<div class="wcma-ph-group">
						<h4><?php echo esc_html( $group['title'] ); ?></h4>
						<table class="wcma-ph-table">
							<thead>
								<tr>
									<th>متغیر</th>
									<th>عنوان</th>
									<th>کارکرد</th>
									<th>نمونه خروجی</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $group['items'] as $tag => $meta ) : ?>
									<tr>
										<td>
											<button type="button" class="wcma-tag" data-tag="<?php echo esc_attr( $tag ); ?>"><?php echo esc_html( $tag ); ?></button>
										</td>
										<td><strong><?php echo esc_html( $meta['label'] ); ?></strong></td>
										<td><?php echo esc_html( $meta['desc'] ); ?></td>
										<td class="wcma-ph-sample"><?php echo esc_html( $meta['sample'] ); ?></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endforeach; ?>

				<p class="wcma-field__desc">
					با کلیک روی هر متغیر، در محل مکان‌نما درج می‌شود و در صورت نیاز فاصله‌ی
					لازم هم گذاشته می‌شود تا به کلمه‌ی قبل یا بعد نچسبد.
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * دکمه‌ی ذخیره.
	 *
	 * @param string $label برچسب.
	 */
	public static function submit( $label = 'ذخیره‌ی تغییرات' ) {
		?>
		<div class="wcma-actions wcma-actions--save">
			<?php /* تغییرات خودکار ذخیره می‌شوند؛ این دکمه فقط اگر ذخیره‌ی خودکار شکست بخورد نمایان می‌شود. */ ?>
			<button type="submit" class="wcma-btn wcma-btn--primary wcma-save-fallback" hidden>
				<span class="dashicons dashicons-yes"></span>
				<?php echo esc_html( $label ); ?>
			</button>
		</div>
		<?php
	}

	/**
	 * نوار بالای فهرست: شمار کل و انتخاب تعداد در هر صفحه.
	 *
	 * @param array $args پیکربندی.
	 */
	public static function list_bar( array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'key'     => 'per',   // نام پارامتر اندازه در نشانی.
				'current' => 20,
				'total'   => null,    // null یعنی شمار کل را ننویس.
				'shown'   => null,
				'label'   => 'نمایش',
			)
		);

		$sizes = WCMA_Admin::page_sizes();
		?>
		<div class="wcma-listbar">
			<div class="wcma-listbar__count">
				<?php if ( null !== $args['total'] ) : ?>
					<?php
					printf(
						'%s مورد',
						esc_html( WCMA_Date::number( (int) $args['total'] ) )
					);
					?>
				<?php endif; ?>
			</div>

			<?php
			/*
			 * فرمِ جدا با method=get، تا انتخاب اندازه همه‌ی فیلترهای جاری را
			 * با خودش ببرد و کاربر از نو فیلتر نکند. شماره‌ی صفحه عمداً
			 * همراه نمی‌رود: با اندازه‌ی تازه، صفحه‌ی ۹ ممکن است اصلاً وجود
			 * نداشته باشد و فهرست خالی دربیاید.
			 */
			$skip = array( $args['key'], 'paged', 'cpage', 'spage', 'hpage', 'opage', 'ipage', 'campage' );
			?>
			<form method="get" class="wcma-listbar__size is-instant">
				<?php foreach ( self::current_query( $skip ) as $qk => $qv ) : ?>
					<input type="hidden" name="<?php echo esc_attr( $qk ); ?>" value="<?php echo esc_attr( $qv ); ?>" />
				<?php endforeach; ?>

				<label>
					<span><?php echo esc_html( $args['label'] ); ?></span>
					<select name="<?php echo esc_attr( $args['key'] ); ?>">
						<?php foreach ( $sizes as $size ) : ?>
							<option value="<?php echo esc_attr( $size ); ?>" <?php selected( (int) $args['current'], $size ); ?>>
								<?php echo esc_html( WCMA_Date::number( $size ) ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</label>

				<button type="submit" class="screen-reader-text">اعمال</button>
			</form>
		</div>
		<?php
	}

	/**
	 * شماره‌ی صفحه‌ها، با نگه داشتن فیلترهای جاری.
	 *
	 * پیش‌تر هر تب خودش نشانی می‌ساخت و در پرونده‌ی مشتریان، رفتن به صفحه‌ی
	 * دوم همه‌ی فیلترها را دور می‌ریخت. اینجا پارامترهای نشانی جاری
	 * دست‌نخورده می‌مانند و فقط شماره‌ی صفحه عوض می‌شود.
	 *
	 * @param array $args پیکربندی.
	 */
	public static function pagination( array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'key'     => 'paged',
				'current' => 1,
				'pages'   => 1,
				'window'  => 3,
			)
		);

		$pages = (int) $args['pages'];

		if ( $pages < 2 ) {
			return;
		}

		$current = min( max( 1, (int) $args['current'] ), $pages );
		$window  = max( 1, (int) $args['window'] );
		$base    = self::current_query( array( $args['key'] ) );
		$from    = max( 1, $current - $window );
		$to      = min( $pages, $current + $window );

		$link = static function ( $number ) use ( $base, $args ) {
			return add_query_arg(
				array_merge( $base, array( $args['key'] => (int) $number ) ),
				admin_url( 'admin.php' )
			);
		};
		?>
		<div class="wcma-pagination">
			<?php if ( $from > 1 ) : ?>
				<a href="<?php echo esc_url( $link( 1 ) ); ?>"><?php echo esc_html( WCMA_Date::number( 1 ) ); ?></a>
				<?php if ( $from > 2 ) : ?>
					<span class="wcma-pagination__gap">…</span>
				<?php endif; ?>
			<?php endif; ?>

			<?php for ( $i = $from; $i <= $to; $i++ ) : ?>
				<a
					href="<?php echo esc_url( $link( $i ) ); ?>"
					class="<?php echo $i === $current ? 'is-current' : ''; ?>"
				><?php echo esc_html( WCMA_Date::number( $i ) ); ?></a>
			<?php endfor; ?>

			<?php if ( $to < $pages ) : ?>
				<?php if ( $to < $pages - 1 ) : ?>
					<span class="wcma-pagination__gap">…</span>
				<?php endif; ?>
				<a href="<?php echo esc_url( $link( $pages ) ); ?>"><?php echo esc_html( WCMA_Date::number( $pages ) ); ?></a>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * پارامترهای نشانی جاری، جز آن‌هایی که کنار گذاشته شده‌اند.
	 *
	 * @param array $skip کلیدهایی که نباید همراه بروند.
	 * @return array
	 */
	public static function current_query( array $skip = array() ) {
		$out = array();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		foreach ( (array) $_GET as $key => $value ) {
			$key = sanitize_key( $key );

			if ( '' === $key || in_array( $key, $skip, true ) || is_array( $value ) ) {
				continue;
			}

			$out[ $key ] = sanitize_text_field( wp_unslash( $value ) );
		}

		return $out;
	}

	/**
	 * شروع یک کارت.
	 *
	 * @param string $title    عنوان.
	 * @param string $subtitle زیرعنوان.
	 * @param string $icon     آیکن.
	 * @param string $help     راهنمای شناور.
	 * @param string $id       شناسه‌ی کارت، برای پیوند مستقیم از منوی تنظیمات.
	 */
	public static function card_start( $title = '', $subtitle = '', $icon = '', $help = '', $id = '' ) {
		?>
		<section class="wcma-card"<?php echo $id ? ' id="' . esc_attr( WCMA_Admin::section_id( $id ) ) . '"' : ''; ?>>
			<?php if ( $title ) : ?>
				<header class="wcma-card__head">
					<?php if ( $icon ) : ?>
						<span class="wcma-card__icon dashicons dashicons-<?php echo esc_attr( $icon ); ?>"></span>
					<?php endif; ?>
					<div>
						<h2 class="wcma-card__title">
							<?php echo esc_html( $title ); ?>
							<?php self::help( $help ); ?>
						</h2>
						<?php if ( $subtitle ) : ?>
							<p class="wcma-card__subtitle"><?php echo wp_kses_post( $subtitle ); ?></p>
						<?php endif; ?>
					</div>
				</header>
			<?php endif; ?>
			<div class="wcma-card__body">
		<?php
	}

	/**
	 * آیکون راهنما با توضیح شناور.
	 *
	 * با tabindex و aria-label نوشته شده تا با صفحه‌کلید و صفحه‌خوان هم کار کند،
	 * نه فقط با ماوس.
	 *
	 * @param string $text متن راهنما؛ خالی یعنی چیزی نمایش داده نشود.
	 */
	public static function help( $text ) {
		$text = trim( (string) $text );

		if ( '' === $text ) {
			return;
		}
		?>
		<span
			class="wcma-help"
			tabindex="0"
			role="note"
			aria-label="<?php echo esc_attr( 'راهنما: ' . $text ); ?>"
			data-tip="<?php echo esc_attr( $text ); ?>"
		>
			<span class="dashicons dashicons-editor-help" aria-hidden="true"></span>
		</span>
		<?php
	}

	/**
	 * پایان کارت.
	 */
	public static function card_end() {
		?>
			</div>
		</section>
		<?php
	}

	/**
	 * گزینه‌های وضعیت سفارش ووکامرس.
	 *
	 * @return array
	 */
	public static function order_status_options() {
		$statuses = wc_get_order_statuses();
		$clean    = array();

		foreach ( $statuses as $key => $label ) {
			$clean[ str_replace( 'wc-', '', $key ) ] = $label;
		}

		return $clean;
	}
}
