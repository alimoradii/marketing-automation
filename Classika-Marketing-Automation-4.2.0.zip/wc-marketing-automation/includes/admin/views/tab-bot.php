<?php
/**
 * تب مدیریت ربات تلگرام و بله.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_missing  = ! WCMA_Install::table_exists( 'wcma_bot_subs' );
$wcma_stats    = WCMA_Bot_Manager::stats();
$wcma_menu     = WCMA_Bot_Manager::menu();
$wcma_sequence = WCMA_Bot_Manager::sequence();
$wcma_actions  = WCMA_Bot_Manager::button_actions();
$wcma_types    = WCMA_Messengers::content_types();
$wcma_messages = WCMA_Bot_Manager::messages();
$wcma_kinds    = WCMA_Bot_Manager::message_button_kinds();

// فهرست پیام‌های آماده برای کشوهای انتخاب؛ اسکریپت برگه آن را با ویرایشگر همگام نگه می‌دارد.
$wcma_msg_options = array();

foreach ( $wcma_messages as $wcma_msg_id => $wcma_msg_item ) {
	$wcma_msg_options[ $wcma_msg_id ] = WCMA_Bot_Manager::message_title( $wcma_msg_item );
}

/**
 * چاپ گزینه‌های کشوی «انتخاب پیام آماده».
 *
 * @param array  $options  شناسه ⇐ نام.
 * @param string $selected شناسه‌ی انتخاب‌شده.
 */
$wcma_msg_select = static function ( array $options, $selected ) {
	echo '<option value="">— یک پیام آماده انتخاب کنید —</option>';

	foreach ( $options as $wcma_opt_id => $wcma_opt_title ) {
		printf(
			'<option value="%1$s"%2$s>%3$s</option>',
			esc_attr( $wcma_opt_id ),
			selected( $selected, $wcma_opt_id, false ),
			esc_html( $wcma_opt_title )
		);
	}
};
$wcma_channel  = WCMA_Bot_Manager::channel();
$wcma_ready    = WCMA_Messengers::is_ready( $wcma_channel );
// همه‌ی روزها رندر می‌شوند ولی روزهای خالی پنهان‌اند و با دکمه‌ی «افزودن روز» باز می‌شوند.
$wcma_rows     = WCMA_Bot_Manager::MAX_DAYS;
$wcma_last     = $wcma_sequence ? max( array_keys( $wcma_sequence ) ) : 0;
$wcma_open     = max( 1, $wcma_last );
?>

<?php if ( $wcma_missing ) : ?>
	<div class="wcma-notice wcma-notice--error">
		<span class="dashicons dashicons-warning"></span>
		<span>جدول مشترکان ربات ساخته نشده است. به تب «تست ارسال» بروید و «ترمیم جدول‌ها» را بزنید.</span>
	</div>
<?php endif; ?>

<?php if ( ! $wcma_ready ) : ?>
	<div class="wcma-notice wcma-notice--warning">
		<span class="dashicons dashicons-info"></span>
		<span>
			توکن ربات <?php echo esc_html( WCMA_Messengers::label( $wcma_channel ) ); ?> وارد نشده است.
			ابتدا در تب <a href="<?php echo esc_url( WCMA_Admin::tab_url( 'sms' ) ); ?>">کانال‌های ارتباطی</a>
			توکن را وارد و وب‌هوک را ثبت کنید.
		</span>
	</div>
<?php endif; ?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat">
		<span class="wcma-stat__icon dashicons dashicons-groups"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['total'] ) ); ?></span>
			<span class="wcma-stat__label">کل مشترکان ربات</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-controls-play"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['active'] ) ); ?></span>
			<span class="wcma-stat__label">در حال دریافت دنباله</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-smartphone"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['with_phone'] ) ); ?></span>
			<span class="wcma-stat__label">شماره‌ی ثبت‌شده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-paperclip"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['sent'] ) ); ?></span>
			<span class="wcma-stat__label">پیام دنباله‌ی فرستاده‌شده</span>
		</div>
	</div>
</div>

<?php include WCMA_PATH . 'includes/admin/views/partial-contacts-import.php'; ?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'وضعیت ربات', 'با روشن کردن این بخش، ربات منوی دکمه‌ها و دنباله‌ی روزانه را اجرا می‌کند.', 'admin-generic', '', 'bot-status' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'tg_bot_enabled', 'فعال بودن مدیریت ربات', '', 'تا این کلید روشن نباشد، منوی دکمه‌ها و دنباله‌ی روزانه اجرا نمی‌شوند — حتی اگر توکن ربات را وارد کرده باشید.' );

		WCMA_Admin_Fields::select(
			'tg_bot_channel',
			'ربات روی کدام پیام‌رسان؟',
			array(
				'telegram' => 'تلگرام',
				'bale'     => 'بله',
			),
			array( 'description' => 'ایتا و روبیکا از دکمه و رسانه‌ی این‌چنینی پشتیبانی نمی‌کنند.' )
		);

		WCMA_Admin_Fields::toggle( 'tg_admin_notify', 'خبر عضو تازه و شماره‌ی تازه برای مدیران ربات', '', 'هر وقت کسی ربات را شروع کند یا شماره‌اش را بدهد، مدیران ربات (بخش «مدیران ربات در تلگرام» در پایین همین برگه) در تلگرام خبردار می‌شوند.' );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'سلامت ربات', 'اگر دکمه‌ها در ربات کار نمی‌کنند یا استارت بی‌پاسخ می‌ماند، اینجا را بزنید.', 'shield-alt', 'پیام‌های ورودی از راه «وب‌هوک» به سایت می‌رسند. اگر وب‌هوک ثبت نشده باشد، ربات پیام می‌فرستد ولی هیچ دکمه‌ای کار نمی‌کند.' ); ?>
		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				پیام‌های ورودی از راه «وب‌هوک» به سایت می‌رسند. اگر وب‌هوک ثبت نشده باشد،
				ربات همچنان پیام <em>می‌فرستد</em> و دکمه‌ها روی صفحه دیده می‌شوند، ولی هیچ‌کدام
				کار نمی‌کند؛ چون تلگرام نمی‌تواند فشردن دکمه را به سایت خبر بدهد.
			</div>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-bot-diag">
				<span class="dashicons dashicons-search"></span>
				بررسی وضعیت ربات
			</button>
			<button type="button" class="wcma-btn wcma-btn--secondary wcma-register-hook" data-messenger="<?php echo esc_attr( WCMA_Bot_Manager::channel() ); ?>">
				<span class="dashicons dashicons-update"></span>
				ثبت دوباره‌ی وب‌هوک
			</button>
		</div>

		<div class="wcma-diagnostics" id="wcma-bot-diag-result" hidden></div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پیام شروع', 'وقتی کاربر /start را می‌زند یا اولین بار وارد ربات می‌شود.', 'controls-play' ); ?>
		<?php
		WCMA_Admin_Fields::select( 'tg_welcome_type', 'نوع پیام خوش‌آمد', wp_list_pluck( $wcma_types, 'label' ) );

		WCMA_Admin_Fields::text(
			'tg_welcome_file',
			'نشانی فایل (برای عکس، ویدیو، صوت یا فایل)',
			array( 'placeholder' => 'https://example.com/intro.mp4', 'description' => 'برای پیام متنی خالی بگذارید. نشانی باید عمومی و مستقیم باشد.' )
		);

		WCMA_Admin_Fields::textarea( 'tg_welcome_text', 'متن خوش‌آمد', array( 'rows' => 3 ) );
		?>

		<?php WCMA_Admin_Fields::placeholder_help( array( 'site_title', 'site_url', 'shop_phone', 'start_date', 'start_weekday' ) ); ?>

		<h3 class="wcma-subtitle">گرفتن شماره موبایل</h3>

		<?php
		WCMA_Admin_Fields::toggle( 'tg_ask_phone', 'نمایش دکمه‌ی «اشتراک‌گذاری شماره» در پیام شروع', '', 'دکمه‌ای که با یک لمس شماره‌ی کاربر را می‌گیرد و در پرونده‌ی مشتریان ثبت می‌کند. تا وقتی کاربر شماره ندهد، این دکمه روی کیبوردش می‌ماند.' );
		WCMA_Admin_Fields::text( 'tg_phone_button', 'متن دکمه‌ی اشتراک شماره' );
		WCMA_Admin_Fields::textarea( 'tg_phone_thanks', 'پیام پس از دریافت شماره', array( 'rows' => 2 ) );

		WCMA_Admin_Fields::textarea(
			'tg_known_text',
			'پیام برای کسی که در پنل شناخته شد',
			array(
				'rows'        => 3,
				'description' => 'وقتی شماره‌ای که کاربر می‌دهد از پیش در پرونده‌ی مشتریان (مثلاً از فایل اکسل) با نام ثبت شده باشد، این پیام به‌جای پیام بالا می‌رود. {full_name}، {first_name} و {last_name} از همان پرونده پر می‌شوند. خالی بگذارید تا همان پیام بالا برود.',
			)
		);
		?>

		<?php
		$wcma_keyboard = WCMA_Bot_Manager::keyboard( true );
		$wcma_has_phone_row = false;

		if ( $wcma_keyboard ) {
			foreach ( $wcma_keyboard['keyboard'] as $wcma_row ) {
				foreach ( $wcma_row as $wcma_key_btn ) {
					if ( ! empty( $wcma_key_btn['request_contact'] ) ) {
						$wcma_has_phone_row = true;
					}
				}
			}
		}
		?>

		<div class="wcma-keyboard-preview">
			<span class="wcma-keyboard-preview__title">
				<span class="dashicons dashicons-visibility"></span>
				کیبوردی که کاربر پس از /start می‌بیند
			</span>

			<?php if ( ! $wcma_keyboard ) : ?>
				<p class="wcma-field__desc">هیچ دکمه‌ای تعریف نشده است.</p>
			<?php else : ?>
				<div class="wcma-keyboard-preview__box">
					<?php foreach ( $wcma_keyboard['keyboard'] as $wcma_row ) : ?>
						<div class="wcma-keyboard-preview__row">
							<?php foreach ( $wcma_row as $wcma_key_btn ) : ?>
								<span class="wcma-keyboard-preview__key <?php echo ! empty( $wcma_key_btn['request_contact'] ) ? 'is-phone' : ''; ?>">
									<?php echo esc_html( $wcma_key_btn['text'] ); ?>
								</span>
							<?php endforeach; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! $wcma_has_phone_row ) : ?>
				<div class="wcma-notice wcma-notice--error">
					<span class="dashicons dashicons-warning"></span>
					<span>دکمه‌ی اشتراک شماره در کیبورد نیست. کلید بالا را روشن کنید و مطمئن شوید متن دکمه خالی نیست.</span>
				</div>
			<?php endif; ?>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				شماره‌ای که کاربر می‌فرستد خودکار در
				<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'crm' ) ); ?>">پرونده‌ی مشتریان</a>
				ثبت می‌شود و اگر با حساب فروشگاه بخواند، به همان کاربر وصل می‌گردد.
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پیام‌های آماده', 'پیام را یک بار بسازید — متن، عکس، ویدیو یا فایل، همراه دکمه‌های شیشه‌ای — و بعد آن را به دکمه‌های منو بدهید یا برای مشترکان بفرستید.', 'testimonial', 'هر پیام آماده یک شناسه‌ی ثابت دارد؛ اگر متنش را عوض کنید، همه‌ی دکمه‌هایی که به آن وصل‌اند همان پیام تازه را می‌فرستند.', 'bot-messages' ); ?>
		<?php
		WCMA_Admin_Fields::placeholder_help(
			array( 'site_title', 'site_url', 'shop_phone', 'username', 'phone', 'start_date', 'start_date_long', 'days_since_start', 'phone_date' )
		);

		$wcma_msg_list    = array_values( $wcma_messages );
		$wcma_msg_visible = max( 1, count( $wcma_msg_list ) );
		$wcma_msg_max_btn = WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS;
		?>

		<div class="wcma-canned-list" data-max="<?php echo esc_attr( WCMA_Bot_Manager::MAX_MESSAGES ); ?>">
			<?php for ( $wcma_j = 0; $wcma_j < WCMA_Bot_Manager::MAX_MESSAGES; $wcma_j++ ) : ?>
				<?php
				$wcma_msg      = $wcma_msg_list[ $wcma_j ] ?? array();
				$wcma_msg_id   = $wcma_msg['id'] ?? WCMA_Bot_Manager::new_message_id();
				$wcma_msg_type = $wcma_msg['type'] ?? 'text';
				$wcma_msg_btns = $wcma_msg['buttons'] ?? array();
				$wcma_msg_name = 'wcma[tg_messages][' . $wcma_j . ']';
				?>
				<div class="wcma-canned" data-index="<?php echo esc_attr( $wcma_j ); ?>" <?php echo $wcma_j < $wcma_msg_visible ? '' : 'hidden'; ?>>
					<div class="wcma-canned__head">
						<span class="wcma-canned__icon dashicons dashicons-<?php echo esc_attr( $wcma_types[ $wcma_msg_type ]['icon'] ?? 'editor-alignright' ); ?>"></span>

						<input type="hidden" class="wcma-canned__id" name="<?php echo esc_attr( $wcma_msg_name ); ?>[id]" value="<?php echo esc_attr( $wcma_msg_id ); ?>" />

						<input
							type="text"
							class="wcma-canned__title"
							name="<?php echo esc_attr( $wcma_msg_name ); ?>[title]"
							value="<?php echo esc_attr( $wcma_msg['title'] ?? '' ); ?>"
							placeholder="نام پیام، مثلاً «معرفی دوره» (فقط برای شما)"
						/>

						<select class="wcma-canned__type" name="<?php echo esc_attr( $wcma_msg_name ); ?>[type]">
							<?php foreach ( $wcma_types as $wcma_key => $wcma_type ) : ?>
								<option
									value="<?php echo esc_attr( $wcma_key ); ?>"
									data-icon="<?php echo esc_attr( $wcma_type['icon'] ); ?>"
									<?php selected( $wcma_msg_type, $wcma_key ); ?>
								><?php echo esc_html( $wcma_type['label'] ); ?></option>
							<?php endforeach; ?>
						</select>

						<button type="button" class="wcma-canned__remove" title="پاک کردن این پیام">
							<span class="dashicons dashicons-trash"></span>
						</button>
					</div>

					<div class="wcma-canned__body">
						<input
							type="url"
							class="wcma-canned__file wcma-ltr-input"
							name="<?php echo esc_attr( $wcma_msg_name ); ?>[file]"
							value="<?php echo esc_attr( $wcma_msg['file'] ?? '' ); ?>"
							placeholder="نشانی فایل (برای عکس، ویدیو، صوت یا فایل)"
							dir="ltr"
						/>

						<textarea
							class="wcma-canned__text"
							name="<?php echo esc_attr( $wcma_msg_name ); ?>[text]"
							rows="4"
							placeholder="متن پیام یا توضیح زیر رسانه"
						><?php echo esc_textarea( $wcma_msg['text'] ?? '' ); ?></textarea>

						<div class="wcma-canned__buttons">
							<div class="wcma-canned__buttons-head">
								<span class="wcma-day__buttons-title">
									<span class="dashicons dashicons-screenoptions"></span>
									دکمه‌های شیشه‌ای زیر پیام (اختیاری، تا <?php echo esc_html( WCMA_Date::number( $wcma_msg_max_btn ) ); ?> تا)
								</span>

								<select class="wcma-canned__cols" name="<?php echo esc_attr( $wcma_msg_name ); ?>[cols]">
									<option value="1" <?php selected( (int) ( $wcma_msg['cols'] ?? 1 ), 1 ); ?>>هر دکمه در یک ردیف</option>
									<option value="2" <?php selected( (int) ( $wcma_msg['cols'] ?? 1 ), 2 ); ?>>دو دکمه در هر ردیف</option>
								</select>
							</div>

							<?php for ( $wcma_k = 0; $wcma_k < $wcma_msg_max_btn; $wcma_k++ ) : ?>
								<?php
								$wcma_mbtn  = $wcma_msg_btns[ $wcma_k ] ?? array();
								$wcma_mkind = $wcma_mbtn['kind'] ?? 'url';
								$wcma_mname = $wcma_msg_name . '[buttons][' . $wcma_k . ']';
								?>
								<div class="wcma-canned__button" data-index="<?php echo esc_attr( $wcma_k ); ?>" <?php echo ( $wcma_k > 0 && empty( $wcma_mbtn['label'] ) ) ? 'hidden' : ''; ?>>
									<input
										type="text"
										class="wcma-canned__button-label"
										name="<?php echo esc_attr( $wcma_mname ); ?>[label]"
										value="<?php echo esc_attr( $wcma_mbtn['label'] ?? '' ); ?>"
										placeholder="متن دکمه"
									/>

									<select class="wcma-canned__button-kind" name="<?php echo esc_attr( $wcma_mname ); ?>[kind]">
										<?php foreach ( $wcma_kinds as $wcma_kind_key => $wcma_kind_label ) : ?>
											<option value="<?php echo esc_attr( $wcma_kind_key ); ?>" <?php selected( $wcma_mkind, $wcma_kind_key ); ?>><?php echo esc_html( $wcma_kind_label ); ?></option>
										<?php endforeach; ?>
									</select>

									<input
										type="url"
										class="wcma-canned__button-url wcma-ltr-input"
										name="<?php echo esc_attr( $wcma_mname ); ?>[url]"
										value="<?php echo esc_attr( $wcma_mbtn['url'] ?? '' ); ?>"
										placeholder="https://example.com/product"
										dir="ltr"
										<?php echo 'message' === $wcma_mkind ? 'hidden' : ''; ?>
									/>

									<select
										class="wcma-canned-select wcma-canned__button-message"
										name="<?php echo esc_attr( $wcma_mname ); ?>[message]"
										<?php echo 'message' === $wcma_mkind ? '' : 'hidden'; ?>
									>
										<?php $wcma_msg_select( array_diff_key( $wcma_msg_options, array( $wcma_msg_id => true ) ), $wcma_mbtn['message'] ?? '' ); ?>
									</select>

									<button type="button" class="wcma-btn wcma-btn--ghost wcma-canned__button-remove" title="حذف این دکمه">
										<span class="dashicons dashicons-no-alt"></span>
									</button>
								</div>
							<?php endfor; ?>

							<button type="button" class="wcma-btn wcma-btn--ghost wcma-canned__button-add">
								<span class="dashicons dashicons-plus-alt2"></span>
								افزودن دکمه
							</button>
						</div>
					</div>
				</div>
			<?php endfor; ?>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-add-message">
				<span class="dashicons dashicons-plus-alt2"></span>
				افزودن پیام آماده
			</button>
			<span class="wcma-field__desc" id="wcma-message-count"></span>
		</div>

		<p class="wcma-field__desc">
			پیامی که نه متن دارد نه فایل، ذخیره نمی‌شود. دکمه‌ی «نمایش یک پیام آماده‌ی دیگر» پیام انتخاب‌شده را
			همان‌جا در ربات می‌فرستد؛ پس می‌توانید با چند پیام آماده، یک منوی تو در تو بسازید. پیامی که دکمه‌ی
			شیشه‌ای ندارد، منوی اصلی ربات را زیر خودش نشان می‌دهد.
		</p>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'منوی دکمه‌های ربات', 'این دکمه‌ها زیر کادر تایپ کاربر نمایش داده می‌شوند. برای هر دکمه بگویید با فشردنش چه شود؛ مثلاً یکی از پیام‌های آماده‌ی بالا فرستاده شود.', 'menu' ); ?>
		<?php
		WCMA_Admin_Fields::select(
			'tg_menu_cols',
			'چند دکمه در هر ردیف؟',
			array(
				'1' => 'یک دکمه (پهن، برای برچسب‌های بلند)',
				'2' => 'دو دکمه',
				'3' => 'سه دکمه (برای برچسب‌های کوتاه)',
			)
		);

		// ردیف‌های پرشده به‌علاوه‌ی یک ردیف خالی؛ بقیه با دکمه‌ی «افزودن» نمایان می‌شوند.
		$wcma_filled  = count( $wcma_menu );
		$wcma_visible = max( 1, min( WCMA_Bot_Manager::MAX_BUTTONS, $wcma_filled + 1 ) );

		$wcma_icons = array(
			'reply'   => 'format-status',
			'message' => 'testimonial',
			'phone'   => 'smartphone',
			'link'    => 'admin-links',
			'day'     => 'calendar-alt',
			'stop'    => 'dismiss',
			'restart' => 'update',
		);
		?>

		<div class="wcma-botmenu" data-max="<?php echo esc_attr( WCMA_Bot_Manager::MAX_BUTTONS ); ?>">
			<?php for ( $wcma_i = 0; $wcma_i < WCMA_Bot_Manager::MAX_BUTTONS; $wcma_i++ ) : ?>
				<?php
				$wcma_button = $wcma_menu[ $wcma_i ] ?? array();
				$wcma_action = $wcma_button['action'] ?? 'reply';
				?>
				<div class="wcma-botmenu__row" data-index="<?php echo esc_attr( $wcma_i ); ?>" <?php echo $wcma_i < $wcma_visible ? '' : 'hidden'; ?>>
					<span class="wcma-botmenu__num"><?php echo esc_html( WCMA_Date::number( $wcma_i + 1 ) ); ?></span>

					<span class="wcma-botmenu__icon dashicons dashicons-<?php echo esc_attr( $wcma_icons[ $wcma_action ] ?? 'format-status' ); ?>"></span>

					<input
						type="text"
						name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][label]"
						value="<?php echo esc_attr( $wcma_button['label'] ?? '' ); ?>"
						placeholder="متن روی دکمه"
						class="wcma-botmenu__label"
					/>

					<select name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][action]" class="wcma-botmenu__action">
						<?php foreach ( $wcma_actions as $wcma_key => $wcma_label ) : ?>
							<option
								value="<?php echo esc_attr( $wcma_key ); ?>"
								data-icon="<?php echo esc_attr( $wcma_icons[ $wcma_key ] ?? 'format-status' ); ?>"
								<?php selected( $wcma_action, $wcma_key ); ?>
							><?php echo esc_html( $wcma_label ); ?></option>
						<?php endforeach; ?>
					</select>

					<input
						type="text"
						name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][value]"
						value="<?php echo esc_attr( $wcma_button['value'] ?? '' ); ?>"
						placeholder="متن پاسخ، نشانی لینک یا شماره‌ی روز"
						class="wcma-botmenu__value"
						<?php echo 'message' === $wcma_action ? 'hidden' : ''; ?>
					/>

					<select
						name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][message]"
						class="wcma-canned-select wcma-botmenu__message"
						<?php echo 'message' === $wcma_action ? '' : 'hidden'; ?>
					>
						<?php $wcma_msg_select( $wcma_msg_options, $wcma_button['message'] ?? '' ); ?>
					</select>

					<button type="button" class="wcma-botmenu__remove" title="پاک کردن این دستور">
						<span class="dashicons dashicons-trash"></span>
					</button>
				</div>
			<?php endfor; ?>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-add-command">
				<span class="dashicons dashicons-plus-alt2"></span>
				افزودن دستور تازه
			</button>
			<span class="wcma-field__desc" id="wcma-command-count"></span>
		</div>

		<p class="wcma-field__desc">
			دکمه‌ی بدون متن ذخیره نمی‌شود. برای «ارسال یک پیام آماده»، پیام را از فهرست کنارش انتخاب کنید.
			برای «ارسال پیام یک روز مشخص»، در ستون آخر فقط شماره‌ی روز
			را بنویسید (مثلاً <code>۳</code>). حداکثر
			<?php echo esc_html( WCMA_Date::number( WCMA_Bot_Manager::MAX_BUTTONS ) ); ?>
			دستور می‌توانید تعریف کنید.
		</p>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'دنباله‌ی پیام‌های روزانه', 'هر مشترک از روز عضویتش، هر روز یک پیام در ساعت تعیین‌شده دریافت می‌کند.', 'calendar-alt', 'هر روز یا «چند روز پس از شروعِ هر مشترک» می‌رود، یا «در تاریخ مشخص» که برای همه یکی است. روز خاموش رد می‌شود.' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'tg_seq_enabled', 'فعال بودن دنباله‌ی روزانه', '', 'هر مشترک از روز عضویتش، روزی یک پیام می‌گیرد. برای دوره‌های چندروزه و پرورش سرنخ ساخته شده است.' );
		WCMA_Admin_Fields::toggle( 'tg_seq_first_now', 'پیام روز یک بی‌درنگ پس از عضویت فرستاده شود', '', 'اگر خاموش باشد، پیام روز یک تا ساعت تعیین‌شده صبر می‌کند. روشن بودنش تجربه‌ی بهتری می‌دهد چون کاربر بی‌درنگ چیزی دریافت می‌کند.' );

		WCMA_Admin_Fields::text(
			'tg_seq_time',
			'ساعت پیش‌فرض ارسال',
			array( 'type' => 'time', 'description' => 'برای روزهایی که ساعت جداگانه‌ای برایشان تعیین نکرده‌اید.' )
		);
		?>

		<?php
		WCMA_Admin_Fields::placeholder_help(
			array(
				'site_title', 'site_url', 'shop_phone', 'coupon_code',
				'day', 'day_of_journey', 'days_since_start', 'start_date', 'start_date_long', 'start_weekday',
				'phone_date', 'phone_date_long', 'days_since_phone', 'total_days', 'remaining_days',
				'username', 'sent_count',
			)
		);
		?>

		<div class="wcma-days">
			<?php for ( $wcma_d = 1; $wcma_d <= $wcma_rows; $wcma_d++ ) : ?>
				<?php
				$wcma_item = $wcma_sequence[ $wcma_d ] ?? array();
				$wcma_on   = ! empty( $wcma_item['active'] );
				?>
				<div
					class="wcma-day <?php echo $wcma_on ? 'is-active' : ''; ?>"
					data-day="<?php echo esc_attr( $wcma_d ); ?>"
					<?php echo ( $wcma_d > $wcma_open ) ? 'hidden' : ''; ?>
				>
					<div class="wcma-day__head">
						<label class="wcma-switch">
							<input type="hidden" name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][active]" value="" />
							<input
								type="checkbox"
								class="wcma-day__toggle"
								name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][active]"
								value="yes"
								<?php checked( $wcma_on ); ?>
							/>
							<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
						</label>

						<span class="wcma-day__icon dashicons dashicons-<?php echo esc_attr( $wcma_types[ $wcma_item['type'] ?? 'text' ]['icon'] ?? 'editor-alignright' ); ?>"></span>

						<strong>روز <?php echo esc_html( WCMA_Date::number( $wcma_d ) ); ?></strong>

						<input type="hidden" name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][day]" value="<?php echo esc_attr( $wcma_d ); ?>" />

						<?php $wcma_mode = $wcma_item['mode'] ?? 'offset'; ?>

						<select name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][mode]" class="wcma-day__mode">
							<option value="offset" <?php selected( $wcma_mode, 'offset' ); ?>>روز <?php echo esc_html( WCMA_Date::number( $wcma_d ) ); ?> پس از شروع</option>
							<option value="date" <?php selected( $wcma_mode, 'date' ); ?>>در تاریخ مشخص</option>
						</select>

						<span class="wcma-day__date" <?php echo ( 'date' === $wcma_mode ) ? '' : 'hidden'; ?>>
							<input
								type="date"
								data-wcma-jalali
								name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][date]"
								value="<?php echo esc_attr( $wcma_item['date'] ?? '' ); ?>"
								class="wcma-date-input"
								title="تاریخ ارسال این روز"
							/>
						</span>

						<span class="wcma-day__time">
							ساعت
							<input
								type="time"
								name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][time]"
								value="<?php echo esc_attr( $wcma_item['time'] ?? WCMA_Settings::get( 'tg_seq_time', '10:00' ) ); ?>"
							/>
						</span>

						<button type="button" class="wcma-day__remove" title="برداشتن این روز">
							<span class="dashicons dashicons-trash"></span>
						</button>

						<select name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][type]" class="wcma-day__type">
							<?php foreach ( $wcma_types as $wcma_key => $wcma_type ) : ?>
								<option
									value="<?php echo esc_attr( $wcma_key ); ?>"
									data-icon="<?php echo esc_attr( $wcma_type['icon'] ); ?>"
									<?php selected( $wcma_item['type'] ?? 'text', $wcma_key ); ?>
								><?php echo esc_html( $wcma_type['label'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="wcma-day__body">
						<input
							type="url"
							name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][file]"
							value="<?php echo esc_attr( $wcma_item['file'] ?? '' ); ?>"
							placeholder="نشانی فایل (برای عکس، ویدیو، صوت یا فایل)"
							dir="ltr"
							class="wcma-ltr-input"
						/>

						<textarea
							name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][text]"
							rows="3"
							placeholder="متن پیام یا توضیح زیر رسانه"
						><?php echo esc_textarea( $wcma_item['text'] ?? '' ); ?></textarea>

						<?php
						// ساختار قدیمیِ تک‌دکمه‌ای هم به همین فهرست می‌آید تا چیزی گم نشود.
						$wcma_day_buttons = WCMA_Bot_Manager::day_buttons( $wcma_item );
						$wcma_max_btn     = WCMA_Bot_Manager::MAX_DAY_BUTTONS;
						?>

						<div class="wcma-day__buttons" data-max="<?php echo esc_attr( $wcma_max_btn ); ?>">
							<span class="wcma-day__buttons-title">
								<span class="dashicons dashicons-admin-links"></span>
								دکمه‌های زیر پیام (اختیاری، تا <?php echo esc_html( WCMA_Date::number( $wcma_max_btn ) ); ?> تا)
							</span>

							<?php for ( $wcma_b = 0; $wcma_b < $wcma_max_btn; $wcma_b++ ) : ?>
								<?php
								$wcma_btn  = $wcma_day_buttons[ $wcma_b ] ?? array();
								$wcma_used = ! empty( $wcma_btn['label'] );
								?>
								<div class="wcma-day__button" data-index="<?php echo esc_attr( $wcma_b ); ?>" <?php echo ( $wcma_b > 0 && ! $wcma_used ) ? 'hidden' : ''; ?>>
									<input
										type="text"
										name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][buttons][<?php echo esc_attr( $wcma_b ); ?>][label]"
										value="<?php echo esc_attr( $wcma_btn['label'] ?? '' ); ?>"
										placeholder="متن دکمه"
									/>
									<input
										type="url"
										name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][buttons][<?php echo esc_attr( $wcma_b ); ?>][url]"
										value="<?php echo esc_attr( $wcma_btn['url'] ?? '' ); ?>"
										placeholder="https://example.com/product"
										dir="ltr"
										class="wcma-ltr-input"
									/>
									<button type="button" class="wcma-btn wcma-btn--ghost wcma-day__button-remove" title="حذف این دکمه">
										<span class="dashicons dashicons-no-alt"></span>
									</button>
								</div>
							<?php endfor; ?>

							<button type="button" class="wcma-btn wcma-btn--ghost wcma-day__button-add">
								<span class="dashicons dashicons-plus-alt2"></span>
								افزودن دکمه
							</button>
						</div>
					</div>
				</div>
			<?php endfor; ?>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-add-day">
				<span class="dashicons dashicons-plus-alt2"></span>
				افزودن روز تازه
			</button>
			<span class="wcma-field__desc" id="wcma-day-count"></span>
		</div>

		<p class="wcma-field__desc">
			هر روز می‌تواند «چند روز پس از شروعِ هر مشترک» بفرستد (هر کسی از روز عضویت خودش
			می‌شمارد) یا «در تاریخ مشخص» که برای همه یک روز ثابت است — مثل اطلاعیه یا جشنواره.
			روزی که خاموش باشد رد می‌شود و دنباله به روز بعد می‌رود.
		</p>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php
$wcma_admins       = WCMA_Bot_Admin::current_admins();
$wcma_bot_username = ltrim( trim( (string) WCMA_Settings::get( $wcma_channel . '_bot_username' ) ), '@' );

WCMA_Admin_Fields::card_start(
	'مدیران ربات در تلگرام',
	'حساب‌هایی که از درون خودِ ربات مدیریتش می‌کنند: آمار، پیام همگانی با عکس و ویدیو، پیام آماده، جستجوی مشترک، پیام مستقیم و ورود مخاطبان با فرستادن فایل اکسل.',
	'shield',
	'مدیر در ربات دکمه‌ی «' . WCMA_Bot_Admin::ENTRY . '» را می‌بیند یا /admin می‌زند. فرمان‌های مدیریتی فقط در گفتگوی خصوصی با ربات کار می‌کنند.',
	'bot-admins'
);
?>
	<?php if ( $wcma_admins ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table" id="wcma-admins">
				<thead>
					<tr>
						<th>مدیر</th>
						<th>شناسه‌ی چت</th>
						<th>از</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_admins as $wcma_admin_key => $wcma_admin ) : ?>
						<tr>
							<td>
								<?php echo esc_html( '' !== $wcma_admin['name'] ? $wcma_admin['name'] : 'بی‌نام' ); ?>
								<?php if ( ! empty( $wcma_admin['telegram'] ) ) : ?>
									<small dir="auto">در تلگرام: <?php echo esc_html( $wcma_admin['telegram'] ); ?></small>
								<?php endif; ?>
							</td>
							<td dir="ltr" class="wcma-ltr"><?php echo esc_html( $wcma_admin['chat_id'] ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_admin['added_at'], 'date' ); ?></td>
							<td>
								<button type="button" class="wcma-btn wcma-btn--tiny wcma-admin-remove" data-key="<?php echo esc_attr( $wcma_admin_key ); ?>">برداشتن</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-empty wcma-empty--small">هنوز مدیری تعیین نشده است.</p>
	<?php endif; ?>

	<h3 class="wcma-subtitle">افزودن مدیر</h3>

	<div class="wcma-sim">
		<input type="text" id="wcma-admin-who" placeholder="شماره‌ی موبایل، شناسه‌ی چت یا نام کاربری (با @)" />
		<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-admin-add">
			<span class="dashicons dashicons-plus-alt2"></span>
			مدیر شود
		</button>
	</div>
	<p class="wcma-field__desc">
		کسی که ربات را باز کرده و شماره‌اش را داده، با شماره‌اش پیدا می‌شود. می‌توانید از جدول «مشترکان ربات» در پایین هم کنار نام هر کس «مدیر کن» را بزنید.
	</p>

	<h3 class="wcma-subtitle">یا با لینک دعوت</h3>

	<div class="wcma-actions">
		<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-admin-invite">
			<span class="dashicons dashicons-admin-links"></span>
			ساختن لینک دعوت یک‌بارمصرف
		</button>
	</div>
	<div id="wcma-admin-invite-result" hidden></div>
	<p class="wcma-field__desc">
		لینک را برای همکارتان بفرستید؛ با باز کردنش ربات او را مدیر می‌کند. هر لینک فقط یک‌بار و تا ۲۴ ساعت کار می‌کند.
		<?php if ( '' === $wcma_bot_username ) : ?>
			برای ساختن لینک، نام کاربری ربات را در تب <a href="<?php echo esc_url( WCMA_Admin::tab_url( 'sms' ) ); ?>">کانال‌های ارتباطی</a> وارد کنید؛ تا آن موقع، همکارتان می‌تواند فرمانی را که نمایش داده می‌شود در ربات بفرستد.
		<?php endif; ?>
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'ارسال پیام آماده', 'یکی از پیام‌های آماده را برای همه‌ی مشترکان ربات یا گروهی از آن‌ها بفرستید؛ همین حالا یا در زمانی که تعیین می‌کنید.', 'megaphone', 'ارسال تکه‌تکه و با سرعتی زیر سقف تلگرام انجام می‌شود. تا این برگه باز است پیشرفت را همین‌جا می‌بینید؛ اگر ببندیدش، ارسال در پس‌زمینه (هر چند دقیقه یک‌بار) ادامه پیدا می‌کند.', 'bot-broadcast' ); ?>
	<?php if ( ! WCMA_Bot_Broadcast::ready() ) : ?>
		<div class="wcma-notice wcma-notice--error">
			<span class="dashicons dashicons-warning"></span>
			<span>جدول ارسال‌های ربات ساخته نشده است. به تب «تست ارسال» بروید و «ترمیم جدول‌ها» را بزنید.</span>
		</div>
	<?php endif; ?>

	<div class="wcma-broadcast" id="wcma-broadcast" data-running="<?php echo esc_attr( WCMA_Bot_Broadcast::running_id() ); ?>">
		<div class="wcma-broadcast__grid">
			<label class="wcma-broadcast__field">
				<span>کدام پیام؟</span>
				<select id="wcma-bc-message" class="wcma-canned-select">
					<?php $wcma_msg_select( $wcma_msg_options, (string) key( $wcma_msg_options ) ); ?>
				</select>
			</label>

			<label class="wcma-broadcast__field">
				<span>برای چه کسانی؟</span>
				<select id="wcma-bc-audience">
					<?php foreach ( WCMA_Bot_Broadcast::audiences() as $wcma_aud_key => $wcma_aud_label ) : ?>
						<option value="<?php echo esc_attr( $wcma_aud_key ); ?>">
							<?php echo esc_html( sprintf( '%s — %s نفر', $wcma_aud_label, WCMA_Date::number( WCMA_Bot_Broadcast::count( $wcma_aud_key, $wcma_channel ) ) ) ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</label>

			<label class="wcma-broadcast__field">
				<span>زمان ارسال (خالی یعنی همین حالا)</span>
				<input type="datetime-local" id="wcma-bc-when" data-wcma-jalali title="زمان ارسال" />
			</label>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-bc-start">
				<span class="dashicons dashicons-megaphone"></span>
				ارسال به مشترکان
			</button>
		</div>

		<div class="wcma-sim wcma-broadcast__test">
			<input type="text" id="wcma-bc-chat" dir="ltr" placeholder="شناسه‌ی چت شما برای ارسال آزمایشی (مثلاً 123456789)" />
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-bc-test">
				<span class="dashicons dashicons-controls-play"></span>
				ارسال آزمایشی به همین چت
			</button>
		</div>

		<div id="wcma-bc-result"></div>
	</div>

	<?php $wcma_jobs = WCMA_Bot_Broadcast::recent( 10 ); ?>

	<h3 class="wcma-subtitle">ارسال‌های اخیر</h3>

	<div class="wcma-empty" id="wcma-bc-empty" <?php echo $wcma_jobs ? 'hidden' : ''; ?>>
		<span class="dashicons dashicons-megaphone"></span>
		<p>هنوز پیامی به‌صورت گروهی فرستاده نشده است.</p>
	</div>

	<div class="wcma-table-wrap" <?php echo $wcma_jobs ? '' : 'hidden'; ?>>
		<table class="wcma-table" id="wcma-bc-jobs">
			<thead>
				<tr>
					<th>پیام</th>
					<th>مخاطب</th>
					<th>وضعیت</th>
					<th>پیشرفت</th>
					<th>رسید</th>
					<th>نرسید</th>
					<th>زمان</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wcma_jobs as $wcma_job_row ) : ?>
					<?php $wcma_job = WCMA_Bot_Broadcast::view( $wcma_job_row ); ?>
					<tr data-id="<?php echo esc_attr( $wcma_job['id'] ); ?>">
						<td><?php echo esc_html( $wcma_job['title'] ); ?></td>
						<td class="wcma-bc-audience"><?php echo esc_html( $wcma_job['audience'] ); ?></td>
						<td><span class="wcma-badge wcma-bc-status <?php echo esc_attr( $wcma_job['badge'] ); ?>"><?php echo esc_html( $wcma_job['label'] ); ?></span></td>
						<td>
							<div class="wcma-progress"><span class="wcma-bc-bar" style="width: <?php echo esc_attr( $wcma_job['percent'] ); ?>%"></span></div>
							<small class="wcma-bc-total"><?php echo esc_html( $wcma_job['progress'] ); ?></small>
						</td>
						<td class="wcma-bc-sent"><?php echo esc_html( $wcma_job['sent'] ); ?></td>
						<td class="wcma-bc-failed" title="<?php echo esc_attr( $wcma_job['error'] ); ?>"><?php echo esc_html( $wcma_job['failed'] ); ?></td>
						<td class="wcma-nowrap"><?php echo esc_html( $wcma_job['start'] ); ?></td>
						<td>
							<button type="button" class="wcma-btn wcma-btn--tiny wcma-bc-cancel" data-id="<?php echo esc_attr( $wcma_job['id'] ); ?>" <?php echo $wcma_job['active'] ? '' : 'hidden'; ?>>لغو</button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<p class="wcma-field__desc">
		کسی که دریافت پیام روزانه را با دکمه‌ی «لغو» قطع کرده، فقط در گروه «همه» پیام می‌گیرد. کسی که ربات را
		بسته (Block کرده)، خودکار کنار گذاشته می‌شود و هر وقت دوباره به ربات پیام بدهد، برمی‌گردد.
		نشانگر را روی عدد «نرسید» نگه دارید تا آخرین خطا را ببینید.
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'آزمودن ربات', 'پیام یک روز مشخص را برای یک شناسه‌ی چت بفرستید تا پیش از شروع، از درستی آن مطمئن شوید.', 'controls-play' ); ?>
	<div class="wcma-sim">
		<input type="text" id="wcma-bot-chat" dir="ltr" placeholder="شناسه‌ی چت شما (مثلاً 123456789)" />
		<input type="number" id="wcma-bot-day" min="1" max="<?php echo esc_attr( WCMA_Bot_Manager::MAX_DAYS ); ?>" value="1" />
		<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-bot-test">
			<span class="dashicons dashicons-controls-play"></span>
			ارسال آزمایشی
		</button>
	</div>
	<div id="wcma-bot-test-result"></div>

	<p class="wcma-field__desc">
		شناسه‌ی چت خود را می‌توانید با فرستادن یک پیام به ربات و دیدن آن در تب
		<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'chat' ) ); ?>">گفتگو</a> پیدا کنید.
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'مشترکان ربات', 'کسانی که ربات را شروع کرده‌اند و جایگاهشان در دنباله.', 'groups' ); ?>
	<?php
	$wcma_subs = WCMA_Bot_Manager::subscribers(
		array(
			'per_page' => WCMA_Admin::per_page( 's_per' ),
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'page'     => isset( $_GET['spage'] ) ? max( 1, (int) $_GET['spage'] ) : 1,
		)
	);

	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 's_per',
			'current' => WCMA_Admin::per_page( 's_per' ),
			'total'   => (int) $wcma_subs['total'],
		)
	);
	?>

	<?php if ( $wcma_subs['items'] ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>نام</th>
						<th>شناسه‌ی چت</th>
						<th>موبایل</th>
						<th>وضعیت</th>
						<th>روز فعلی</th>
						<th>آخرین ارسال</th>
						<th>عضویت</th>
						<th>پرونده در پنل</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_subs['items'] as $wcma_sub ) : ?>
						<?php
						$wcma_states = array(
							'active'  => array( 'در حال دریافت', 'wcma-badge--green' ),
							'done'    => array( 'پایان‌یافته', 'wcma-badge--blue' ),
							'stopped' => array( 'لغو شده', 'wcma-badge--gray' ),
							'blocked' => array( 'ربات را بسته', 'wcma-badge--red' ),
						);

						$wcma_state = $wcma_states[ $wcma_sub['status'] ] ?? array( $wcma_sub['status'], 'wcma-badge--gray' );
						?>
						<tr>
							<td>
								<?php echo esc_html( $wcma_sub['name'] ? $wcma_sub['name'] : 'بدون نام' ); ?>
								<?php if ( $wcma_sub['username'] ) : ?>
									<small dir="ltr">@<?php echo esc_html( $wcma_sub['username'] ); ?></small>
								<?php endif; ?>
							</td>
							<td dir="ltr" class="wcma-ltr"><?php echo esc_html( $wcma_sub['chat_id'] ); ?></td>
							<td dir="ltr"><?php echo esc_html( $wcma_sub['phone'] ? WCMA_Date::digits( $wcma_sub['phone'] ) : '—' ); ?></td>
							<td><span class="wcma-badge <?php echo esc_attr( $wcma_state[1] ); ?>"><?php echo esc_html( $wcma_state[0] ); ?></span></td>
							<td><?php echo esc_html( WCMA_Date::number( $wcma_sub['day_sent'] ) ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_sub['last_sent_at'] ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_sub['started_at'], 'date' ); ?></td>
							<td>
								<?php $wcma_sub_contact = ! empty( $wcma_sub['contact_id'] ) ? WCMA_CRM::get( (int) $wcma_sub['contact_id'] ) : null; ?>
								<?php if ( $wcma_sub_contact ) : ?>
									<a href="<?php echo esc_url( add_query_arg( array( 'contact' => (int) $wcma_sub_contact['id'] ), WCMA_Admin::tab_url( 'crm' ) ) ); ?>">
										<?php echo esc_html( WCMA_CRM::display_name( $wcma_sub_contact ) ); ?>
									</a>
								<?php else : ?>
									<span class="wcma-field__desc">ناشناس</span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( WCMA_Bot_Admin::is_admin( $wcma_sub['channel'], $wcma_sub['chat_id'] ) ) : ?>
									<span class="wcma-badge wcma-badge--blue">مدیر ربات</span>
								<?php elseif ( $wcma_sub['channel'] === $wcma_channel && 'blocked' !== $wcma_sub['status'] ) : ?>
									<button type="button" class="wcma-btn wcma-btn--tiny wcma-make-admin" data-chat="<?php echo esc_attr( $wcma_sub['chat_id'] ); ?>">مدیر کن</button>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'spage',
				'current' => (int) ( $wcma_subs['page'] ?? 1 ),
				'pages'   => (int) ( $wcma_subs['pages'] ?? 1 ),
			)
		);
		?>
	<?php else : ?>
		<div class="wcma-empty">
			<span class="dashicons dashicons-groups"></span>
			<p>هنوز کسی ربات را شروع نکرده است. لینک ربات را در سایت و شبکه‌های اجتماعی خود بگذارید.</p>
		</div>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
