<?php
/**
 * کلاس اصلی افزونه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Plugin
 */
final class WCMA_Plugin {

	/**
	 * نمونه‌ی یکتا.
	 *
	 * @var WCMA_Plugin|null
	 */
	protected static $instance = null;

	/**
	 * ورک‌فلوهای ثبت‌شده.
	 *
	 * @var WCMA_Workflow[]
	 */
	protected $workflows = array();

	/**
	 * دریافت نمونه.
	 *
	 * @return WCMA_Plugin
	 */
	/**
	 * نسخه‌ی یک فایل ایستا، بر پایه‌ی زمان تغییر خودش.
	 *
	 * نسخه‌ی افزونه بین به‌روزرسانی‌ها ثابت می‌ماند و مرورگر (و افزونه‌های کش و
	 * CDN) همان CSS و JS قدیمی را نگه می‌داشتند؛ نتیجه این بود که کد تازه‌ی
	 * سرور با اسکریپت کهنه‌ی مرورگر اجرا می‌شد و دکمه‌های تازه هیچ کاری
	 * نمی‌کردند. با زمان تغییرِ خود فایل، نشانی هر بار که فایل عوض شود تازه است.
	 *
	 * @param string $relative مسیر نسبی از ریشه‌ی افزونه.
	 * @return string
	 */
	public static function asset_version( $relative ) {
		$path = WCMA_PATH . ltrim( $relative, '/' );
		$time = file_exists( $path ) ? filemtime( $path ) : 0;

		return $time ? WCMA_VERSION . '.' . $time : WCMA_VERSION;
	}

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * سازنده.
	 */
	protected function __construct() {
		$this->includes();
		$this->init();
	}

	/**
	 * بارگذاری فایل‌ها.
	 */
	protected function includes() {
		$files = array(
			'includes/class-wcma-settings.php',
			'includes/class-wcma-date.php',
			'includes/class-wcma-logger.php',
			'includes/class-wcma-subscribers.php',
			'includes/class-wcma-placeholders.php',
			'includes/class-wcma-coupons.php',
			'includes/class-wcma-queue.php',
			'includes/class-wcma-carts.php',
			'includes/class-wcma-stock-alerts.php',
			'includes/class-wcma-vip.php',
			'includes/class-wcma-crm.php',
			'includes/class-wcma-contacts-import.php',
			'includes/class-wcma-chatbot.php',
			'includes/class-wcma-chat-files.php',
			'includes/class-wcma-livechat.php',
			'includes/class-wcma-cron.php',
			'includes/class-wcma-ai.php',
			'includes/channels/class-wcma-sms-gateways.php',
			'includes/channels/class-wcma-messengers.php',
			'includes/channels/class-wcma-bot-link.php',
			'includes/channels/class-wcma-bot-link-ui.php',
			'includes/channels/class-wcma-bot-manager.php',
			'includes/channels/class-wcma-bot-staff.php',
			'includes/channels/class-wcma-bot-broadcast.php',
			'includes/channels/class-wcma-bot-admin.php',
			'includes/channels/class-wcma-sender.php',
			'includes/workflows/class-wcma-workflow.php',
			'includes/workflows/class-wcma-workflow-abandoned.php',
			'includes/workflows/class-wcma-workflow-review-reminder.php',
			'includes/workflows/class-wcma-workflow-review-reward.php',
			'includes/workflows/class-wcma-workflow-winback.php',
			'includes/workflows/class-wcma-workflow-stock-alert.php',
			'includes/workflows/class-wcma-workflow-vip.php',
			'includes/workflows/class-wcma-workflow-birthday.php',
			'includes/workflows/class-wcma-workflow-order-status.php',
			'includes/class-wcma-campaigns.php',
			'includes/class-wcma-health.php',
			'includes/class-wcma-lead-magnet.php',
			'includes/class-wcma-app-users.php',
			'includes/class-wcma-app-route.php',
			'includes/class-wcma-agent-api.php',
			'includes/class-wcma-smtp.php',
			'includes/class-wcma-followups.php',
			'includes/class-wcma-otp.php',
			'includes/class-wcma-accounts.php',
			'includes/class-wcma-wallet.php',
			'includes/class-wcma-tickets.php',
			'includes/class-wcma-panel.php',
		);

		foreach ( $files as $file ) {
			require_once WCMA_PATH . $file;
		}

		if ( is_admin() ) {
			require_once WCMA_PATH . 'includes/admin/class-wcma-admin.php';
		}
	}

	/**
	 * راه‌اندازی اجزا.
	 */
	protected function init() {
		WCMA_Install::maybe_upgrade();

		WCMA_Cron::init();
		WCMA_Carts::init();
		WCMA_Subscribers::init();
		WCMA_Campaigns::init();
		WCMA_Bot_Link::init();
		WCMA_Bot_Link_UI::init();
		WCMA_Bot_Manager::init();
		WCMA_Bot_Staff::init();
		WCMA_Bot_Broadcast::init();
		WCMA_Bot_Admin::init();
		WCMA_Stock_Alerts::init();
		WCMA_VIP::init();
		WCMA_CRM::init();
		WCMA_Chatbot::init();
		WCMA_Chat_Files::init();
		WCMA_LiveChat::init();
		WCMA_SMTP::init();
		WCMA_Followups::init();
		WCMA_OTP::init();
		WCMA_Accounts::init();
		WCMA_Wallet::init();
		WCMA_Tickets::init();
		WCMA_Panel::init();
		WCMA_Lead_Magnet::init();
		WCMA_Agent_API::init();
		WCMA_App_Route::init();

		$this->register_workflows();

		add_filter( 'wcma_process_queue_job', array( $this, 'handle_campaign_job' ), 10, 3 );
		add_filter( 'plugin_action_links_' . WCMA_BASENAME, array( $this, 'plugin_action_links' ) );

		if ( is_admin() ) {
			new WCMA_Admin();
		}

		/**
		 * پس از آماده شدن کامل افزونه.
		 *
		 * @param WCMA_Plugin $plugin نمونه.
		 */
		do_action( 'wcma_loaded', $this );
	}

	/**
	 * ثبت ورک‌فلوها.
	 */
	protected function register_workflows() {
		$classes = array(
			'WCMA_Workflow_Abandoned',
			'WCMA_Workflow_Review_Reminder',
			'WCMA_Workflow_Review_Reward',
			'WCMA_Workflow_Winback',
			'WCMA_Workflow_Stock_Alert',
			'WCMA_Workflow_VIP',
			'WCMA_Workflow_Birthday',
			'WCMA_Workflow_Order_Status',
		);

		/**
		 * فیلتر فهرست کلاس‌های ورک‌فلو.
		 *
		 * @param array $classes کلاس‌ها.
		 */
		$classes = apply_filters( 'wcma_workflow_classes', $classes );

		foreach ( $classes as $class ) {
			if ( class_exists( $class ) ) {
				$workflow = new $class();
				$this->workflows[ $workflow->get_id() ] = $workflow;
			}
		}
	}

	/**
	 * دریافت یک ورک‌فلو.
	 *
	 * @param string $id شناسه.
	 * @return WCMA_Workflow|null
	 */
	public function get_workflow( $id ) {
		return $this->workflows[ $id ] ?? null;
	}

	/**
	 * دریافت همه‌ی ورک‌فلوها.
	 *
	 * @return WCMA_Workflow[]
	 */
	public function get_workflows() {
		return $this->workflows;
	}

	/**
	 * پردازش کارهای صف مربوط به کمپین.
	 *
	 * @param bool|null $handled وضعیت.
	 * @param array     $job     کار.
	 * @param array     $payload داده.
	 * @return bool|null
	 */
	public function handle_campaign_job( $handled, $job, $payload ) {
		if ( 'campaign' === $job['workflow'] ) {
			return WCMA_Campaigns::send_job( $job, $payload );
		}

		return $handled;
	}

	/**
	 * افزودن لینک تنظیمات در فهرست افزونه‌ها.
	 *
	 * @param array $links لینک‌ها.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$settings = '<a href="' . esc_url( admin_url( 'admin.php?page=wcma' ) ) . '">تنظیمات</a>';
		array_unshift( $links, $settings );

		return $links;
	}
}
