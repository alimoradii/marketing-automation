/**
 * پنل مدیریت ارتباط با مشتریان کلاسیکا.
 *
 * با «رمز اپلیکیشن» وردپرس به REST سایت وصل می‌شود. هیچ داده‌ی مشتری روی
 * دستگاه ذخیره نمی‌شود؛ فقط نشانی سایت و اعتبار ورود.
 */
( function () {
	'use strict';

	var STORE = 'wcma-agent-auth';
	var POLL_ACTIVE = 5000;
	var POLL_IDLE = 15000;

	var auth = null;
	var timer = null;
	var openChat = 0;
	var view = 'chats';
	var caps = [];
	var fileCfg = {};

	// ---------- ابزارهای کوچک ----------

	function $( id ) {
		return document.getElementById( id );
	}

	function el( tag, cls, text ) {
		var node = document.createElement( tag );

		if ( cls ) {
			node.className = cls;
		}

		if ( undefined !== text && null !== text ) {
			node.textContent = text;
		}

		return node;
	}

	function show( id, on ) {
		$( id ).hidden = ! on;
	}

	var toastTimer = null;

	function toast( text, bad ) {
		var box = $( 'toast' );

		box.textContent = text;
		box.className = bad ? 'toast is-bad' : 'toast';
		box.hidden = false;

		clearTimeout( toastTimer );
		toastTimer = setTimeout( function () {
			box.hidden = true;
		}, 3000 );
	}

	/**
	 * ارقام لاتین را فارسی نشان می‌دهیم تا با بقیه‌ی افزونه یکدست باشد.
	 *
	 * @param {*} value ورودی.
	 * @return {string} خروجی.
	 */
	function fa( value ) {
		return String( undefined === value || null === value ? '' : value )
			.replace( /[0-9]/g, function ( d ) { return '۰۱۲۳۴۵۶۷۸۹'[ d ]; } );
	}

	function money( amount ) {
		var n = Math.round( Number( amount ) || 0 );

		return fa( n.toLocaleString( 'en-US' ) ) + ' تومان';
	}

	// ---------- دسترسی‌ها ----------

	/**
	 * آیا حساب جاری این اجازه را دارد؟
	 *
	 * فهرست از سرور می‌آید؛ پنهان‌کردن اینجا فقط برای این است که کاربر دکمه‌ی
	 * بی‌فایده نبیند. جلوگیری واقعی سمت سرور انجام می‌شود.
	 *
	 * @param {string} cap نام دسترسی.
	 * @return {boolean} مجاز است؟
	 */
	function can( cap ) {
		return caps.indexOf( cap ) > -1;
	}

	/**
	 * نشان‌دادن یا پنهان‌کردن هر چیزی که data-cap دارد.
	 */
	function applyCaps() {
		Array.prototype.forEach.call( document.querySelectorAll( '[data-cap]' ), function ( node ) {
			node.hidden = ! can( node.dataset.cap );
		} );

		$( 'reply-denied' ).hidden = can( 'chat_reply' );
		$( 'note-denied' ).hidden = can( 'note_add' );

		// اگر نمای باز دیگر مجاز نیست، به گفتگوها برمی‌گردیم.
		var current = document.querySelector( '.tab[data-view="' + view + '"]' );

		if ( current && current.hidden ) {
			switchView( 'chats' );
		}
	}

	// ---------- ارتباط با سایت ----------

	/**
	 * ریشه‌ی REST سایت.
	 *
	 * اپ همیشه از خودِ سایت سرو می‌شود، پس نیازی نیست نشانی را از کاربر
	 * بپرسیم. سه حالت پوشش داده می‌شود: تزریق از سمت PHP، حدس از روی مسیر
	 * wp-content (وقتی وردپرس در زیرپوشه نصب است)، و در نهایت ریشه‌ی دامنه.
	 *
	 * @return {string} نشانی پایه.
	 */
	function restBase() {
		if ( window.wcmaRest ) {
			return String( window.wcmaRest ).replace( /\/+$/, '' );
		}

		var path = window.location.pathname;
		var root = '';
		var cut = path.indexOf( '/wp-content/' );

		if ( cut > -1 ) {
			root = path.slice( 0, cut );
		} else {
			/*
			 * بعضی سایت‌ها پوشه‌ی wp-content را تغییر نام داده‌اند؛ در آن حالت
			 * از روی پوشه‌ی plugins یک پله بالاتر می‌رویم تا به ریشه برسیم.
			 */
			cut = path.lastIndexOf( '/plugins/' );

			if ( cut > -1 ) {
				root = path.slice( 0, cut );
				root = root.slice( 0, root.lastIndexOf( '/' ) + 1 ).replace( /\/$/, '' );
			}
		}

		return window.location.origin + root + '/wp-json/wcma/v1';
	}

	/**
	 * شکل جایگزین نشانی، برای سایت‌هایی که پیوند یکتای «ساده» دارند.
	 *
	 * @param {string} path مسیر.
	 * @return {string} نشانی.
	 */
	function restFallback( path ) {
		var base = restBase();

		// اگر پایه خودش شکل rest_route دارد، همان درست است.
		if ( base.indexOf( 'rest_route=' ) > -1 ) {
			return base + path;
		}

		return base.replace( /\/wp-json\/wcma\/v1$/, '' ) + '/?rest_route=/wcma/v1' + path;
	}

	function api( path, options, alternate ) {
		options = options || {};

		var url = alternate ? restFallback( path ) : restBase() + path;

		return fetch( url, {
			method: options.method || 'GET',
			// اعتبار در هدر می‌رود؛ کوکی سایت نباید دخالت کند.
			credentials: 'omit',
			headers: {
				'Content-Type': 'application/json',
				Authorization: 'Bearer ' + auth.token
			},
			body: options.body ? JSON.stringify( options.body ) : undefined
		} ).then( function ( response ) {
			/*
			 * ۴۰۴ روی مسیر wp-json یعنی سایت پیوند یکتای ساده دارد؛ یک‌بار با
			 * شکل rest_route دوباره تلاش می‌کنیم.
			 */
			if ( 404 === response.status && ! alternate ) {
				return api( path, options, true );
			}

			if ( 401 === response.status || 403 === response.status ) {
				throw new Error( 'دسترسی رد شد. دوباره وارد شوید.' );
			}

			if ( 429 === response.status ) {
				throw new Error( 'درخواست‌های زیادی فرستاده شده. کمی صبر کنید.' );
			}

			return response.json().then( function ( data ) {
				if ( ! response.ok ) {
					throw new Error( ( data && data.message ) || 'خطای سرور' );
				}

				return data;
			} );
		} );
	}

	// ---------- ورود و خروج ----------

	/**
	 * فقط کلید موقت ذخیره می‌شود، نه رمز؛ رمز هرگز روی دستگاه نمی‌ماند.
	 *
	 * @param {string} site  نشانی سایت.
	 * @param {string} token کلید.
	 * @param {Object} user  اطلاعات اپراتور.
	 */
	function saveAuth( token, user ) {
		auth = {
			token: token,
			name: user && user.name ? user.name : '',
			role: user && user.role ? user.role : 'agent'
		};

		try {
			localStorage.setItem( STORE, JSON.stringify( auth ) );
		} catch ( e ) {
			// حالت ناشناس مرورگر؛ همین نشست کار می‌کند.
		}
	}

	function loadAuth() {
		try {
			var raw = localStorage.getItem( STORE );

			return raw ? JSON.parse( raw ) : null;
		} catch ( e ) {
			return null;
		}
	}

	function logout() {
		// تلاش برای باطل کردن سمت سرور؛ حتی اگر نرسید، محلی خارج می‌شویم.
		if ( auth ) {
			api( '/agent/logout', { method: 'POST' } ).catch( function () {} );
		}

		auth = null;
		caps = [];
		clearTimeout( timer );

		try {
			localStorage.removeItem( STORE );
		} catch ( e ) {}

		show( 'screen-main', false );
		show( 'screen-thread', false );
		show( 'screen-contact', false );
		show( 'screen-login', true );
	}

	function start() {
		show( 'screen-login', false );
		show( 'screen-main', true );

		api( '/agent/me' ).then( function ( data ) {
			$( 'site-name' ).textContent = data.site;
			$( 'agent-name' ).textContent = data.name;

			caps = Array.isArray( data.caps ) ? data.caps : [];
			fileCfg = data.files || {};

			var picker = $( 'reply-file' );

			picker.accept = fileCfg.accept || '';
			$( 'btn-attach' ).hidden = ! fileCfg.on;
			$( 'btn-mic' ).hidden = ! ( fileCfg.on && fileCfg.voice && canRecord() );

			var role = $( 'agent-role' );

			role.textContent = data.roleLabel || '';
			role.hidden = ! data.roleLabel;

			applyCaps();
			switchView( 'chats' );
		} ).catch( function ( error ) {
			toast( error.message, true );
			logout();
		} );
	}

	$( 'login-form' ).addEventListener( 'submit', function ( event ) {
		event.preventDefault();

		var note = $( 'login-note' );
		var btn = $( 'btn-login' );

		note.hidden = true;
		btn.disabled = true;
		btn.textContent = 'در حال بررسی…';

		function fail( message ) {
			note.textContent = message;
			note.className = 'login__note';
			note.hidden = false;
			auth = null;

			try {
				localStorage.removeItem( STORE );
			} catch ( e ) {}
		}

		// پیش از ورود هنوز توکنی نداریم، پس api() با اعتبار خالی کار نمی‌کند.
		auth = { token: '' };

		api( '/agent/login', {
			method: 'POST',
			body: {
				username: $( 'in-user' ).value,
				password: $( 'in-pass' ).value,
				device: navigator.userAgent.slice( 0, 120 )
			}
		} ).then( function ( data ) {
			if ( ! data || ! data.ok ) {
				fail( ( data && data.message ) || 'ورود ناموفق بود.' );
				return;
			}

			saveAuth( data.token, data.user );
			$( 'in-pass' ).value = '';
			start();
		} ).catch( function ( error ) {
			fail( error && error.message ? error.message : 'به سایت وصل نشد.' );
		} ).then( function () {
			btn.disabled = false;
			btn.textContent = 'ورود';
		} );
	} );

	/**
	 * پاک کردن کش و گرفتن نسخه‌ی تازه.
	 *
	 * سرویس‌ورکر پوسته را کش می‌کند و اگر میزبان فایل‌ها را هم کش کند، نسخه‌ی
	 * کهنه ممکن است روی دستگاه بماند. این دکمه راه بیرون آمدن بدون رفتن به
	 * تنظیمات مرورگر است.
	 */
	function hardRefresh() {
		var jobs = [];

		if ( window.caches && caches.keys ) {
			jobs.push( caches.keys().then( function ( keys ) {
				return Promise.all( keys.map( function ( key ) {
					return caches.delete( key );
				} ) );
			} ) );
		}

		if ( 'serviceWorker' in navigator ) {
			jobs.push( navigator.serviceWorker.getRegistrations().then( function ( list ) {
				return Promise.all( list.map( function ( reg ) {
					return reg.unregister();
				} ) );
			} ) );
		}

		Promise.all( jobs ).catch( function () {} ).then( function () {
			// پارامتر زمان، کش خود مرورگر را هم دور می‌زند.
			window.location.replace( window.location.pathname + '?fresh=' + Date.now() );
		} );
	}

	[ 'btn-refresh', 'btn-refresh-login' ].forEach( function ( id ) {
		var node = $( id );

		if ( node ) {
			node.addEventListener( 'click', hardRefresh );
		}
	} );

	$( 'btn-logout' ).addEventListener( 'click', function () {
		if ( window.confirm( 'از این دستگاه خارج می‌شوید؟' ) ) {
			logout();
		}
	} );

	// ---------- جابه‌جایی نما ----------

	/**
	 * رفتن به یک نما.
	 *
	 * @param {string} name نام نما.
	 */
	function switchView( name ) {
		var tab = document.querySelector( '.tab[data-view="' + name + '"]' );

		// نمایی که دسترسی‌اش نیست، باز نمی‌شود.
		if ( ! tab || tab.hidden ) {
			name = 'chats';
			tab = document.querySelector( '.tab[data-view="chats"]' );
		}

		view = name;

		Array.prototype.forEach.call( document.querySelectorAll( '.tab' ), function ( t ) {
			t.classList.toggle( 'is-active', t === tab );
		} );

		[ 'chats', 'contacts', 'history' ].forEach( function ( key ) {
			$( 'view-' + key ).classList.toggle( 'is-active', key === name );
		} );

		if ( 'contacts' === name ) {
			loadContacts();
		} else if ( 'history' === name ) {
			loadHistory();
		} else {
			loadChats();
		}
	}

	Array.prototype.forEach.call( document.querySelectorAll( '.tab' ), function ( tab ) {
		tab.addEventListener( 'click', function () {
			switchView( tab.dataset.view );
		} );
	} );

	Array.prototype.forEach.call( document.querySelectorAll( '[data-close]' ), function ( btn ) {
		btn.addEventListener( 'click', function () {
			if ( 'thread' === btn.dataset.close ) {
				openChat = 0;
				show( 'screen-thread', false );
				loadChats();
			} else {
				show( 'screen-contact', false );
			}
		} );
	} );

	// ---------- صندوق گفتگو ----------

	function loadChats() {
		if ( ! auth ) {
			return;
		}

		var query = '?status=' + encodeURIComponent( $( 'chat-status' ).value ) +
			'&search=' + encodeURIComponent( $( 'chat-search' ).value );

		api( '/agent/chats' + query ).then( function ( data ) {
			renderChats( data.items );

			var badge = $( 'unread-badge' );

			badge.textContent = fa( data.unread );
			badge.hidden = ! data.unread;

			schedule();
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	}

	function renderChats( items ) {
		var list = $( 'chat-list' );

		list.textContent = '';

		if ( ! items.length ) {
			list.appendChild( el( 'p', 'empty', 'گفتگویی نیست.' ) );
			return;
		}

		items.forEach( function ( chat ) {
			var card = el( 'button', 'item' );

			card.type = 'button';

			var row = el( 'div', 'item__row' );

			row.appendChild( el( 'span', 'item__name', chat.name ) );

			if ( chat.unread ) {
				row.appendChild( el( 'span', 'badge', fa( chat.unread ) ) );
			}

			row.appendChild( el( 'span', 'item__date', chat.date ) );
			card.appendChild( row );
			card.appendChild( el( 'div', 'item__last', chat.last || '—' ) );

			var meta = el( 'div', 'item__meta' );

			meta.appendChild( el( 'span', 'chip', chat.channel ) );
			meta.appendChild( el( 'span', 'chip', 'human' === chat.mode ? 'اپراتور' : 'ربات' ) );

			if ( chat.phone ) {
				meta.appendChild( el( 'span', 'chip chip--ltr', chat.phone ) );
			}

			card.appendChild( meta );
			card.addEventListener( 'click', function () {
				openThread( chat.id );
			} );

			list.appendChild( card );
		} );
	}

	function openThread( id ) {
		openChat = id;
		// نقل‌قول گفتگوی قبلی نباید به گفتگوی تازه بچسبد.
		cancelReply();
		show( 'screen-thread', true );
		$( 'thread-messages' ).textContent = '';
		loadThread( true );
	}

	function loadThread( scroll ) {
		if ( ! openChat ) {
			return;
		}

		api( '/agent/chats/' + openChat ).then( function ( data ) {
			$( 'thread-name' ).textContent = data.chat.name;
			$( 'thread-channel' ).textContent = data.chat.channel + ( data.chat.phone ? ' · ' + data.chat.phone : '' );
			$( 'btn-mode' ).textContent = 'human' === data.chat.mode ? 'اپراتور' : 'ربات';
			$( 'btn-mode' ).dataset.mode = data.chat.mode;

			renderMessages( data.messages, scroll );
			schedule();
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	}

	var replyTo = null;

	/**
	 * نام نوع پیوست، وقتی پیامِ نقل‌قول‌شده متنی ندارد.
	 *
	 * @param {string} kind نوع.
	 * @return {string} برچسب.
	 */
	function kindLabel( kind ) {
		return { image: 'عکس', video: 'ویدیو', audio: 'پیام صوتی', doc: 'فایل', zip: 'فایل فشرده' }[ kind ] || 'پیوست';
	}

	/**
	 * نمایش نقل‌قول یک پیام.
	 *
	 * @param {Object} ref پیام ارجاع‌شده.
	 * @return {Node} گره نقل‌قول.
	 */
	function quoteNode( ref ) {
		var box = el( 'div', 'quote is-' + ( ref.side || 'agent' ) );

		box.appendChild( el( 'span', 'quote__who', 'visitor' === ref.side ? 'مشتری' : 'اپراتور' ) );
		box.appendChild( el( 'span', 'quote__text', ref.text || kindLabel( ref.kind ) ) );

		return box;
	}

	/**
	 * دکمه‌ی پاسخ کنار هر پیام.
	 *
	 * @param {Object} message پیام.
	 * @return {Node} گره دکمه.
	 */
	function replyButton( message ) {
		var btn = el( 'button', 'msg-reply', '↩' );

		btn.type = 'button';
		btn.title = 'پاسخ به این پیام';
		btn.setAttribute( 'aria-label', 'پاسخ به این پیام' );
		btn.addEventListener( 'click', function () {
			startReply( message );
		} );

		return btn;
	}

	/**
	 * گرفتن پاسخ به یک پیام: نوار نقل‌قول بالای جعبه‌ی پاسخ.
	 *
	 * @param {Object} message پیام.
	 */
	function startReply( message ) {
		var text = message.body || '';

		if ( message.file && message.file.url && ( ! text || text === message.file.name ) ) {
			text = kindLabel( message.file.kind );
		}

		replyTo = { id: message.id, text: text, side: 'customer' === message.side ? 'visitor' : 'agent' };
		paintReplyBar();
		$( 'reply-text' ).focus();
	}

	function cancelReply() {
		replyTo = null;
		paintReplyBar();
	}

	function paintReplyBar() {
		var bar = $( 'reply-bar' );

		bar.textContent = '';

		if ( ! replyTo ) {
			bar.hidden = true;

			return;
		}

		bar.hidden = false;
		bar.appendChild( quoteNode( replyTo ) );

		var drop = el( 'button', 'icon-btn icon-btn--quiet', '✕' );

		drop.type = 'button';
		drop.title = 'انصراف از پاسخ';
		drop.setAttribute( 'aria-label', 'انصراف از پاسخ' );
		drop.addEventListener( 'click', cancelReply );
		bar.appendChild( drop );
	}

	function renderMessages( messages, scroll ) {
		var box = $( 'thread-messages' );
		var atBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 60;

		box.textContent = '';

		messages.forEach( function ( message ) {
			var row = el( 'div', 'msg-row msg-row--' + message.side );
			var bubble = el( 'div', 'msg msg--' + message.side );

			// نقل‌قول پیامی که این یکی پاسخ آن است، بالای متن می‌نشیند.
			if ( message.reply && ( message.reply.text || message.reply.kind ) ) {
				bubble.appendChild( quoteNode( message.reply ) );
			}

			if ( message.file && message.file.url ) {
				// سرور برچسب خودکار را از توضیح واقعی جدا می‌کند.
				var caption = undefined !== message.file.caption
					? message.file.caption
					: ( ( message.body && message.body !== message.file.name ) ? message.body : '' );

				if ( ! caption && ( 'image' === message.file.kind || 'video' === message.file.kind ) ) {
					bubble.classList.add( 'is-bare' );
				}

				// حباب رسانه‌ای فاصله‌ی داخلی کمتری می‌گیرد تا پیام‌ها به هم نزدیک بمانند.
				bubble.classList.add( 'is-media' );

				bubble.appendChild( attachmentNode( message.file ) );

				if ( caption ) {
					bubble.appendChild( el( 'div', 'msg__caption', caption ) );
				}
			} else {
				bubble.appendChild( document.createTextNode( message.body ) );
			}

			bubble.appendChild( el( 'time', '', message.date ) );
			row.appendChild( bubble );
			row.appendChild( replyButton( message ) );
			box.appendChild( row );
		} );

		if ( scroll || atBottom ) {
			box.scrollTop = box.scrollHeight;
		}
	}

	$( 'reply-form' ).addEventListener( 'submit', function ( event ) {
		event.preventDefault();

		var field = $( 'reply-text' );
		var text = field.value.trim();

		if ( ! text ) {
			return;
		}

		var btn = $( 'btn-send' );

		btn.disabled = true;

		api( '/agent/chats/' + openChat + '/reply', {
			method: 'POST',
			body: { text: text, reply: replyTo ? replyTo.id : 0 }
		} ).then( function () {
			field.value = '';
			cancelReply();
			loadThread( true );
		} ).catch( function ( error ) {
			toast( error.message, true );
		} ).then( function () {
			btn.disabled = false;
		} );
	} );

	// ---------- پیوست و صدا ----------

	/**
	 * ساخت نمایش پیوست بر اساس نوع آن.
	 *
	 * @param {Object} file پیوست.
	 * @return {Node} گره آماده.
	 */
	function attachmentNode( file ) {
		var wrap = el( 'div', 'att is-' + ( file.kind || 'doc' ) );

		// عکس خودش پیام است؛ نام و حجم زیرش فقط شلوغی می‌ساخت.
		if ( 'image' === file.kind ) {
			var open = el( 'a', 'att__open' );
			var img = el( 'img', 'att__img' );

			img.src = file.url;
			img.alt = file.name || '';
			img.loading = 'lazy';

			open.href = file.url;
			open.target = '_blank';
			open.rel = 'noopener noreferrer';
			open.title = file.name || '';
			open.appendChild( img );
			wrap.appendChild( open );

			return wrap;
		}

		if ( 'video' === file.kind ) {
			var video = el( 'video', 'att__media' );

			video.src = file.url;
			video.controls = true;
			video.preload = 'metadata';
			wrap.appendChild( video );

			return wrap;
		}

		if ( 'audio' === file.kind ) {
			var player = el( 'audio', 'att__media' );

			player.src = file.url;
			player.controls = true;
			player.preload = 'metadata';
			wrap.appendChild( player );

			/*
			 * عدد داخل bdi می‌رود: برچسب فارسی راست‌به‌چپ است و «۰:۰۵٫۳» را
			 * وارونه نشان می‌داد.
			 */
			var stamp = el( 'span', 'att__time' );
			var bdi = document.createElement( 'bdi' );

			stamp.appendChild( document.createTextNode( 'مدت ضبط: ' ) );
			bdi.textContent = file.clock || '—';
			stamp.appendChild( bdi );
			wrap.appendChild( stamp );

			return wrap;
		}

		var link = el( 'a', 'att__link' );

		link.href = file.url;
		link.target = '_blank';
		link.rel = 'noopener noreferrer';
		link.textContent = ( file.name || 'دریافت فایل' ) + ( file.human ? ' · ' + file.human : '' );

		wrap.appendChild( link );

		return wrap;
	}

	/**
	 * آیا مرورگر می‌تواند صدا ضبط کند؟
	 *
	 * @return {boolean} می‌تواند؟
	 */
	function canRecord() {
		return !! ( window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia );
	}

	/**
	 * فرستادن فایل به گفتگوی باز.
	 *
	 * api() بدنه را JSON می‌کند و برای فایل کار نمی‌کند، پس مستقیم fetch
	 * می‌کنیم؛ مرورگر خودش مرز چندبخشی را می‌گذارد.
	 *
	 * @param {Blob}   blob محتوا.
	 * @param {string} name نام فایل.
	 */
	function sendFile( blob, name, ms ) {
		if ( ! openChat || ! fileCfg.on ) {
			return;
		}

		if ( fileCfg.max && blob.size > fileCfg.max ) {
			toast( 'حجم فایل بیشتر از حد مجاز است' + ( fileCfg.label ? ' (' + fileCfg.label + ')' : '' ) + '.', true );
			return;
		}

		var data = new FormData();

		data.append( 'file', blob, name );
		data.append( 'text', $( 'reply-text' ).value || '' );
		data.append( 'reply', replyTo ? String( replyTo.id ) : '0' );

		// مدت واقعی ضبط؛ خواندنش از خود فایل webm نامطمئن است.
		if ( ms ) {
			data.append( 'duration', String( Math.round( ms ) ) );
		}

		var btn = $( 'btn-send' );

		btn.disabled = true;
		toast( 'در حال ارسال فایل…' );

		fetch( restBase() + '/agent/chats/' + openChat + '/upload', {
			method: 'POST',
			credentials: 'omit',
			// Content-Type عمداً گذاشته نمی‌شود تا مرورگر boundary را بسازد.
			headers: { Authorization: 'Bearer ' + auth.token },
			body: data
		} ).then( function ( response ) {
			return response.json().catch( function () {
				return null;
			} );
		} ).then( function ( result ) {
			if ( ! result || ! result.ok ) {
				toast( ( result && result.message ) || 'ارسال نشد.', true );
				return;
			}

			$( 'reply-text' ).value = '';
			cancelReply();
			loadThread( true );
		} ).catch( function () {
			toast( 'ارسال نشد.', true );
		} ).then( function () {
			btn.disabled = false;
		} );
	}

	$( 'btn-attach' ).addEventListener( 'click', function () {
		$( 'reply-file' ).click();
	} );

	$( 'reply-file' ).addEventListener( 'change', function () {
		var file = this.files && this.files[ 0 ];

		if ( file ) {
			sendFile( file, file.name );
		}

		// پاک کردن، تا انتخاب دوباره‌ی همان فایل هم رویداد بدهد.
		this.value = '';
	} );

	var recorder = null;
	var recordTick = null;
	var recordStart = 0;

	/**
	 * «۰:۰۳٫۴» از روی میلی‌ثانیه.
	 *
	 * دهمِ ثانیه نگه داشته می‌شود، وگرنه ویس کوتاه همیشه ۰:۰۰ دیده می‌شود.
	 *
	 * @param {number} ms میلی‌ثانیه.
	 * @return {string} زمان خوانا.
	 */
	function clock( ms ) {
		ms = Math.max( 0, ms | 0 );

		var total = Math.floor( ms / 1000 );
		var mm = Math.floor( total / 60 );
		var ss = total % 60;
		var tenth = Math.floor( ( ms % 1000 ) / 100 );

		return fa( mm + ':' + ( ss < 10 ? '0' : '' ) + ss + '٫' + tenth );
	}

	$( 'btn-mic' ).addEventListener( 'click', function () {
		var btn = this;

		if ( recorder && 'recording' === recorder.state ) {
			recorder.stop();
			return;
		}

		navigator.mediaDevices.getUserMedia( { audio: true } ).then( function ( stream ) {
			var chunks = [];
			var mime = '';

			[ 'audio/webm', 'audio/ogg', 'audio/mp4' ].some( function ( candidate ) {
				if ( window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported( candidate ) ) {
					mime = candidate;
					return true;
				}

				return false;
			} );

			recorder = mime ? new window.MediaRecorder( stream, { mimeType: mime } ) : new window.MediaRecorder( stream );

			recorder.addEventListener( 'dataavailable', function ( e ) {
				if ( e.data && e.data.size ) {
					chunks.push( e.data );
				}
			} );

			recorder.addEventListener( 'stop', function () {
				// میکروفون بلافاصله آزاد می‌شود تا چراغش روشن نماند.
				stream.getTracks().forEach( function ( track ) {
					track.stop();
				} );

				clearInterval( recordTick );
				recordTick = null;

				var ms = recordStart ? Date.now() - recordStart : 0;

				btn.classList.remove( 'is-live' );
				btn.textContent = '🎙';

				var type = recorder.mimeType || mime || 'audio/webm';
				var blob = new Blob( chunks, { type: type } );
				var ext = type.indexOf( 'ogg' ) > -1 ? 'ogg' : ( type.indexOf( 'mp4' ) > -1 ? 'm4a' : 'webm' );

				recorder = null;

				if ( blob.size ) {
					sendFile( blob, 'voice.' + ext, ms );
				}
			} );

			btn.classList.add( 'is-live' );
			toast( 'در حال ضبط… برای پایان دوباره بزنید.' );
			recorder.start();

			// شمارنده‌ی زنده روی خود دکمه.
			recordStart = Date.now();
			btn.textContent = clock( 0 );

			clearInterval( recordTick );
			recordTick = setInterval( function () {
				btn.textContent = clock( Date.now() - recordStart );
			}, 100 );

			// سقف دو دقیقه، تا ضبط فراموش‌شده فایل بزرگ نسازد.
			setTimeout( function () {
				if ( recorder && 'inactive' !== recorder.state ) {
					recorder.stop();
				}
			}, 120000 );
		} ).catch( function () {
			toast( 'دسترسی به میکروفون ممکن نشد.', true );
		} );
	} );

	$( 'btn-mode' ).addEventListener( 'click', function () {
		var next = 'human' === this.dataset.mode ? 'bot' : 'human';

		api( '/agent/chats/' + openChat + '/mode', { method: 'POST', body: { mode: next } } ).then( function ( data ) {
			$( 'btn-mode' ).textContent = 'human' === data.mode ? 'اپراتور' : 'ربات';
			$( 'btn-mode' ).dataset.mode = data.mode;
			toast( 'human' === data.mode ? 'پاسخ‌ها با شماست.' : 'ربات دوباره پاسخ می‌دهد.' );
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	} );

	// ---------- مشتریان ----------

	function loadContacts() {
		if ( ! auth ) {
			return;
		}

		api( '/agent/contacts?search=' + encodeURIComponent( $( 'contact-search' ).value ) ).then( function ( data ) {
			var list = $( 'contact-list' );

			list.textContent = '';

			if ( ! data.items.length ) {
				list.appendChild( el( 'p', 'empty', 'مشتری‌ای پیدا نشد.' ) );
				return;
			}

			data.items.forEach( function ( contact ) {
				var card = el( 'button', 'item' );

				card.type = 'button';

				var row = el( 'div', 'item__row' );

				row.appendChild( el( 'span', 'item__name', contact.name ) );

				var stage = el( 'span', 'chip', contact.stage );

				stage.style.color = contact.color;
				stage.style.background = contact.color + '1a';
				row.appendChild( stage );
				card.appendChild( row );

				var meta = el( 'div', 'item__meta' );

				if ( contact.phone ) {
					meta.appendChild( el( 'span', 'chip chip--ltr', contact.phone ) );
				}

				meta.appendChild( el( 'span', 'chip', contact.source ) );
				meta.appendChild( el( 'span', 'chip', fa( contact.orders ) + ' سفارش' ) );
				card.appendChild( meta );

				card.addEventListener( 'click', function () {
					openContact( contact.id );
				} );

				list.appendChild( card );
			} );
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	}

	var openContactId = 0;

	function openContact( id ) {
		openContactId = id;
		show( 'screen-contact', true );
		$( 'contact-body' ).textContent = '';
		loadContact();
	}

	function loadContact() {
		api( '/agent/contacts/' + openContactId ).then( function ( data ) {
			var c = data.contact;

			$( 'contact-name' ).textContent = c.name;
			$( 'contact-stage' ).textContent = c.stage + ' · ' + c.source;

			var body = $( 'contact-body' );

			body.textContent = '';

			var profile = el( 'div', 'profile' );
			var grid = el( 'div', 'profile__grid' );

			[
				[ 'موبایل', c.phone || '—' ],
				[ 'ایمیل', c.email || '—' ],
				[ 'سفارش‌ها', fa( c.orders ) ],
				[ 'مبلغ کل', money( c.spent ) ]
			].forEach( function ( pair ) {
				var cell = el( 'div' );

				cell.appendChild( el( 'span', '', pair[ 0 ] ) );
				cell.appendChild( el( 'strong', '', pair[ 1 ] ) );
				grid.appendChild( cell );
			} );

			profile.appendChild( grid );
			body.appendChild( profile );
			body.appendChild( el( 'div', 'section-title', 'گردش کار' ) );

			if ( ! data.journey.length ) {
				body.appendChild( el( 'p', 'empty', 'رویدادی ثبت نشده است.' ) );
				return;
			}

			data.journey.forEach( function ( event ) {
				var item = el( 'div', 'event is-' + event.kind );
				var dot = el( 'span', 'event__dot' );

				dot.style.background = event.color;
				item.appendChild( dot );

				var wrap = el( 'div', 'event__body' );
				var head = el( 'div', 'event__head' );

				head.appendChild( el( 'strong', '', event.title ) );
				head.appendChild( el( 'time', '', event.date ) );
				wrap.appendChild( head );

				if ( event.detail ) {
					wrap.appendChild( el( 'span', 'event__detail', event.detail ) );
				}

				if ( event.author ) {
					wrap.appendChild( el( 'span', 'event__detail', event.author ) );
				}

				item.appendChild( wrap );
				body.appendChild( item );
			} );
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	}

	$( 'note-form' ).addEventListener( 'submit', function ( event ) {
		event.preventDefault();

		var field = $( 'note-text' );
		var text = field.value.trim();

		if ( ! text ) {
			return;
		}

		api( '/agent/contacts/' + openContactId + '/note', {
			method: 'POST',
			body: { body: text, type: $( 'note-type' ).value }
		} ).then( function () {
			field.value = '';
			toast( 'یادداشت ثبت شد.' );
			loadContact();
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	} );

	// ---------- تاریخچه‌ی همکاران ----------

	var historyFilled = false;

	/**
	 * تاریخچه‌ی اقدام‌ها؛ سرور هم همین را فقط به مدیر می‌دهد.
	 */
	function loadHistory() {
		if ( ! auth || ! can( 'team_history' ) ) {
			return;
		}

		var list = $( 'history-list' );

		api( '/agent/history?action=' + encodeURIComponent( $( 'history-action' ).value ) ).then( function ( data ) {
			fillHistoryFilter( data.items );

			list.textContent = '';

			if ( ! data.items.length ) {
				list.appendChild( el( 'p', 'empty', 'اقدامی ثبت نشده است.' ) );
				return;
			}

			data.items.forEach( function ( row ) {
				var card = el( 'div', 'item' );
				var head = el( 'div', 'item__row' );

				head.appendChild( el( 'span', 'item__name', row.actor || '—' ) );
				head.appendChild( el( 'span', 'item__date', row.date ) );
				card.appendChild( head );
				card.appendChild( el( 'div', 'item__last', row.action ) );

				if ( row.detail ) {
					var meta = el( 'div', 'item__meta' );

					meta.appendChild( el( 'span', 'chip', row.detail ) );
					card.appendChild( meta );
				}

				list.appendChild( card );
			} );
		} ).catch( function ( error ) {
			toast( error.message, true );
		} );
	}

	/**
	 * پر کردن فهرست فیلتر از روی اقدام‌های واقعاً ثبت‌شده.
	 *
	 * @param {Array} items ردیف‌ها.
	 */
	function fillHistoryFilter( items ) {
		if ( historyFilled || ! items.length ) {
			return;
		}

		historyFilled = true;

		var seen = {};
		var select = $( 'history-action' );

		items.forEach( function ( row ) {
			// مقدار فیلتر باید کلید خام باشد؛ سرور برچسب فارسی را نمی‌شناسد.
			if ( row.key && ! seen[ row.key ] ) {
				seen[ row.key ] = true;

				var option = el( 'option', '', row.action || row.key );

				option.value = row.key;
				select.appendChild( option );
			}
		} );
	}

	$( 'history-action' ).addEventListener( 'change', loadHistory );

	// ---------- تازه‌سازی دوره‌ای ----------

	/**
	 * وردپرس WebSocket ندارد، پس پولینگ می‌کنیم — ولی فقط وقتی اپ جلوی چشم
	 * است و با فاصله‌ی بیشتر وقتی گفتگویی باز نیست، تا به سرور فشار نیاید.
	 */
	function schedule() {
		clearTimeout( timer );

		if ( ! auth || document.hidden ) {
			return;
		}

		timer = setTimeout( function () {
			if ( ! $( 'screen-thread' ).hidden && openChat ) {
				loadThread( false );
			} else if ( 'chats' === view ) {
				loadChats();
			}
		}, openChat ? POLL_ACTIVE : POLL_IDLE );
	}

	document.addEventListener( 'visibilitychange', function () {
		if ( document.hidden ) {
			clearTimeout( timer );
		} else if ( auth ) {
			schedule();
		}
	} );

	var searchTimer = null;

	[ 'chat-search', 'contact-search' ].forEach( function ( id ) {
		$( id ).addEventListener( 'input', function () {
			clearTimeout( searchTimer );
			searchTimer = setTimeout( 'chat-search' === id ? loadChats : loadContacts, 400 );
		} );
	} );

	$( 'chat-status' ).addEventListener( 'change', loadChats );

	// ---------- راه‌اندازی ----------

	auth = loadAuth();

	if ( auth && auth.token ) {
		start();
	} else {
		auth = null;
		show( 'screen-login', true );
	}

	if ( 'serviceWorker' in navigator ) {
		navigator.serviceWorker.register( './sw.js' ).catch( function () {
			// نصب‌شدنی نبودن اپ، مانع کارکردنش نیست.
		} );
	}
}() );
