/**
 * سرویس‌ورکر اپ اپراتور.
 *
 * فقط پوسته‌ی اپ کش می‌شود. پاسخ‌های API هرگز کش نمی‌شوند، چون داده‌ی
 * خصوصی مشتریان است و نباید روی دستگاه بماند.
 */
var CACHE = 'wcma-agent-v9';
var SHELL = [
	'./', './index.html', './app.css', './app.js', './manifest.json',
	// فونت هم کش می‌شود، وگرنه اپ نصب‌شده در حالت آفلاین با فونت سیستمی باز می‌شد.
	'../assets/fonts/Vazirmatn-Regular.woff2',
	'../assets/fonts/Vazirmatn-Bold.woff2'
];

self.addEventListener( 'install', function ( event ) {
	event.waitUntil(
		caches.open( CACHE ).then( function ( cache ) {
			// addAll با یک شکست کل نصب را باطل می‌کند؛ تک‌تک می‌افزاییم.
			return Promise.all( SHELL.map( function ( url ) {
				return cache.add( url ).catch( function () {} );
			} ) );
		} ).then( function () {
			return self.skipWaiting();
		} )
	);
} );

self.addEventListener( 'activate', function ( event ) {
	event.waitUntil(
		caches.keys().then( function ( keys ) {
			return Promise.all( keys.map( function ( key ) {
				return key === CACHE ? null : caches.delete( key );
			} ) );
		} ).then( function () {
			return self.clients.claim();
		} )
	);
} );

self.addEventListener( 'fetch', function ( event ) {
	var url = new URL( event.request.url );

	// هر چیزی که به API مربوط است، مستقیم از شبکه؛ نه کش، نه ذخیره.
	if ( 'GET' !== event.request.method || url.pathname.indexOf( '/wcma/v1/' ) !== -1 || url.search.indexOf( 'wcma/v1' ) !== -1 ) {
		return;
	}

	event.respondWith(
		caches.match( event.request ).then( function ( hit ) {
			return hit || fetch( event.request );
		} )
	);
} );
