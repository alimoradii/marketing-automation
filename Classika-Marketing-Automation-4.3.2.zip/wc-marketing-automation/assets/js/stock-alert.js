/**
 * فرم «موجود شد خبرم کن» در صفحه‌ی محصول.
 */
( function ( $ ) {
	'use strict';

	/**
	 * حذف فاصله‌های دو سر رشته؛ jQuery 4 تابع $.trim را حذف کرده است.
	 *
	 * @param {*} value ورودی.
	 * @return {string} خروجی.
	 */
	function trim( value ) {
		return String( null === value || undefined === value ? '' : value ).trim();
	}

	$( function () {
		var $box = $( '.wcma-stock' );

		if ( ! $box.length ) {
			return;
		}

		/**
		 * نمایش پیام نتیجه.
		 */
		function say( text, isError ) {
			$box.find( '.wcma-stock__result' )
				.text( text )
				.removeClass( 'is-error is-success' )
				.addClass( isError ? 'is-error' : 'is-success' );
		}

		// محصولات متغیر: فرم فقط برای تنوع ناموجود نمایش داده شود.
		if ( $box.data( 'variable' ) ) {
			var $form = $( 'form.variations_form' );

			$form.on( 'found_variation', function ( event, variation ) {
				$box.find( 'input[name="variation_id"]' ).val( variation.variation_id );

				if ( variation.is_in_stock ) {
					$box.hide();
				} else {
					$box.find( '.wcma-stock__result' ).text( '' );
					$box.show();
				}
			} );

			$form.on( 'reset_data hide_variation', function () {
				$box.hide();
				$box.find( 'input[name="variation_id"]' ).val( 0 );
			} );
		}

		/**
		 * تشخیص اینکه مقدار واردشده ایمیل است یا شماره موبایل ایرانی.
		 */
		function classify( value ) {
			var v = trim( value || '' );

			if ( ! v ) {
				return '';
			}

			if ( v.indexOf( '@' ) !== -1 ) {
				return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( v ) ? 'email' : 'bad-email';
			}

			// ارقام فارسی و عربی را به لاتین تبدیل کن.
			var latin = v.replace( /[۰-۹]/g, function ( d ) {
				return '۰۱۲۳۴۵۶۷۸۹'.indexOf( d );
			} ).replace( /[٠-٩]/g, function ( d ) {
				return '٠١٢٣٤٥٦٧٨٩'.indexOf( d );
			} ).replace( /[^0-9+]/g, '' );

			return /^(?:0|0098|\+98|98)?9\d{9}$/.test( latin ) ? 'phone' : 'bad-phone';
		}

		$box.on( 'submit', '.wcma-stock__form', function ( e ) {
			e.preventDefault();

			var $form = $( this );
			var $btn = $form.find( 'button' );
			var original = $btn.text();

			var contact = $form.find( 'input[name="contact"]' ).val() || '';
			var email = $form.find( 'input[name="email"]' ).val() || '';
			var phone = $form.find( 'input[name="phone"]' ).val() || '';

			// اعتبارسنجی سمت کاربر با پیام فارسی، پیش از رفت‌وبرگشت به سرور.
			if ( $form.find( 'input[name="contact"]' ).length ) {
				var kind = classify( contact );

				if ( ! kind ) {
					say( 'ایمیل یا شماره موبایل خود را وارد کنید.', true );
					return;
				}

				if ( kind === 'bad-email' ) {
					say( 'ایمیل واردشده معتبر نیست.', true );
					return;
				}

				if ( kind === 'bad-phone' ) {
					say( 'شماره موبایل واردشده معتبر نیست. نمونه: 09121234567', true );
					return;
				}
			} else {
				if ( ! trim( email ) && ! trim( phone ) ) {
					say( 'ایمیل یا شماره موبایل خود را وارد کنید.', true );
					return;
				}

				if ( trim( email ) && classify( email ) !== 'email' ) {
					say( 'ایمیل واردشده معتبر نیست.', true );
					return;
				}

				if ( trim( phone ) && classify( phone ) !== 'phone' ) {
					say( 'شماره موبایل واردشده معتبر نیست. نمونه: 09121234567', true );
					return;
				}
			}

			$btn.prop( 'disabled', true ).text( 'در حال ثبت...' );

			$.post( window.wcmaStock.ajaxUrl, {
				action: 'wcma_stock_subscribe',
				nonce: window.wcmaStock.nonce,
				product_id: $form.find( 'input[name="product_id"]' ).val(),
				variation_id: $form.find( 'input[name="variation_id"]' ).val(),
				email: email,
				phone: phone,
				contact: contact,
				first_name: $form.find( 'input[name="first_name"]' ).val() || ''
			} ).done( function ( response ) {
				if ( response && response.success ) {
					say( response.data.message, false );
					$form.slideUp( 200 );
				} else {
					say( ( response && response.data && response.data.message ) || 'خطایی رخ داد.', true );
				}
			} ).fail( function () {
				say( 'ارتباط با سرور برقرار نشد. دوباره تلاش کنید.', true );
			} ).always( function () {
				$btn.prop( 'disabled', false ).text( original );
			} );
		} );
	} );

} )( jQuery );
