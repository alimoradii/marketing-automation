/**
 * ثبت اطلاعات تماس کاربران مهمان برای پیگیری سبد رها شده.
 */
( function ( $ ) {
	'use strict';

	var timer = null;
	var lastPayload = '';

	/**
	 * ارسال اطلاعات تماس واردشده به سرور.
	 */
	function capture() {
		var email = $( '#billing_email' ).val() || '';
		var phone = $( '#billing_phone' ).val() || '';
		var firstName = $( '#billing_first_name' ).val() || '';

		// تا وقتی راه تماسی وارد نشده، چیزی ارسال نمی‌کنیم.
		if ( ! email && ! phone ) {
			return;
		}

		// ایمیل ناقص را نفرست.
		if ( email && email.indexOf( '@' ) === -1 ) {
			return;
		}

		var payload = email + '|' + phone + '|' + firstName;

		if ( payload === lastPayload ) {
			return;
		}

		lastPayload = payload;

		$.post( window.wcmaCapture.ajaxUrl, {
			action: 'wcma_capture_guest',
			nonce: window.wcmaCapture.nonce,
			email: email,
			phone: phone,
			first_name: firstName
		} );
	}

	/**
	 * تأخیر برای جلوگیری از ارسال در هر کلید.
	 */
	function schedule() {
		clearTimeout( timer );
		timer = setTimeout( capture, 1200 );
	}

	$( function () {
		$( document.body ).on(
			'change keyup blur',
			'#billing_email, #billing_phone, #billing_first_name',
			schedule
		);

		// پشتیبانی از بلوک‌های جدید ووکامرس.
		$( document.body ).on(
			'change blur',
			'input[id*="email"], input[id*="phone"]',
			schedule
		);
	} );

} )( jQuery );
