/**
 * ویجت چت آنلاین سایت.
 *
 * بدون وابستگی به کتابخانه، سبک و راست‌به‌چپ.
 */
( function () {
	'use strict';

	var cfg = window.wcmaLiveChat;
	var host = document.getElementById( 'wcma-livechat' );

	if ( ! cfg || ! host ) {
		return;
	}

	/**
	 * ویجت داخل Shadow DOM ساخته می‌شود تا هیچ استایلی از قالب سایت به آن نرسد.
	 * روی مرورگرهای قدیمی که این قابلیت را ندارند، به همان صفحه برمی‌گردیم.
	 */
	var shadow = null;

	if ( host.attachShadow ) {
		try {
			shadow = host.attachShadow( { mode: 'open' } );
		} catch ( e ) {
			shadow = null;
		}
	}

	/*
	 * قاعده‌های ‎@font-face داخل Shadow DOM نادیده گرفته می‌شوند، پس فونت باید در
	 * خودِ سند ثبت شود؛ وگرنه ویجت به فونت پیش‌فرض سیستم برمی‌گردد.
	 */
	if ( cfg.font && ! document.querySelector( 'link[data-wcma-font]' ) ) {
		var fontSheet = document.createElement( 'link' );

		fontSheet.rel = 'stylesheet';
		fontSheet.href = cfg.font;
		fontSheet.setAttribute( 'data-wcma-font', '1' );
		( document.head || document.documentElement ).appendChild( fontSheet );
	}

	var root = document.createElement( 'div' );

	if ( shadow ) {
		var sheet = document.createElement( 'link' );

		sheet.rel = 'stylesheet';
		sheet.href = cfg.css;
		shadow.appendChild( sheet );
		shadow.appendChild( root );
	} else {
		host.appendChild( root );
	}

	var STORE = 'wcma_lc_token';
	var SEEN = 'wcma_lc_seen';
	var OPEN = 'wcma_lc_open';
	var GREET = 'wcma_lc_greeted';
	var FORMED = 'wcma_lc_formed';
	var LEAD = 'wcma_lc_lead';

	var state = {
		profile: {},
		token: read( STORE ) || '',
		lastId: parseInt( read( SEEN ), 10 ) || 0,
		open: false,
		started: false,
		polling: null,
		unread: 0,
		typingSent: 0,
		rated: 0,
		online: !! cfg.online
	};

	function read( key ) {
		try {
			return window.localStorage.getItem( key ) || '';
		} catch ( e ) {
			return '';
		}
	}

	function write( key, value ) {
		try {
			window.localStorage.setItem( key, value );
		} catch ( e ) {
			// حالت مرور خصوصی: گفتگو فقط تا پایان همین صفحه می‌ماند.
		}
	}

	function el( tag, cls, text ) {
		var node = document.createElement( tag );

		if ( cls ) {
			node.className = cls;
		}

		if ( undefined !== text && null !== text ) {
			node.textContent = text;
		}

		return node;
	}

	/*
	 * خطاهای اعتبارسنجی وردپرس؛ همه به یک معنا هستند: کوکی ورود همراه درخواست
	 * رفته ولی نانسِ داخل صفحه کهنه است (معمولاً به‌خاطر کش صفحه).
	 */
	function isAuthError( data ) {
		if ( ! data || ! data.code ) {
			return false;
		}

		return 0 === String( data.code ).indexOf( 'rest_cookie' ) ||
			'rest_forbidden' === data.code;
	}

	function api( path, body, done, noCookies ) {
		var url = cfg.root + '/chat/' + path;

		body = body || {};
		body.token = state.token;
		body.page = window.location.href;
		body.title = document.title;
		body.referrer = document.referrer;

		function finish( data ) {
			/*
			 * تلاش دوم بدون کوکی: بدون کوکیِ ورود، وردپرس اصلاً سراغ نانس
			 * نمی‌رود و این مسیرهای عمومی باز می‌شوند. یک‌بار بیشتر تکرار
			 * نمی‌شود تا حلقه نشود.
			 */
			if ( isAuthError( data ) && ! noCookies && window.fetch ) {
				api( path, body, done, true );
				return;
			}

			if ( done ) {
				done( data );
			}
		}

		if ( noCookies ) {
			window.fetch( url, {
				method: 'POST',
				credentials: 'omit',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( body )
			} ).then( function ( response ) {
				return response.json();
			} ).then( function ( data ) {
				if ( done ) {
					done( data );
				}
			} ).catch( function () {
				if ( done ) {
					done( null );
				}
			} );

			return;
		}

		var xhr = new XMLHttpRequest();

		xhr.open( 'POST', url, true );
		xhr.setRequestHeader( 'Content-Type', 'application/json' );
		xhr.setRequestHeader( 'X-WP-Nonce', cfg.nonce );

		xhr.onload = function () {
			var data = null;

			try {
				data = JSON.parse( xhr.responseText );
			} catch ( e ) {
				data = null;
			}

			finish( data );
		};

		xhr.onerror = function () {
			finish( null );
		};

		xhr.send( JSON.stringify( body ) );
	}

	// --- ساخت ظاهر ---

	var launcher = el( 'button', 'wcma-lc-launcher' );
	var badge = el( 'span', 'wcma-lc-badge' );
	var panel = el( 'div', 'wcma-lc-panel' );
	var list;
	var input;
	var typingRow;

	function svg( paths, size, cls ) {
		var node = document.createElementNS( 'http://www.w3.org/2000/svg', 'svg' );

		node.setAttribute( 'viewBox', '0 0 24 24' );
		node.setAttribute( 'width', size || 26 );
		node.setAttribute( 'height', size || 26 );
		node.setAttribute( 'fill', 'currentColor' );
		node.setAttribute( 'aria-hidden', 'true' );

		if ( cls ) {
			node.setAttribute( 'class', cls );
		}

		paths.forEach( function ( d ) {
			var path = document.createElementNS( 'http://www.w3.org/2000/svg', 'path' );
			path.setAttribute( 'd', d );
			node.appendChild( path );
		} );

		return node;
	}

	function buildLauncher() {
		launcher.type = 'button';
		launcher.setAttribute( 'aria-label', cfg.title );

		/*
		 * حباب گفتگو کل مربع ۲۴×۲۴ را پر می‌کند تا روی دکمه‌ی گرد بزرگ و
		 * خوانا دیده شود. سه نقطه در خلاف جهتِ خطِ بیرونی کشیده می‌شوند تا
		 * قانون nonzero آن‌ها را سوراخ کند، نه اینکه پرشان کند.
		 */
		launcher.appendChild( svg(
			[ 'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z' +
				'M7.2 11.55a1.55 1.55 0 1 1 0-3.1 1.55 1.55 0 0 1 0 3.1z' +
				'M12 11.55a1.55 1.55 0 1 1 0-3.1 1.55 1.55 0 0 1 0 3.1z' +
				'M16.8 11.55a1.55 1.55 0 1 1 0-3.1 1.55 1.55 0 0 1 0 3.1z' ],
			36,
			'wcma-lc-ico wcma-lc-ico--chat'
		) );

		launcher.appendChild( svg(
			[ 'M18.3 5.71 12 12.01l-6.3-6.3-1.41 1.41 6.3 6.3-6.3 6.3 1.41 1.41 6.3-6.3 6.3 6.3 1.41-1.41-6.3-6.3 6.3-6.3z' ],
			28,
			'wcma-lc-ico wcma-lc-ico--close'
		) );

		badge.hidden = true;
		launcher.appendChild( badge );
		launcher.addEventListener( 'click', toggle );
		root.appendChild( launcher );
	}

	/**
	 * تصویر همکاران پشتیبانی، روی هم.
	 *
	 * وقتی چند نفر پشت گفتگو هستند، دیدن چهره‌شان اعتماد می‌سازد. با نبودن
	 * تصویر، حرف اول عنوان در دایره می‌نشیند تا سربرگ خالی نماند.
	 *
	 * @return {Node} گره سربرگ.
	 */
	function teamStack() {
		var team = ( cfg.team && cfg.team.length ) ? cfg.team : ( cfg.avatar ? [ cfg.avatar ] : [] );
		var wrap = el( 'div', 'wcma-lc-team' );

		if ( ! team.length ) {
			wrap.appendChild( el( 'div', 'wcma-lc-face wcma-lc-face--fallback', ( cfg.title || '؟' ).trim().charAt( 0 ) ) );

			return wrap;
		}

		// بیش از سه چهره، سربرگ را شلوغ می‌کند.
		team.slice( 0, 3 ).forEach( function ( url ) {
			var img = el( 'img', 'wcma-lc-face' );

			img.src = url;
			img.alt = '';
			img.loading = 'lazy';
			wrap.appendChild( img );
		} );

		return wrap;
	}

	/**
	 * تصویر کوچک کنار پیام اپراتور.
	 *
	 * @return {Node} گره تصویر.
	 */
	function messageFace() {
		var url = ( cfg.team && cfg.team.length ) ? cfg.team[ 0 ] : cfg.avatar;

		if ( ! url ) {
			return el( 'div', 'wcma-lc-msgface wcma-lc-face--fallback', ( cfg.title || '؟' ).trim().charAt( 0 ) );
		}

		var img = el( 'img', 'wcma-lc-msgface' );

		img.src = url;
		img.alt = '';
		img.loading = 'lazy';

		return img;
	}

	function buildPanel() {
		panel.hidden = true;

		var head = el( 'div', 'wcma-lc-head' );

		head.appendChild( teamStack() );

		var titles = el( 'div', 'wcma-lc-titles' );
		titles.appendChild( el( 'strong', '', cfg.title ) );

		var status = el( 'span', 'wcma-lc-status' );
		status.appendChild( el( 'i', 'wcma-lc-dot' ) );
		status.appendChild( el( 'span', 'wcma-lc-statustext', state.online ? cfg.i18n.online : cfg.subtitle ) );
		titles.appendChild( status );
		head.appendChild( titles );

		var close = el( 'button', 'wcma-lc-close' );
		close.type = 'button';
		close.setAttribute( 'aria-label', cfg.i18n.close );
		close.appendChild( svg( [ 'M18.3 5.71 12 12.01l-6.3-6.3-1.41 1.41 6.3 6.3-6.3 6.3 1.41 1.41 6.3-6.3 6.3 6.3 1.41-1.41-6.3-6.3 6.3-6.3z' ], 17 ) );
		close.addEventListener( 'click', toggle );
		head.appendChild( close );

		panel.appendChild( head );

		list = el( 'div', 'wcma-lc-list' );

		// فهرست تازه یعنی هیچ جداکننده‌ای هنوز گذاشته نشده.
		lastDay = '';
		panel.appendChild( list );

		typingRow = el( 'div', 'wcma-lc-typing' );

		var dots = el( 'span', 'wcma-lc-typing__dots' );

		dots.appendChild( el( 'i' ) );
		dots.appendChild( el( 'i' ) );
		dots.appendChild( el( 'i' ) );

		typingRow.appendChild( dots );
		typingRow.appendChild( el( 'span', '', cfg.i18n.typing ) );
		typingRow.hidden = true;
		panel.appendChild( typingRow );

		var replybar = el( 'div', 'wcma-lc-replybar' );

		replybar.hidden = true;
		panel.appendChild( replybar );

		var form = el( 'form', 'wcma-lc-form' );

		input = el( 'textarea', 'wcma-lc-input' );
		input.rows = 1;
		input.placeholder = cfg.i18n.placeholder;
		input.setAttribute( 'aria-label', cfg.i18n.placeholder );

		input.addEventListener( 'input', function () {
			input.style.height = 'auto';
			input.style.height = Math.max( 42, Math.min( 104, input.scrollHeight ) ) + 'px';
			signalTyping();
		} );

		input.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key && ! e.shiftKey ) {
				e.preventDefault();
				send( input.value );
			}
		} );

		var button = el( 'button', 'wcma-lc-send' );
		button.type = 'submit';
		button.setAttribute( 'aria-label', cfg.i18n.send );
		button.appendChild( svg( [ 'M3 20.5 21 12 3 3.5 3 10l12 2-12 2z' ], 19 ) );

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			send( input.value );
		} );

		form.appendChild( input );

		/*
		 * پیوست و ضبط در یک جعبه‌ی چسبیده کنار هم می‌نشینند تا فاصله‌ای بین
		 * خودشان نماند و جای بیشتری برای کادر نوشتن پیام بماند.
		 */
		var tools = el( 'div', 'wcma-lc-tools' );

		if ( cfg.files ) {
			tools.appendChild( buildAttachButton() );
		}

		if ( cfg.voice && canRecord() ) {
			tools.appendChild( buildVoiceButton() );
		}

		if ( tools.childNodes.length ) {
			form.appendChild( tools );
		}

		form.appendChild( button );
		panel.appendChild( form );

		var credit = el( 'div', 'wcma-lc-foot' );
		credit.appendChild( el( 'span', '', cfg.subtitle ) );
		panel.appendChild( credit );

		root.appendChild( panel );
	}

	// --- پیوست و صدا ---

	/**
	 * آیا مرورگر می‌تواند صدا ضبط کند؟
	 *
	 * روی صفحه‌ی بدون HTTPS، مرورگرها میکروفون نمی‌دهند؛ پس دکمه هم نباید
	 * نشان داده شود.
	 *
	 * @return {boolean} می‌تواند؟
	 */
	function canRecord() {
		return !! ( window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia );
	}

	function buildAttachButton() {
		var picker = el( 'input' );

		picker.type = 'file';
		picker.className = 'wcma-lc-file';
		picker.accept = cfg.accept || '';
		picker.tabIndex = -1;

		picker.addEventListener( 'change', function () {
			var file = picker.files && picker.files[ 0 ];

			if ( file ) {
				upload( file, file.name );
			}

			// پاک کردن، تا انتخاب دوباره‌ی همان فایل هم رویداد بدهد.
			picker.value = '';
		} );

		var btn = el( 'button', 'wcma-lc-icon' );

		btn.type = 'button';
		btn.title = cfg.i18n.attach;
		btn.setAttribute( 'aria-label', cfg.i18n.attach );
		btn.appendChild( svg( [ 'M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z' ], 18 ) );
		btn.addEventListener( 'click', function () {
			picker.click();
		} );

		var wrap = el( 'span', 'wcma-lc-attach' );

		wrap.appendChild( picker );
		wrap.appendChild( btn );

		return wrap;
	}

	var recorder = null;
	var recordTimer = null;
	var recordTick = null;
	var recordStart = 0;
	var recordBox = null;

	/**
	 * نمایش «۰:۰۳٫۴» از روی میلی‌ثانیه.
	 *
	 * دهمِ ثانیه نگه داشته می‌شود چون بدون آن، ویس کوتاه همیشه ۰:۰۰ دیده
	 * می‌شود و کاربر نمی‌فهمد ضبط دارد جلو می‌رود.
	 *
	 * @param {number} ms میلی‌ثانیه.
	 * @return {string} زمان خوانا.
	 */
	function clock( ms ) {
		ms = Math.max( 0, ms | 0 );

		var total = Math.floor( ms / 1000 );
		var mm = Math.floor( total / 60 );
		var ss = total % 60;
		var tenth = Math.floor( ( ms % 1000 ) / 100 );
		var text = mm + ':' + ( ss < 10 ? '0' : '' ) + ss + '٫' + tenth;

		// بقیه‌ی ویجت با رقم فارسی نوشته شده؛ شمارنده هم باید یکدست بماند.
		return text.replace( /[0-9]/g, function ( d ) {
			return '۰۱۲۳۴۵۶۷۸۹'[ d ];
		} );
	}

	/**
	 * شمارنده‌ی زنده‌ی ضبط، داخل خود گفتگو.
	 */
	function startClock() {
		recordStart = Date.now();
		recordBox = timeNode( 'wcma-lc-note wcma-lc-rec', cfg.i18n.recording, clock( 0 ) );

		if ( list ) {
			list.appendChild( recordBox );
			list.scrollTop = list.scrollHeight;
		}

		clearInterval( recordTick );
		recordTick = setInterval( function () {
			if ( recordBox ) {
				recordBox.querySelector( 'bdi' ).textContent = clock( Date.now() - recordStart );
			}
		}, 100 );
	}

	function stopClock() {
		clearInterval( recordTick );
		recordTick = null;

		if ( recordBox ) {
			recordBox.remove();
			recordBox = null;
		}

		return recordStart ? Date.now() - recordStart : 0;
	}

	function buildVoiceButton() {
		var btn = el( 'button', 'wcma-lc-icon wcma-lc-mic' );

		btn.type = 'button';
		btn.title = cfg.i18n.record;
		btn.setAttribute( 'aria-label', cfg.i18n.record );
		btn.appendChild( svg( [ 'M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z', 'M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z' ], 18 ) );

		btn.addEventListener( 'click', function () {
			if ( recorder && 'recording' === recorder.state ) {
				stopRecording();
				return;
			}

			startRecording( btn );
		} );

		return btn;
	}

	/**
	 * شروع ضبط صدا.
	 *
	 * @param {Node} btn دکمه‌ی ضبط.
	 */
	function startRecording( btn ) {
		navigator.mediaDevices.getUserMedia( { audio: true } ).then( function ( stream ) {
			var chunks = [];
			var mime = '';

			[ 'audio/webm', 'audio/ogg', 'audio/mp4' ].some( function ( candidate ) {
				if ( window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported( candidate ) ) {
					mime = candidate;
					return true;
				}

				return false;
			} );

			recorder = mime ? new window.MediaRecorder( stream, { mimeType: mime } ) : new window.MediaRecorder( stream );

			recorder.addEventListener( 'dataavailable', function ( e ) {
				if ( e.data && e.data.size ) {
					chunks.push( e.data );
				}
			} );

			recorder.addEventListener( 'stop', function () {
				// میکروفون باید بلافاصله آزاد شود، وگرنه چراغش روشن می‌ماند.
				stream.getTracks().forEach( function ( track ) {
					track.stop();
				} );

				btn.classList.remove( 'is-live' );
				btn.title = cfg.i18n.record;
				clearTimeout( recordTimer );

				var ms = stopClock();
				var type = recorder.mimeType || mime || 'audio/webm';
				var blob = new Blob( chunks, { type: type } );

				recorder = null;

				if ( ! blob.size ) {
					return;
				}

				upload( blob, 'voice.' + extFor( type ), ms );
			} );

			btn.classList.add( 'is-live' );
			btn.title = cfg.i18n.stop;
			startClock();
			recorder.start();

			// سقف دو دقیقه، تا یک ضبط فراموش‌شده فایل بزرگ نسازد.
			recordTimer = setTimeout( stopRecording, 120000 );
		} ).catch( function () {
			systemNote( cfg.i18n.noMic );
		} );
	}

	function stopRecording() {
		if ( recorder && 'inactive' !== recorder.state ) {
			recorder.stop();
		}
	}

	/**
	 * پسوند مناسب برای نوع صدای ضبط‌شده.
	 *
	 * @param {string} type نوع MIME.
	 * @return {string} پسوند.
	 */
	function extFor( type ) {
		type = String( type || '' );

		if ( type.indexOf( 'ogg' ) > -1 ) {
			return 'ogg';
		}

		if ( type.indexOf( 'mp4' ) > -1 ) {
			return 'm4a';
		}

		return 'webm';
	}

	// --- پیام‌ها ---

	var quickCard = null;

	/**
	 * کارت پرسش‌های آماده.
	 *
	 * فقط در آغاز گفتگو نشان داده می‌شود: همان‌جا که بازدیدکننده هنوز چیزی
	 * نپرسیده و پیشنهاد کمک می‌کند. به‌محض اینکه خودش پیامی بفرستد برداشته
	 * می‌شود تا وسط گفتگو جا نگیرد.
	 */
	function buildQuick() {
		if ( quickCard || ! list || ! cfg.quick || ! cfg.quick.length ) {
			return;
		}

		quickCard = el( 'div', 'wcma-lc-quick' );
		quickCard.appendChild( el( 'div', 'wcma-lc-quick__title', cfg.i18n.quickTitle ) );

		cfg.quick.forEach( function ( item ) {
			var chip = el( 'button', 'wcma-lc-chip', item );

			chip.type = 'button';
			chip.addEventListener( 'click', function () {
				send( item );
			} );
			quickCard.appendChild( chip );
		} );

		list.appendChild( quickCard );
	}

	/**
	 * برداشتن کارت پرسش‌ها، پس از اولین پیام خودِ بازدیدکننده.
	 */
	function dropQuick() {
		if ( quickCard ) {
			quickCard.remove();
			quickCard = null;
		}
	}

	/**
	 * نمایش نقل‌قول یک پیام، بالای پاسخ.
	 *
	 * @param {Object} ref پیام ارجاع‌شده.
	 * @return {Node} گره نقل‌قول.
	 */
	function quoteNode( ref ) {
		var box = el( 'div', 'wcma-lc-quote is-' + ( ref.side || 'agent' ) );

		box.appendChild( el( 'span', 'wcma-lc-quote__who', 'visitor' === ref.side ? cfg.i18n.quoteYou : cfg.title ) );
		box.appendChild( el( 'span', 'wcma-lc-quote__text', ref.text || kindLabel( ref.kind ) ) );

		return box;
	}

	/**
	 * نام نوع پیوست، وقتی پیامِ نقل‌قول‌شده متنی ندارد.
	 *
	 * @param {string} kind نوع.
	 * @return {string} برچسب.
	 */
	function kindLabel( kind ) {
		var map = cfg.i18n.kinds || {};

		return map[ kind ] || cfg.i18n.download;
	}

	/**
	 * دکمه‌ی پاسخ کنار هر پیام.
	 *
	 * @param {Object} message پیام.
	 * @return {Node} گره دکمه.
	 */
	function replyButton( message ) {
		var btn = el( 'button', 'wcma-lc-replybtn' );

		btn.type = 'button';
		btn.title = cfg.i18n.reply;
		btn.setAttribute( 'aria-label', cfg.i18n.reply );
		btn.appendChild( svg( [ 'M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z' ], 16 ) );

		btn.addEventListener( 'click', function () {
			startReply( message );
		} );

		return btn;
	}

	var replyTo = null;

	/**
	 * گرفتن پاسخ به یک پیام: نوار نقل‌قول بالای جعبه‌ی متن.
	 *
	 * @param {Object} message پیام.
	 */
	function startReply( message ) {
		if ( ! message.id ) {
			return;
		}

		var text = message.body || '';

		if ( message.file && message.file.url && ( ! text || text === message.file.name ) ) {
			text = kindLabel( message.file.kind );
		}

		replyTo = { id: message.id, text: text, side: 'me' === message.from ? 'visitor' : 'agent' };
		paintReplyBar();

		if ( input ) {
			input.focus();
		}
	}

	function cancelReply() {
		replyTo = null;
		paintReplyBar();
	}

	function paintReplyBar() {
		var bar = panel.querySelector( '.wcma-lc-replybar' );

		if ( ! bar ) {
			return;
		}

		bar.textContent = '';

		if ( ! replyTo ) {
			bar.hidden = true;

			return;
		}

		bar.hidden = false;
		bar.appendChild( quoteNode( replyTo ) );

		var drop = el( 'button', 'wcma-lc-replybar__x' );

		drop.type = 'button';
		drop.title = cfg.i18n.close;
		drop.setAttribute( 'aria-label', cfg.i18n.close );
		drop.appendChild( svg( [ 'M18.3 5.71 12 12.01l-6.3-6.3-1.41 1.41 6.3 6.3-6.3 6.3 1.41 1.41 6.3-6.3 6.3 6.3 1.41-1.41-6.3-6.3 6.3-6.3z' ], 14 ) );
		drop.addEventListener( 'click', cancelReply );
		bar.appendChild( drop );
	}

	var lastDay = '';

	/**
	 * گذاشتن جداکننده‌ی روز بالای گروه پیام‌ها.
	 *
	 * @param {string} day برچسب روز.
	 */
	function dayDivider( day ) {
		if ( ! list || ! day || day === lastDay ) {
			return;
		}

		lastDay = day;

		var wrap = el( 'div', 'wcma-lc-day' );

		wrap.appendChild( el( 'span', '', day ) );
		list.appendChild( wrap );
	}

	/*
	 * زیر آخرین پیام، اگر بیش از شش ساعت از آن گذشته باشد، «چند وقت پیش»
	 * نوشته می‌شود. فقط آخرین پیام، چون در یک گفتگوی زنده تکرارش زیر هر
	 * حباب بیشتر شلوغی است تا کمک.
	 */
	var AGO_AFTER = 6 * 3600;
	var agoNode;
	var agoTimer;

	function paintAgo() {
		if ( ! list ) {
			return;
		}

		if ( agoNode && agoNode.parentNode ) {
			agoNode.parentNode.removeChild( agoNode );
		}

		agoNode = null;

		var rows = list.querySelectorAll( '.wcma-lc-msg' );
		var last = rows.length ? rows[ rows.length - 1 ] : null;

		if ( ! last || ! last.wcmaMessage ) {
			return;
		}

		var seconds = ageOf( last.wcmaMessage );

		if ( seconds < AGO_AFTER ) {
			return;
		}

		agoNode = el( 'span', 'wcma-lc-ago', agoLabel( seconds ) );
		last.appendChild( agoNode );
	}

	/*
	 * گفتگو ممکن است ساعت‌ها باز بماند؛ برچسب هر دقیقه بازخوانی می‌شود تا
	 * «۶ ساعت پیش» روی صفحه کهنه نشود.
	 */
	function watchAgo() {
		if ( agoTimer ) {
			return;
		}

		agoTimer = setInterval( paintAgo, 60000 );
	}

	function addMessage( message, quiet ) {
		if ( ! list ) {
			return;
		}

		var mine = 'me' === message.from;

		// جداکننده‌ی روز، فقط وقتی روزِ پیام با پیام قبلی فرق کند.
		dayDivider( message.day || cfg.i18n.today );

		var row = el( 'div', 'wcma-lc-msg ' + ( mine ? 'is-me' : 'is-them' ) + ( 'bot' === message.from ? ' is-bot' : '' ) );
		var line = el( 'div', 'wcma-lc-line' );

		// چهره‌ی پشتیبان فقط کنار پیام‌های او می‌نشیند، نه کنار پیام مشتری.
		if ( ! mine ) {
			line.appendChild( messageFace() );
		}

		var body = el( 'div', 'wcma-lc-bubble' );

		// نقل‌قول پیامی که این یکی پاسخ آن است، بالای خود پیام می‌نشیند.
		if ( message.reply && ( message.reply.text || message.reply.kind ) ) {
			body.appendChild( quoteNode( message.reply ) );
		}

		if ( message.file && message.file.url ) {
			/*
			 * سرور خودش تشخیص می‌دهد متن پیام توضیح واقعی است یا برچسب خودکار
			 * («پیام صوتی» یا نام فایل)؛ نسخه‌های قدیمی‌تر آن را نمی‌فرستند،
			 * پس همان مقایسه‌ی قبلی هم به‌عنوان پشتیبان می‌ماند.
			 */
			var caption = undefined !== message.file.caption
				? message.file.caption
				: ( ( message.body && message.body !== message.file.name ) ? message.body : '' );
			var bare = ! caption && ( 'image' === message.file.kind || 'video' === message.file.kind );

			// عکس و ویدیوی بدون زیرنویس، بدون کادر و زمینه نشان داده می‌شوند.
			if ( bare ) {
				row.classList.add( 'is-bare' );
			}

			// حباب رسانه‌ای فاصله‌ی داخلی کمتری می‌گیرد تا پیام‌ها به هم نزدیک بمانند.
			row.classList.add( 'is-media' );

			body.appendChild( attachmentNode( message.file ) );

			if ( caption ) {
				body.appendChild( el( 'div', 'wcma-lc-att__caption', caption ) );
			}
		} else {
			/*
			 * textContent همه‌ی فرزندها را پاک می‌کند و نقل‌قولِ بالای پیام را
			 * می‌برد؛ پس متن به‌صورت گره اضافه می‌شود.
			 */
			body.appendChild( document.createTextNode( message.body ) );
		}

		/*
		 * ساعت پیام روی خودِ حباب می‌نشیند و فقط با رفتن موس (یا فوکوس
		 * صفحه‌کلید) دیده می‌شود؛ چیدمان گفتگو این‌طور تمیز می‌ماند.
		 */
		if ( message.date ) {
			var stamp = el( 'span', 'wcma-lc-stamp', message.date );
			stamp.setAttribute( 'aria-hidden', 'true' );
			body.appendChild( stamp );

			// برای صفحه‌خوان، ساعت همیشه خواندنی است.
			body.setAttribute( 'aria-label', message.date );
		}

		line.appendChild( body );
		line.appendChild( replyButton( message ) );
		row.appendChild( line );

		// لحظه‌ی رسیدن پیام، تا سنش بعداً زنده بماند.
		if ( undefined !== message.ago && null !== message.ago && ! message.seenAt ) {
			message.seenAt = Date.now();
		}

		row.wcmaMessage = message;

		list.appendChild( row );
		paintAgo();
		list.scrollTop = list.scrollHeight;

		if ( message.id && message.id > state.lastId ) {
			state.lastId = message.id;
			write( SEEN, String( state.lastId ) );
		}

		if ( ! mine && ! state.open && ! quiet ) {
			state.unread++;
			badge.textContent = String( state.unread );
			badge.hidden = false;
			launcher.classList.add( 'is-pinging' );
			ding();
		}
	}

	/**
	 * ساخت نمایش پیوست بر اساس نوع آن.
	 *
	 * عکس را نشان می‌دهیم، صدا و ویدیو را پخش‌شدنی می‌کنیم و بقیه را به یک
	 * لینک دریافت تبدیل می‌کنیم؛ نام فایل همیشه به‌صورت متن می‌نشیند، نه HTML.
	 *
	 * @param {Object} file پیوست.
	 * @return {Node} گره آماده.
	 */
	function attachmentNode( file ) {
		var wrap = el( 'div', 'wcma-lc-att is-' + ( file.kind || 'doc' ) );

		/*
		 * عکس و ویدیو خودشان را نشان می‌دهند؛ نام و حجم زیرشان فقط شلوغی است.
		 * خودِ تصویر لینک باز کردن اندازه‌ی کامل می‌شود.
		 */
		if ( 'image' === file.kind || 'video' === file.kind ) {
			var media;

			if ( 'image' === file.kind ) {
				media = el( 'img', 'wcma-lc-att__img' );
				media.src = file.url;
				media.alt = file.name || '';
				media.loading = 'lazy';
			} else {
				media = el( 'video', 'wcma-lc-att__media' );
				media.src = file.url;
				media.controls = true;
				media.preload = 'metadata';
			}

			if ( 'image' === file.kind ) {
				var open = el( 'a', 'wcma-lc-att__open' );

				open.href = file.url;
				open.target = '_blank';
				open.rel = 'noopener noreferrer';
				open.title = file.name || '';
				open.appendChild( media );
				wrap.appendChild( open );
			} else {
				wrap.appendChild( media );
			}

			return wrap;
		}

		if ( 'audio' === file.kind ) {
			wrap.appendChild( voicePlayer( file ) );

			return wrap;
		}

		// فایل متنی و فشرده چیزی برای نشان دادن ندارند؛ لینک دریافت می‌مانند.
		var link = el( 'a', 'wcma-lc-att__link' );

		link.href = file.url;
		link.target = '_blank';
		link.rel = 'noopener noreferrer';
		link.textContent = ( file.name || cfg.i18n.download ) + ( file.human ? ' · ' + file.human : '' );

		wrap.appendChild( link );

		return wrap;
	}

	var RATES = [ 1, 1.5, 2 ];
	var RATE_KEY = 'wcma_lc_rate';
	var voiceRate = 1;

	try {
		var savedRate = parseFloat( window.localStorage.getItem( RATE_KEY ) );

		if ( RATES.indexOf( savedRate ) > -1 ) {
			voiceRate = savedRate;
		}
	} catch ( e ) {
		// حالت ناشناس مرورگر؛ همان سرعت عادی می‌ماند.
	}

	function rememberRate() {
		try {
			window.localStorage.setItem( RATE_KEY, String( voiceRate ) );
		} catch ( e ) {}
	}

	/**
	 * سرعت بعدی در چرخه‌ی ۱x → ۱٫۵x → ۲x → ۱x.
	 *
	 * @param {number} rate سرعت کنونی.
	 * @return {number} سرعت بعدی.
	 */
	function nextRate( rate ) {
		var at = RATES.indexOf( rate );

		return RATES[ ( at + 1 ) % RATES.length ];
	}

	/**
	 * ثانیه‌ی سپری‌شده از یک پیام، همین حالا.
	 *
	 * سرور سن پیام را در لحظه‌ی پاسخ می‌فرستد؛ اینجا زمانی که از دریافت
	 * گذشته به آن افزوده می‌شود. این‌طور ساعتِ اشتباهِ دستگاه کاربر و
	 * اختلاف منطقه‌ی زمانی هیچ اثری ندارد.
	 *
	 * @param {Object} message پیام.
	 * @return {number} ثانیه.
	 */
	function ageOf( message ) {
		if ( undefined === message.ago || null === message.ago ) {
			return -1;
		}

		var since = message.seenAt ? ( Date.now() - message.seenAt ) / 1000 : 0;

		return Math.max( 0, ( message.ago | 0 ) + Math.round( since ) );
	}

	/**
	 * «۶ ساعت پیش» و مانند آن.
	 *
	 * @param {number} seconds ثانیه.
	 * @return {string} برچسب.
	 */
	function agoLabel( seconds ) {
		var t = cfg.i18n;

		if ( seconds < 60 ) {
			return t.justNow || 'همین حالا';
		}

		var value;
		var template;

		if ( seconds < 3600 ) {
			value = Math.floor( seconds / 60 );
			template = t.minutesAgo || '%s دقیقه پیش';
		} else if ( seconds < 86400 ) {
			value = Math.floor( seconds / 3600 );
			template = t.hoursAgo || '%s ساعت پیش';
		} else {
			value = Math.floor( seconds / 86400 );
			template = t.daysAgo || '%s روز پیش';
		}

		return template.replace( '%s', faNum( value ) );
	}

	/**
	 * رقم‌های یک عدد به فارسی.
	 *
	 * @param {number|string} value عدد.
	 * @return {string} رشته.
	 */
	function faNum( value ) {
		return String( value ).replace( /[0-9]/g, function ( d ) {
			return '۰۱۲۳۴۵۶۷۸۹'[ d ];
		} );
	}

	/**
	 * برچسب سرعت با رقم فارسی.
	 *
	 * @param {number} rate سرعت.
	 * @return {string} برچسب.
	 */
	function rateLabel( rate ) {
		return String( rate ).replace( '.', '٫' ).replace( /[0-9]/g, function ( d ) {
			return '۰۱۲۳۴۵۶۷۸۹'[ d ];
		} ) + 'x';
	}

	/**
	 * زمان پخش به شکل دقیقه:ثانیه، بدون دهم.
	 *
	 * روی پخش‌کننده، دهمِ ثانیه فقط شلوغی است؛ آنجا فقط هنگام ضبط لازم بود.
	 *
	 * @param {number} ms میلی‌ثانیه.
	 * @return {string} زمان خوانا.
	 */
	function clockShort( ms ) {
		var total = Math.max( 0, Math.round( ( ms | 0 ) / 1000 ) );
		var mm = Math.floor( total / 60 );
		var ss = total % 60;
		var text = ( mm < 10 ? '0' : '' ) + mm + ':' + ( ss < 10 ? '0' : '' ) + ss;

		return text.replace( /[0-9]/g, function ( d ) {
			return '۰۱۲۳۴۵۶۷۸۹'[ d ];
		} );
	}

	/**
	 * پخش‌کننده‌ی ویس.
	 *
	 * کنترل پیش‌فرض مرورگر در هر سیستم‌عامل شکل دیگری دارد، جای زیادی می‌گیرد
	 * و با ظاهر گفتگو جور نیست؛ پس یک دکمه‌ی پخش، نوار پیشرفت و زمان
	 * ساخته می‌شود و خودِ عنصر صدا پنهان می‌ماند.
	 *
	 * @param {Object} file پیوست.
	 * @return {Node} گره آماده.
	 */
	function voicePlayer( file ) {
		var box = el( 'div', 'wcma-lc-voice' );
		var audio = el( 'audio' );

		audio.src = file.url;
		audio.preload = 'metadata';
		audio.playbackRate = voiceRate;

		var btn = el( 'button', 'wcma-lc-voice__btn' );

		btn.type = 'button';
		btn.setAttribute( 'aria-label', cfg.i18n.play );
		btn.appendChild( svg( [ 'M8 5v14l11-7z' ], 20, 'wcma-lc-voice__icon' ) );

		var meter = el( 'div', 'wcma-lc-voice__meter' );
		var stamp = el( 'span', 'wcma-lc-voice__time' );
		var bdi = document.createElement( 'bdi' );

		// مدت از سرور می‌آید؛ فایل webm اغلب مدتش را «بی‌نهایت» گزارش می‌کند.
		bdi.textContent = clockShort( file.ms || 0 );
		stamp.appendChild( bdi );

		var track = el( 'div', 'wcma-lc-voice__track' );
		var fill = el( 'i', 'wcma-lc-voice__fill' );

		track.appendChild( fill );
		meter.appendChild( stamp );
		meter.appendChild( track );

		function paint() {
			var total = audio.duration;

			if ( ! isFinite( total ) || ! total ) {
				total = ( file.ms || 0 ) / 1000;
			}

			var ratio = total ? Math.min( 1, audio.currentTime / total ) : 0;

			fill.style.width = ( ratio * 100 ) + '%';
			// پیش از پخش، مدت کل؛ هنگام پخش، زمان گذشته.
			bdi.textContent = clockShort( ( audio.currentTime > 0 ? audio.currentTime * 1000 : ( file.ms || total * 1000 ) ) );
		}

		function icon( playing ) {
			btn.textContent = '';
			btn.appendChild( svg(
				playing ? [ 'M6 5h4v14H6zM14 5h4v14h-4z' ] : [ 'M8 5v14l11-7z' ],
				20,
				'wcma-lc-voice__icon'
			) );
			btn.setAttribute( 'aria-label', playing ? cfg.i18n.pause : cfg.i18n.play );
			box.classList.toggle( 'is-playing', playing );
		}

		btn.addEventListener( 'click', function () {
			if ( audio.paused ) {
				// هم‌زمان دو ویس پخش نشود.
				Array.prototype.forEach.call( list.querySelectorAll( 'audio' ), function ( other ) {
					if ( other !== audio ) {
						other.pause();
					}
				} );

				audio.play().catch( function () {
					systemNote( cfg.i18n.failed );
				} );

				return;
			}

			audio.pause();
		} );

		audio.addEventListener( 'play', function () { icon( true ); } );
		audio.addEventListener( 'pause', function () { icon( false ); } );
		audio.addEventListener( 'timeupdate', paint );
		audio.addEventListener( 'loadedmetadata', paint );
		audio.addEventListener( 'ended', function () {
			icon( false );
			audio.currentTime = 0;
			paint();
		} );

		// بردن نشانگر با کلیک روی نوار.
		track.addEventListener( 'click', function ( e ) {
			var total = isFinite( audio.duration ) && audio.duration ? audio.duration : ( file.ms || 0 ) / 1000;

			if ( ! total ) {
				return;
			}

			var rect = track.getBoundingClientRect();
			// نوار در چیدمان راست‌به‌چپ هم از چپ به راست پر می‌شود.
			var ratio = ( e.clientX - rect.left ) / rect.width;

			audio.currentTime = Math.max( 0, Math.min( 1, ratio ) ) * total;
			paint();
		} );

		var speed = el( 'button', 'wcma-lc-voice__rate', rateLabel( voiceRate ) );

		speed.type = 'button';
		speed.title = cfg.i18n.speed;
		speed.setAttribute( 'aria-label', cfg.i18n.speed );
		speed.addEventListener( 'click', function () {
			voiceRate = nextRate( voiceRate );
			rememberRate();

			// سرعت روی همه‌ی ویس‌های گفتگو یکی می‌ماند، نه فقط همین یکی.
			Array.prototype.forEach.call( list.querySelectorAll( 'audio' ), function ( node ) {
				node.playbackRate = voiceRate;
			} );

			Array.prototype.forEach.call( list.querySelectorAll( '.wcma-lc-voice__rate' ), function ( node ) {
				node.textContent = rateLabel( voiceRate );
			} );
		} );

		box.appendChild( btn );
		box.appendChild( meter );
		box.appendChild( speed );
		box.appendChild( audio );

		return box;
	}

	/**
	 * برچسب مدت، با عدد ایزوله‌شده.
	 *
	 * برچسب فارسی راست‌به‌چپ است و عدد را داخل خودش می‌چرخاند — «۰:۰۵٫۳»
	 * وارونه دیده می‌شد. bdi عدد را از جهت متن جدا نگه می‌دارد.
	 *
	 * @param {string} cls   کلاس.
	 * @param {string} label برچسب.
	 * @param {string} value مقدار.
	 * @return {Node} گره آماده.
	 */
	function timeNode( cls, label, value ) {
		var box = el( 'span', cls );

		box.appendChild( document.createTextNode( label + ' ' ) );

		var bdi = document.createElement( 'bdi' );

		bdi.textContent = value || '—';
		box.appendChild( bdi );

		return box;
	}

	/**
	 * فرستادن یک فایل یا صدای ضبط‌شده.
	 *
	 * چون چندبخشی است، از همان کمک‌کار JSON استفاده نمی‌کند.
	 *
	 * @param {Blob}   blob محتوا.
	 * @param {string} name نام فایل.
	 */
	function upload( blob, name, ms ) {
		if ( ! cfg.files ) {
			return;
		}

		if ( cfg.maxFile && blob.size > cfg.maxFile ) {
			systemNote( cfg.i18n.tooBig + ( cfg.maxLabel ? ' (' + cfg.maxLabel + ')' : '' ) );
			return;
		}

		var note = el( 'div', 'wcma-lc-note', cfg.i18n.uploading );

		if ( list ) {
			list.appendChild( note );
			list.scrollTop = list.scrollHeight;
		}

		var data = new FormData();

		data.append( 'file', blob, name );
		data.append( 'token', state.token || '' );

		if ( replyTo ) {
			data.append( 'reply', String( replyTo.id ) );
			cancelReply();
		}

		// مدت واقعی ضبط از همین‌جا می‌رود؛ خواندنش از فایل webm نامطمئن است.
		if ( ms ) {
			data.append( 'duration', String( Math.round( ms ) ) );
		}

		[ 'name', 'phone', 'email' ].forEach( function ( key ) {
			if ( state.profile[ key ] ) {
				data.append( key, state.profile[ key ] );
			}
		} );

		var xhr = new XMLHttpRequest();

		xhr.open( 'POST', cfg.root + '/chat/upload', true );

		// کوکی نمی‌فرستیم تا وردپرس نانس نخواهد؛ مسیر خودش عمومی است.
		xhr.withCredentials = false;

		xhr.onload = function () {
			var result = null;

			try {
				result = JSON.parse( xhr.responseText );
			} catch ( e ) {
				result = null;
			}

			note.remove();

			if ( ! result || ! result.ok ) {
				systemNote( ( result && result.message ) || cfg.i18n.failed );
				return;
			}

			if ( result.token && result.token !== state.token ) {
				state.token = result.token;
				write( STORE, state.token );
			}

			state.started = true;

			dropQuick();
			addMessage( { from: 'me', body: result.body, file: result.file, date: result.date }, true );
			startPolling();
		};

		xhr.onerror = function () {
			note.remove();
			systemNote( cfg.i18n.failed );
		};

		xhr.send( data );
	}

	function systemNote( text ) {
		if ( ! list ) {
			return;
		}

		list.appendChild( el( 'div', 'wcma-lc-note', text ) );
		list.scrollTop = list.scrollHeight;
	}

	function ding() {
		if ( ! cfg.sound ) {
			return;
		}

		try {
			var Ctx = window.AudioContext || window.webkitAudioContext;

			if ( ! Ctx ) {
				return;
			}

			var ctx = new Ctx();
			var osc = ctx.createOscillator();
			var gain = ctx.createGain();

			osc.frequency.value = 880;
			gain.gain.value = 0.05;
			osc.connect( gain );
			gain.connect( ctx.destination );
			osc.start();
			osc.stop( ctx.currentTime + 0.12 );
		} catch ( e ) {
			// صدا مهم نیست؛ اگر مرورگر اجازه نداد بی‌صدا رد می‌شویم.
		}
	}

	function send( text ) {
		text = ( text || '' ).trim();

		if ( ! text ) {
			return;
		}

		var payload = { text: text };
		// نقل‌قول پیش از پاک شدن نوار برداشته می‌شود تا در حباب هم نشان داده شود.
		var echo = replyTo;

		if ( replyTo ) {
			payload.reply = replyTo.id;
			cancelReply();
		}

		dropQuick();
		addMessage( { from: 'me', body: text, date: '', reply: echo }, true );
		input.value = '';
		input.style.height = '';

		if ( state.profile.name ) {
			payload.name = state.profile.name;
		}

		if ( state.profile.phone ) {
			payload.phone = state.profile.phone;
		}

		if ( state.profile.email ) {
			payload.email = state.profile.email;
		}

		api( 'send', payload, function ( data ) {
			if ( ! data || ! data.ok ) {
				// پیام فنیِ وردپرس («Cookie check failed» و مانند آن) به کاربر نشان داده نمی‌شود.
				var note = ( data && data.ok === false && data.message ) ? data.message : cfg.i18n.failed;

				systemNote( note );

				if ( data && data.code && window.console ) {
					window.console.warn( 'WCMA chat:', data.code, data.message );
				}

				return;
			}

			if ( data.token && data.token !== state.token ) {
				state.token = data.token;
				write( STORE, state.token );
			}

			state.started = true;
			state.online = !! data.online;
			paintStatus();

			( data.replies || [] ).forEach( function ( reply ) {
				addMessage( reply );
			} );

			if ( ! data.replies || ! data.replies.length ) {
				if ( ! state.online && ! cfg.within ) {
					systemNote( cfg.offline );
				}
			}

			startPolling();
		} );
	}

	function signalTyping() {
		var now = Date.now();

		if ( now - state.typingSent < 4000 || ! state.token ) {
			return;
		}

		state.typingSent = now;
		api( 'meta', { typing: 1 } );
	}

	// --- فرم پیش از گفتگو ---

	function needsForm() {
		// شناسه‌ی نشست به‌محض باز شدن ویجت ساخته می‌شود، پس معیارِ «شروع شدن» نیست؛
		// معیار این است که گفتگویی وجود داشته باشد یا فرم قبلاً پر شده باشد.
		if ( state.started || read( FORMED ) ) {
			return false;
		}

		return cfg.askName || cfg.askPhone || cfg.askEmail;
	}

	function buildForm() {
		var wrap = el( 'div', 'wcma-lc-prechat' );

		wrap.appendChild( el( 'p', 'wcma-lc-prechat__intro', cfg.welcome ) );

		var fields = {};

		function field( key, label, type, value ) {
			var box = el( 'label', 'wcma-lc-field' );
			box.appendChild( el( 'span', '', label ) );

			var node = el( 'input' );
			node.type = type;
			node.value = value || '';

			if ( 'tel' === type ) {
				node.dir = 'ltr';
				node.inputMode = 'numeric';
			}

			if ( 'email' === type ) {
				node.dir = 'ltr';
			}

			box.appendChild( node );
			wrap.appendChild( box );
			fields[ key ] = node;
		}

		if ( cfg.askName ) {
			field( 'name', cfg.i18n.name, 'text', cfg.me.name );
		}

		if ( cfg.askPhone ) {
			field( 'phone', cfg.i18n.phone, 'tel', cfg.me.phone );
		}

		if ( cfg.askEmail ) {
			field( 'email', cfg.i18n.email, 'email', cfg.me.email );
		}

		var error = el( 'p', 'wcma-lc-error' );
		error.hidden = true;
		wrap.appendChild( error );

		var start = el( 'button', 'wcma-lc-start', cfg.i18n.start );
		start.type = 'button';

		start.addEventListener( 'click', function () {
			var values = {};
			var problem = '';

			Object.keys( fields ).forEach( function ( key ) {
				values[ key ] = fields[ key ].value.trim();
			} );

			if ( cfg.askName && ! values.name ) {
				problem = cfg.i18n.required;
			}

			// اعتبارسنجی فارسی، بدون تکیه بر پیام انگلیسی مرورگر.
			if ( ! problem && cfg.askPhone ) {
				var digits = ( values.phone || '' ).replace( /[۰-۹]/g, function ( d ) {
					return String( '۰۱۲۳۴۵۶۷۸۹'.indexOf( d ) );
				} ).replace( /\D/g, '' );

				if ( digits.length < 10 ) {
					problem = cfg.i18n.badPhone;
				} else {
					values.phone = digits;
				}
			}

			if ( ! problem && cfg.askEmail && values.email && ! /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test( values.email ) ) {
				problem = cfg.i18n.badEmail;
			}

			if ( problem ) {
				error.textContent = problem;
				error.hidden = false;
				return;
			}

			if ( ! state.token ) {
				state.token = 'x' + Math.random().toString( 36 ).slice( 2 ) + Date.now().toString( 36 );
				write( STORE, state.token );
			}

			// تا پیش از نخستین پیام، گفتگویی در سرور نیست؛ پس مقادیر را نگه می‌داریم
			// تا همراه همان پیام فرستاده شوند و از دست نروند.
			state.profile = values;
			write( FORMED, '1' );
			api( 'meta', values );
			state.started = true;
			wrap.remove();
			panel.classList.remove( 'is-prechat' );
			greet();
			input.focus();
		} );

		wrap.appendChild( start );
		panel.classList.add( 'is-prechat' );
		panel.insertBefore( wrap, list );
	}

	function greet() {
		if ( read( GREET ) ) {
			return;
		}

		write( GREET, '1' );
		addMessage( { from: 'bot', body: cfg.welcome, date: '' }, true );
		buildQuick();

		if ( ! cfg.within ) {
			if ( ! leadForm() ) {
				systemNote( cfg.offline );
			}
		}
	}

	// --- فرم تماس خارج از ساعت کاری ---

	/**
	 * فرم کوتاه گرفتن شماره، وقتی کسی آن‌طرف نیست.
	 *
	 * بیرون از ساعت کاری، یادداشتِ «الان نیستیم» کاری از پیش نمی‌برد؛ این
	 * فرم همان‌جا در گفتگو می‌نشیند و مشخصات را در پرونده‌ی مشتریان ثبت
	 * می‌کند تا صبح کسی پیگیری کند.
	 *
	 * @return {boolean} آیا فرم نشان داده شد؟
	 */
	function leadForm() {
		var conf = cfg.leadForm;

		if ( ! conf || read( LEAD ) || root.querySelector( '.wcma-lc-lead' ) ) {
			return false;
		}

		var row = el( 'div', 'wcma-lc-msg is-them is-lead' );
		var line = el( 'div', 'wcma-lc-line' );

		line.appendChild( messageFace() );

		var card = el( 'div', 'wcma-lc-bubble wcma-lc-lead' );

		if ( conf.text ) {
			card.appendChild( el( 'p', 'wcma-lc-lead__intro', conf.text ) );
		}

		var fields = {};

		function field( key, label, type ) {
			var node = el( 'input', 'wcma-lc-lead__input' );

			node.type = type;
			node.placeholder = label;
			node.setAttribute( 'aria-label', label );

			if ( 'tel' === type ) {
				node.dir = 'ltr';
				node.inputMode = 'numeric';
			}

			card.appendChild( node );
			fields[ key ] = node;
		}

		if ( conf.name ) {
			field( 'name', cfg.i18n.leadName, 'text' );
		}

		field( 'phone', cfg.i18n.leadPhone, 'tel' );

		if ( conf.order ) {
			field( 'order', cfg.i18n.leadOrder, 'text' );
		}

		var error = el( 'p', 'wcma-lc-error' );
		error.hidden = true;
		card.appendChild( error );

		var send = el( 'button', 'wcma-lc-lead__send', cfg.i18n.leadSend );
		send.type = 'button';

		send.addEventListener( 'click', function () {
			var values = {};

			Object.keys( fields ).forEach( function ( key ) {
				values[ key ] = fields[ key ].value.trim();
			} );

			var digits = ( values.phone || '' ).replace( /[۰-۹]/g, function ( d ) {
				return String( '۰۱۲۳۴۵۶۷۸۹'.indexOf( d ) );
			} ).replace( /\D/g, '' );

			if ( digits.length < 10 ) {
				error.textContent = cfg.i18n.badPhone;
				error.hidden = false;
				fields.phone.focus();
				return;
			}

			values.phone = digits;
			send.disabled = true;

			// بدون توکن، سرور گفتگویی برای بستن این مشخصات پیدا نمی‌کند.
			if ( ! state.token ) {
				state.token = 'x' + Math.random().toString( 36 ).slice( 2 ) + Date.now().toString( 36 );
				write( STORE, state.token );
			}

			api( 'lead', values, function ( data ) {
				send.disabled = false;

				if ( ! data || ! data.ok ) {
					error.textContent = ( data && data.message ) || cfg.i18n.failed;
					error.hidden = false;
					return;
				}

				write( LEAD, '1' );
				row.remove();

				if ( data.message ) {
					addMessage( { from: 'bot', body: data.message, date: '' }, true );
				}
			} );
		} );

		card.appendChild( send );
		line.appendChild( card );
		row.appendChild( line );
		list.appendChild( row );
		list.scrollTop = list.scrollHeight;

		return true;
	}

	// --- امتیازدهی ---

	function askRating() {
		if ( ! cfg.rating || state.rated || ! state.started ) {
			return;
		}

		state.rated = 1;

		var wrap = el( 'div', 'wcma-lc-rate' );
		wrap.appendChild( el( 'span', '', cfg.i18n.rate ) );

		var stars = el( 'div', 'wcma-lc-stars' );

		// از ۵ به ۱، چون چیدمان ستاره‌ها معکوس است و انتخابگر CSS باید ستاره‌های
		// کوچک‌تر را هم پر کند.
		for ( var i = 5; i >= 1; i-- ) {
			( function ( score ) {
				var star = el( 'button', 'wcma-lc-star', '★' );
				star.type = 'button';
				star.setAttribute( 'aria-label', String( score ) );

				star.addEventListener( 'click', function () {
					api( 'meta', { rating: score } );

					while ( wrap.firstChild ) {
						wrap.removeChild( wrap.firstChild );
					}

					wrap.appendChild( el( 'span', '', cfg.i18n.thanks ) );
				} );

				stars.appendChild( star );
			}( i ) );
		}

		wrap.appendChild( stars );
		list.appendChild( wrap );
		list.scrollTop = list.scrollHeight;
	}

	// --- وضعیت و پولینگ ---

	function paintStatus() {
		var text = root.querySelector( '.wcma-lc-statustext' );
		var dot = root.querySelector( '.wcma-lc-dot' );

		if ( text ) {
			text.textContent = state.online ? cfg.i18n.online : cfg.subtitle;
		}

		if ( dot ) {
			dot.classList.toggle( 'is-online', state.online );
		}
	}

	function poll() {
		if ( ! state.token ) {
			return;
		}

		api( 'poll', { since: state.lastId }, function ( data ) {
			if ( ! data || ! data.ok ) {
				return;
			}

			state.online = !! data.online;
			paintStatus();

			var wasTyping = ! typingRow.hidden;

			typingRow.hidden = ! data.typing;

			// با پیدا شدن نشان تایپ، آخرین پیام نباید زیر آن پنهان بماند.
			if ( data.typing && ! wasTyping && list ) {
				list.scrollTop = list.scrollHeight;
			}

			( data.messages || [] ).forEach( function ( message ) {
				addMessage( message );
			} );
		} );
	}

	function startPolling() {
		if ( state.polling ) {
			return;
		}

		// وقتی جعبه باز است سریع‌تر، وگرنه آرام‌تر تا باری روی سرور نگذارد.
		state.polling = setInterval( function () {
			if ( document.hidden ) {
				return;
			}

			poll();
		}, state.open ? 5000 : 20000 );
	}

	function restartPolling() {
		if ( state.polling ) {
			clearInterval( state.polling );
			state.polling = null;
		}

		startPolling();
	}

	function toggle() {
		state.open = ! state.open;
		panel.hidden = ! state.open;
		launcher.classList.toggle( 'is-open', state.open );

		if ( state.open ) {
			state.unread = 0;
			badge.hidden = true;
			launcher.classList.remove( 'is-pinging' );
			write( OPEN, '1' );
			watchAgo();
			paintAgo();

			// حباب دعوت با باز شدن پنجره کار خودش را کرده و باید برود.
			var invite = root.querySelector( '.wcma-lc-invite' );

			if ( invite ) {
				invite.remove();
			}

			if ( needsForm() ) {
				if ( ! root.querySelector( '.wcma-lc-prechat' ) ) {
					buildForm();
				}
			} else {
				greet();

				if ( input ) {
					input.focus();
				}
			}

			poll();
		} else {
			write( OPEN, '' );
			askRating();
		}

		restartPolling();
	}

	// --- راه‌اندازی ---

	function boot() {
		buildLauncher();
		buildPanel();
		paintStatus();

		api( 'open', {}, function ( data ) {
			if ( ! data || ! data.ok ) {
				return;
			}

			if ( data.token ) {
				state.token = data.token;
				write( STORE, state.token );
			}

			state.online = !! data.online;
			state.rated = data.rated || 0;
			paintStatus();

			if ( data.chat ) {
				state.started = true;
				write( FORMED, '1' );
			}

			if ( data.messages && data.messages.length ) {
				state.started = true;
				write( GREET, '1' );

				var asked = false;

				data.messages.forEach( function ( message ) {
					addMessage( message, true );

					if ( 'me' === message.from ) {
						asked = true;
					}
				} );

				// اگر بازدیدکننده قبلاً چیزی پرسیده، دیگر آغاز گفتگو نیست.
				if ( ! asked ) {
					buildQuick();
				}
			}

			startPolling();

			if ( read( OPEN ) ) {
				toggle();
			}
		} );

		// پیام دعوت خودکار، فقط یک بار برای هر بازدیدکننده.
		if ( cfg.greeting && cfg.delay > 0 && ! read( GREET ) ) {
			setTimeout( function () {
				if ( state.open || read( GREET ) ) {
					return;
				}

				var bubble = el( 'div', 'wcma-lc-invite' );
				bubble.appendChild( el( 'span', '', cfg.greeting ) );

				var dismiss = el( 'button', 'wcma-lc-invite__close', '✕' );
				dismiss.type = 'button';
				dismiss.addEventListener( 'click', function ( e ) {
					e.stopPropagation();
					bubble.remove();
				} );

				bubble.addEventListener( 'click', function () {
					bubble.remove();
					toggle();
				} );

				bubble.appendChild( dismiss );
				root.appendChild( bubble );
			}, cfg.delay * 1000 );
		}
	}

	root.style.setProperty( '--lc-color', cfg.color );
	root.className = 'wcma-lc wcma-lc--' + ( 'right' === cfg.position ? 'right' : 'left' );

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}() );
