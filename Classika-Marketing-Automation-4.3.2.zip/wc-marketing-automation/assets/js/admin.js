/**
 * اسکریپت پیشخوان افزونه اتوماسیون بازاریابی.
 */
( function ( $ ) {
	'use strict';

	var i18n = ( window.wcmaAdmin && window.wcmaAdmin.i18n ) || {};

	/**
	 * نمایش پیام شناور.
	 */
	function toast( message, type ) {
		var $el = $( '#wcma-toast' );

		if ( ! $el.length ) {
			return;
		}

		$el.text( message )
			.removeClass( 'is-error is-success' )
			.addClass( 'is-visible' )
			.addClass( 'error' === type ? 'is-error' : 'is-success' );

		clearTimeout( $el.data( 'timer' ) );
		$el.data( 'timer', setTimeout( function () {
			$el.removeClass( 'is-visible' );
		}, 5000 ) );
	}

	/**
	 * درخواست ایجکس با نانس.
	 */
	/**
	 * حذف فاصله‌های دو سر رشته.
	 *
	 * jQuery 4 تابع $.trim را حذف کرده و وردپرس دیر یا زود آن را می‌آورد؛
	 * تکیه بر آن یعنی هر دکمه‌ای که از آن استفاده می‌کند بی‌صدا از کار بیفتد.
	 *
	 * @param {*} value ورودی.
	 * @return {string} خروجی.
	 */
	function trim( value ) {
		return String( null === value || undefined === value ? '' : value ).trim();
	}

	function request( action, data ) {
		return $.post( window.wcmaAdmin.ajaxUrl, $.extend( {
			action: action,
			nonce: window.wcmaAdmin.nonce
		}, data || {} ) );
	}

	/**
	 * پنهان یا نمایان کردن یک ردیف ویرایشگر، همراه با فیلدهایش.
	 *
	 * فیلدِ ردیفِ پنهان غیرفعال می‌شود تا فرستاده نشود. ردیف‌های خالیِ پنهان
	 * (روزهای دنباله، پیام‌های آماده و دکمه‌هایشان) روی هم صدها متغیر می‌شدند
	 * و از سقف max_input_vars در PHP می‌گذشتند؛ آن‌وقت PHP بقیه‌ی تنظیمات را
	 * بی‌صدا دور می‌ریخت.
	 *
	 * @param {Object}  $row ردیف.
	 * @param {boolean} on   نمایان شود؟
	 */
	function showRow( $row, on ) {
		$row.prop( 'hidden', ! on );
		$row.find( 'input, select, textarea' ).prop( 'disabled', ! on );
	}

	/**
	 * شمارنده‌ی کاراکتر و تعداد پیامک.
	 */
	function updateSmsCounter( $textarea ) {
		var text = $textarea.val() || '';
		var len = text.length;
		// تشخیص وجود حروف فارسی/عربی برای محاسبه‌ی صحیح تعداد پیامک.
		var isUnicode = /[؀-ۿ]/.test( text );
		var single = isUnicode ? 70 : 160;
		var multi = isUnicode ? 66 : 153;
		var parts = 0;

		if ( len > 0 ) {
			parts = len <= single ? 1 : Math.ceil( len / multi );
		}

		var $counter = $textarea.closest( '.wcma-field' ).find( '.wcma-sms-counter' );
		$counter.find( 'strong' ).eq( 0 ).text( len.toLocaleString( 'fa-IR' ) );
		$counter.find( 'strong' ).eq( 1 ).text( parts.toLocaleString( 'fa-IR' ) );
	}

	/**
	 * درج متغیر در آخرین فیلد فعال.
	 */
	function initPlaceholders() {
		var lastFocused = null;

		$( document ).on( 'focus', '.wcma-field textarea, .wcma-field input[type="text"], .wcma-canned__body textarea, .wcma-day__body textarea', function () {
			lastFocused = this;
		} );

		$( document ).on( 'click', '.wcma-ph-toggle', function () {
			var $box = $( this ).closest( '.wcma-placeholders' );
			var open = ! $box.hasClass( 'is-expanded' );

			$box.toggleClass( 'is-expanded', open );
			$( this ).text( open ? '\u0628\u0633\u062a\u0646 \u0631\u0627\u0647\u0646\u0645\u0627' : '\u0631\u0627\u0647\u0646\u0645\u0627\u06cc \u06a9\u0627\u0631\u06a9\u0631\u062f \u0647\u0631 \u0645\u062a\u063a\u06cc\u0631' );
		} );

		$( document ).on( 'click', '.wcma-tag', function ( e ) {
			e.preventDefault();

			var tag = $( this ).data( 'tag' );

			// دکمه‌هایی با ظاهر مشابه ولی بدون متغیر (مثل مدل‌های هوش مصنوعی).
			if ( ! tag ) {
				return;
			}

			var target = lastFocused;

			// اگر فیلدی انتخاب نشده، نزدیک‌ترین ناحیه‌ی متنی بعد از این جعبه.
			if ( ! target ) {
				target = $( this ).closest( '.wcma-placeholders' ).nextAll().find( 'textarea' ).get( 0 );
			}

			if ( ! target ) {
				return;
			}

			var start = target.selectionStart || 0;
			var end = target.selectionEnd || 0;
			var value = target.value || '';
			var before = value.substring( 0, start );
			var after = value.substring( end );

			// بدون این، متغیر به کلمه‌ی قبل و بعد می‌چسبد و متن به‌هم می‌ریزد.
			// فاصله فقط وقتی افزوده می‌شود که واقعاً لازم باشد.
			var needsSpaceBefore = before.length > 0 && ! /[\s(\[{«"']$/.test( before );
			var needsSpaceAfter = after.length > 0 && ! /^[\s.,،!?؟:;)\]}»"']/.test( after );

			var insert = ( needsSpaceBefore ? ' ' : '' ) + tag + ( needsSpaceAfter ? ' ' : '' );

			target.value = before + insert + after;
			target.focus();

			var caret = start + insert.length;
			target.selectionStart = target.selectionEnd = caret;

			$( target ).trigger( 'input' );
		} );
	}

	/**
	 * نمایش فیلدهای مربوط به درگاه پیامک انتخاب‌شده.
	 */
	function initGatewayFields() {
		var $wrap = $( '.wcma-gateway-fields' );

		if ( ! $wrap.length ) {
			return;
		}

		var map = $wrap.data( 'gateways' ) || {};

		function refresh() {
			var gateway = $( '#sms_gateway' ).val();
			var fields = map[ gateway ] || [];

			$wrap.children( '[data-field]' ).each( function () {
				var $field = $( this );
				$field.toggleClass( 'is-visible', fields.indexOf( $field.data( 'field' ) ) !== -1 );
			} );
		}

		$( document ).on( 'change', '#sms_gateway', refresh );
		refresh();
	}

	/**
	 * نمایش فیلدهای مربوط به نوع مخاطب کمپین.
	 */
	function initAudienceFields() {
		var $wrap = $( '.wcma-audience-fields' );

		if ( ! $wrap.length ) {
			return;
		}

		function refresh() {
			var type = $( '#audience_type' ).val();

			$wrap.children( '[data-audience]' ).each( function () {
				var $field = $( this );
				$field.toggleClass( 'is-visible', $field.data( 'audience' ) === type );
			} );
		}

		$( document ).on( 'change', '#audience_type', refresh );
		refresh();
	}

	/**
	 * وضعیت بصری مراحل سبد رها شده.
	 */
	function initSteps() {
		$( document ).on( 'change', '.wcma-step__toggle', function () {
			$( this ).closest( '.wcma-step' ).toggleClass( 'is-active', this.checked );
		} );
	}

	/**
	 * تأیید پیش از عملیات حساس.
	 */
	function initConfirmations() {
		$( document ).on( 'click', '[data-confirm]', function ( e ) {
			if ( ! window.confirm( $( this ).data( 'confirm' ) ) ) {
				e.preventDefault();
				return false;
			}
		} );
	}

	/**
	 * ارسال پیام آزمایشی.
	 */
	function initTestSend() {
		$( document ).on( 'click', '#wcma-send-test', function () {
			var $btn = $( this );
			var $result = $( '#wcma-test-result' );

			$btn.prop( 'disabled', true );
			$result.html( '<div class="wcma-notice wcma-notice--success">' + ( i18n.sending || 'در حال ارسال...' ) + '</div>' );

			request( 'wcma_test_send', {
				channel: $( '#test_channel' ).val(),
				to: $( '#test_to' ).val(),
				subject: $( '#test_subject' ).val(),
				message: $( '#test_message' ).val()
			} ).done( function ( response ) {
				if ( response && response.success ) {
					$result.html( '<div class="wcma-notice wcma-notice--success"><span class="dashicons dashicons-yes-alt"></span><span>' + response.data.message + '</span></div>' );
					toast( response.data.message, 'success' );
				} else {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$result.html( '<div class="wcma-notice wcma-notice--error"><span class="dashicons dashicons-warning"></span><span>' + msg + '</span></div>' );
					toast( msg, 'error' );
				}
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * تولید محتوا با هوش مصنوعی.
	 */
	function initAiGenerate() {
		$( document ).on( 'click', '.wcma-btn--ai', function () {
			var $btn = $( this );
			var targetId = $btn.data( 'target' ) || 'ai_lab_output';
			var $target = $( '#' + targetId );

			var template = $btn.data( 'template' ) || $( '#ai_lab_template' ).val() || 'campaign_email';
			var channel = $( '#ai_lab_channel' ).val() || $( '#campaign_channel' ).val() || 'email';
			var brief = $( '#wcma-ai-brief' ).val() || $( '#ai_lab_brief' ).val() || '';

			var original = $btn.html();
			$btn.prop( 'disabled', true ).text( i18n.generating || 'در حال تولید...' );

			request( 'wcma_ai_generate', {
				template: template,
				channel: channel,
				brief: brief
			} ).done( function ( response ) {
				if ( response && response.success ) {
					$target.val( response.data.content ).trigger( 'input' );
					toast( 'محتوا تولید شد. پیش از ارسال آن را بازخوانی کنید.', 'success' );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).fail( function () {
				toast( i18n.error || 'خطا', 'error' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	/**
	 * تست اتصال درجا در تب تنظیمات، با مقادیر ذخیره‌نشده‌ی فرم.
	 */
	function initConnectionTest() {
		// کلیدهایی که سرور برای تست می‌پذیرد.
		var keys = [
			'sms_enabled', 'sms_gateway', 'sms_api_key', 'sms_username', 'sms_password',
			'sms_sender', 'sms_custom_url', 'sms_custom_method', 'sms_custom_body',
			'sms_custom_headers', 'sms_ippanel_api', 'from_name', 'from_email',
			'telegram_enabled', 'telegram_bot_token', 'telegram_channel_id',
			'bale_enabled', 'bale_bot_token', 'bale_chat_id',
			'eitaa_enabled', 'eitaa_token', 'eitaa_chat_id',
			'rubika_enabled', 'rubika_token', 'rubika_chat_id',
			'whatsapp_enabled', 'whatsapp_token', 'whatsapp_phone_id',
			'whatsapp_api_version', 'whatsapp_template', 'whatsapp_template_lang',
			'telegram_bot_username', 'bale_bot_username', 'rubika_bot_username',
			'smtp_enabled', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_auth',
			'smtp_user', 'smtp_pass', 'smtp_from_email', 'smtp_from_name',
			'smtp_force_from', 'smtp_debug'
		];

		/**
		 * خواندن مقادیر فعلی فرم تنظیمات.
		 */
		function collectSettings( channel ) {
			var data = {};

			keys.forEach( function ( key ) {
				var $field = $( '#' + key );
				if ( $field.length ) {
					data[ key ] = $field.val();
				}
			} );

			// تست باید فارغ از اینکه هنوز کانال را فعال کرده‌اند یا نه انجام شود.
			if ( 'sms' === channel ) {
				data.sms_enabled = 'yes';
			} else {
				data[ channel + '_enabled' ] = 'yes';
			}

			return data;
		}

		$( document ).on( 'click', '.wcma-conntest__btn', function () {
			var $btn = $( this );
			var $box = $btn.closest( '.wcma-conntest' );
			var channel = $box.data( 'channel' );
			var $result = $box.find( '.wcma-conntest__result' );
			var to = trim( $box.find( '.wcma-conntest__to' ).val() || '' );

			// خالی بودن کادر یعنی «همان مقصد تنظیم‌شده در این کارت».
			if ( ! to ) {
				var fallbackField = $box.find( '.wcma-conntest__to' ).data( 'fallback' );

				if ( fallbackField ) {
					to = trim( $( '#' + fallbackField ).val() || '' );
				}
			}

			if ( ! to ) {
				var hint = 'مقصد پیام (شناسه‌ی کانال یا چت) را وارد کنید.';

				if ( 'sms' === channel || 'whatsapp' === channel ) {
					hint = 'شماره موبایل گیرنده را وارد کنید.';
				} else if ( 'email' === channel ) {
					hint = 'نشانی ایمیل گیرنده را وارد کنید.';
				}
				$result.html( '<div class="wcma-notice wcma-notice--error">' + hint + '</div>' );
				return;
			}

			var original = $btn.html();
			$btn.prop( 'disabled', true ).text( i18n.sending || 'در حال ارسال...' );
			$result.html( '<div class="wcma-notice wcma-notice--success">' + ( i18n.sending || 'در حال ارسال...' ) + '</div>' );

			request( 'wcma_test_send', {
				channel: channel,
				to: to,
				subject: 'تست اتصال',
				message: '',
				settings: collectSettings( channel )
			} ).done( function ( response ) {
				if ( response && response.success ) {
					$result.html(
						'<div class="wcma-notice wcma-notice--success"><span class="dashicons dashicons-yes-alt"></span><span>' +
						'اتصال برقرار است — ' + response.data.message +
						'</span></div>'
					);
					toast( 'تست اتصال موفق بود.', 'success' );
				} else {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$result.html(
						'<div class="wcma-notice wcma-notice--error"><span class="dashicons dashicons-warning"></span><span>' +
						'اتصال برقرار نشد — ' + msg +
						'</span></div>'
					);
					toast( 'تست اتصال ناموفق بود.', 'error' );
				}
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	/**
	 * ثبت خودکار وب‌هوک ربات.
	 */
	function initRegisterHook() {
		$( document ).on( 'click', '.wcma-register-hook', function () {
			var $btn = $( this );
			var messenger = $btn.data( 'messenger' );
			// در برگه‌ی ربات، کارت botlink وجود ندارد؛ نتیجه در همان کارت عیب‌یابی نشان داده می‌شود.
			var $result = $btn.closest( '.wcma-botlink' ).find( '.wcma-botlink__result' );

			if ( ! $result.length ) {
				$result = $( '#wcma-bot-diag-result' ).removeAttr( 'hidden' );
			}

			// توکن ذخیره‌نشده‌ی همین فرم را هم بفرست تا نیازی به ذخیره نباشد.
			var settings = {};
			$( '#' + messenger + '_bot_token, #' + messenger + '_token' ).each( function () {
				settings[ this.id ] = this.value;
			} );
			settings[ messenger + '_enabled' ] = 'yes';

			var original = $btn.html();
			$btn.prop( 'disabled', true ).text( 'در حال ثبت...' );
			$result.html( '' );

			request( 'wcma_register_hook', {
				messenger: messenger,
				settings: settings
			} ).done( function ( response ) {
				if ( response && response.success ) {
					$result.html( '<div class="wcma-notice wcma-notice--success"><span class="dashicons dashicons-yes-alt"></span><span>' + response.data.message + '</span></div>' );
					toast( 'وب‌هوک ثبت شد.', 'success' );
				} else {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$result.html( '<div class="wcma-notice wcma-notice--error"><span class="dashicons dashicons-warning"></span><span>' + msg + '</span></div>' );
					toast( msg, 'error' );
				}
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	/**
	 * شبیه‌سازی هشدار موجودی و ترمیم جدول‌ها.
	 */
	function initStockDiagnostics() {
		$( document ).on( 'click', '#wcma-repair-tables', function () {
			var $btn = $( this );
			var $out = $( '#wcma-repair-result' );

			$btn.prop( 'disabled', true );
			$out.text( 'در حال بررسی...' );

			request( 'wcma_repair_tables' ).done( function ( response ) {
				var ok = response && response.success;
				var msg = ( response && response.data && response.data.message ) || i18n.error;

				$out.html( '<span style="color:' + ( ok ? '#059669' : '#dc2626' ) + '">' + msg + '</span>' );
				toast( msg, ok ? 'success' : 'error' );
			} ).fail( function () {
				$out.text( i18n.error || 'خطا' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		// کلیک روی نام محصولات نمونه، شناسه را پر می‌کند.
		$( document ).on( 'click', '.wcma-sim-pick', function () {
			$( '#wcma-sim-product' ).val( $( this ).data( 'id' ) );
			$( '#wcma-sim-picker' ).val( '' ).trigger( 'change' );
		} );

		$( document ).on( 'click', '#wcma-sim-run', function () {
			var $btn = $( this );
			var $out = $( '#wcma-sim-result' );
			// اولویت با انتخابگر محصول؛ سپس متن آزاد.
			var productId = trim( $( '#wcma-sim-picker' ).val() || '' ) ||
				trim( $( '#wcma-sim-product' ).val() || '' );
			var contact = trim( $( '#wcma-sim-contact' ).val() || '' );

			if ( ! productId ) {
				$out.html( '<li class="is-warn"><span class="dashicons dashicons-warning"></span><span>یک محصول انتخاب کنید یا نام/شناسه‌ی آن را بنویسید.</span></li>' );
				return;
			}

			if ( ! contact ) {
				$out.html( '<li class="is-warn"><span class="dashicons dashicons-warning"></span><span>ایمیل یا شماره‌ی گیرنده را وارد کنید.</span></li>' );
				return;
			}

			var original = $btn.html();
			$btn.prop( 'disabled', true ).text( 'در حال اجرا...' );
			$out.html( '' );

			request( 'wcma_stock_simulate', {
				product_id: productId,
				contact: contact
			} ).done( function ( response ) {
				if ( ! response || ! response.success ) {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$out.html( '<li class="is-warn"><span class="dashicons dashicons-warning"></span><span>' + msg + '</span></li>' );
					return;
				}

				var html = '';

				( response.data.steps || [] ).forEach( function ( step ) {
					html += '<li class="' + ( step.ok ? 'is-ok' : 'is-warn' ) + '">' +
						'<span class="dashicons dashicons-' + ( step.ok ? 'yes-alt' : 'warning' ) + '"></span>' +
						'<span><strong>' + step.label + '</strong>' +
						( step.detail ? ' — ' + step.detail : '' ) + '</span></li>';
				} );

				$out.html( html );
				toast( response.data.success ? 'شبیه‌سازی موفق بود؛ پیام ارسال شد.' : 'شبیه‌سازی به مشکل خورد؛ فهرست بالا را ببینید.', response.data.success ? 'success' : 'error' );
			} ).fail( function () {
				$out.html( '<li class="is-warn"><span class="dashicons dashicons-warning"></span><span>' + ( i18n.error || 'خطا' ) + '</span></li>' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	/**
	 * بازمحاسبه‌ی سطوح باشگاه مشتریان.
	 */
	function initVipRecalc() {
		$( document ).on( 'change', '.wcma-tier__toggle', function () {
			$( this ).closest( '.wcma-tier' ).toggleClass( 'is-active', this.checked );
		} );

		$( document ).on( 'click', '#wcma-vip-recalc', function () {
			var $btn = $( this );
			var $out = $( '#wcma-vip-recalc-result' );
			var original = $btn.html();

			$btn.prop( 'disabled', true ).text( 'در حال محاسبه...' );
			$out.text( '' );

			request( 'wcma_vip_recalc' ).done( function ( response ) {
				if ( response && response.success ) {
					$out.text( response.data.message );
					toast( response.data.message, 'success' );
					setTimeout( function () { window.location.reload(); }, 1200 );
				} else {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$out.text( msg );
					toast( msg, 'error' );
				}
			} ).fail( function () {
				$out.text( i18n.error || 'خطا' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	/**
	 * اجرای فوری زمان‌بند.
	 */
	function initRunNow() {
		$( document ).on( 'click', '#wcma-run-now', function () {
			var $btn = $( this );
			$btn.prop( 'disabled', true );

			request( 'wcma_run_now' ).done( function ( response ) {
				if ( response && response.success ) {
					toast( response.data.message, 'success' );
				} else {
					toast( i18n.error, 'error' );
				}
			} ).fail( function () {
				toast( i18n.error || 'خطا', 'error' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * عملیات دستی روی سفارش‌ها.
	 */
	function initOrderActions() {
		$( document ).on( 'click', '.wcma-order-action', function () {
			var $btn = $( this );

			if ( ! window.confirm( 'پیام برای این سفارش ارسال شود؟' ) ) {
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_order_action', {
				order_id: $btn.data( 'order' ),
				op: $btn.data( 'op' )
			} ).done( function ( response ) {
				if ( response && response.success ) {
					toast( response.data.message, 'success' );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).fail( function () {
				toast( i18n.error || 'خطا', 'error' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * پیش‌نمایش تعداد مخاطبان کمپین.
	 */
	function initAudiencePreview() {
		$( document ).on( 'click', '#wcma-preview-audience', function () {
			var $btn = $( this );
			var $result = $( '.wcma-audience-preview__result' );

			$btn.prop( 'disabled', true );
			$result.text( 'در حال محاسبه...' );

			request( 'wcma_preview_audience', {
				type: $( '#audience_type' ).val(),
				product_ids: $( '#audience_product_ids' ).val() || [],
				category_ids: $( '#audience_category_ids' ).val() || [],
				min_spend: $( '#audience_min_spend' ).val(),
				inactive_days: $( '#audience_inactive_days' ).val(),
				manual_list: $( '#audience_manual_list' ).val()
			} ).done( function ( response ) {
				if ( response && response.success ) {
					$result.text(
						'مجموع ' + response.data.total.toLocaleString( 'fa-IR' ) + ' مخاطب — ' +
						response.data.email.toLocaleString( 'fa-IR' ) + ' با ایمیل، ' +
						response.data.phone.toLocaleString( 'fa-IR' ) + ' با شماره موبایل'
					);
				} else {
					$result.text( 'محاسبه ناموفق بود.' );
				}
			} ).fail( function () {
				$result.text( 'محاسبه ناموفق بود.' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * به‌روزرسانی زنده‌ی راهنما و مدل‌های سرویس هوش مصنوعی.
	 */
	function initAiProvider() {
		var $holder = $( '.wcma-ai-providers' );

		if ( ! $holder.length ) {
			return;
		}

		var map = $holder.data( 'providers' ) || {};
		var $select = $( '#ai_provider' );
		var $model = $( '#ai_model' );

		function refresh() {
			var key = $select.val();
			var data = map[ key ] || {};
			var models = data.models || [];

			$( '.wcma-ai-help' ).text( data.help || '' );

			// راهنمای مدل‌ها: با کلیک روی هر مدل، در فیلد نام مدل نوشته می‌شود.
			var $hint = $( '.wcma-ai-models' ).empty();

			if ( models.length ) {
				$hint.append( document.createTextNode( '\u0645\u062f\u0644\u200c\u0647\u0627\u06cc \u067e\u06cc\u0634\u0646\u0647\u0627\u062f\u06cc: ' ) );

				$.each( models, function ( i, name ) {
					$( '<button/>', {
						type: 'button',
						'class': 'wcma-chip wcma-ai-model',
						dir: 'ltr',
						text: name
					} ).appendTo( $hint );
				} );
			} else {
				$hint.text( '\u0646\u0627\u0645 \u0645\u062f\u0644 \u0633\u0631\u0648\u06cc\u0633 \u062e\u0648\u062f \u0631\u0627 \u0648\u0627\u0631\u062f \u06a9\u0646\u06cc\u062f.' );
			}

			$model.attr( 'placeholder', data.default || '' );

			// اگر مدل واردشده به سرویس قبلی تعلق داشت، پیش‌فرض سرویس جدید را بگذار.
			var current = trim( $model.val() );
			var belongs = false;

			$.each( map, function ( k, p ) {
				if ( $.inArray( current, p.models || [] ) !== -1 ) {
					belongs = true;
				}
			} );

			if ( current && belongs && $.inArray( current, models ) === -1 ) {
				$model.val( data.default || '' );
			}

			$( '.wcma-ai-base' ).each( function () {
				var only = String( $( this ).data( 'only' ) || '' ).split( ',' );
				$( this ).toggleClass( 'is-hidden', $.inArray( key, only ) === -1 );
			} );
		}

		$( document ).on( 'change', '#ai_provider', refresh );

		$( document ).on( 'click', '.wcma-ai-model', function ( e ) {
			e.preventDefault();
			$model.val( $( this ).text() ).trigger( 'input' );
		} );

		refresh();
	}

	/**
	 * پرونده‌ی مشتریان: همگام‌سازی، ذخیره و یادداشت.
	 */
	function initCrm() {
		$( document ).on( 'click', '#wcma-crm-sync', function () {
			var $btn = $( this );
			var $result = $( '#wcma-crm-sync-result' );

			$btn.prop( 'disabled', true );
			$result.text( 'در حال بررسی سفارش‌ها و سبدها...' );

			request( 'wcma_crm_sync' ).done( function ( response ) {
				if ( response && response.success ) {
					$result.text( response.data.message );
					toast( response.data.message, 'success' );
					setTimeout( function () {
						window.location.reload();
					}, 1200 );
				} else {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$result.text( msg );
					toast( msg, 'error' );
				}
			} ).fail( function () {
				$result.text( i18n.error || 'خطا' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'click', '#wcma-crm-save', function () {
			var $btn = $( this );
			var $panel = $( '.wcma-crm-panel' );
			var $result = $( '#wcma-crm-save-result' );

			$btn.prop( 'disabled', true );
			$result.text( 'در حال ذخیره...' );

			request( 'wcma_crm_save_contact', {
				contact_id: $panel.data( 'contact' ),
				first_name: $( '#crm_first_name' ).val(),
				last_name: $( '#crm_last_name' ).val(),
				company: $( '#crm_company' ).val(),
				city: $( '#crm_city' ).val(),
				stage: $( '#crm_stage' ).val(),
				owner_id: $( '#crm_owner' ).val(),
				tags: $( '#crm_tags' ).val(),
				followup_note: $( '#crm_followup_note' ).val(),
				next_followup_at: $( '#crm_followup' ).val()
			} ).done( function ( response ) {
				var ok = response && response.success;
				var msg = ok ? response.data.message : ( ( response && response.data && response.data.message ) || i18n.error );

				$result.text( msg );
				toast( msg, ok ? 'success' : 'error' );
			} ).fail( function () {
				$result.text( i18n.error || 'خطا' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'click', '#wcma-crm-note', function () {
			var $btn = $( this );
			var $body = $( '#crm_note_body' );

			if ( ! trim( $body.val() ) ) {
				toast( 'متن یادداشت خالی است.', 'error' );
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_crm_add_note', {
				contact_id: $( '.wcma-crm-panel' ).data( 'contact' ),
				type: $( '#crm_note_type' ).val(),
				body: $body.val(),
				due: $( '#crm_note_due' ).val() || ''
			} ).done( function ( response ) {
				if ( response && response.success ) {
					var note = response.data.note;

					// همان ساختار رویدادهای گردش کار، تا یادداشت تازه بی‌درنگ سرِ جایش بنشیند.
					var $item = $( '<div class="wcma-journey__item is-note" data-kind="note"/>' );
					var $dot = $( '<span class="wcma-journey__dot"/>' )
						.css( { background: 'rgba(15, 118, 110, .1)', color: '#0f766e' } )
						.append( $( '<span class="dashicons dashicons-' + ( note.icon || 'edit' ) + '"/>' ) );
					var $head = $( '<div class="wcma-journey__head"/>' )
						.append( $( '<strong/>' ).text( note.type ) )
						.append( $( '<time/>' ).text( note.date ) );
					var $body2 = $( '<div class="wcma-journey__body"/>' )
						.append( $head )
						.append( $( '<span class="wcma-journey__detail"/>' ).text( note.body ) );

					if ( note.author ) {
						$body2.append(
							$( '<span class="wcma-journey__author"/>' )
								.append( $( '<span class="dashicons dashicons-admin-users"/>' ) )
								.append( document.createTextNode( ' ' + note.author ) )
						);
					}

					$item.append( $dot ).append( $body2 );
					$( '#wcma-crm-journey' ).prepend( $item );

					// اگر فیلتری فعال است، رویداد تازه باید با آن بخواند.
					applyJourneyFilter();

					if ( note.due ) {
						$body2.append(
							$( '<span class="wcma-journey__author"/>' )
								.append( $( '<span class="dashicons dashicons-clock"/>' ) )
								.append( document.createTextNode( ' یادآوری: ' + note.due ) )
						);
					}

					$body.val( '' );

					/*
					 * تقویم شمسی فیلد اصلی را پنهان می‌کند و یک فیلد نمایشی
					 * کنارش می‌گذارد؛ پاک کردن فقط یکی، دیگری را پر باقی
					 * می‌گذاشت و یادداشت بعدی همان تاریخ را می‌گرفت.
					 */
					$( '#crm_note_due' ).val( '' ).trigger( 'change' );
					$( '#crm_note_due_view' ).val( '' );

					toast( response.data.message, 'success' );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	/**
	 * ویرایش و حذف یادداشت‌های گردش کار.
	 *
	 * فقط یادداشت‌ها دکمه می‌گیرند؛ سفارش و پیام و گفتگو ثبتِ چیزی‌اند که
	 * واقعاً رخ داده و قالب هم برایشان دکمه‌ای چاپ نمی‌کند.
	 */
	function initJourneyEdit() {
		var types = [
			[ 'note', 'یادداشت' ],
			[ 'call', 'تماس تلفنی' ],
			[ 'meeting', 'جلسه' ],
			[ 'followup', 'پیگیری' ]
		];

		$( document ).on( 'click', '.wcma-note-edit', function () {
			var $btn = $( this );
			var $item = $btn.closest( '.wcma-journey__item' );
			var $body = $item.find( '.wcma-journey__body' );

			if ( $body.find( '.wcma-note-editor' ).length ) {
				return;
			}

			var $editor = $( '<div class="wcma-note-editor"/>' );
			var $type = $( '<select/>' );

			types.forEach( function ( pair ) {
				$type.append( $( '<option/>' ).val( pair[ 0 ] ).text( pair[ 1 ] ) );
			} );

			$type.val( $btn.data( 'type' ) || 'note' );

			var $text = $( '<textarea rows="2"/>' ).val( String( $btn.data( 'body' ) || '' ) );
			var $due = $( '<input type="datetime-local" data-wcma-jalali/>' )
				.attr( 'title', 'یادآوری در تاریخ و ساعت' )
				.val( String( $btn.data( 'due' ) || '' ) );

			var $save = $( '<button type="button" class="wcma-btn wcma-btn--primary"/>' ).text( 'ذخیره' );
			var $cancel = $( '<button type="button" class="wcma-btn wcma-btn--ghost"/>' ).text( 'انصراف' );

			$editor.append( $type ).append( $text ).append( $due ).append( $save ).append( $cancel );
			$body.append( $editor );
			$item.addClass( 'is-editing' );

			/*
			 * فیلد تاریخ همین حالا ساخته شده و تقویم شمسی آن را ندیده است؛
			 * این رویداد همان چیزی است که خودِ تقویم به آن گوش می‌دهد.
			 */
			if ( document.body ) {
				document.body.dispatchEvent( new Event( 'wcma:rescan' ) );
			}

			$text.trigger( 'focus' );

			function close() {
				$item.removeClass( 'is-editing' );
				$editor.remove();
			}

			$cancel.on( 'click', close );

			$save.on( 'click', function () {
				if ( ! trim( $text.val() ) ) {
					toast( 'متن یادداشت خالی است.', 'error' );
					return;
				}

				$save.prop( 'disabled', true );

				request( 'wcma_crm_edit_note', {
					note_id: $btn.data( 'note' ),
					body: $text.val(),
					type: $type.val(),
					due: $due.val() || ''
				} ).done( function ( response ) {
					if ( ! response || ! response.success ) {
						$save.prop( 'disabled', false );
						toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
						return;
					}

					var note = response.data.note;

					$item.find( '.wcma-journey__detail' ).text( note.body );
					$item.find( '.wcma-journey__head strong' ).text( note.type );
					$item.find( '.wcma-journey__dot .dashicons' )
						.attr( 'class', 'dashicons dashicons-' + ( note.icon || 'edit' ) );

					var $due2 = $item.find( '.wcma-journey__due' );

					if ( note.due ) {
						$due2.find( '.wcma-journey__due-value' ).html( note.due );
						$due2.find( '.wcma-journey__due-label' )
							.text( note.done ? 'انجام شد — سررسید بود: ' : 'یادآوری: ' );
						$due2.toggleClass( 'is-done', !! note.done ).prop( 'hidden', false );
					} else {
						$due2.prop( 'hidden', true );
					}

					// دکمه‌ها باید مقدار تازه را نگه دارند تا ویرایش بعدی درست باز شود.
					$btn.data( 'body', note.body ).data( 'type', $type.val() ).data( 'due', $due.val() || '' );

					close();
					toast( response.data.message, 'success' );
				} ).fail( function () {
					$save.prop( 'disabled', false );
					toast( i18n.error, 'error' );
				} );
			} );
		} );

		$( document ).on( 'click', '.wcma-note-delete', function () {
			var $btn = $( this );

			if ( ! window.confirm( $btn.data( 'confirm' ) || i18n.confirm ) ) {
				return;
			}

			var $item = $btn.closest( '.wcma-journey__item' );

			$btn.prop( 'disabled', true );

			request( 'wcma_crm_delete_note', { note_id: $btn.data( 'note' ) } )
				.done( function ( response ) {
					if ( response && response.success ) {
						$item.slideUp( 200, function () { $item.remove(); } );
						toast( response.data.message, 'success' );
					} else {
						$btn.prop( 'disabled', false );
						toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
					}
				} )
				.fail( function () {
					$btn.prop( 'disabled', false );
					toast( i18n.error, 'error' );
				} );
		} );
	}

	/**
	 * فیلترهایی که بی‌درنگ اعمال می‌شوند.
	 *
	 * دکمه‌ی «فیلتر» برداشته شده؛ هر تغییری در فهرست‌ها و تاریخ‌ها همان لحظه
	 * صفحه را تازه می‌کند. جعبه‌ی جستجو با هر حرف فرستاده نمی‌شود — با
	 * اینتر یا بیرون رفتن از فیلد، که وگرنه هر تایپ یک بارگذاری می‌شد.
	 */
	function initInstantFilters() {
		// هر فرمی که این نشان را دارد، چه نوار فیلتر باشد چه نوار بالای فهرست.
		var $forms = $( 'form.is-instant' );

		if ( ! $forms.length ) {
			return;
		}

		function go( form ) {
			if ( form.dataset.wcmaSubmitting ) {
				return;
			}

			form.dataset.wcmaSubmitting = '1';
			form.submit();
		}

		$forms.on( 'change', 'select, input[type="date"], input[type="hidden"]', function () {
			go( this.form );
		} );

		$forms.on( 'change', 'input[type="search"], input[type="text"]', function () {
			go( this.form );
		} );

		/*
		 * تقویم شمسی، فیلد اصلی را پنهان می‌کند و یک فیلد نمایشی کنارش
		 * می‌گذارد؛ change روی همان فیلد پنهان می‌افتد، پس هم آن و هم فیلد
		 * نمایشی گوش داده می‌شوند.
		 */
		$forms.on( 'change', '.wcma-jdate__view', function () {
			var form = $( this ).closest( 'form' )[ 0 ];

			if ( form ) {
				setTimeout( function () { go( form ); }, 30 );
			}
		} );
	}

	/**
	 * کارهای امروز: بستن هر کار بدون بارگذاری دوباره‌ی صفحه.
	 */
	function initTasks() {
		$( document ).on( 'click', '.wcma-task__done', function () {
			var $btn = $( this );
			var $row = $btn.closest( '.wcma-task' );

			$btn.prop( 'disabled', true );

			request( 'wcma_crm_task_done', { note_id: $btn.data( 'note' ), done: 1 } )
				.done( function ( response ) {
					if ( response && response.success ) {
						// کار بسته‌شده محو می‌شود، نه اینکه ناگهان بپرد.
						$row.addClass( 'is-done' ).slideUp( 220, function () {
							$row.remove();

							if ( ! $( '.wcma-task' ).length ) {
								$( '.wcma-tasks' ).replaceWith(
									$( '<p class="wcma-empty"/>' ).text( 'کاری برای امروز نمانده. 🎉' )
								);
							}
						} );

						toast( response.data.message, 'success' );
					} else {
						$btn.prop( 'disabled', false );
						toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
					}
				} )
				.fail( function () {
					$btn.prop( 'disabled', false );
					toast( i18n.error, 'error' );
				} );
		} );
	}

	/**
	 * کد اتصال حساب کنسول به ربات.
	 */
	function initStaffBot() {
		$( document ).on( 'click', '.wcma-staff-code', function () {
			var $btn = $( this );
			var $out = $btn.closest( '.wcma-staffbot' ).find( '.wcma-staffbot__out' );

			$btn.prop( 'disabled', true );

			request( 'wcma_staff_code', { user_id: $btn.data( 'user' ) } )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
						return;
					}

					var data = response.data;

					$out.empty()
						.append( $( '<code/>' ).text( data.command ) )
						.append( $( '<span/>' ).text( 'این را در ربات بفرستید.' ) );

					// یک پیوند برای هر رباتی که سایت روشن کرده است.
					( data.links || [] ).forEach( function ( link ) {
						$out.append(
							$( '<a/>' )
								.attr( { href: link.url, target: '_blank', rel: 'noopener' } )
								.text( 'باز کردن در ' + link.label )
						);
					} );

					$out.prop( 'hidden', false );
					toast( data.message, 'success' );
				} )
				.fail( function () {
					toast( i18n.error, 'error' );
				} )
				.always( function () {
					$btn.prop( 'disabled', false );
				} );
		} );

		$( document ).on( 'click', '.wcma-staff-unlink', function () {
			var $btn = $( this );

			if ( ! window.confirm( $btn.data( 'confirm' ) || i18n.confirm ) ) {
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_staff_code', { user_id: $btn.data( 'user' ), unlink: 1 } )
				.done( function ( response ) {
					if ( response && response.success ) {
						toast( response.data.message, 'success' );
						window.location.reload();
					} else {
						$btn.prop( 'disabled', false );
						toast( i18n.error, 'error' );
					}
				} )
				.fail( function () {
					$btn.prop( 'disabled', false );
					toast( i18n.error, 'error' );
				} );
		} );
	}

	/**
	 * صندوق گفتگو: خواندن، پاسخ دستی و تغییر حالت ربات/اپراتور.
	 */
	function initChat() {
		var current = 0;
		var lastSeen = 0;

		/**
		 * تازه‌سازی فهرست گفتگوها بدون بارگذاری دوباره‌ی صفحه.
		 */
		function refreshList( chats ) {
			var $list = $( '.wcma-inbox__list' );

			if ( ! $list.length || ! chats ) {
				return;
			}

			$list.find( '.wcma-empty' ).remove();

			$.each( chats, function ( i, chat ) {
				var $item = $list.find( '.wcma-inbox__item[data-chat="' + chat.id + '"]' );

				if ( ! $item.length ) {
					$item = $( '<button type="button" class="wcma-inbox__item"/>' ).attr( 'data-chat', chat.id );
					$item.append( $( '<span class="wcma-inbox__top"/>' ) );
					$item.append( $( '<span class="wcma-inbox__preview"/>' ) );
					$item.append( $( '<span class="wcma-inbox__time"/>' ) );
					$list.prepend( $item );
				}

				var $top = $item.find( '.wcma-inbox__top' ).empty();

				$top.append( $( '<strong/>' ).text( chat.name ) );
				$top.append( $( '<span class="wcma-badge wcma-badge--soft"/>' ).text( chat.channel ) );

				if ( chat.online ) {
					$top.append( $( '<span class="wcma-live-dot" title="آنلاین"/>' ) );
				}

				if ( 'human' === chat.mode ) {
					$top.append( $( '<span class="wcma-badge wcma-badge--amber"/>' ).text( 'اپراتور' ) );
				}

				$item.find( '.wcma-inbox__preview' ).text( chat.preview );
				$item.find( '.wcma-inbox__time' ).text( chat.date );
				$item.toggleClass( 'is-unread', chat.unread > 0 && chat.id !== current );
			} );
		}

		var replyTo = null;

		/**
		 * نام نوع پیوست، وقتی پیامِ نقل‌قول‌شده متنی ندارد.
		 *
		 * @param {string} kind نوع.
		 * @return {string} برچسب.
		 */
		function kindLabel( kind ) {
			return { image: 'عکس', video: 'ویدیو', audio: 'پیام صوتی', doc: 'فایل', zip: 'فایل فشرده' }[ kind ] || 'پیوست';
		}

		/**
		 * گرفتن پاسخ به یک پیام: نوار نقل‌قول بالای جعبه‌ی پاسخ.
		 *
		 * @param {Object} message پیام.
		 */
		function startReply( message ) {
			var text = message.body || '';

			if ( message.file && message.file.url && ( ! text || text === message.file.name ) ) {
				text = kindLabel( message.file.kind );
			}

			replyTo = { id: message.id, text: text, side: 'in' === message.direction ? 'visitor' : 'agent' };
			paintReplyBar();
			$( '#wcma-chat-text' ).trigger( 'focus' );
		}

		function cancelReply() {
			replyTo = null;
			paintReplyBar();
		}

		function paintReplyBar() {
			var $bar = $( '#wcma-chat-replybar' );

			if ( ! $bar.length ) {
				return;
			}

			$bar.empty();

			if ( ! replyTo ) {
				$bar.attr( 'hidden', 'hidden' );

				return;
			}

			$bar.removeAttr( 'hidden' )
				.append(
					$( '<div class="wcma-msg__quote"/>' )
						.append( $( '<span class="wcma-msg__quote-who"/>' ).text( 'visitor' === replyTo.side ? 'مشتری' : 'اپراتور' ) )
						.append( $( '<span class="wcma-msg__quote-text"/>' ).text( replyTo.text ) )
				)
				.append(
					$( '<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-chat-replyx"/>' )
						.attr( { title: 'انصراف از پاسخ', 'aria-label': 'انصراف از پاسخ' } )
						.html( '<span class="dashicons dashicons-no-alt"></span>' )
				);
		}

		$( document ).on( 'click', '#wcma-chat-replyx', cancelReply );

		/**
		 * بدنه‌ی یک پیام: متن ساده یا پیوست.
		 *
		 * متن همیشه با text() می‌نشیند نه html()، چون از سمت مشتری می‌آید.
		 *
		 * @param {Object} message پیام.
		 * @return {jQuery} گره بدنه.
		 */
		function messageBody( message ) {
			var $body = $( '<div class="wcma-msg__body"/>' );
			var file = message.file;

			// نقل‌قول پیامی که این یکی پاسخ آن است، بالای متن می‌نشیند.
			if ( message.reply && ( message.reply.text || message.reply.kind ) ) {
				$body.append(
					$( '<div/>', { 'class': 'wcma-msg__quote is-' + ( message.reply.side || 'agent' ) } )
						.append( $( '<span class="wcma-msg__quote-who"/>' ).text( 'visitor' === message.reply.side ? 'مشتری' : 'اپراتور' ) )
						.append( $( '<span class="wcma-msg__quote-text"/>' ).text( message.reply.text || kindLabel( message.reply.kind ) ) )
				);
			}

			if ( ! file || ! file.url ) {
				// text() فرزندها را پاک می‌کند و نقل‌قول را می‌برد.
				return $body.append( document.createTextNode( message.body ) );
			}

			var $att = $( '<div/>', { 'class': 'wcma-msg__att is-' + ( file.kind || 'doc' ) } );
			// سرور برچسب خودکار را از توضیح واقعی جدا می‌کند؛ مقایسه‌ی قدیمی
			// فقط برای داده‌ی نسخه‌های پیشین می‌ماند.
			var caption = undefined !== file.caption
				? file.caption
				: ( ( message.body && message.body !== file.name ) ? message.body : '' );

			if ( 'image' === file.kind ) {
				// عکس خودش پیام است؛ نام و حجم زیرش چیزی اضافه نمی‌کرد.
				$att.append(
					$( '<a class="wcma-msg__open" target="_blank" rel="noopener noreferrer"/>' )
						.attr( { href: file.url, title: file.name || '' } )
						.append( $( '<img/>', { src: file.url, alt: file.name || '', loading: 'lazy' } ) )
				);
			} else if ( 'video' === file.kind ) {
				$att.append( $( '<video controls preload="metadata"/>' ).attr( 'src', file.url ) );
			} else if ( 'audio' === file.kind ) {
				$att.append( $( '<audio controls preload="metadata"/>' ).attr( 'src', file.url ) );
				// عدد داخل bdi می‌رود، وگرنه برچسب راست‌به‌چپ آن را وارونه می‌کند.
				$att.append(
					$( '<span class="wcma-msg__time"/>' )
						.text( 'مدت ضبط: ' )
						.append( $( '<bdi/>' ).text( file.clock || '—' ) )
				);
			} else {
				$att.append(
					$( '<a class="wcma-msg__file" target="_blank" rel="noopener noreferrer"/>' )
						.attr( 'href', file.url )
						.text( ( file.name || 'دریافت فایل' ) + ( file.human ? ' · ' + file.human : '' ) )
				);
			}

			$body.append( $att );

			if ( caption ) {
				$body.append( $( '<div class="wcma-msg__caption"/>' ).text( caption ) );
			} else if ( 'image' === file.kind || 'video' === file.kind ) {
				// بدون زیرنویس، حباب هم لازم نیست.
				$body.addClass( 'is-bare' );
			}

			// حباب رسانه‌ای فاصله‌ی داخلی کمتری می‌گیرد تا پیام‌ها به هم نزدیک بمانند.
			$body.addClass( 'is-media' );

			return $body;
		}

		/**
		 * افزودن پیام‌های تازه به انتهای گفتگوی باز.
		 */
		function appendFresh( messages ) {
			var $list = $( '.wcma-thread__list' );

			if ( ! $list.length ) {
				return;
			}

			$.each( messages, function ( i, message ) {
				if ( message.id > lastSeen ) {
					lastSeen = message.id;
				}

				var cls = 'wcma-msg wcma-msg--' + ( 'in' === message.direction ? 'in' : 'out' );

				if ( 'bot' === message.sender ) {
					cls += ' wcma-msg--bot';
				}

				var $msg = $( '<div/>', { 'class': cls } );
				var $body = messageBody( message );

				// کلاس روی خود حباب می‌نشیند تا زمینه و کادرش برداشته شود.
				$msg.toggleClass( 'is-bare', $body.hasClass( 'is-bare' ) );
				$msg.toggleClass( 'is-media', $body.hasClass( 'is-media' ) );
				$msg.append( $body );
				$msg.append( $( '<div class="wcma-msg__meta"/>' ).text( message.date ) );
				$list.append( $msg );
			} );

			$list.scrollTop( $list[ 0 ].scrollHeight );
		}

		function renderThread( data ) {
			var $wrap = $( '#wcma-chat-thread' ).empty();
			var chat = data.chat;

			var $head = $( '<div class="wcma-thread__head"/>' );

			var sub = chat.channel;

			if ( chat.phone ) {
				sub += ' — ' + chat.phone;
			}

			if ( chat.email ) {
				sub += ' — ' + chat.email;
			}

			var $who = $( '<div/>' ).append( $( '<strong/>' ).text( chat.name ) );

			if ( chat.online ) {
				$who.find( 'strong' ).append( $( '<span class="wcma-live-dot" title="همین حالا روی سایت است"/>' ) );
			}

			$who.append( $( '<small/>' ).text( sub ) );
			$head.append( $who );

			var $actions = $( '<div class="wcma-thread__actions"/>' );

			if ( 'human' === chat.mode ) {
				$actions.append( $( '<button type="button" class="wcma-btn wcma-btn--ghost"/>' )
					.text( 'بازگرداندن به ربات' )
					.attr( 'data-mode', 'bot' ) );
			} else {
				$actions.append( $( '<button type="button" class="wcma-btn wcma-btn--secondary"/>' )
					.text( 'پاسخ می‌دهم (توقف ربات)' )
					.attr( 'data-mode', 'human' ) );
			}

			$actions.append( $( '<button type="button" class="wcma-btn wcma-btn--ghost"/>' )
				.text( 'closed' === chat.status ? 'بازکردن گفتگو' : 'بستن گفتگو' )
				.attr( 'data-status', 'closed' === chat.status ? 'open' : 'closed' ) );

			if ( data.contact ) {
				$actions.append( $( '<a class="wcma-btn wcma-btn--ghost"/>' )
					.text( 'پرونده: ' + data.contact.stage )
					.attr( 'href', data.contact.url ) );
			}

			$head.append( $actions );
			$wrap.append( $head );

			if ( chat.facts && chat.facts.length ) {
				var $facts = $( '<div class="wcma-thread__facts"/>' );

				$.each( chat.facts, function ( i, fact ) {
					$facts.append( $( '<span/>' ).text( fact ) );
				} );

				if ( chat.rating ) {
					$facts.append( $( '<span class="wcma-thread__rating"/>' ).text( 'رضایت: ' + new Array( chat.rating + 1 ).join( '★' ) ) );
				}

				$wrap.append( $facts );
			}

			var $list = $( '<div class="wcma-thread__list"/>' );

			$.each( data.messages, function ( i, message ) {
				var cls = 'wcma-msg wcma-msg--' + ( 'in' === message.direction ? 'in' : 'out' );

				if ( 'bot' === message.sender ) {
					cls += ' wcma-msg--bot';
				}

				if ( 'failed' === message.status ) {
					cls += ' wcma-msg--failed';
				}

				var $msg = $( '<div/>', { 'class': cls } );
				var $body = messageBody( message );

				$msg.toggleClass( 'is-bare', $body.hasClass( 'is-bare' ) );
				$msg.toggleClass( 'is-media', $body.hasClass( 'is-media' ) );
				$msg.append( $body );

				var meta = message.date;

				if ( 'bot' === message.sender ) {
					meta += ' — ربات' + ( message.rule ? ' (' + message.rule + ')' : '' );
				} else if ( 'human' === message.sender ) {
					meta += ' — اپراتور';
				}

				if ( 'failed' === message.status ) {
					meta += ' — ارسال نشد';
				}

				// دکمه‌ی پاسخ کنار زمان، تا اپراتور به پیام مشخصی جواب بدهد.
				$msg.append(
					$( '<div class="wcma-msg__meta"/>' )
						.text( meta + ' ' )
						.append(
							$( '<button type="button" class="wcma-msg__reply"/>' )
								.attr( { title: 'پاسخ به این پیام', 'aria-label': 'پاسخ به این پیام' } )
								.html( '<span class="dashicons dashicons-undo"></span>' )
								.on( 'click', function () {
									startReply( message );
								} )
						)
				);

				$list.append( $msg );
			} );

			$wrap.append( $list );

			$wrap.append( $( '<div class="wcma-thread__replybar" id="wcma-chat-replybar" hidden/>' ) );

			var $form = $( '<div class="wcma-thread__reply"/>' );

			$form.append( $( '<textarea rows="2" id="wcma-chat-text"/>' ).attr( 'placeholder', 'پاسخ خود را بنویسید...' ) );

			var files = ( window.wcmaAdmin && window.wcmaAdmin.files ) || {};

			if ( files.on ) {
				$form.append(
					$( '<input type="file" id="wcma-chat-file" class="wcma-hidden-file"/>' ).attr( 'accept', files.accept || '' )
				);
				$form.append(
					$( '<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-chat-attach"/>' )
						.attr( 'title', 'پیوست فایل' + ( files.label ? ' (تا ' + files.label + ')' : '' ) )
						.attr( 'aria-label', 'پیوست فایل' )
						.html( '<span class="dashicons dashicons-paperclip"></span>' )
				);

				if ( files.voice && canRecord() ) {
					$form.append(
						$( '<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-chat-mic"/>' )
							.attr( 'title', 'ضبط پیام صوتی' )
							.attr( 'aria-label', 'ضبط پیام صوتی' )
							.html( '<span class="dashicons dashicons-microphone"></span>' )
					);
				}
			}

			$form.append( $( '<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-chat-send"/>' ).text( 'ارسال' ) );
			$wrap.append( $form );

			$list.scrollTop( $list[ 0 ] ? $list[ 0 ].scrollHeight : 0 );

			$form.before( $( '<div class="wcma-typing-flag"/>' ).text( 'در حال نوشتن...' ) );

			lastSeen = 0;

			$.each( data.messages, function ( i, message ) {
				if ( message.id && message.id > lastSeen ) {
					lastSeen = message.id;
				}
			} );

			if ( window.wcmaRefreshDates ) {
				window.wcmaRefreshDates();
			}
		}

		function load( chatId ) {
			current = chatId;
			// نقل‌قول گفتگوی قبلی نباید به گفتگوی تازه بچسبد.
			replyTo = null;

			$( '#wcma-chat-thread' ).html( '<div class="wcma-inbox__empty"><p>در حال بارگذاری...</p></div>' );

			request( 'wcma_chat_thread', { chat_id: chatId } ).done( function ( response ) {
				if ( response && response.success ) {
					renderThread( response.data );
					$( '.wcma-inbox__item[data-chat="' + chatId + '"]' ).removeClass( 'is-unread' );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} );
		}

		$( document ).on( 'click', '.wcma-inbox__item', function () {
			$( '.wcma-inbox__item' ).removeClass( 'is-selected' );
			$( this ).addClass( 'is-selected' );
			load( $( this ).data( 'chat' ) );
		} );

		$( document ).on( 'click', '#wcma-chat-send', function () {
			var $btn = $( this );
			var $text = $( '#wcma-chat-text' );

			if ( ! trim( $text.val() ) || ! current ) {
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_chat_reply', { chat_id: current, text: $text.val(), reply: replyTo ? replyTo.id : 0 } ).done( function ( response ) {
				if ( response && response.success ) {
					$text.val( '' );
					toast( response.data.message, 'success' );
					load( current );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		/**
		 * آیا مرورگر می‌تواند صدا ضبط کند؟
		 *
		 * @return {boolean} می‌تواند؟
		 */
		function canRecord() {
			return !! ( window.MediaRecorder && navigator.mediaDevices && navigator.mediaDevices.getUserMedia );
		}

		/**
		 * فرستادن فایل اپراتور با FormData.
		 *
		 * request() بدنه را به صورت فرم ساده می‌فرستد و برای فایل کار نمی‌کند،
		 * پس اینجا مستقیم با $.ajax فرستاده می‌شود.
		 *
		 * @param {Blob}   blob محتوا.
		 * @param {string} name نام فایل.
		 */
		function sendFile( blob, name, ms ) {
			var files = ( window.wcmaAdmin && window.wcmaAdmin.files ) || {};

			if ( ! current ) {
				return;
			}

			if ( files.max && blob.size > files.max ) {
				toast( 'حجم فایل بیشتر از حد مجاز است' + ( files.label ? ' (' + files.label + ')' : '' ) + '.', 'error' );
				return;
			}

			var data = new FormData();

			data.append( 'action', 'wcma_chat_upload' );
			data.append( 'nonce', window.wcmaAdmin.nonce );
			data.append( 'chat_id', current );
			data.append( 'text', $( '#wcma-chat-text' ).val() || '' );
			data.append( 'reply', replyTo ? String( replyTo.id ) : '0' );
			data.append( 'file', blob, name );

			// مدت واقعی ضبط؛ خواندنش از خود فایل webm نامطمئن است.
			if ( ms ) {
				data.append( 'duration', String( Math.round( ms ) ) );
			}

			toast( i18n.sending || 'در حال ارسال...', 'info' );

			$.ajax( {
				url: window.wcmaAdmin.ajaxUrl,
				method: 'POST',
				data: data,
				processData: false,
				contentType: false
			} ).done( function ( response ) {
				if ( response && response.success ) {
					$( '#wcma-chat-text' ).val( '' );
					toast( response.data.message, 'success' );
					load( current );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).fail( function () {
				toast( i18n.error, 'error' );
			} );
		}

		$( document ).on( 'click', '#wcma-chat-attach', function () {
			$( '#wcma-chat-file' ).trigger( 'click' );
		} );

		$( document ).on( 'change', '#wcma-chat-file', function () {
			var file = this.files && this.files[ 0 ];

			if ( file ) {
				sendFile( file, file.name );
			}

			// پاک کردن، تا انتخاب دوباره‌ی همان فایل هم رویداد بدهد.
			this.value = '';
		} );

		var adminRecorder = null;
		var adminTick = null;
		var adminStart = 0;

		/**
		 * «۰:۰۳٫۴» از روی میلی‌ثانیه، با رقم فارسی.
		 *
		 * @param {number} ms میلی‌ثانیه.
		 * @return {string} زمان خوانا.
		 */
		function clock( ms ) {
			ms = Math.max( 0, ms | 0 );

			var total = Math.floor( ms / 1000 );
			var mm = Math.floor( total / 60 );
			var ss = total % 60;
			var tenth = Math.floor( ( ms % 1000 ) / 100 );

			return ( mm + ':' + ( ss < 10 ? '0' : '' ) + ss + '٫' + tenth ).replace( /[0-9]/g, function ( d ) {
				return '۰۱۲۳۴۵۶۷۸۹'[ d ];
			} );
		}

		$( document ).on( 'click', '#wcma-chat-mic', function () {
			var $btn = $( this );

			if ( adminRecorder && 'recording' === adminRecorder.state ) {
				adminRecorder.stop();
				return;
			}

			navigator.mediaDevices.getUserMedia( { audio: true } ).then( function ( stream ) {
				var chunks = [];
				var mime = '';

				$.each( [ 'audio/webm', 'audio/ogg', 'audio/mp4' ], function ( i, candidate ) {
					if ( ! mime && window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported( candidate ) ) {
						mime = candidate;
					}
				} );

				adminRecorder = mime ? new window.MediaRecorder( stream, { mimeType: mime } ) : new window.MediaRecorder( stream );

				adminRecorder.addEventListener( 'dataavailable', function ( e ) {
					if ( e.data && e.data.size ) {
						chunks.push( e.data );
					}
				} );

				adminRecorder.addEventListener( 'stop', function () {
					// میکروفون بلافاصله آزاد می‌شود تا چراغش روشن نماند.
					$.each( stream.getTracks(), function ( i, track ) {
						track.stop();
					} );

					clearInterval( adminTick );
					adminTick = null;

					var ms = adminStart ? Date.now() - adminStart : 0;

					$btn.removeClass( 'is-recording' ).html( '<span class="dashicons dashicons-microphone"></span>' );

					var type = adminRecorder.mimeType || mime || 'audio/webm';
					var blob = new Blob( chunks, { type: type } );
					var ext = type.indexOf( 'ogg' ) > -1 ? 'ogg' : ( type.indexOf( 'mp4' ) > -1 ? 'm4a' : 'webm' );

					adminRecorder = null;

					if ( blob.size ) {
						sendFile( blob, 'voice.' + ext, ms );
					}
				} );

				$btn.addClass( 'is-recording' );
				adminRecorder.start();

				// شمارنده‌ی زنده روی خود دکمه، تا اپراتور بداند چقدر ضبط شده.
				adminStart = Date.now();
				$btn.empty().append( $( '<bdi class="wcma-rec-clock"/>' ).text( clock( 0 ) ) );

				clearInterval( adminTick );
				adminTick = setInterval( function () {
					$btn.find( '.wcma-rec-clock' ).text( clock( Date.now() - adminStart ) );
				}, 100 );

				// سقف دو دقیقه، تا ضبط فراموش‌شده فایل بزرگ نسازد.
				setTimeout( function () {
					if ( adminRecorder && 'inactive' !== adminRecorder.state ) {
						adminRecorder.stop();
					}
				}, 120000 );
			} ).catch( function () {
				toast( 'دسترسی به میکروفون ممکن نشد.', 'error' );
			} );
		} );

		$( document ).on( 'click', '[data-mode], [data-status]', function () {
			var $btn = $( this );

			if ( ! current || ! $btn.closest( '.wcma-thread__actions' ).length ) {
				return;
			}

			request( 'wcma_chat_mode', {
				chat_id: current,
				mode: $btn.data( 'mode' ) || '',
				status: $btn.data( 'status' ) || ''
			} ).done( function ( response ) {
				if ( response && response.success ) {
					toast( response.data.message, 'success' );
					load( current );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} );
		} );

		$( document ).on( 'click', '#wcma-chat-sim-run', function () {
			var $btn = $( this );
			var text = $( '#wcma-chat-sim' ).val();
			var $result = $( '#wcma-chat-sim-result' );

			if ( ! trim( text ) ) {
				return;
			}

			$btn.prop( 'disabled', true );
			$result.html( '<div class="wcma-notice wcma-notice--success">در حال بررسی...</div>' );

			request( 'wcma_chat_simulate', { text: text } ).done( function ( response ) {
				if ( response && response.success ) {
					var $box = $( '<div class="wcma-notice wcma-notice--success"/>' );

					$box.append( $( '<div/>' ).text( response.data.text ) );
					$box.append( $( '<small/>' ).text(
						'پاسخ‌دهنده: ' + response.data.rule + ( response.data.handover ? ' — سپس به اپراتور سپرده می‌شود' : '' )
					) );

					$result.empty().append( $box );
				} else {
					$result.html( '' );
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'change', '.wcma-rule__toggle', function () {
			$( this ).closest( '.wcma-rule' ).toggleClass( 'is-active', this.checked );
		} );

		// اعلام تایپ اپراتور، حداکثر هر ۴ ثانیه یک بار.
		var typingSent = 0;

		$( document ).on( 'input', '#wcma-chat-text', function () {
			var now = Date.now();

			if ( ! current || now - typingSent < 4000 ) {
				return;
			}

			typingSent = now;
			request( 'wcma_chat_typing', { chat_id: current } );
		} );

		// به‌روزرسانی زنده‌ی صندوق، تا اپراتور صفحه را دستی تازه نکند.
		if ( $( '.wcma-inbox' ).length ) {
			setInterval( function () {
				if ( document.hidden ) {
					return;
				}

				request( 'wcma_chat_updates', { chat_id: current, since: lastSeen } ).done( function ( response ) {
					if ( ! response || ! response.success ) {
						return;
					}

					refreshList( response.data.chats );

					$( '.wcma-typing-flag' ).toggleClass( 'is-on', !! response.data.typing );

					if ( response.data.fresh && response.data.fresh.length ) {
						appendFresh( response.data.fresh );
					}
				} );
			}, 8000 );
		}
	}

	/**
	 * ذخیره‌ی لحظه‌ای فرم‌های تنظیمات، بدون زدن دکمه‌ی ذخیره.
	 *
	 * کل فرم فرستاده می‌شود، نه یک فیلد، تا فیلدهای آرایه‌ای (مراحل سبد، سطوح باشگاه،
	 * قاعده‌های چت‌بات و ترتیب کانال‌ها) هم درست ذخیره شوند.
	 */
	function initAutosave() {
		var $forms = $( '.wcma-form' ).filter( function () {
			return 'save_settings' === $( this ).find( 'input[name="wcma_action"]' ).val();
		} );

		if ( ! $forms.length ) {
			return;
		}

		$forms.each( function () {
			var form = this;
			var $form = $( form );
			var timer = null;
			var pending = false;
			var $status = $( '<span class="wcma-autosave"/>' );

			$form.find( '.wcma-actions' ).last().append( $status );

			var $fallback = $form.find( '.wcma-save-fallback' );

			function failed( message ) {
				$status.text( message ).removeClass( 'is-saving is-saved' ).addClass( 'is-failed' );

				// تنها وقتی ذخیره‌ی خودکار کار نکند، راه دستی نشان داده می‌شود.
				$fallback.prop( 'hidden', false );
			}

			function collect() {
				var fields = {};
				var boxes = [];

				$form.find( '[name^="wcma["]' ).each( function () {
					// فیلد ردیف‌های پنهان عمداً غیرفعال است و نباید فرستاده شود.
					if ( this.disabled ) {
						return;
					}

					var name = this.name.replace( /^wcma\[/, '' ).replace( /\]$/, '' );
					var path = name.split( '][' );
					var isCheckbox = 'checkbox' === this.type;

					if ( isCheckbox && path.length === 1 ) {
						boxes.push( path[ 0 ] );
					}

					if ( isCheckbox && ! this.checked ) {
						return;
					}

					if ( 'radio' === this.type && ! this.checked ) {
						return;
					}

					var value = $( this ).val();

					if ( null === value ) {
						return;
					}

					// ساخت ساختار تودرتو از نام فیلد.
					var node = fields;

					for ( var i = 0; i < path.length; i++ ) {
						var part = path[ i ];
						var last = i === path.length - 1;

						if ( '' === part ) {
							// آرایه‌ی بدون کلید (چندانتخابی).
							if ( ! ( node instanceof Array ) ) {
								node = [];
							}

							node.push( value );
							break;
						}

						if ( last ) {
							node[ part ] = value;
						} else {
							if ( ! node[ part ] || typeof node[ part ] !== 'object' ) {
								node[ part ] = {};
							}

							node = node[ part ];
						}
					}
				} );

				// چندانتخابی‌ها (name="wcma[key][]") جداگانه جمع می‌شوند.
				var groups = {};

				$form.find( '[name$="][]"]' ).each( function () {
					var key = this.name.replace( /^wcma\[/, '' ).replace( /\]\[\]$/, '' );

					if ( key.indexOf( '][' ) !== -1 ) {
						return;
					}

					if ( ! groups[ key ] ) {
						groups[ key ] = [];
					}

					if ( 'checkbox' === this.type && ! this.checked ) {
						return;
					}

					var v = $( this ).val();

					if ( '' !== v && null !== v ) {
						groups[ key ].push( v );
					}
				} );

				$.each( groups, function ( key, values ) {
					fields[ key ] = values.length ? values : [ '' ];
				} );

				return { fields: fields, boxes: boxes };
			}

			function save() {
				var data = collect();

				pending = false;
				$status.text( 'در حال ذخیره...' ).removeClass( 'is-saved is-failed' ).addClass( 'is-saving' );

				request( 'wcma_autosave', {
					fields: data.fields,
					checkboxes: data.boxes
				} ).done( function ( response ) {
					if ( response && response.success ) {
						$status.text( 'ذخیره شد · ' + response.data.time ).removeClass( 'is-saving is-failed' ).addClass( 'is-saved' );
						$fallback.prop( 'hidden', true );

						// ربات در این فاصله از تلگرام ویرایش شده؛ این برگه کهنه است.
						if ( response.data.stale ) {
							staleNotice( $form );
						}
					} else {
						failed( ( response && response.data && response.data.message ) || 'ذخیره نشد' );
					}
				} ).fail( function () {
					failed( 'ذخیره نشد؛ دکمه‌ی ذخیره را بزنید.' );
				} );
			}

			function schedule() {
				pending = true;
				$status.text( 'تغییر ذخیره‌نشده...' ).removeClass( 'is-saved is-failed' );
				clearTimeout( timer );
				timer = setTimeout( save, 900 );
			}

			$form.on( 'change', 'input, select, textarea', schedule );
			$form.on( 'input', 'input[type="text"], input[type="number"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], textarea', schedule );

			// اگر کاربر پیش از پایان مهلت صفحه را ترک کند، همان لحظه ذخیره می‌کنیم.
			$( window ).on( 'beforeunload', function () {
				if ( pending ) {
					clearTimeout( timer );
					save();
				}
			} );
		} );
	}

	/**
	 * انتخاب تصویر از کتابخانه‌ی رسانه‌ی وردپرس.
	 */
	function initImageField() {
		var frames = {};

		$( document ).on( 'click', '.wcma-image__pick', function () {
			var $field = $( this ).closest( '.wcma-image' );
			var key = $field.data( 'key' );

			if ( ! window.wp || ! window.wp.media ) {
				// اگر کتابخانه‌ی رسانه در دسترس نبود، کادر نشانی دستی همچنان کار می‌کند.
				$field.find( '.wcma-image__url' ).focus();
				return;
			}

			if ( ! frames[ key ] ) {
				frames[ key ] = window.wp.media( {
					title: 'انتخاب تصویر',
					button: { text: 'استفاده از این تصویر' },
					library: { type: 'image' },
					multiple: false
				} );

				frames[ key ].on( 'select', function () {
					var item = frames[ key ].state().get( 'selection' ).first().toJSON();
					var url = item.url;

					// اگر اندازه‌ی کوچک‌تری هست، همان بهتر است.
					if ( item.sizes && item.sizes.thumbnail ) {
						url = item.sizes.thumbnail.url;
					}

					$field.find( '.wcma-image__url' ).val( url ).trigger( 'change' );
					$field.find( '.wcma-image__preview' )
						.addClass( 'has-image' )
						.html( $( '<img/>' ).attr( 'src', url ).attr( 'alt', '' ) );
					$field.find( '.wcma-image__clear' ).prop( 'hidden', false );
				} );
			}

			frames[ key ].open();
		} );

		$( document ).on( 'click', '.wcma-image__clear', function () {
			var $field = $( this ).closest( '.wcma-image' );

			$field.find( '.wcma-image__url' ).val( '' ).trigger( 'change' );
			$field.find( '.wcma-image__preview' )
				.removeClass( 'has-image' )
				.html( '<span class="dashicons dashicons-format-image"></span>' );
			$( this ).prop( 'hidden', true );
		} );

		// نشانی دستی هم پیش‌نمایش را به‌روز کند.
		$( document ).on( 'change', '.wcma-image__url', function () {
			var $field = $( this ).closest( '.wcma-image' );
			var url = trim( $( this ).val() );

			if ( url ) {
				$field.find( '.wcma-image__preview' )
					.addClass( 'has-image' )
					.html( $( '<img/>' ).attr( 'src', url ).attr( 'alt', '' ) );
				$field.find( '.wcma-image__clear' ).prop( 'hidden', false );
			}
		} );
	}

	/**
	 * ارسال آزمایشی یک روز از دنباله‌ی ربات.
	 */
	/**
	 * افزودن، برداشتن و حالتِ زمان‌بندی روزهای دنباله.
	 */
	function initDays() {
		var $wrap = $( '.wcma-days' );

		if ( ! $wrap.length ) {
			return;
		}

		function count() {
			var open = $wrap.find( '.wcma-day:not([hidden])' ).length;
			var max = $wrap.find( '.wcma-day' ).length;

			$( '#wcma-day-count' ).text( 'روز ' + open + ' از ' + max );
			$( '#wcma-add-day' ).prop( 'disabled', open >= max );
		}

		$( document ).on( 'click', '#wcma-add-day', function () {
			var $next = $wrap.find( '.wcma-day[hidden]' ).first();

			if ( ! $next.length ) {
				toast( 'بیشتر از این نمی‌شود روز اضافه کرد.', 'error' );
				return;
			}

			showRow( $next, true );
			$next.find( 'textarea' ).trigger( 'focus' );
			count();
		} );

		$( document ).on( 'click', '.wcma-day__remove', function () {
			var $day = $( this ).closest( '.wcma-day' );

			// خالی کردن مقدارها لازم است، وگرنه روزِ پنهان باز هم ذخیره می‌شد.
			$day.find( 'input[type="text"], input[type="url"], textarea' ).val( '' );
			$day.find( 'input[type="checkbox"]' ).prop( 'checked', false );
			$day.removeClass( 'is-active' );

			// پیش از غیرفعال شدن فیلدها، تا ذخیره‌ی خودکار باخبر شود.
			$day.find( 'textarea' ).first().trigger( 'change' );

			if ( $wrap.find( '.wcma-day:not([hidden])' ).length > 1 ) {
				showRow( $day, false );
			}

			count();
		} );

		// نمایش کادر تاریخ فقط در حالت «تاریخ مشخص».
		$( document ).on( 'change', '.wcma-day__mode', function () {
			var $date = $( this ).closest( '.wcma-day__head' ).find( '.wcma-day__date' );

			$date.prop( 'hidden', 'date' !== this.value );

			if ( 'date' === this.value && window.wcmaRefreshDates ) {
				window.wcmaRefreshDates();
			}
		} );

		$wrap.find( '.wcma-day[hidden]' ).each( function () {
			showRow( $( this ), false );
		} );

		count();
	}

	/**
	 * استعلام لحظه‌ای اعتبار پنل پیامک.
	 */
	/**
	 * ساخت خودکار دنباله‌ی ۷ روزه‌ی لید مگنت.
	 */
	/**
	 * نمایش رویدادهای گردش کار بر پایه‌ی دسته‌ی انتخاب‌شده.
	 */
	function applyJourneyFilter() {
		var $active = $( '.wcma-journey-filter.is-active' );

		if ( ! $active.length ) {
			return;
		}

		var kinds = String( $active.data( 'kinds' ) || '' ).split( ' ' ).filter( Boolean );
		var $items = $( '#wcma-crm-journey .wcma-journey__item' );
		var shown = 0;

		$items.each( function () {
			var ok = ! kinds.length || kinds.indexOf( String( $( this ).data( 'kind' ) ) ) !== -1;

			$( this ).prop( 'hidden', ! ok );

			if ( ok ) {
				shown++;
			}
		} );

		$( '#wcma-journey-empty' ).prop( 'hidden', shown > 0 );
	}

	/**
	 * دکمه‌های فیلتر گردش کار.
	 */
	function initJourneyFilter() {
		$( document ).on( 'click', '.wcma-journey-filter', function () {
			$( '.wcma-journey-filter' ).removeClass( 'is-active' );
			$( this ).addClass( 'is-active' );
			applyJourneyFilter();
		} );
	}

	function initLeadMagnet() {
		$( document ).on( 'click', '#wcma-lm-setup', function () {
			var $btn = $( this );
			var $result = $( '#wcma-lm-setup-result' );
			var original = $btn.html();

			$btn.prop( 'disabled', true ).text( 'در حال ساخت...' );
			$result.html( '' );

			request( 'wcma_lm_setup', { topic: trim( $( '#wcma-lm-topic' ).val() ) } ).done( function ( response ) {
				if ( response && response.success ) {
					$result.html( '<div class="wcma-notice wcma-notice--success"><span class="dashicons dashicons-yes-alt"></span><span>' + response.data.message + '</span></div>' );
					toast( 'دنباله ساخته شد.', 'success' );
				} else {
					var msg = ( response && response.data && response.data.message ) || i18n.error;
					$result.html( '<div class="wcma-notice wcma-notice--error"><span class="dashicons dashicons-warning"></span><span>' + msg + '</span></div>' );
				}
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );

		// فقط فیلدهای مربوط به پاداشِ انتخاب‌شده دیده شوند.
		function syncReward() {
			var value = $( '[name="wcma[lm_reward]"]' ).val();

			$( '.wcma-lm-reward' ).each( function () {
				$( this ).toggle( $( this ).data( 'reward' ) === value );
			} );
		}

		$( document ).on( 'change', '[name="wcma[lm_reward]"]', syncReward );
		syncReward();
	}

	function initSmsCredit() {
		var $pill = $( '#wcma-sms-credit' );

		if ( ! $pill.length ) {
			return;
		}

		var $text = $pill.find( '.wcma-credit__text' );
		var busy = false;

		function load() {
			if ( busy ) {
				return;
			}

			busy = true;
			$pill.addClass( 'is-loading' ).removeClass( 'is-failed' );
			$text.text( 'اعتبار پیامک: در حال استعلام…' );

			request( 'wcma_sms_balance', {} ).done( function ( response ) {
				if ( response && response.success ) {
					$text.text( 'اعتبار پیامک: ' + response.data.amount + ' ' + response.data.unit );
					$pill.attr( 'title', 'استعلام‌شده در ساعت ' + response.data.time + ' — برای استعلام دوباره کلیک کنید' );
				} else {
					$pill.addClass( 'is-failed' );
					$text.text( 'اعتبار پیامک: استعلام نشد' );
					$pill.attr( 'title', ( response && response.data && response.data.message ) || i18n.error );
				}
			} ).fail( function () {
				$pill.addClass( 'is-failed' );
				$text.text( 'اعتبار پیامک: استعلام نشد' );
			} ).always( function () {
				busy = false;
				$pill.removeClass( 'is-loading' );
			} );
		}

		$pill.on( 'click keypress', function ( e ) {
			if ( 'keypress' === e.type && 13 !== e.which && 32 !== e.which ) {
				return;
			}

			load();
		} );

		load();
	}

	/**
	 * پاک کردن دستی فایل‌های گفتگو، با به‌روز کردن شمارنده در همان صفحه.
	 */
	/**
	 * آزمون ارسال ایمیل با SMTP.
	 *
	 * مقادیر ذخیره‌نشده‌ی همین فرم فرستاده می‌شوند تا پیش از ذخیره هم بشود
	 * آزمود؛ در صورت شکست، پاسخ خام سرور نشان داده می‌شود چون تنها جایی است
	 * که دلیل واقعی را می‌گوید.
	 */
	function initSmtpTest() {
		var $box = $( '#wcma-smtp-test' );

		if ( ! $box.length ) {
			return;
		}

		var $btn = $( '#wcma-smtp-test-btn' );
		var $result = $box.find( '.wcma-conntest__result' );

		$btn.on( 'click', function () {
			var to = trim( $box.find( '.wcma-conntest__to' ).val() || '' );

			if ( ! to ) {
				$result.html( '<div class="wcma-notice wcma-notice--error">نشانی ایمیل گیرنده را وارد کنید.</div>' );
				return;
			}

			var settings = {};

			/*
			 * از روی name خوانده می‌شود نه id: سوییچ‌های روشن/خاموش اصلاً id
			 * ندارند و با انتخابگر شناسه‌ای نادیده می‌ماندند.
			 */
			$( '[name^="wcma[smtp_"]' ).each( function () {
				var $field = $( this );
				var key = ( this.name.match( /^wcma\[(smtp_[a-z_]+)\]$/ ) || [] )[ 1 ];

				if ( ! key ) {
					return;
				}

				settings[ key ] = $field.is( ':checkbox' ) ? ( $field.is( ':checked' ) ? 'yes' : 'no' ) : $field.val();
			} );

			// آزمون باید کار کند حتی اگر هنوز کلید اصلی را روشن نکرده باشند.
			settings.smtp_enabled = 'yes';

			var original = $btn.html();

			$btn.prop( 'disabled', true ).text( i18n.sending || 'در حال ارسال...' );
			$result.html( '<div class="wcma-notice wcma-notice--success">' + ( i18n.sending || 'در حال ارسال...' ) + '</div>' );

			request( 'wcma_smtp_test', { to: to, settings: settings } ).done( function ( response ) {
				if ( response && response.success ) {
					$result.empty().append(
						$( '<div class="wcma-notice wcma-notice--success"/>' )
							.append( '<span class="dashicons dashicons-yes-alt"></span>' )
							.append( $( '<span/>' ).text( response.data.message ) )
					);
					toast( 'ایمیل آزمایشی فرستاده شد.', 'success' );
					return;
				}

				var data = ( response && response.data ) || {};
				var $note = $( '<div class="wcma-notice wcma-notice--error"/>' )
					.append( '<span class="dashicons dashicons-warning"></span>' )
					.append( $( '<span/>' ).text( data.message || i18n.error ) );

				$result.empty().append( $note );

				if ( data.debug && data.debug.length ) {
					$result.append( $( '<pre class="wcma-smtp-debug"/>' ).text( data.debug.join( '\n' ) ) );
				}

				toast( 'ارسال ایمیل آزمایشی ناموفق بود.', 'error' );
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	function initChatFiles() {
		var $btn = $( '#wcma-files-purge' );

		if ( ! $btn.length ) {
			return;
		}

		$btn.on( 'click', function () {
			/*
			 * تأیید همین‌جا گرفته می‌شود، نه با data-confirm: آن یکی روی
			 * document نشسته و بعد از این هندلر اجرا می‌شود، پس جلوی کار را
			 * نمی‌گرفت.
			 */
			if ( ! window.confirm( 'همه‌ی فایل‌های گفتگو از هاست پاک می‌شوند. این کار برگشت‌پذیر نیست. ادامه؟' ) ) {
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_chat_files_purge', {} ).done( function ( response ) {
				if ( response && response.success ) {
					$( '#wcma-files-count' ).text( response.data.count );
					$( '#wcma-files-size' ).text( response.data.size );
					toast( response.data.message, 'success' );
				} else {
					toast( ( response && response.data && response.data.message ) || i18n.error, 'error' );
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );
	}

	function initSmsBalance() {
		var $box = $( '#wcma-sms-balance' );

		if ( ! $box.length ) {
			return;
		}

		var $value = $box.find( '.wcma-balance__value' );
		var $meta = $box.find( '.wcma-balance__meta' );
		var busy = false;

		function load() {
			if ( busy ) {
				return;
			}

			busy = true;
			$box.removeClass( 'is-failed' ).addClass( 'is-loading' );
			$value.text( 'در حال استعلام...' );
			$meta.text( '' );

			// مقادیر ذخیره‌نشده‌ی فرم فرستاده می‌شوند تا پیش از ذخیره هم کار کند.
			var settings = {};

			$( '[name^="wcma[sms_"]' ).each( function () {
				var key = this.name.replace( /^wcma\[/, '' ).replace( /\]$/, '' );

				if ( 'checkbox' === this.type && ! this.checked ) {
					return;
				}

				settings[ key ] = $( this ).val();
			} );

			request( 'wcma_sms_balance', { settings: settings } ).done( function ( response ) {
				if ( response && response.success ) {
					$value.text( response.data.amount + ' ' + response.data.unit );
					$meta.text( 'استعلام‌شده در ساعت ' + response.data.time );
				} else {
					$box.addClass( 'is-failed' );
					$value.text( 'استعلام نشد' );
					$meta.text( ( response && response.data && response.data.message ) || i18n.error );
				}
			} ).fail( function () {
				$box.addClass( 'is-failed' );
				$value.text( 'استعلام نشد' );
				$meta.text( i18n.error || 'خطا' );
			} ).always( function () {
				busy = false;
				$box.removeClass( 'is-loading' );
			} );
		}

		$box.on( 'click', '.wcma-balance__refresh', load );

		// با عوض شدن سرویس یا کلید، دوباره استعلام می‌گیریم.
		$( document ).on( 'change', '[name="wcma[sms_gateway]"], [name="wcma[sms_api_key]"], [name="wcma[sms_username]"], [name="wcma[sms_password]"]', function () {
			clearTimeout( $box.data( 'timer' ) );
			$box.data( 'timer', setTimeout( load, 900 ) );
		} );

		load();
	}

	/**
	 * هشدار برگه‌ی کهنه: ربات از تلگرام ویرایش شده و این برگه نسخه‌ی پیشین را دارد.
	 *
	 * @param {jQuery} $form فرم.
	 */
	function staleNotice( $form ) {
		if ( $form.find( '.wcma-stale' ).length ) {
			return;
		}

		var $notice = $( '<div class="wcma-notice wcma-notice--warning wcma-stale"/>' );
		var $reload = $( '<button type="button" class="wcma-btn wcma-btn--secondary"/>' ).text( 'تازه کردن برگه' );

		$notice.append( $( '<span class="dashicons dashicons-warning"/>' ) );
		$notice.append( $( '<span/>' ).text( 'یک مدیر در این فاصله بخشی از ربات را از خود تلگرام عوض کرده است. بقیه‌ی تغییرهای این برگه ذخیره شد، ولی آن بخش با نسخه‌ی کهنه‌ی این برگه بازنویسی نشد تا کار او برنگردد. برگه را تازه کنید؛ اگر همان بخش را هم تغییر داده بودید، دوباره تغییر دهید.' ) );
		$notice.append( $reload );

		$reload.on( 'click', function () {
			window.location.reload();
		} );

		// صفحه جابه‌جا نمی‌شود؛ هشدار بالای فرم و پیام کوتاه کافی است.
		$form.prepend( $notice );
		toast( 'بخشی از ربات از تلگرام عوض شده؛ برگه را تازه کنید.', 'error' );
	}

	/**
	 * سنجش سرعت ربات.
	 */
	function initBotSpeed() {
		function ms( value ) {
			return null === value || undefined === value ? '—' : Number( value ).toLocaleString( 'fa-IR' ) + ' میلی‌ثانیه';
		}

		function row( ok, label, value ) {
			var $li = $( '<li/>' ).addClass( ok ? 'is-ok' : 'is-bad' );

			$li.append( $( '<span/>' ).addClass( 'dashicons dashicons-' + ( ok ? 'yes-alt' : 'warning' ) ) );
			$li.append( $( '<strong/>' ).text( label ) );
			// متن خطای سرور یا تلگرام ممکن است < داشته باشد؛ به‌شکل متن نوشته می‌شود.
			$li.append( $( '<span/>' ).text( value ) );

			return $li;
		}

		$( document ).on( 'click', '#wcma-bot-speed', function () {
			var $btn = $( this );
			var $result = $( '#wcma-bot-speed-result' );
			var original = $btn.html();

			$btn.prop( 'disabled', true ).text( 'در حال سنجش...' );
			$result.removeAttr( 'hidden' ).empty().append( $( '<div class="wcma-notice"/>' ).text( 'چند ثانیه طول می‌کشد؛ ارتباط با تلگرام و بالا آمدن وردپرس اندازه گرفته می‌شود...' ) );

			request( 'wcma_bot_speed', {} ).done( function ( response ) {
				if ( ! response || ! response.success ) {
					$result.empty().append( $( '<div class="wcma-notice wcma-notice--error"/>' ).text( ( response && response.data && response.data.message ) || i18n.error || 'خطا' ) );
					return;
				}

				var data = response.data || {};
				var api = data.api || {};
				var hook = data.webhook || {};
				var $list = $( '<ul class="wcma-diagnostics__list"/>' );

				if ( api.ok ) {
					var parts = [ 'کل: ' + ms( api.total ) ];

					if ( api.dns !== undefined ) {
						parts.push( 'DNS: ' + ms( api.dns ) );
						parts.push( 'اتصال: ' + ms( api.connect ) );
						parts.push( 'TLS: ' + ms( api.tls ) );
					}

					if ( null !== api.warm && undefined !== api.warm ) {
						parts.push( 'روی اتصال باز: ' + ms( api.warm ) );
					}

					if ( api.ip ) {
						parts.push( api.ip.indexOf( ':' ) !== -1 ? 'IPv6' : 'IPv4' );
					}

					$list.append( row( api.total < 600, 'ارتباط با تلگرام', parts.join( ' · ' ) ) );
				} else {
					$list.append( row( false, 'ارتباط با تلگرام', api.error || 'برقرار نشد' ) );
				}

				if ( data.api_v4 ) {
					$list.append( row( !! data.api_v4.ok, 'ارتباط فقط با IPv4', data.api_v4.ok ? 'کل: ' + ms( data.api_v4.total ) : ( data.api_v4.error || 'برقرار نشد' ) ) );
				}

				if ( hook.ok ) {
					$list.append( row( hook.boot < 700, 'بالا آمدن وردپرس برای هر پیام', ms( hook.boot ) ) );
				} else {
					$list.append( row( false, 'بالا آمدن وردپرس برای هر پیام', hook.error || 'سنجیده نشد' ) );
				}

				if ( null !== data.pending && undefined !== data.pending ) {
					$list.append( row( data.pending < 4, 'پیام‌های معطل در صف تلگرام', Number( data.pending ).toLocaleString( 'fa-IR' ) ) );
				}

				var $advice = $( '<ul class="wcma-speed__advice"/>' );

				$.each( data.advice || [], function ( i, item ) {
					$advice.append( $( '<li/>' ).addClass( 'is-' + item.level ).text( item.text ) );
				} );

				$result.empty().append( $list ).append( $( '<h4 class="wcma-speed__title"/>' ).text( 'نتیجه و پیشنهاد' ) ).append( $advice );
			} ).fail( function () {
				$result.empty().append( $( '<div class="wcma-notice wcma-notice--error"/>' ).text( i18n.error || 'خطا' ) );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );
	}

	/**
	 * بررسی سلامت ربات و وب‌هوک.
	 */
	function initBotDiag() {
		$( document ).on( 'click', '#wcma-bot-diag', function () {
			var $btn = $( this );
			var $result = $( '#wcma-bot-diag-result' );
			var original = $btn.html();

			$btn.prop( 'disabled', true ).text( 'در حال بررسی...' );
			$result.removeAttr( 'hidden' ).html( '<div class="wcma-notice">در حال گرفتن وضعیت از تلگرام...</div>' );

			request( 'wcma_bot_diag', {} ).done( function ( response ) {
				if ( ! response || ! response.success ) {
					$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
					return;
				}

				var data = response.data || {};
				var rows = data.rows || [];
				var html = '<ul class="wcma-diagnostics__list">';

				$.each( rows, function ( i, row ) {
					html += '<li class="' + ( row.ok ? 'is-ok' : 'is-bad' ) + '">' +
						'<span class="dashicons dashicons-' + ( row.ok ? 'yes-alt' : 'warning' ) + '"></span>' +
						'<strong>' + row.label + '</strong>' +
						'<span>' + row.value + '</span>' +
						'</li>';
				} );

				html += '</ul>';

				if ( ! data.ok ) {
					html += '<div class="wcma-notice wcma-notice--error"><span class="dashicons dashicons-warning"></span><span>' +
						'موردهای قرمز بالا را درست کنید. بیشتر وقت‌ها زدن «ثبت دوباره‌ی وب‌هوک» مشکل را حل می‌کند.' +
						'</span></div>';
				} else {
					html += '<div class="wcma-notice wcma-notice--success"><span class="dashicons dashicons-yes-alt"></span><span>همه چیز سالم است.</span></div>';
				}

				$result.html( html );
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false ).html( original );
			} );
		} );

		// عمداً خودکار اجرا نمی‌شود؛ استعلام از تلگرام کند است و باز کردن برگه نباید معطل بماند.
	}

	/**
	 * افزودن و برداشتن دکمه‌های زیر پیام هر روز.
	 */
	function initDayButtons() {
		$( document ).on( 'click', '.wcma-day__button-add', function () {
			var $wrap = $( this ).closest( '.wcma-day__buttons' );
			var $next = $wrap.find( '.wcma-day__button[hidden]' ).first();

			if ( ! $next.length ) {
				toast( 'بیشتر از این نمی‌شود دکمه گذاشت.', 'error' );
				return;
			}

			$next.removeAttr( 'hidden' ).find( 'input' ).first().trigger( 'focus' );
			syncDayAdd( $wrap );
		} );

		$( document ).on( 'click', '.wcma-day__button-remove', function () {
			var $row = $( this ).closest( '.wcma-day__button' );
			var $wrap = $row.closest( '.wcma-day__buttons' );

			$row.find( 'input' ).val( '' ).last().trigger( 'change' );

			// ردیف اول همیشه می‌ماند تا کارت خالی و گیج‌کننده نشود.
			if ( $wrap.find( '.wcma-day__button:not([hidden])' ).length > 1 ) {
				$row.attr( 'hidden', 'hidden' );
			}

			syncDayAdd( $wrap );
		} );

		$( '.wcma-day__buttons' ).each( function () {
			syncDayAdd( $( this ) );
		} );
	}

	/**
	 * نمایش یا پنهان کردن دکمه‌ی «افزودن دکمه».
	 *
	 * @param {Object} $wrap جعبه‌ی دکمه‌های یک روز.
	 */
	function syncDayAdd( $wrap ) {
		var left = $wrap.find( '.wcma-day__button[hidden]' ).length;

		$wrap.find( '.wcma-day__button-add' ).toggle( left > 0 );
	}

	function initBotTest() {
		$( document ).on( 'click', '#wcma-bot-test', function () {
			var $btn = $( this );
			var $result = $( '#wcma-bot-test-result' );
			var chat = trim( $( '#wcma-bot-chat' ).val() );

			if ( ! chat ) {
				$result.html( '<div class="wcma-notice wcma-notice--error">شناسه‌ی چت را وارد کنید.</div>' );
				return;
			}

			$btn.prop( 'disabled', true );
			$result.html( '<div class="wcma-notice wcma-notice--success">' + ( i18n.sending || 'در حال ارسال...' ) + '</div>' );

			request( 'wcma_bot_test', { chat: chat, day: $( '#wcma-bot-day' ).val() } ).done( function ( response ) {
				var ok = response && response.success;
				var msg = ok ? response.data.message : ( ( response && response.data && response.data.message ) || i18n.error );

				$result.html(
					'<div class="wcma-notice wcma-notice--' + ( ok ? 'success' : 'error' ) + '">' +
					'<span class="dashicons dashicons-' + ( ok ? 'yes-alt' : 'warning' ) + '"></span><span>' + msg + '</span></div>'
				);
				toast( msg, ok ? 'success' : 'error' );
			} ).fail( function () {
				$result.html( '<div class="wcma-notice wcma-notice--error">' + ( i18n.error || 'خطا' ) + '</div>' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'change', '.wcma-day__toggle', function () {
			$( this ).closest( '.wcma-day' ).toggleClass( 'is-active', this.checked );
		} );

		// --- دستورهای ربات: افزودن، پاک کردن و آیکون متناسب ---

		var $menu = $( '.wcma-botmenu' );

		function refreshCommands() {
			var max = parseInt( $menu.data( 'max' ), 10 ) || 8;
			var shown = $menu.find( '.wcma-botmenu__row' ).not( '[hidden]' ).length;

			$( '#wcma-add-command' ).prop( 'disabled', shown >= max );
			$( '#wcma-command-count' ).text(
				shown.toLocaleString( 'fa-IR' ) + ' از ' + max.toLocaleString( 'fa-IR' ) + ' دستور'
			);
		}

		$( document ).on( 'click', '#wcma-add-command', function () {
			var $next = $menu.find( '.wcma-botmenu__row[hidden]' ).first();

			if ( ! $next.length ) {
				return;
			}

			$next.prop( 'hidden', false ).find( '.wcma-botmenu__label' ).focus();
			refreshCommands();
		} );

		$( document ).on( 'click', '.wcma-botmenu__remove', function () {
			var $row = $( this ).closest( '.wcma-botmenu__row' );

			// خالی کردن مقادیر لازم است، وگرنه دستور پنهان‌شده باز هم ذخیره می‌شد.
			$row.find( 'input' ).val( '' ).trigger( 'change' );
			$row.find( 'select' ).prop( 'selectedIndex', 0 );
			$row.find( '.wcma-botmenu__action' ).trigger( 'change' );

			if ( $menu.find( '.wcma-botmenu__row' ).not( '[hidden]' ).length > 1 ) {
				$row.prop( 'hidden', true );
			}

			refreshCommands();
		} );

		// آیکون هر روز با نوع محتوای انتخاب‌شده هماهنگ می‌شود.
		$( document ).on( 'change', '.wcma-day__type', function () {
			var icon = $( this ).find( 'option:selected' ).data( 'icon' ) || 'editor-alignright';

			$( this ).closest( '.wcma-day' ).find( '.wcma-day__icon' )
				.attr( 'class', 'wcma-day__icon dashicons dashicons-' + icon );
		} );

		// راهنمای کادر آخر هر ردیف، بسته به کاری که دکمه انجام می‌دهد.
		var hints = {
			reply: 'متن پاسخ',
			phone: 'متن درخواست شماره (اختیاری)',
			link: 'https://example.com',
			day: 'شماره‌ی روز، مثلاً ۳',
			stop: 'متن تأیید لغو (اختیاری)',
			restart: 'متن تأیید شروع دوباره (اختیاری)'
		};

		function syncCommand( $row ) {
			var action = $row.find( '.wcma-botmenu__action' ).val();

			// برای «پیام آماده» کشوی انتخاب پیام جای کادر متن را می‌گیرد.
			$row.find( '.wcma-botmenu__value' ).prop( 'hidden', 'message' === action ).attr( 'placeholder', hints[ action ] || '' );
			$row.find( '.wcma-botmenu__message' ).prop( 'hidden', 'message' !== action );
		}

		// آیکون هر ردیف با کاری که انتخاب شده هماهنگ می‌شود.
		$( document ).on( 'change', '.wcma-botmenu__action', function () {
			var icon = $( this ).find( 'option:selected' ).data( 'icon' ) || 'format-status';
			var $row = $( this ).closest( '.wcma-botmenu__row' );

			$row.find( '.wcma-botmenu__icon' ).attr( 'class', 'wcma-botmenu__icon dashicons dashicons-' + icon );
			syncCommand( $row );
		} );

		if ( $menu.length ) {
			$menu.find( '.wcma-botmenu__row' ).each( function () {
				syncCommand( $( this ) );
			} );

			refreshCommands();
		}
	}

	/**
	 * ویرایشگر پیام‌های آماده: افزودن و برداشتن پیام و دکمه‌های شیشه‌ای،
	 * و همگام نگه داشتن همه‌ی کشوهای «انتخاب پیام آماده» با آن.
	 */
	function initBotMessages() {
		var $wrap = $( '.wcma-canned-list' );

		if ( ! $wrap.length ) {
			return;
		}

		var timer = null;

		function count() {
			var open = $wrap.find( '.wcma-canned:not([hidden])' ).length;
			var max = $wrap.find( '.wcma-canned' ).length;

			$( '#wcma-message-count' ).text( open.toLocaleString( 'fa-IR' ) + ' از ' + max.toLocaleString( 'fa-IR' ) + ' پیام' );
			$( '#wcma-add-message' ).prop( 'disabled', open >= max );
		}

		// پیام‌هایی که چیزی برای فرستادن دارند؛ همان‌هایی که سرور هم نگه می‌دارد.
		function list() {
			var out = [];

			$wrap.find( '.wcma-canned:not([hidden])' ).each( function () {
				var $msg = $( this );
				var text = trim( $msg.find( '.wcma-canned__text' ).val() );
				var file = trim( $msg.find( '.wcma-canned__file' ).val() );
				var title = trim( $msg.find( '.wcma-canned__title' ).val() );

				if ( ! text && ! file ) {
					return;
				}

				if ( ! title ) {
					title = text
						? text.replace( /\s+/g, ' ' ).substring( 0, 40 )
						: 'فایل ' + file.split( '?' )[ 0 ].split( '/' ).pop();
				}

				out.push( { id: $msg.find( '.wcma-canned__id' ).val(), title: title } );
			} );

			return out;
		}

		function sync() {
			var items = list();

			$( '.wcma-canned-select' ).each( function () {
				var $select = $( this );
				var current = $select.val() || '';
				var own = $select.closest( '.wcma-canned' ).find( '.wcma-canned__id' ).val();

				$select.empty().append( $( '<option/>', { value: '', text: '— یک پیام آماده انتخاب کنید —' } ) );

				$.each( items, function ( i, item ) {
					// دکمه‌ای که پیام را به خودش برگرداند، کاربر را درجا نگه می‌دارد.
					if ( item.id !== own ) {
						$select.append( $( '<option/>', { value: item.id, text: item.title } ) );
					}
				} );

				$select.val( current );

				if ( null === $select.val() ) {
					$select.val( '' );
				}
			} );
		}

		function later() {
			clearTimeout( timer );
			timer = setTimeout( sync, 300 );
		}

		function syncButton( $row ) {
			var kind = $row.find( '.wcma-canned__button-kind' ).val();

			$row.find( '.wcma-canned__button-url' ).prop( 'hidden', 'message' === kind );
			$row.find( '.wcma-canned__button-message' ).prop( 'hidden', 'message' !== kind );
		}

		function syncAdd( $buttons ) {
			$buttons.find( '.wcma-canned__button-add' ).toggle( $buttons.find( '.wcma-canned__button[hidden]' ).length > 0 );
		}

		$( document ).on( 'click', '#wcma-add-message', function () {
			var $next = $wrap.find( '.wcma-canned[hidden]' ).first();

			if ( ! $next.length ) {
				toast( 'بیشتر از این نمی‌شود پیام آماده ساخت.', 'error' );
				return;
			}

			showRow( $next, true );

			// دکمه‌های پنهانِ همین پیام غیرفعال می‌مانند.
			$next.find( '.wcma-canned__button[hidden]' ).each( function () {
				showRow( $( this ), false );
			} );

			$next.find( '.wcma-canned__title' ).trigger( 'focus' );
			count();
			sync();
		} );

		$( document ).on( 'click', '.wcma-canned__remove', function () {
			var $msg = $( this ).closest( '.wcma-canned' );

			if ( ! window.confirm( 'این پیام آماده پاک شود؟ دکمه‌هایی که به آن وصل‌اند دیگر کاری نمی‌کنند.' ) ) {
				return;
			}

			// خالی کردن لازم است، وگرنه پیامِ پنهان باز هم ذخیره می‌شد.
			$msg.find( 'input[type="text"], input[type="url"], textarea' ).val( '' );
			$msg.find( 'select' ).prop( 'selectedIndex', 0 );

			// شناسه‌ی تازه، تا دکمه‌های قدیمی به پیامی که بعداً در همین جا ساخته شود نرسند.
			$msg.find( '.wcma-canned__id' ).val( 'm' + Math.random().toString( 36 ).slice( 2, 10 ) );
			$msg.find( '.wcma-canned__type' ).trigger( 'change' );

			$msg.find( '.wcma-canned__button' ).each( function ( i ) {
				showRow( $( this ), 0 === i );
				syncButton( $( this ) );
			} );

			syncAdd( $msg.find( '.wcma-canned__buttons' ) );

			// پیش از غیرفعال شدن فیلدها، تا ذخیره‌ی خودکار باخبر شود.
			$msg.find( 'textarea' ).trigger( 'change' );

			if ( $wrap.find( '.wcma-canned:not([hidden])' ).length > 1 ) {
				showRow( $msg, false );
			}

			count();
			sync();
		} );

		// آیکون پیام با نوع محتوایش هماهنگ می‌شود.
		$( document ).on( 'change', '.wcma-canned__type', function () {
			var icon = $( this ).find( 'option:selected' ).data( 'icon' ) || 'editor-alignright';

			$( this ).closest( '.wcma-canned' ).find( '.wcma-canned__icon' )
				.attr( 'class', 'wcma-canned__icon dashicons dashicons-' + icon );
		} );

		$( document ).on( 'click', '.wcma-canned__button-add', function () {
			var $buttons = $( this ).closest( '.wcma-canned__buttons' );
			var $next = $buttons.find( '.wcma-canned__button[hidden]' ).first();

			if ( ! $next.length ) {
				toast( 'بیشتر از این نمی‌شود دکمه گذاشت.', 'error' );
				return;
			}

			showRow( $next, true );
			syncButton( $next );
			$next.find( 'input' ).first().trigger( 'focus' );
			syncAdd( $buttons );
		} );

		$( document ).on( 'click', '.wcma-canned__button-remove', function () {
			var $row = $( this ).closest( '.wcma-canned__button' );
			var $buttons = $row.closest( '.wcma-canned__buttons' );

			$row.find( 'input' ).val( '' );
			$row.find( 'select' ).prop( 'selectedIndex', 0 );
			syncButton( $row );

			// پیش از غیرفعال شدن فیلدها، تا ذخیره‌ی خودکار باخبر شود.
			$row.find( 'input' ).first().trigger( 'change' );

			// ردیف اول همیشه می‌ماند تا جعبه خالی و گیج‌کننده نشود.
			if ( $buttons.find( '.wcma-canned__button:not([hidden])' ).length > 1 ) {
				showRow( $row, false );
			}

			syncAdd( $buttons );
		} );

		$( document ).on( 'change', '.wcma-canned__button-kind', function () {
			syncButton( $( this ).closest( '.wcma-canned__button' ) );
		} );

		$( document ).on( 'input change', '.wcma-canned__title, .wcma-canned__text, .wcma-canned__file', later );

		$wrap.find( '.wcma-canned__button' ).each( function () {
			syncButton( $( this ) );
		} );

		// ردیف‌های پنهان (پیام یا دکمه) فرستاده نمی‌شوند.
		$wrap.find( '.wcma-canned[hidden], .wcma-canned__button[hidden]' ).each( function () {
			showRow( $( this ), false );
		} );

		$wrap.find( '.wcma-canned__buttons' ).each( function () {
			syncAdd( $( this ) );
		} );

		count();
		sync();
	}

	/**
	 * ارسال گروهی پیام آماده: آغاز، ارسال آزمایشی، پیشرفت زنده و لغو.
	 */
	function initBroadcast() {
		var $box = $( '#wcma-broadcast' );

		if ( ! $box.length ) {
			return;
		}

		var $result = $( '#wcma-bc-result' );
		var polling = {};

		function notice( message, ok ) {
			var $notice = $( '<div/>', { 'class': 'wcma-notice wcma-notice--' + ( ok ? 'success' : 'error' ) } );

			$notice.append( $( '<span/>', { 'class': 'dashicons dashicons-' + ( ok ? 'yes-alt' : 'warning' ) } ) );
			// پیام خطای تلگرام ممکن است < داشته باشد؛ به‌شکل متن نوشته می‌شود، نه HTML.
			$notice.append( $( '<span/>' ).text( message ) );
			$result.empty().append( $notice );
		}

		function failure( response ) {
			return ( response && response.data && response.data.message ) || i18n.error || 'خطا';
		}

		function render( job ) {
			if ( ! job ) {
				return;
			}

			var $table = $( '#wcma-bc-jobs' );
			var $row = $table.find( 'tr[data-id="' + job.id + '"]' );

			if ( ! $row.length ) {
				$row = $( '<tr/>' ).attr( 'data-id', job.id ).html(
					'<td class="wcma-bc-title"></td><td class="wcma-bc-audience"></td>' +
					'<td><span class="wcma-badge wcma-bc-status"></span></td>' +
					'<td><div class="wcma-progress"><span class="wcma-bc-bar"></span></div><small class="wcma-bc-total"></small></td>' +
					'<td class="wcma-bc-sent"></td><td class="wcma-bc-failed"></td><td class="wcma-nowrap wcma-bc-start"></td>' +
					'<td><button type="button" class="wcma-btn wcma-btn--tiny wcma-bc-cancel">لغو</button></td>'
				);

				$row.find( '.wcma-bc-title' ).text( job.title );
				$row.find( '.wcma-bc-audience' ).text( job.audience );
				$row.find( '.wcma-bc-start' ).text( job.start );
				$row.find( '.wcma-bc-cancel' ).attr( 'data-id', job.id );

				$table.find( 'tbody' ).prepend( $row );
				$table.closest( '.wcma-table-wrap' ).prop( 'hidden', false );
				$( '#wcma-bc-empty' ).prop( 'hidden', true );
			}

			$row.find( '.wcma-bc-status' ).attr( 'class', 'wcma-badge wcma-bc-status ' + job.badge ).text( job.label );
			$row.find( '.wcma-bc-bar' ).css( 'width', job.percent + '%' );
			$row.find( '.wcma-bc-total' ).text( job.progress );
			$row.find( '.wcma-bc-sent' ).text( job.sent );
			$row.find( '.wcma-bc-failed' ).text( job.failed ).attr( 'title', job.error || '' );
			$row.find( '.wcma-bc-cancel' ).prop( 'hidden', ! job.active );
		}

		// تا برگه باز است، تکه‌تکه می‌فرستیم؛ با بستن برگه کرون کار را ادامه می‌دهد.
		function poll( id ) {
			var errors = 0;

			if ( polling[ id ] ) {
				return;
			}

			polling[ id ] = true;

			function step() {
				request( 'wcma_bot_broadcast_step', { id: id } ).done( function ( response ) {
					if ( ! response || ! response.success ) {
						polling[ id ] = false;
						return;
					}

					var job = response.data.job;

					errors = 0;
					render( job );

					// کلید اصلی افزونه خاموش است؛ پرس‌وجوی پیاپی بی‌فایده است.
					if ( job.paused && job.active ) {
						polling[ id ] = false;
						notice( 'کلید اصلی افزونه خاموش است؛ ارسال پس از روشن شدن آن در پس‌زمینه ادامه پیدا می‌کند.', false );
						return;
					}

					if ( 'running' === job.status ) {
						setTimeout( step, 1500 );
						return;
					}

					polling[ id ] = false;

					if ( 'done' === job.status ) {
						toast( 'ارسال «' + job.title + '» تمام شد.', 'success' );
					}
				} ).fail( function () {
					// قطعی کوتاه شبکه نباید پیشرفت را از چشم بیندازد؛ پس از چند بار، کرون ادامه می‌دهد.
					if ( ++errors < 5 ) {
						setTimeout( step, 5000 );
					} else {
						polling[ id ] = false;
					}
				} );
			}

			step();
		}

		$( document ).on( 'click', '#wcma-bc-start', function () {
			var $btn = $( this );
			var message = $( '#wcma-bc-message' ).val();

			if ( ! message ) {
				notice( 'اول یک پیام آماده انتخاب کنید.', false );
				return;
			}

			var question = 'پیام «' + $( '#wcma-bc-message option:selected' ).text() + '» برای «' +
				trim( $( '#wcma-bc-audience option:selected' ).text() ) + '» فرستاده شود؟';

			if ( ! window.confirm( question ) ) {
				return;
			}

			$btn.prop( 'disabled', true );
			notice( i18n.sending || 'در حال ارسال...', true );

			request( 'wcma_bot_broadcast', {
				message: message,
				audience: $( '#wcma-bc-audience' ).val(),
				start_at: $( '#wcma-bc-when' ).val() || ''
			} ).done( function ( response ) {
				var ok = response && response.success;
				var msg = ok ? response.data.message : failure( response );

				notice( msg, ok );
				toast( msg, ok ? 'success' : 'error' );

				if ( ok && response.data.job ) {
					render( response.data.job );

					if ( 'running' === response.data.job.status ) {
						poll( response.data.job.id );
					}
				}
			} ).fail( function () {
				notice( i18n.error || 'خطا', false );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'click', '#wcma-bc-test', function () {
			var $btn = $( this );
			var chat = trim( $( '#wcma-bc-chat' ).val() );
			var message = $( '#wcma-bc-message' ).val();

			if ( ! message ) {
				notice( 'اول یک پیام آماده انتخاب کنید.', false );
				return;
			}

			if ( ! chat ) {
				notice( 'شناسه‌ی چت را وارد کنید.', false );
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_bot_message_test', { chat: chat, message: message } ).done( function ( response ) {
				var ok = response && response.success;
				var msg = ok ? response.data.message : failure( response );

				notice( msg, ok );
				toast( msg, ok ? 'success' : 'error' );
			} ).fail( function () {
				notice( i18n.error || 'خطا', false );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'click', '.wcma-bc-cancel', function () {
			var $btn = $( this );

			if ( ! window.confirm( 'این ارسال لغو شود؟ پیام‌هایی که رفته‌اند برنمی‌گردند.' ) ) {
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_bot_broadcast_cancel', { id: $btn.attr( 'data-id' ) } ).done( function ( response ) {
				var ok = response && response.success;

				toast( ok ? response.data.message : failure( response ), ok ? 'success' : 'error' );

				if ( ok ) {
					render( response.data.job );
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		// ارسالی که پیش از باز شدن برگه آغاز شده، همین‌جا ادامه پیدا می‌کند.
		var running = parseInt( $box.attr( 'data-running' ), 10 );

		if ( running ) {
			poll( running );
		}
	}

	/**
	 * مدیران ربات: افزودن، برداشتن، لینک دعوت و نمایش نام فایل انتخاب‌شده برای ورود.
	 */
	function initBotAdmins() {
		function add( data, $btn ) {
			if ( ! data.who && ! data.chat ) {
				toast( 'شماره‌ی موبایل یا شناسه‌ی چت را وارد کنید.', 'error' );
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_bot_admin_add', data ).done( function ( response ) {
				var ok = response && response.success;

				toast( ( response && response.data && response.data.message ) || i18n.error, ok ? 'success' : 'error' );

				// فرصت خواندنِ اینکه دسترسی به کدام حساب تلگرام رسید؛ جدول هم همان را نشان می‌دهد.
				if ( ok ) {
					setTimeout( function () {
						window.location.reload();
					}, 3000 );
				}
			} ).fail( function () {
				toast( i18n.error || 'خطا', 'error' );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		}

		$( document ).on( 'click', '#wcma-admin-add', function () {
			add( { who: trim( $( '#wcma-admin-who' ).val() ) }, $( this ) );
		} );

		$( document ).on( 'keydown', '#wcma-admin-who', function ( e ) {
			if ( 13 === e.which ) {
				e.preventDefault();
				$( '#wcma-admin-add' ).trigger( 'click' );
			}
		} );

		$( document ).on( 'click', '.wcma-make-admin', function () {
			if ( window.confirm( 'این مشترک مدیر ربات شود؟ از درون ربات به آمار، ارسال همگانی و جستجوی مشترکان دسترسی پیدا می‌کند.' ) ) {
				add( { chat: String( $( this ).attr( 'data-chat' ) ) }, $( this ) );
			}
		} );

		$( document ).on( 'click', '.wcma-admin-remove', function () {
			var $btn = $( this );

			if ( ! window.confirm( 'دسترسی مدیریت این حساب برداشته شود؟' ) ) {
				return;
			}

			$btn.prop( 'disabled', true );

			request( 'wcma_bot_admin_remove', { key: $btn.attr( 'data-key' ) } ).done( function ( response ) {
				var ok = response && response.success;

				toast( ( response && response.data && response.data.message ) || i18n.error, ok ? 'success' : 'error' );

				if ( ok ) {
					$btn.closest( 'tr' ).remove();
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		$( document ).on( 'click', '#wcma-admin-invite', function () {
			var $btn = $( this );
			var $box = $( '#wcma-admin-invite-result' );

			$btn.prop( 'disabled', true );

			request( 'wcma_bot_admin_invite', {} ).done( function ( response ) {
				if ( ! response || ! response.success ) {
					toast( i18n.error || 'خطا', 'error' );
					return;
				}

				var data = response.data;
				var value = data.link || data.command;
				var $input = $( '<input type="text" readonly dir="ltr" class="wcma-invite__value"/>' ).val( value );
				var $copy = $( '<button type="button" class="wcma-btn wcma-btn--secondary"><span class="dashicons dashicons-admin-page"></span> کپی</button>' );
				var hint = data.link
					? 'این لینک را برای همکارتان بفرستید. اعتبار تا ' + data.expires + '.'
					: 'همکارتان ربات را باز کند و این فرمان را بفرستد. اعتبار تا ' + data.expires + '.';

				$copy.on( 'click', function () {
					$input.trigger( 'select' );

					if ( navigator.clipboard ) {
						navigator.clipboard.writeText( value );
					} else {
						document.execCommand( 'copy' );
					}

					toast( 'کپی شد.', 'success' );
				} );

				$box.empty().append( $( '<div class="wcma-sim wcma-invite"/>' ).append( $input, $copy ) )
					.append( $( '<p class="wcma-field__desc"/>' ).text( hint ) )
					.prop( 'hidden', false );
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		// نام فایل انتخاب‌شده به‌جای متن راهنما.
		$( document ).on( 'change', '.wcma-import__file input[type="file"]', function () {
			var name = this.files && this.files[ 0 ] ? this.files[ 0 ].name : '';

			$( this ).closest( '.wcma-import__file' ).toggleClass( 'has-file', !! name )
				.find( '.wcma-import__file-text' ).text( name || 'فایل اکسل (xlsx) یا CSV را انتخاب کنید' );
		} );
	}

	$( function () {
		initPlaceholders();
		initGatewayFields();
		initAudienceFields();
		initSteps();
		initConfirmations();
		initTestSend();
		initConnectionTest();
		initRegisterHook();
		initStockDiagnostics();
		initVipRecalc();
		initAiGenerate();
		initAiProvider();
		initRunNow();
		initOrderActions();
		initAudiencePreview();
		initCrm();
		initJourneyEdit();
		initInstantFilters();
		initTasks();
		initStaffBot();
		initChat();
		initAutosave();
		initImageField();
		initBotTest();
		initBotDiag();
		initBotSpeed();
		initChatFiles();
		initSmtpTest();
		initSmsBalance();
		initSmsCredit();
		initLeadMagnet();
		initJourneyFilter();
		initDayButtons();
		initDays();
		initBotMessages();
		initBroadcast();
		initBotAdmins();

		// شمارنده‌ی پیامک.
		$( document ).on( 'input', '[data-sms-counter]', function () {
			updateSmsCounter( $( this ) );
		} );

		$( '[data-sms-counter]' ).each( function () {
			updateSmsCounter( $( this ) );
		} );

		// راه‌اندازی انتخابگرهای پیشرفته‌ی ووکامرس.
		if ( $.fn.selectWoo ) {
			$( '.wc-enhanced-select' ).selectWoo();
		}

		/*
		 * زیرفهرست «تنظیمات عمومی» آخرین گزینه‌ی ستون منوست و ستون هم چسبان
		 * است؛ پس اگر همان‌جا که هست باز شود، پایینش از صفحه بیرون می‌ماند و
		 * دست‌نیافتنی می‌شود. اینجا فقط اندازه گرفته و داخل صفحه کشیده می‌شود.
		 */
		/*
		 * فهرست تا لحظه‌ای پس از بیرون رفتن موس باز می‌ماند تا موس در مسیرش به
		 * زیربخش‌ها (که از روی گزینه‌های دیگر ستون رد می‌شود) به آن برسد.
		 */
		var flyoutTimer = null;

		$( document ).on( 'mouseenter', '.wcma-nav__row.has-flyout', function () {
			clearTimeout( flyoutTimer );
			$( '.wcma-nav__row.has-flyout.is-open' ).not( this ).removeClass( 'is-open' );
			$( this ).addClass( 'is-open' );
		} );

		$( document ).on( 'mouseleave', '.wcma-nav__row.has-flyout', function () {
			var row = this;

			clearTimeout( flyoutTimer );
			flyoutTimer = setTimeout( function () {
				$( row ).removeClass( 'is-open' );
			}, 650 );
		} );

		// روی صفحه‌ی لمسی، لمس پیکان فهرست را باز و بسته می‌کند و برگه را عوض نمی‌کند.
		$( document ).on( 'click', '.wcma-nav__row.has-flyout .wcma-nav__caret', function ( e ) {
			if ( window.innerWidth <= 960 ) {
				return;
			}

			e.preventDefault();
			e.stopPropagation();

			var $row = $( this ).closest( '.wcma-nav__row' );

			clearTimeout( flyoutTimer );
			$row.toggleClass( 'is-open' );
		} );

		$( document ).on( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				$( '.wcma-nav__row.has-flyout.is-open' ).removeClass( 'is-open' );
			}
		} );

		/*
		 * ستون منو از بلندای صفحه بلندتر است و خودش اسکرول می‌خورد؛ زیرفهرست با
		 * موقعیت ثابت (fixed) کنار گزینه گذاشته می‌شود تا اسکرولِ ستون آن را نبرد.
		 */
		function placeFlyout( rowEl ) {
			var fly = rowEl.querySelector( '.wcma-flyout' );

			if ( ! fly ) {
				return;
			}

			if ( window.innerWidth <= 960 ) {
				fly.classList.remove( 'is-fixed' );
				fly.style.top  = '';
				fly.style.left = '';

				return;
			}

			fly.classList.add( 'is-fixed' );
			fly.style.maxHeight = '';
			fly.style.overflowY = '';

			var row    = rowEl.getBoundingClientRect();
			var gap    = 12;
			var height = fly.offsetHeight;
			var room   = window.innerHeight - gap * 2;
			var top    = row.top - 8;

			if ( height > room ) {
				fly.style.maxHeight = room + 'px';
				fly.style.overflowY = 'auto';
				height = room;
			}

			if ( top + height > window.innerHeight - gap ) {
				top = window.innerHeight - gap - height;
			}

			top = Math.max( gap, top );

			var width = fly.offsetWidth;
			var rtl   = 'rtl' === window.getComputedStyle( rowEl ).direction;

			fly.style.top   = top + 'px';
			fly.style.left  = ( rtl ? row.left - 8 - width : row.right + 8 ) + 'px';
			fly.style.right = 'auto';

			/*
			 * پلِ نامرئی میان گزینه و فهرست باید تا پایینِ خودِ گزینه برسد؛ وقتی
			 * فهرست بلند است و به بالا کشیده می‌شود، دیگر هم‌تراز گزینه نیست.
			 */
			fly.style.setProperty(
				'--wcma-bridge',
				Math.max( height, row.bottom - top ) + 'px'
			);
		}

		$( document ).on( 'mouseenter focusin', '.wcma-nav__row.has-flyout', function () {
			placeFlyout( this );
		} );

		// اسکرول صفحه یا خودِ ستون منو، فهرستِ باز را همراه گزینه‌اش جابه‌جا می‌کند.
		function followFlyout() {
			$( '.wcma-nav__row.has-flyout' ).each( function () {
				if ( this.classList.contains( 'is-open' ) || this.matches( ':hover' ) ) {
					placeFlyout( this );
				}
			} );
		}

		window.addEventListener( 'scroll', followFlyout, { passive: true } );
		window.addEventListener( 'resize', followFlyout );

		$( '.wcma-nav' ).each( function () {
			this.addEventListener( 'scroll', followFlyout, { passive: true } );
		} );
	} );

} )( jQuery );
