/**
 * ارسال فرم لید مگنت بدون بارگذاری دوباره‌ی صفحه.
 */
( function () {
	'use strict';

	var cfg = window.wcmaLead;

	if ( ! cfg || ! cfg.url ) {
		return;
	}

	/**
	 * ارقام فارسی و عربی به لاتین، تا شماره درست به سرور برسد.
	 *
	 * @param {string} value ورودی.
	 * @return {string} خروجی.
	 */
	function latin( value ) {
		return String( value || '' )
			.replace( /[۰-۹]/g, function ( d ) { return String( '۰۱۲۳۴۵۶۷۸۹'.indexOf( d ) ); } )
			.replace( /[٠-٩]/g, function ( d ) { return String( '٠١٢٣٤٥٦٧٨٩'.indexOf( d ) ); } );
	}

	function note( box, text, ok ) {
		box.textContent = text;
		box.className = 'wcma-lead__note is-shown ' + ( ok ? 'is-ok' : 'is-bad' );
	}

	function bind( wrap ) {
		var form = wrap.querySelector( '.wcma-lead__form' );

		if ( ! form || form.dataset.wcmaBound ) {
			return;
		}

		form.dataset.wcmaBound = '1';

		var button = form.querySelector( '.wcma-lead__submit' );
		var box = form.querySelector( '.wcma-lead__note' );
		var label = button ? button.textContent : '';

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			var phoneField = form.querySelector( '[name="phone"]' );
			var phone = latin( phoneField ? phoneField.value : '' ).replace( /[^0-9+]/g, '' );

			if ( phone.length < 10 ) {
				note( box, 'شماره موبایل را کامل وارد کنید.', false );

				if ( phoneField ) {
					phoneField.focus();
				}

				return;
			}

			var nameField = form.querySelector( '[name="name"]' );
			var emailField = form.querySelector( '[name="email"]' );
			var trap = form.querySelector( '[name="website"]' );

			button.disabled = true;
			button.textContent = 'در حال ثبت...';
			box.className = 'wcma-lead__note';

			var payload = {
				phone: phone,
				name: nameField ? nameField.value : '',
				email: emailField ? emailField.value : '',
				website: trap ? trap.value : '',
				page: window.location.href
			};

			fetch( cfg.url, {
				method: 'POST',
				// مسیر عمومی است؛ بدون کوکی می‌رود تا نانسِ کهنه‌ی صفحات کش‌شده مانعش نشود.
				credentials: 'omit',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( payload )
			} ).then( function ( response ) {
				return response.json();
			} ).then( function ( data ) {
				if ( data && data.ok ) {
					note( box, data.message || 'ثبت شد!', true );
					wrap.classList.add( 'is-done' );

					if ( data.link ) {
						var a = document.createElement( 'a' );
						a.href = data.link;
						a.textContent = 'دریافت فایل';
						a.target = '_blank';
						a.rel = 'noopener';
						box.appendChild( document.createElement( 'br' ) );
						box.appendChild( a );
					}

					return;
				}

				note( box, ( data && data.message ) || 'ثبت نشد؛ دوباره تلاش کنید.', false );
			} ).catch( function () {
				note( box, 'ارتباط برقرار نشد؛ دوباره تلاش کنید.', false );
			} ).then( function () {
				button.disabled = false;
				button.textContent = label;
			} );
		} );
	}

	function boot() {
		var list = document.querySelectorAll( '.wcma-lead' );

		for ( var i = 0; i < list.length; i++ ) {
			bind( list[ i ] );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}() );
