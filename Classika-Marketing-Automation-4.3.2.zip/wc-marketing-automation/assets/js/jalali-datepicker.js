/**
 * تقویم شمسی برای فیلدهای تاریخ افزونه.
 *
 * فیلد اصلی (با نام و مقدار میلادی Y-m-d) دست‌نخورده می‌ماند و فقط پنهان می‌شود،
 * پس آنچه به سرور می‌رود همان قالب استاندارد است و هیچ کوئری‌ای تغییر نمی‌کند.
 */
( function () {
	'use strict';

	var config = window.wcmaDatePicker || {};

	if ( ! config.months ) {
		return;
	}

	var FA = [ '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ];

	function toFa( text ) {
		if ( 'fa' !== config.digits ) {
			return String( text );
		}

		return String( text ).replace( /[0-9]/g, function ( d ) {
			return FA[ d ];
		} );
	}

	function toEn( text ) {
		return String( text )
			.replace( /[۰-۹]/g, function ( d ) {
				return String( FA.indexOf( d ) );
			} )
			.replace( /[٠-٩]/g, function ( d ) {
				return String( d.charCodeAt( 0 ) - 1632 );
			} );
	}

	function div( a, b ) {
		return Math.floor( a / b );
	}

	/**
	 * میلادی → شمسی (همان الگوریتم سمت سرور).
	 */
	function toJalali( gy, gm, gd ) {
		var acc = [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ];
		var gy2 = gm > 2 ? gy + 1 : gy;

		var days = 355666 + ( 365 * gy ) + div( gy2 + 3, 4 ) - div( gy2 + 99, 100 ) +
			div( gy2 + 399, 400 ) + gd + acc[ gm - 1 ];

		var jy = -1595 + ( 33 * div( days, 12053 ) );

		days %= 12053;
		jy += 4 * div( days, 1461 );
		days %= 1461;

		if ( days > 365 ) {
			jy += div( days - 1, 365 );
			days = ( days - 1 ) % 365;
		}

		if ( days < 186 ) {
			return { jy: jy, jm: 1 + div( days, 31 ), jd: 1 + ( days % 31 ) };
		}

		return { jy: jy, jm: 7 + div( days - 186, 30 ), jd: 1 + ( ( days - 186 ) % 30 ) };
	}

	/**
	 * شمسی → میلادی.
	 */
	function toGregorian( jy, jm, jd ) {
		jy += 1595;

		var days = -355668 + ( 365 * jy ) + ( div( jy, 33 ) * 8 ) + div( ( jy % 33 ) + 3, 4 ) +
			jd + ( jm < 7 ? ( jm - 1 ) * 31 : ( ( jm - 7 ) * 30 ) + 186 );

		var gy = 400 * div( days, 146097 );

		days %= 146097;

		if ( days > 36524 ) {
			days--;
			gy += 100 * div( days, 36524 );
			days %= 36524;

			if ( days >= 365 ) {
				days++;
			}
		}

		gy += 4 * div( days, 1461 );
		days %= 1461;

		if ( days > 365 ) {
			gy += div( days - 1, 365 );
			days = ( days - 1 ) % 365;
		}

		var gd = days + 1;
		var leap = ( 0 === gy % 4 && 0 !== gy % 100 ) || 0 === gy % 400;
		var lengths = [ 0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
		var gm = 0;

		for ( gm = 0; gm < 13 && gd > lengths[ gm ]; gm++ ) {
			gd -= lengths[ gm ];
		}

		return { gy: gy, gm: gm, gd: gd };
	}

	function monthDays( jy, jm ) {
		if ( jm <= 6 ) {
			return 31;
		}

		if ( jm <= 11 ) {
			return 30;
		}

		var g = toGregorian( jy, 12, 30 );

		return toJalali( g.gy, g.gm, g.gd ).jy === jy ? 30 : 29;
	}

	/**
	 * شماره‌ی روز هفته‌ی یک تاریخ شمسی، از شنبه = ۰.
	 */
	function weekIndex( jy, jm, jd ) {
		var g = toGregorian( jy, jm, jd );
		var w = new Date( Date.UTC( g.gy, g.gm - 1, g.gd ) ).getUTCDay();

		return ( w + 1 ) % 7;
	}

	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}

	/**
	 * تجزیه‌ی مقدار میلادی فیلد اصلی.
	 */
	function readValue( input ) {
		var raw = ( input.value || '' ).replace( 'T', ' ' ).trim();
		var m = raw.match( /^(\d{4})-(\d{1,2})-(\d{1,2})/ );

		if ( ! m ) {
			return null;
		}

		var t = raw.match( /(\d{1,2}):(\d{2})/ );

		return {
			gy: parseInt( m[ 1 ], 10 ),
			gm: parseInt( m[ 2 ], 10 ),
			gd: parseInt( m[ 3 ], 10 ),
			hh: t ? parseInt( t[ 1 ], 10 ) : 0,
			mi: t ? parseInt( t[ 2 ], 10 ) : 0
		};
	}

	/**
	 * نوشتن مقدار در فیلد اصلی، همیشه به قالب میلادی استاندارد.
	 */
	function writeValue( input, gy, gm, gd, hh, mi, withTime ) {
		var value = gy + '-' + pad( gm ) + '-' + pad( gd );

		if ( withTime ) {
			value += 'T' + pad( hh || 0 ) + ':' + pad( mi || 0 );
		}

		input.value = value;
		input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
	}

	function display( parts, withTime ) {
		if ( ! parts ) {
			return '';
		}

		var y = parts.gy;
		var m = parts.gm;
		var d = parts.gd;

		if ( config.jalali ) {
			var j = toJalali( y, m, d );
			y = j.jy;
			m = j.jm;
			d = j.jd;
		}

		var out = y + '/' + pad( m ) + '/' + pad( d );

		if ( withTime ) {
			out += ' ' + pad( parts.hh ) + ':' + pad( parts.mi );
		}

		return toFa( out );
	}

	/**
	 * تجزیه‌ی آنچه کاربر تایپ کرده است.
	 */
	function parseTyped( text, withTime ) {
		var value = toEn( text ).replace( /[T،]/g, ' ' ).trim();

		if ( ! value ) {
			return null;
		}

		var hh = 0;
		var mi = 0;
		var t = value.match( /(\d{1,2}):(\d{2})/ );

		if ( t ) {
			hh = Math.min( 23, parseInt( t[ 1 ], 10 ) );
			mi = Math.min( 59, parseInt( t[ 2 ], 10 ) );
			value = value.replace( t[ 0 ], '' );
		}

		var m = value.match( /(\d{4})\s*[\/\-.]\s*(\d{1,2})\s*[\/\-.]\s*(\d{1,2})/ );

		if ( ! m ) {
			return null;
		}

		var y = parseInt( m[ 1 ], 10 );
		var mo = parseInt( m[ 2 ], 10 );
		var d = parseInt( m[ 3 ], 10 );

		if ( mo < 1 || mo > 12 || d < 1 ) {
			return null;
		}

		if ( y < 1700 ) {
			if ( d > monthDays( y, mo ) ) {
				return null;
			}

			var g = toGregorian( y, mo, d );

			return { gy: g.gy, gm: g.gm, gd: g.gd, hh: hh, mi: mi };
		}

		if ( d > 31 ) {
			return null;
		}

		return { gy: y, gm: mo, gd: d, hh: hh, mi: mi };
	}

	function el( tag, className, text ) {
		var node = document.createElement( tag );

		if ( className ) {
			node.className = className;
		}

		if ( undefined !== text ) {
			node.textContent = text;
		}

		return node;
	}

	/**
	 * ساخت تقویم برای یک فیلد.
	 */
	function build( input ) {
		if ( input.getAttribute( 'data-wcma-jalali-ready' ) ) {
			return;
		}

		input.setAttribute( 'data-wcma-jalali-ready', '1' );

		var withTime = 'datetime-local' === input.getAttribute( 'type' );

		input.setAttribute( 'data-wcma-type', withTime ? 'datetime-local' : 'date' );

		// فیلد اصلی فقط پنهان می‌شود تا نام و مقدارش دست‌نخورده به سرور برود.
		input.type = 'hidden';

		var wrap = el( 'div', 'wcma-jdate' );
		var view = el( 'input', 'wcma-jdate__view ' + ( input.className || '' ) );

		view.type = 'text';
		view.dir = 'ltr';
		view.autocomplete = 'off';
		view.placeholder = withTime ? ( config.jalali ? '۱۴۰۵/۰۶/۱۸ ۰۹:۰۰' : '2026/09/09 09:00' ) : ( config.jalali ? '۱۴۰۵/۰۶/۱۸' : '2026/09/09' );

		if ( input.getAttribute( 'title' ) ) {
			view.title = input.getAttribute( 'title' );
		}

		if ( input.id ) {
			view.id = input.id + '_view';

			var label = document.querySelector( 'label[for="' + input.id + '"]' );

			if ( label ) {
				label.setAttribute( 'for', view.id );
			}
		}

		input.parentNode.insertBefore( wrap, input );
		wrap.appendChild( input );
		wrap.appendChild( view );

		var pop = el( 'div', 'wcma-jdate__pop' );

		wrap.appendChild( pop );

		var state = null;
		var cursor = null;

		function sync() {
			state = readValue( input );
			view.value = display( state, withTime );
		}

		/**
		 * یک فهرست کشویی از ۰ تا count-۱، با رقم فارسی.
		 *
		 * مقدار هر گزینه لاتین می‌ماند تا محاسبه‌ها ساده بماند؛ فقط آنچه
		 * کاربر می‌بیند فارسی است.
		 *
		 * @param {number} count  تعداد.
		 * @param {number} chosen مقدار انتخاب‌شده.
		 * @return {HTMLSelectElement} فهرست.
		 */
		function numbers( count, chosen ) {
			var select = el( 'select', 'wcma-jdate__clock' );
			var i;

			for ( i = 0; i < count; i++ ) {
				var option = document.createElement( 'option' );

				option.value = String( i );
				option.textContent = toFa( pad( i ) );

				if ( i === chosen ) {
					option.selected = true;
				}

				select.appendChild( option );
			}

			return select;
		}

		function currentJalali() {
			var parts = state || parseTyped( config.now, false ) || { gy: 2026, gm: 1, gd: 1 };

			return config.jalali
				? toJalali( parts.gy, parts.gm, parts.gd )
				: { jy: parts.gy, jm: parts.gm, jd: parts.gd };
		}

		function render() {
			pop.innerHTML = '';

			var head = el( 'div', 'wcma-jdate__head' );
			var prev = el( 'button', 'wcma-jdate__nav', '‹' );
			var next = el( 'button', 'wcma-jdate__nav', '›' );

			prev.type = 'button';
			next.type = 'button';

			var name = config.jalali ? config.months[ cursor.jm - 1 ] : config.gregorianMonths[ cursor.jm - 1 ];
			var title = el( 'span', 'wcma-jdate__title', name + ' ' + toFa( cursor.jy ) );

			// در چیدمان راست‌به‌چپ، دکمه‌ی ماه قبل سمت راست است.
			head.appendChild( next );
			head.appendChild( title );
			head.appendChild( prev );
			pop.appendChild( head );

			prev.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				e.stopPropagation();

				cursor.jm--;

				if ( cursor.jm < 1 ) {
					cursor.jm = 12;
					cursor.jy--;
				}

				render();
				place();
			} );

			next.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				e.stopPropagation();

				cursor.jm++;

				if ( cursor.jm > 12 ) {
					cursor.jm = 1;
					cursor.jy++;
				}

				render();
				place();
			} );

			var grid = el( 'div', 'wcma-jdate__grid' );

			config.days.forEach( function ( d ) {
				grid.appendChild( el( 'span', 'wcma-jdate__dow', d ) );
			} );

			var total = config.jalali
				? monthDays( cursor.jy, cursor.jm )
				: new Date( Date.UTC( cursor.jy, cursor.jm, 0 ) ).getUTCDate();

			var first = config.jalali
				? weekIndex( cursor.jy, cursor.jm, 1 )
				: ( new Date( Date.UTC( cursor.jy, cursor.jm - 1, 1 ) ).getUTCDay() + 1 ) % 7;

			var i = 0;

			for ( i = 0; i < first; i++ ) {
				grid.appendChild( el( 'span', 'wcma-jdate__pad', '' ) );
			}

			var selected = state
				? ( config.jalali ? toJalali( state.gy, state.gm, state.gd ) : { jy: state.gy, jm: state.gm, jd: state.gd } )
				: null;

			var todayParts = parseTyped( config.now, false );
			var today = todayParts
				? ( config.jalali ? toJalali( todayParts.gy, todayParts.gm, todayParts.gd ) : { jy: todayParts.gy, jm: todayParts.gm, jd: todayParts.gd } )
				: null;

			for ( i = 1; i <= total; i++ ) {
				( function ( day ) {
					var cell = el( 'button', 'wcma-jdate__day', toFa( day ) );

					cell.type = 'button';

					if ( selected && selected.jy === cursor.jy && selected.jm === cursor.jm && selected.jd === day ) {
						cell.className += ' is-selected';
					}

					if ( today && today.jy === cursor.jy && today.jm === cursor.jm && today.jd === day ) {
						cell.className += ' is-today';
					}

					cell.addEventListener( 'click', function () {
						var g = config.jalali
							? toGregorian( cursor.jy, cursor.jm, day )
							: { gy: cursor.jy, gm: cursor.jm, gd: day };

						writeValue( input, g.gy, g.gm, g.gd, state ? state.hh : 0, state ? state.mi : 0, withTime );
						sync();

						if ( ! withTime ) {
							close();
						} else {
							render();
						}
					} );

					grid.appendChild( cell );
				}( i ) );
			}

			pop.appendChild( grid );

			if ( withTime ) {
				/*
				 * کنترل ساعتِ خود مرورگر به زبان سیستم کاربر است: روی بیشتر
				 * دستگاه‌ها AM/PM و رقم لاتین نشان می‌دهد، که در یک پیشخوان
				 * فارسیِ ۲۴ساعته بی‌جاست. پس دو فهرست ساده جایش می‌نشیند.
				 */
				var timeRow = el( 'div', 'wcma-jdate__time' );
				var clock = el( 'div', 'wcma-jdate__clockrow' );
				var hourSel = numbers( 24, state ? state.hh : 9 );
				var minSel = numbers( 60, state ? state.mi : 0 );

				function pushTime() {
					if ( ! state ) {
						return;
					}

					writeValue(
						input,
						state.gy,
						state.gm,
						state.gd,
						parseInt( hourSel.value, 10 ) || 0,
						parseInt( minSel.value, 10 ) || 0,
						true
					);
					sync();
				}

				hourSel.addEventListener( 'change', pushTime );
				minSel.addEventListener( 'change', pushTime );

				hourSel.title = 'ساعت';
				minSel.title = 'دقیقه';

				// ساعت سمت چپ و دقیقه سمت راست، همان‌طور که ۰۹:۳۰ خوانده می‌شود.
				clock.appendChild( hourSel );
				clock.appendChild( el( 'span', 'wcma-jdate__colon', ':' ) );
				clock.appendChild( minSel );

				timeRow.appendChild( el( 'span', '', 'ساعت' ) );
				timeRow.appendChild( clock );
				pop.appendChild( timeRow );
			}

			var foot = el( 'div', 'wcma-jdate__foot' );
			var todayBtn = el( 'button', 'wcma-jdate__link', config.today );
			var clearBtn = el( 'button', 'wcma-jdate__link', config.clear );

			todayBtn.type = 'button';
			clearBtn.type = 'button';

			todayBtn.addEventListener( 'click', function () {
				var parts = parseTyped( config.now, false );

				if ( parts ) {
					writeValue( input, parts.gy, parts.gm, parts.gd, state ? state.hh : 0, state ? state.mi : 0, withTime );
					sync();
					cursor = currentJalali();
					render();
				}

				if ( ! withTime ) {
					close();
				}
			} );

			clearBtn.addEventListener( 'click', function () {
				input.value = '';
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				sync();
				close();
			} );

			foot.appendChild( todayBtn );
			foot.appendChild( clearBtn );
			pop.appendChild( foot );
		}

		/**
		 * جای‌گذاری تقویم نسبت به پنجره‌ی مرورگر.
		 *
		 * کارت‌های پیشخوان overflow پنهان دارند، پس تقویم نمی‌تواند فرزندِ جاری بماند و
		 * باید مختصاتش را خودمان حساب کنیم؛ اگر پایین صفحه جا نبود، بالای فیلد باز می‌شود.
		 */
		function place() {
			var box = view.getBoundingClientRect();
			var height = pop.offsetHeight || 300;
			var width = pop.offsetWidth || 258;
			var gap = 6;

			var top = box.bottom + gap;

			if ( top + height > window.innerHeight - 8 && box.top - height - gap > 8 ) {
				top = box.top - height - gap;
			}

			top = Math.max( 8, Math.min( top, window.innerHeight - height - 8 ) );

			// لبه‌ی راست تقویم با لبه‌ی راست فیلد یکی می‌شود (چیدمان راست‌به‌چپ).
			var left = box.right - width;

			left = Math.max( 8, Math.min( left, window.innerWidth - width - 8 ) );

			pop.style.top = Math.round( top ) + 'px';
			pop.style.left = Math.round( left ) + 'px';
		}

		function open() {
			cursor = currentJalali();
			render();
			wrap.className = 'wcma-jdate is-open';
			place();
		}

		function close() {
			wrap.className = 'wcma-jdate';
		}

		view.addEventListener( 'focus', open );
		view.addEventListener( 'click', open );

		window.addEventListener( 'scroll', function () {
			if ( wrap.classList.contains( 'is-open' ) ) {
				place();
			}
		}, true );

		window.addEventListener( 'resize', function () {
			if ( wrap.classList.contains( 'is-open' ) ) {
				place();
			}
		} );

		// تایپ دستی هم پذیرفته می‌شود.
		view.addEventListener( 'change', function () {
			var parts = parseTyped( view.value, withTime );

			if ( ! view.value.trim() ) {
				input.value = '';
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				sync();
				return;
			}

			if ( parts ) {
				writeValue( input, parts.gy, parts.gm, parts.gd, parts.hh, parts.mi, withTime );
			}

			sync();
		} );

		view.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				close();
			}

			if ( 'Enter' === e.key ) {
				view.blur();
				close();
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			/*
			 * دکمه‌ی ماه قبل/بعد خودش تقویم را از نو می‌سازد، پس تا این خط
			 * برسد همان دکمه‌ای که کلیک شده از صفحه برداشته شده و
			 * wrap.contains دیگر «نه» می‌گوید — نتیجه‌اش این بود که تقویم
			 * درست پس از کلیک بسته می‌شد و به چشم کاربر «کار نمی‌کند».
			 * مسیر رویداد هنگام ارسال ساخته می‌شود و با جابه‌جایی گره‌ها
			 * عوض نمی‌شود، پس همان را می‌پرسیم.
			 */
			var path = e.composedPath ? e.composedPath() : null;
			var inside = path ? path.indexOf( wrap ) !== -1 : wrap.contains( e.target );

			if ( ! inside ) {
				close();
			}
		} );

		sync();
	}

	function scan() {
		var nodes = document.querySelectorAll( '[data-wcma-jalali]' );
		var i = 0;

		for ( i = 0; i < nodes.length; i++ ) {
			build( nodes[ i ] );
		}
	}

	/**
	 * قالب‌بندی یک تاریخ خام میلادی بر اساس تنظیم جاری.
	 */
	function formatRaw( raw, type ) {
		var parts = parseTyped( raw, true );

		if ( ! parts ) {
			return '';
		}

		var y = parts.gy;
		var m = parts.gm;
		var d = parts.gd;
		var monthName = config.gregorianMonths[ m - 1 ];

		if ( config.jalali ) {
			var j = toJalali( y, m, d );
			y = j.jy;
			m = j.jm;
			d = j.jd;
			monthName = config.months[ m - 1 ];
		}

		var dayName = config.weekdays[ weekIndex( parts.gy, parts.gm, parts.gd ) ];

		if ( ! config.jalali ) {
			var w = new Date( Date.UTC( parts.gy, parts.gm - 1, parts.gd ) ).getUTCDay();
			dayName = config.weekdays[ ( w + 1 ) % 7 ];
		}

		var date = y + '/' + pad( m ) + '/' + pad( d );
		var time = pad( parts.hh ) + ':' + pad( parts.mi );
		var out;

		switch ( type ) {
			case 'date':
				out = date;
				break;
			case 'date_long':
				out = d + ' ' + monthName + ' ' + y;
				break;
			case 'time':
				out = time;
				break;
			case 'day':
				out = dayName;
				break;
			case 'month':
				out = monthName;
				break;
			case 'datetime_long':
				out = dayName + ' ' + d + ' ' + monthName + ' ' + y + '، ساعت ' + time;
				break;
			default:
				out = date + ' ساعت ' + time;
		}

		return toFa( out );
	}

	/**
	 * به‌روزرسانی همه‌ی تاریخ‌ها و اعدادِ صفحه، بی‌درنگ و بدون بارگذاری دوباره.
	 */
	function refreshAll() {
		var dates = document.querySelectorAll( '[data-wcma-date]' );
		var i = 0;

		for ( i = 0; i < dates.length; i++ ) {
			var text = formatRaw( dates[ i ].getAttribute( 'data-wcma-date' ), dates[ i ].getAttribute( 'data-wcma-format' ) || 'datetime' );

			if ( text ) {
				dates[ i ].textContent = text;
			}
		}

		var numbers = document.querySelectorAll( '[data-wcma-number]' );

		for ( i = 0; i < numbers.length; i++ ) {
			var raw = parseFloat( toEn( numbers[ i ].getAttribute( 'data-wcma-number' ) ) );
			var decimals = parseInt( numbers[ i ].getAttribute( 'data-wcma-decimals' ), 10 ) || 0;

			if ( ! isNaN( raw ) ) {
				numbers[ i ].textContent = toFa(
					raw.toFixed( decimals ).replace( /\B(?=(\d{3})+(?!\d))/g, ',' )
				).replace( /,/g, 'fa' === config.digits ? '٬' : ',' );
			}
		}

		// فیلدهای تاریخ هم باید با تقویم تازه دوباره نوشته شوند.
		var views = document.querySelectorAll( '[data-wcma-jalali-ready]' );

		for ( i = 0; i < views.length; i++ ) {
			var wrap = views[ i ].parentNode;
			var view = wrap && wrap.querySelector( '.wcma-jdate__view' );

			if ( view ) {
				var parts = readValue( views[ i ] );
				view.value = display( parts, 'datetime-local' === views[ i ].getAttribute( 'data-wcma-type' ) );
			}
		}
	}

	/**
	 * تغییر تنظیم تقویم/ارقام: بی‌درنگ اعمال می‌شود و در پس‌زمینه ذخیره می‌گردد.
	 */
	function initLiveSettings() {
		var calendar = document.getElementById( 'date_calendar' );
		var digits = document.getElementById( 'date_digits' );

		if ( ! calendar && ! digits ) {
			return;
		}

		function apply( key, value ) {
			if ( 'date_calendar' === key ) {
				config.jalali = 'gregorian' !== value;
			} else {
				config.digits = value;
			}

			refreshAll();

			var state = document.querySelector( '.wcma-date-live__state' );

			if ( ! window.wcmaAdmin || ! window.wcmaAdmin.ajaxUrl ) {
				return;
			}

			if ( state ) {
				state.textContent = ' — در حال ذخیره...';
			}

			var body = 'action=wcma_save_display&nonce=' + encodeURIComponent( window.wcmaAdmin.nonce ) +
				'&' + encodeURIComponent( key ) + '=' + encodeURIComponent( value );

			var xhr = new XMLHttpRequest();

			xhr.open( 'POST', window.wcmaAdmin.ajaxUrl, true );
			xhr.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );

			xhr.onload = function () {
				var ok = false;

				try {
					ok = JSON.parse( xhr.responseText ).success;
				} catch ( err ) {
					ok = false;
				}

				if ( state ) {
					state.textContent = ok ? ' — ذخیره شد ✓' : ' — ذخیره نشد؛ دکمه‌ی ذخیره را بزنید.';
				}
			};

			xhr.onerror = function () {
				if ( state ) {
					state.textContent = ' — ذخیره نشد؛ دکمه‌ی ذخیره را بزنید.';
				}
			};

			xhr.send( body );
		}

		if ( calendar ) {
			calendar.addEventListener( 'change', function () {
				apply( 'date_calendar', calendar.value );
			} );
		}

		if ( digits ) {
			digits.addEventListener( 'change', function () {
				apply( 'date_digits', digits.value );
			} );
		}
	}

	window.wcmaRefreshDates = refreshAll;

	function boot() {
		scan();
		initLiveSettings();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}

	// فرم‌هایی که با ایجکس دوباره ساخته می‌شوند (مثل صفحه‌ی پرداخت ووکامرس).
	document.addEventListener( 'updated_checkout', scan );
	document.body && document.body.addEventListener( 'wcma:rescan', scan );
}() );
