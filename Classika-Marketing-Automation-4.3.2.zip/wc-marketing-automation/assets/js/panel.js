/**
 * پنل کاربری: ورود با کد پیامکی و چند کمکِ کوچک در فرم‌ها.
 */

( function () {
	'use strict';

	var cfg = window.wcmaPanel || {};

	/**
	 * رقم‌های فارسی و عربی به لاتین.
	 *
	 * صفحه‌کلید فارسی گوشی، رقم فارسی می‌دهد و سرور رقم لاتین می‌خواهد؛
	 * بدون این، شماره و کدِ درست هم رد می‌شد.
	 *
	 * @param {string} text ورودی.
	 * @return {string} خروجی.
	 */
	function latin( text ) {
		return String( text || '' )
			.replace( /[۰-۹]/g, function ( d ) {
				return String( '۰۱۲۳۴۵۶۷۸۹'.indexOf( d ) );
			} )
			.replace( /[٠-٩]/g, function ( d ) {
				return String( '٠١٢٣٤٥٦٧٨٩'.indexOf( d ) );
			} );
	}

	/**
	 * جداکننده‌ی هزارگان، برای فیلد مبلغ.
	 *
	 * @param {string} value مقدار.
	 * @return {string} خروجی.
	 */
	function grouped( value ) {
		var digits = latin( value ).replace( /\D/g, '' );

		return digits.replace( /\B(?=(\d{3})+(?!\d))/g, ',' );
	}

	/* ---------------------------------------------------------------- */
	/* ورود با کد                                                        */
	/* ---------------------------------------------------------------- */

	function initAuth() {
		var form = document.getElementById( 'wcma-auth' );

		if ( ! form || ! cfg.root ) {
			return;
		}

		var steps = {
			phone: form.querySelector( '[data-step="phone"]' ),
			code: form.querySelector( '[data-step="code"]' )
		};

		var phone = document.getElementById( 'wcma-phone' );
		var code = document.getElementById( 'wcma-code' );
		var first = document.getElementById( 'wcma-first' );
		var last = document.getElementById( 'wcma-last' );
		var newbie = document.getElementById( 'wcma-newbie' );
		var error = document.getElementById( 'wcma-error' );
		var sendBtn = document.getElementById( 'wcma-send' );
		var verifyBtn = document.getElementById( 'wcma-verify' );
		var againBtn = document.getElementById( 'wcma-again' );
		var timerBox = document.getElementById( 'wcma-timer' );
		var backBtn = document.getElementById( 'wcma-back' );
		var target = document.getElementById( 'wcma-to' );

		var ticking = null;
		var otpAbort = null;

		function say( message ) {
			error.textContent = message || '';
			error.hidden = ! message;
		}

		function show( which ) {
			steps.phone.hidden = 'phone' !== which;
			steps.code.hidden = 'code' !== which;
			say( '' );
		}

		function post( path, body ) {
			return fetch( cfg.root + '/auth/' + path, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': cfg.nonce || ''
				},
				credentials: 'same-origin',
				body: JSON.stringify( body )
			} ).then( function ( response ) {
				return response.json();
			} );
		}

		function countdown( seconds ) {
			clearInterval( ticking );

			var left = seconds | 0;

			function paint() {
				if ( left <= 0 ) {
					clearInterval( ticking );
					againBtn.disabled = false;
					timerBox.textContent = '';
					return;
				}

				againBtn.disabled = true;
				timerBox.textContent = 'تا ' + left + ' ثانیه دیگر';
				left--;
			}

			paint();
			ticking = setInterval( paint, 1000 );
		}

		/**
		 * گرفتن خودکار کد از پیامک، روی اندروید.
		 *
		 * iOS خودش با autocomplete="one-time-code" کد را پیشنهاد می‌دهد؛
		 * کروم اندروید به این API نیاز دارد و فقط وقتی کار می‌کند که پیامک
		 * با «@دامنه #کد» تمام شده باشد — همان کاری که سرور می‌کند.
		 */
		function watchSms() {
			if ( ! ( 'OTPCredential' in window ) || ! navigator.credentials ) {
				return;
			}

			try {
				otpAbort = new AbortController();

				navigator.credentials.get( {
					otp: { transport: [ 'sms' ] },
					signal: otpAbort.signal
				} ).then( function ( credential ) {
					if ( credential && credential.code ) {
						code.value = credential.code;
						form.requestSubmit ? form.requestSubmit() : verify();
					}
				} ).catch( function () {
					// کاربر اجازه نداد یا پیامکی نیامد؛ تایپ دستی همچنان هست.
				} );
			} catch ( e ) {
				otpAbort = null;
			}
		}

		function stopWatching() {
			if ( otpAbort ) {
				otpAbort.abort();
				otpAbort = null;
			}
		}

		function ask() {
			var number = latin( phone.value ).replace( /\D/g, '' );

			if ( number.length < 10 ) {
				say( 'شماره موبایل را کامل وارد کنید.' );
				phone.focus();
				return;
			}

			sendBtn.disabled = true;
			say( '' );

			post( 'code', { phone: number } ).then( function ( data ) {
				sendBtn.disabled = false;

				if ( ! data || ! data.ok ) {
					say( ( data && data.message ) || 'ارسال کد انجام نشد.' );
					return;
				}

				target.textContent = number;
				newbie.hidden = !! data.known;

				show( 'code' );
				countdown( data.wait || 60 );
				watchSms();
				code.focus();
			} ).catch( function () {
				sendBtn.disabled = false;
				say( 'ارتباط با سرور برقرار نشد.' );
			} );
		}

		function verify() {
			var value = latin( code.value ).replace( /\D/g, '' );

			if ( value.length < 4 ) {
				say( 'کد را کامل وارد کنید.' );
				code.focus();
				return;
			}

			if ( ! newbie.hidden && ! first.value.trim() ) {
				say( 'برای ثبت‌نام، نام خود را وارد کنید.' );
				first.focus();
				return;
			}

			verifyBtn.disabled = true;
			say( '' );

			post( 'verify', {
				phone: latin( phone.value ).replace( /\D/g, '' ),
				code: value,
				first_name: first ? first.value : '',
				last_name: last ? last.value : ''
			} ).then( function ( data ) {
				if ( ! data || ! data.ok ) {
					verifyBtn.disabled = false;
					say( ( data && data.message ) || 'ورود انجام نشد.' );
					return;
				}

				stopWatching();
				window.location.href = data.url || cfg.panel || '/';
			} ).catch( function () {
				verifyBtn.disabled = false;
				say( 'ارتباط با سرور برقرار نشد.' );
			} );
		}

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();

			if ( steps.code.hidden ) {
				ask();
			} else {
				verify();
			}
		} );

		againBtn.addEventListener( 'click', function () {
			stopWatching();
			ask();
		} );

		backBtn.addEventListener( 'click', function () {
			stopWatching();
			clearInterval( ticking );
			code.value = '';
			show( 'phone' );
			phone.focus();
		} );

		// رقم فارسی همان لحظه‌ی تایپ لاتین می‌شود تا کاربر چیز عجیبی نبیند.
		[ phone, code ].forEach( function ( field ) {
			field.addEventListener( 'input', function () {
				var clean = latin( field.value ).replace( /\D/g, '' );

				if ( field.value !== clean ) {
					field.value = clean;
				}

				// پنج رقم که کامل شد، خودش می‌فرستد.
				if ( field === code && clean.length === 5 ) {
					verify();
				}
			} );
		} );

		phone.focus();
	}

	/* ---------------------------------------------------------------- */
	/* کیف پول                                                           */
	/* ---------------------------------------------------------------- */

	function initWallet() {
		var amount = document.getElementById( 'wcma-amount' );

		if ( ! amount ) {
			return;
		}

		amount.addEventListener( 'input', function () {
			amount.value = grouped( amount.value );
		} );

		Array.prototype.forEach.call(
			document.querySelectorAll( '.wp-chip--pick' ),
			function ( chip ) {
				chip.addEventListener( 'click', function () {
					amount.value = grouped( chip.getAttribute( 'data-amount' ) );
					amount.focus();
				} );
			}
		);
	}

	/* ---------------------------------------------------------------- */
	/* پیوست تیکت                                                        */
	/* ---------------------------------------------------------------- */

	/**
	 * نامِ فایلِ انتخاب‌شده را کنارِ دکمه می‌نویسد.
	 *
	 * ورودی فایلِ مرورگر پنهان است تا دکمه‌ی فارسیِ خودمان دیده شود؛ پس
	 * اگر نام را ننویسیم، کاربر نمی‌فهمد فایلی انتخاب شده یا نه.
	 */
	function initFiles() {
		Array.prototype.forEach.call(
			document.querySelectorAll( '.wp-file' ),
			function ( box ) {
				var input = box.querySelector( 'input[type="file"]' );
				var name = box.querySelector( '.wp-file__name' );

				if ( ! input || ! name ) {
					return;
				}

				var empty = name.textContent;

				input.addEventListener( 'change', function () {
					var file = input.files && input.files[ 0 ];

					name.textContent = file ? file.name : empty;
					box.classList.toggle( 'has-file', !! file );
				} );
			}
		);
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			initAuth();
			initWallet();
			initFiles();
		} );
	} else {
		initAuth();
		initWallet();
		initFiles();
	}
} )();
