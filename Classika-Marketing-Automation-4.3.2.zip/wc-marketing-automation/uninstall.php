<?php
/**
 * حذف کامل داده‌های افزونه هنگام پاک کردن آن.
 *
 * @package WCMA
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// فایل «حالت سریع» ربات در هر حال برداشته می‌شود؛ بی‌افزونه کاری ندارد.
require_once plugin_dir_path( __FILE__ ) . 'includes/channels/class-wcma-bot-fastlane.php';
WCMA_Bot_Fastlane::remove();

// فقط در صورتی داده‌ها حذف می‌شوند که مدیر این گزینه را فعال کرده باشد.
$wcma_settings = get_option( 'wcma_settings', array() );

if ( is_array( $wcma_settings ) && ! empty( $wcma_settings['delete_data_on_uninstall'] ) && 'yes' === $wcma_settings['delete_data_on_uninstall'] ) {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wcma-install.php';

	WCMA_Install::drop_data();

	delete_option( 'wcma_opted_out' );
	delete_option( 'wcma_last_run' );

	delete_metadata( 'user', 0, 'wcma_birthday', '', true );
	delete_metadata( 'user', 0, 'wcma_opted_out', '', true );
	delete_metadata( 'user', 0, '_wcma_birthday_year', '', true );
	delete_metadata( 'comment', 0, '_wcma_rewarded', '', true );

	foreach ( array( 'telegram', 'bale', 'eitaa', 'rubika', 'whatsapp' ) as $wcma_messenger ) {
		delete_metadata( 'user', 0, 'wcma_' . $wcma_messenger . '_chat_id', '', true );
	}
}
