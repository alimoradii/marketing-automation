<?php
/**
 * API اپراتور: مدیریت گفتگوها و پرونده‌ی مشتریان از بیرون وردپرس.
 *
 * برخلاف مسیرهای عمومیِ ویجت چت، این مسیرها داده‌ی خصوصی مشتریان را
 * برمی‌گردانند، پس همه‌شان با دسترسی واقعی محافظت می‌شوند. احراز هویت با
 * «رمز اپلیکیشن» خودِ وردپرس انجام می‌شود؛ چیزی دست‌ساز ننوشته‌ایم.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Agent_API
 */
class WCMA_Agent_API {

	const NS       = 'wcma/v1';
	const RATE_KEY = 'wcma_agent_rate_';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * حسابِ اپِ درخواست جاری، اگر با توکن آمده باشد.
	 *
	 * @var array|null
	 */
	protected static $actor = null;

	/**
	 * توکن خام درخواست جاری.
	 *
	 * @return string
	 */
	public static function bearer() {
		$header = '';

		if ( isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			$header = (string) wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] );
		} elseif ( isset( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			// آپاچی گاهی هدر را با پیشوند REDIRECT_ می‌فرستد.
			$header = (string) wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] );
		}

		if ( 0 !== stripos( $header, 'bearer ' ) ) {
			return '';
		}

		return trim( substr( $header, 7 ) );
	}

	/**
	 * حسابِ در حال کار: یا حساب اپ، یا کاربر وردپرسی.
	 *
	 * @return array
	 */
	public static function actor() {
		if ( is_array( self::$actor ) ) {
			return self::$actor;
		}

		$token = self::bearer();

		if ( $token ) {
			$user = WCMA_App_Users::user_by_token( $token );

			if ( $user ) {
				self::$actor = array(
					'id'   => (int) $user['id'],
					'name' => $user['name'],
					'role' => $user['role'],
					'kind' => 'app',
				);

				return self::$actor;
			}
		}

		if ( is_user_logged_in() && current_user_can( 'manage_woocommerce' ) ) {
			$wp_user = wp_get_current_user();

			self::$actor = array(
				'id'   => 0,
				'name' => isset( $wp_user->display_name ) ? $wp_user->display_name : 'مدیر',
				'role' => 'manager',
				'kind' => 'wp',
			);

			return self::$actor;
		}

		self::$actor = array();

		return self::$actor;
	}

	/**
	 * ثبت اقدام در تاریخچه.
	 *
	 * @param string $action      کار.
	 * @param string $object_type نوع هدف.
	 * @param int    $object_id   شناسه.
	 * @param string $detail      توضیح.
	 */
	protected static function track( $action, $object_type = '', $object_id = 0, $detail = '' ) {
		$actor = self::actor();

		if ( ! $actor ) {
			return;
		}

		WCMA_App_Users::log( (int) $actor['id'], $actor['name'], $action, $object_type, $object_id, $detail );
	}

	/**
	 * دسترسی لازم برای همه‌ی مسیرهای اپراتور.
	 *
	 * @return bool|WP_Error
	 */
	public static function can_manage() {
		$actor = self::actor();

		if ( ! $actor ) {
			/*
			 * تفکیک ۴۰۱ و ۴۰۳ مهم است: کاربری که وارد شده ولی دسترسی ندارد،
			 * باید بداند مشکل از نبودِ اجازه است نه از ورود.
			 */
			if ( is_user_logged_in() ) {
				return new WP_Error( 'wcma_forbidden', 'دسترسی لازم را ندارید.', array( 'status' => 403 ) );
			}

			return new WP_Error( 'wcma_unauthorized', 'ابتدا وارد شوید.', array( 'status' => 401 ) );
		}

		if ( ! self::allow_rate() ) {
			return new WP_Error( 'wcma_rate', 'درخواست‌های زیادی فرستاده شده. کمی صبر کنید.', array( 'status' => 429 ) );
		}

		return true;
	}

	/**
	 * دسترسی‌های نشست جاری.
	 *
	 * @return array
	 */
	public static function caps() {
		$actor = self::actor();

		return $actor ? WCMA_App_Users::caps( $actor['role'] ?? '' ) : array();
	}

	/**
	 * آیا نشست جاری این دسترسی را دارد؟
	 *
	 * @param string $cap دسترسی.
	 * @return bool
	 */
	public static function current_can( $cap ) {
		return in_array( (string) $cap, self::caps(), true );
	}

	/**
	 * ساخت نگهبان یک مسیر بر پایه‌ی دسترسی لازم آن.
	 *
	 * هر مسیر دسترسی خودش را اعلام می‌کند تا نقشِ حساب واقعاً کاری بکند؛
	 * پنهان‌کردن دکمه در پنل به‌تنهایی محافظت نیست، چون درخواست را می‌شود
	 * دستی فرستاد.
	 *
	 * @param string $cap دسترسی لازم.
	 * @return callable
	 */
	protected static function needs( $cap ) {
		return function () use ( $cap ) {
			$ok = self::can_manage();

			if ( is_wp_error( $ok ) ) {
				return $ok;
			}

			if ( ! self::current_can( $cap ) ) {
				$labels = WCMA_App_Users::cap_labels();

				return new WP_Error(
					'wcma_forbidden',
					sprintf( 'حساب شما اجازه‌ی «%s» را ندارد.', $labels[ $cap ] ?? $cap ),
					array( 'status' => 403 )
				);
			}

			return true;
		};
	}

	/**
	 * فقط مدیر: دیدن تاریخچه‌ی همکاران.
	 *
	 * @return bool|WP_Error
	 */
	public static function can_manage_team() {
		$guard = self::needs( 'team_history' );

		return $guard();
	}

	/**
	 * محدودیت نرخ برای هر کاربر.
	 *
	 * سقف بالا گرفته شده چون اپ هر چند ثانیه یک‌بار صندوق را می‌خواند؛
	 * هدف جلوگیری از سوءاستفاده است، نه محدود کردن کار عادی.
	 *
	 * @return bool
	 */
	protected static function allow_rate() {
		$actor = self::actor();
		$key   = self::RATE_KEY . ( $actor['kind'] ?? 'x' ) . '_' . ( $actor['id'] ?? get_current_user_id() );
		$count = (int) get_transient( $key );

		if ( $count >= 600 ) {
			return false;
		}

		set_transient( $key, $count + 1, MINUTE_IN_SECONDS * 10 );

		return true;
	}

	/**
	 * ثبت مسیرها.
	 */
	public static function register_routes() {
		$guard = array( __CLASS__, 'can_manage' );

		// ورود عمومی است؛ محافظتش با محدودیت تلاش داخل خودِ login انجام می‌شود.
		register_rest_route(
			self::NS,
			'/agent/login',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'login' ), 'permission_callback' => '__return_true' )
		);

		register_rest_route(
			self::NS,
			'/agent/logout',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'logout' ), 'permission_callback' => $guard )
		);

		register_rest_route(
			self::NS,
			'/agent/history',
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'history' ), 'permission_callback' => array( __CLASS__, 'can_manage_team' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/me',
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'me' ), 'permission_callback' => $guard )
		);

		register_rest_route(
			self::NS,
			'/agent/chats',
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'chats' ), 'permission_callback' => self::needs( 'chat_read' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/chats/(?P<id>\d+)',
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'chat' ), 'permission_callback' => self::needs( 'chat_read' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/chats/(?P<id>\d+)/reply',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'reply' ), 'permission_callback' => self::needs( 'chat_reply' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/chats/(?P<id>\d+)/upload',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'upload' ), 'permission_callback' => self::needs( 'chat_reply' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/chats/(?P<id>\d+)/mode',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'mode' ), 'permission_callback' => self::needs( 'chat_mode' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/contacts',
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'contacts' ), 'permission_callback' => self::needs( 'contact_read' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/contacts/(?P<id>\d+)',
			array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'contact' ), 'permission_callback' => self::needs( 'contact_read' ) )
		);

		register_rest_route(
			self::NS,
			'/agent/contacts/(?P<id>\d+)/note',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'add_note' ), 'permission_callback' => self::needs( 'note_add' ) )
		);
	}

	/**
	 * ورود با حساب کنسول.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function login( $request ) {
		$result = WCMA_App_Users::login(
			(string) $request->get_param( 'username' ),
			(string) $request->get_param( 'password' ),
			(string) $request->get_param( 'device' )
		);

		if ( empty( $result['success'] ) ) {
			// همیشه ۲۰۰، تا اپ بتواند پیام را نشان دهد؛ خودِ ok می‌گوید چه شد.
			return new WP_REST_Response( array( 'ok' => false, 'message' => $result['message'] ), 200 );
		}

		return new WP_REST_Response(
			array(
				'ok'    => true,
				'token' => $result['token'],
				'user'  => $result['user'],
				'days'  => WCMA_App_Users::TOKEN_DAYS,
			),
			200
		);
	}

	/**
	 * خروج از همین دستگاه.
	 *
	 * @return WP_REST_Response
	 */
	public static function logout() {
		self::track( 'logout' );
		WCMA_App_Users::revoke_token( self::bearer() );

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * تاریخچه‌ی اقدام‌ها؛ فقط برای مدیر.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function history( $request ) {
		$result  = WCMA_App_Users::history(
			array(
				'user_id'  => (int) $request->get_param( 'user' ),
				'action'   => sanitize_key( (string) $request->get_param( 'action' ) ),
				'per_page' => 100,
			)
		);

		$labels = WCMA_App_Users::actions();
		$items  = array();

		foreach ( $result['items'] as $row ) {
			$items[] = array(
				'actor'  => $row['actor'],
				// کلید خام برای فیلتر، برچسب فارسی برای نمایش.
				'key'    => (string) $row['action'],
				'action' => $labels[ $row['action'] ] ?? $row['action'],
				'detail' => (string) $row['detail'],
				'date'   => WCMA_Date::mysql( $row['created_at'], 'datetime', '' ),
			);
		}

		return new WP_REST_Response( array( 'ok' => true, 'items' => $items, 'total' => $result['total'] ), 200 );
	}

	/**
	 * اطلاعات اپراتور و شمارنده‌ها؛ اپ با این، ورود را می‌سنجد.
	 *
	 * @return WP_REST_Response
	 */
	public static function me() {
		$actor = self::actor();

		return new WP_REST_Response(
			array(
				'ok'        => true,
				'name'      => $actor['name'] ?? '',
				'role'      => $actor['role'] ?? 'viewer',
				// نوار بالای پنل باریک است؛ توضیح داخل پرانتز آنجا جا نمی‌شود.
				'roleLabel' => strtok( (string) ( WCMA_App_Users::roles()[ $actor['role'] ?? '' ] ?? '' ), ' (' ),
				// پنل با همین فهرست تصمیم می‌گیرد چه چیزی را نشان بدهد.
				'caps'      => self::caps(),
				'files'     => array(
					'on'     => WCMA_Chat_Files::enabled(),
					'voice'  => WCMA_Chat_Files::voice_enabled(),
					'accept' => WCMA_Chat_Files::accept_attr(),
					'max'    => WCMA_Chat_Files::max_bytes(),
					'label'  => WCMA_Chat_Files::human_size( WCMA_Chat_Files::max_bytes() ),
				),
				'site'      => get_bloginfo( 'name' ),
				'unread'    => WCMA_Chatbot::unread_count(),
			),
			200
		);
	}

	/**
	 * صندوق گفتگو.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function chats( $request ) {
		$result = WCMA_Chatbot::chats(
			array(
				'status'   => (string) ( $request->get_param( 'status' ) ?? 'open' ),
				'search'   => sanitize_text_field( (string) $request->get_param( 'search' ) ),
				'per_page' => 50,
			)
		);

		$items = array();

		foreach ( $result['items'] as $row ) {
			$items[] = array(
				'id'      => (int) $row['id'],
				'name'    => $row['name'] ? $row['name'] : 'مهمان',
				'channel' => WCMA_Chatbot::channel_label( $row['channel'] ),
				'mode'    => $row['mode'],
				'status'  => $row['status'],
				'unread'  => (int) $row['unread'],
				'last'    => (string) $row['last_message'],
				'date'    => WCMA_Date::mysql( $row['last_message_at'], 'datetime', '' ),
				'phone'   => (string) $row['phone'],
			);
		}

		return new WP_REST_Response(
			array( 'ok' => true, 'items' => $items, 'total' => (int) $result['total'], 'unread' => WCMA_Chatbot::unread_count() ),
			200
		);
	}

	/**
	 * یک گفتگو با پیام‌هایش.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function chat( $request ) {
		global $wpdb;

		$id   = (int) $request->get_param( 'id' );
		$chat = WCMA_Chatbot::chat( $id );

		if ( ! $chat ) {
			return new WP_Error( 'wcma_not_found', 'گفتگو پیدا نشد.', array( 'status' => 404 ) );
		}

		// باز کردن گفتگو یعنی خوانده شد.
		$wpdb->update( WCMA_Chatbot::chats_table(), array( 'unread' => 0 ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB

		self::track( 'chat_open', 'chat', $id, $chat['name'] );

		$messages = array_reverse( WCMA_Chatbot::recent_messages( $id, 100 ) );
		$refs     = array();

		foreach ( $messages as $message ) {
			if ( ! empty( $message['reply_to'] ) ) {
				$refs[] = (int) $message['reply_to'];
			}
		}

		$quotes = $refs ? WCMA_Chatbot::quotes( $refs ) : array();
		$out    = array();

		foreach ( $messages as $message ) {
			$ref = (int) ( $message['reply_to'] ?? 0 );

			$out[] = array(
				'id'     => (int) $message['id'],
				'side'   => 'in' === $message['direction'] ? 'customer' : 'agent',
				'sender' => $message['sender'],
				'body'   => $message['body'],
				'file'   => WCMA_Chat_Files::shape( $message ),
				'reply'  => ( $ref && isset( $quotes[ $ref ] ) ) ? array_merge( array( 'id' => $ref ), $quotes[ $ref ] ) : null,
				'date'   => WCMA_Date::mysql( $message['created_at'], 'datetime', '' ),
			);
		}

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'chat'     => array(
					'id'      => $id,
					'name'    => $chat['name'] ? $chat['name'] : 'مهمان',
					'channel' => WCMA_Chatbot::channel_label( $chat['channel'] ),
					'mode'    => $chat['mode'],
					'phone'   => (string) $chat['phone'],
					'email'   => (string) $chat['email'],
					'contact' => (int) $chat['contact_id'],
				),
				'messages' => $out,
			),
			200
		);
	}

	/**
	 * پاسخ اپراتور.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function reply( $request ) {
		$id   = (int) $request->get_param( 'id' );
		$text = trim( sanitize_textarea_field( (string) $request->get_param( 'text' ) ) );

		if ( '' === $text ) {
			return new WP_Error( 'wcma_empty', 'متن پیام خالی است.', array( 'status' => 400 ) );
		}

		if ( ! WCMA_Chatbot::chat( $id ) ) {
			return new WP_Error( 'wcma_not_found', 'گفتگو پیدا نشد.', array( 'status' => 404 ) );
		}

		$sent = WCMA_Chatbot::send( $id, $text, 'human', '', (int) $request->get_param( 'reply' ) );

		self::track( 'chat_reply', 'chat', $id, mb_substr( $text, 0, 120 ) );

		return new WP_REST_Response( array( 'ok' => (bool) $sent, 'date' => WCMA_Date::format( null, 'datetime' ) ), 200 );
	}

	/**
	 * تغییر حالت ربات یا اپراتور.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function mode( $request ) {
		$id   = (int) $request->get_param( 'id' );
		$mode = 'human' === $request->get_param( 'mode' ) ? 'human' : 'bot';

		if ( ! WCMA_Chatbot::chat( $id ) ) {
			return new WP_Error( 'wcma_not_found', 'گفتگو پیدا نشد.', array( 'status' => 404 ) );
		}

		WCMA_Chatbot::set_mode( $id, $mode );

		self::track( 'chat_mode', 'chat', $id, 'human' === $mode ? 'اپراتور' : 'ربات' );

		return new WP_REST_Response( array( 'ok' => true, 'mode' => $mode ), 200 );
	}

	/**
	 * فهرست و جستجوی مشتریان.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function contacts( $request ) {
		$result = WCMA_CRM::query(
			array(
				'search'   => sanitize_text_field( (string) $request->get_param( 'search' ) ),
				'stage'    => sanitize_key( (string) $request->get_param( 'stage' ) ),
				'page'     => max( 1, (int) $request->get_param( 'page' ) ),
				'per_page' => 25,
			)
		);

		$stages = WCMA_CRM::stages();
		$items  = array();

		foreach ( $result['items'] as $row ) {
			$source = WCMA_CRM::source_style( (string) $row['source'] );

			$items[] = array(
				'id'      => (int) $row['id'],
				'name'    => WCMA_CRM::display_name( $row ),
				'phone'   => (string) $row['phone'],
				'email'   => (string) $row['email'],
				'stage'   => $stages[ $row['stage'] ]['label'] ?? '',
				'color'   => $stages[ $row['stage'] ]['color'] ?? '#94a3b8',
				'source'  => $source['label'],
				'orders'  => (int) $row['order_count'],
				'spent'   => (float) $row['total_spent'],
			);
		}

		return new WP_REST_Response(
			array( 'ok' => true, 'items' => $items, 'total' => (int) $result['total'] ),
			200
		);
	}

	/**
	 * پرونده‌ی یک مشتری با گردش کارش.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function contact( $request ) {
		$contact = WCMA_CRM::get( (int) $request->get_param( 'id' ) );

		if ( ! $contact ) {
			return new WP_Error( 'wcma_not_found', 'پرونده پیدا نشد.', array( 'status' => 404 ) );
		}

		self::track( 'contact_view', 'contact', (int) $contact['id'], WCMA_CRM::display_name( $contact ) );

		$journey = array();

		foreach ( WCMA_CRM::journey( $contact, 40 ) as $event ) {
			$journey[] = array(
				'kind'   => $event['kind'],
				'icon'   => $event['icon'],
				'color'  => $event['color'],
				'title'  => $event['title'],
				'detail' => (string) ( $event['detail'] ?? '' ),
				'author' => (string) ( $event['author'] ?? '' ),
				'date'   => WCMA_Date::mysql( $event['time'], 'datetime', '' ),
			);
		}

		$stages = WCMA_CRM::stages();
		$source = WCMA_CRM::source_style( (string) $contact['source'] );

		return new WP_REST_Response(
			array(
				'ok'      => true,
				'contact' => array(
					'id'     => (int) $contact['id'],
					'name'   => WCMA_CRM::display_name( $contact ),
					'phone'  => (string) $contact['phone'],
					'email'  => (string) $contact['email'],
					'stage'  => $stages[ $contact['stage'] ]['label'] ?? '',
					'color'  => $stages[ $contact['stage'] ]['color'] ?? '#94a3b8',
					'source' => $source['label'],
					'orders' => (int) $contact['order_count'],
					'spent'  => (float) $contact['total_spent'],
					'tags'   => (string) $contact['tags'],
				),
				'journey' => $journey,
			),
			200
		);
	}

	/**
	 * ارسال فایل یا پیام صوتی از پنل.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function upload( $request ) {
		$id = (int) $request->get_param( 'id' );

		if ( ! WCMA_Chat_Files::enabled() ) {
			return new WP_Error( 'wcma_files_off', 'ارسال فایل در گفتگو خاموش است.', array( 'status' => 400 ) );
		}

		if ( ! WCMA_Chatbot::chat( $id ) ) {
			return new WP_Error( 'wcma_not_found', 'گفتگو پیدا نشد.', array( 'status' => 404 ) );
		}

		$files = $request->get_file_params();
		$saved = WCMA_Chat_Files::store( $files['file'] ?? null, (int) $request->get_param( 'duration' ) );

		if ( is_wp_error( $saved ) ) {
			return new WP_Error( $saved->get_error_code(), $saved->get_error_message(), array( 'status' => 400 ) );
		}

		$caption = trim( sanitize_textarea_field( (string) $request->get_param( 'text' ) ) );
		$result  = WCMA_Chatbot::send_file( $id, $saved, $caption, (int) $request->get_param( 'reply' ) );

		if ( empty( $result['success'] ) ) {
			return new WP_Error( 'wcma_send_failed', $result['message'], array( 'status' => 502 ) );
		}

		self::track( 'chat_file', 'chat', $id, $saved['name'] );

		return new WP_REST_Response( array( 'ok' => true, 'message' => $result['message'] ), 200 );
	}

	/**
	 * افزودن یادداشت به پرونده.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function add_note( $request ) {
		$id   = (int) $request->get_param( 'id' );
		$body = trim( sanitize_textarea_field( (string) $request->get_param( 'body' ) ) );
		$type = sanitize_key( (string) $request->get_param( 'type' ) );
		$type = isset( WCMA_CRM::note_types()[ $type ] ) ? $type : 'note';

		if ( '' === $body ) {
			return new WP_Error( 'wcma_empty', 'متن یادداشت خالی است.', array( 'status' => 400 ) );
		}

		if ( ! WCMA_CRM::get( $id ) ) {
			return new WP_Error( 'wcma_not_found', 'پرونده پیدا نشد.', array( 'status' => 404 ) );
		}

		$note_id = WCMA_CRM::add_note( $id, $body, $type, get_current_user_id(), (string) ( self::actor()['name'] ?? '' ) );

		self::track( 'note_add', 'contact', $id, mb_substr( $body, 0, 120 ) );

		return new WP_REST_Response(
			array( 'ok' => (bool) $note_id, 'date' => WCMA_Date::format( null, 'datetime' ) ),
			200
		);
	}
}
