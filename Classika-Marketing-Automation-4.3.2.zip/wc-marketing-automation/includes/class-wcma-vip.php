<?php
/**
 * باشگاه مشتریان: محاسبه‌ی سطح، نگهداری اعضا و گزارش ۲۰/۸۰.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_VIP
 */
class WCMA_VIP {

	/**
	 * نام جدول اعضا.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcma_vip_members';
	}

	/**
	 * راه‌اندازی بخش سمت مشتری.
	 */
	public static function init() {
		add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'render_account_section' ), 15 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_font' ) );
	}

	/**
	 * فونت کارت باشگاه مشتریان در حساب کاربری.
	 */
	public static function enqueue_font() {
		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			wp_enqueue_style( 'wcma-font', WCMA_URL . 'assets/css/font.css', array(), WCMA_Plugin::asset_version( 'assets/css/font.css' ) );
		}
	}

	/**
	 * مبناهای سطح‌بندی.
	 *
	 * @return array
	 */
	public static function bases() {
		return array(
			'amount' => 'فقط مجموع مبلغ خرید',
			'orders' => 'فقط تعداد سفارش',
			'any'    => 'هر کدام که زودتر برسد (مبلغ یا تعداد)',
			'all'    => 'هر دو با هم لازم است (مبلغ و تعداد)',
		);
	}

	/**
	 * بازه‌های آماده‌ی محاسبه.
	 *
	 * @return array
	 */
	public static function windows() {
		return array(
			0    => 'کل تاریخچه‌ی خرید',
			90   => 'سه ماه گذشته',
			180  => 'شش ماه گذشته',
			365  => 'دوازده ماه گذشته',
			730  => 'دو سال گذشته',
			-1   => 'بازه‌ی دلخواه (روز)',
		);
	}

	/**
	 * تعداد روزهای بازه‌ی محاسبه؛ صفر یعنی کل تاریخچه.
	 *
	 * @return int
	 */
	public static function window_days() {
		$preset = (int) WCMA_Settings::get( 'vip_window', 365 );

		if ( -1 === $preset ) {
			return max( 0, (int) WCMA_Settings::get( 'vip_window_custom', 365 ) );
		}

		return max( 0, $preset );
	}

	/**
	 * سطوح تعریف‌شده، مرتب‌شده از پایین به بالا.
	 *
	 * @return array
	 */
	public static function tiers() {
		$tiers = WCMA_Settings::get( 'vip_tiers', array() );

		if ( ! is_array( $tiers ) ) {
			return array();
		}

		$clean = array();

		foreach ( array_values( $tiers ) as $index => $tier ) {
			if ( empty( $tier['active'] ) || 'yes' !== $tier['active'] ) {
				continue;
			}

			$clean[] = array(
				'index'         => count( $clean ) + 1,
				'name'          => (string) ( $tier['name'] ?? sprintf( 'سطح %d', $index + 1 ) ),
				'min_amount'    => (float) ( $tier['min_amount'] ?? 0 ),
				'min_orders'    => (int) ( $tier['min_orders'] ?? 0 ),
				'color'         => (string) ( $tier['color'] ?? '#6b7280' ),
				'perk'          => (string) ( $tier['perk'] ?? '' ),
				'coupon_type'   => (string) ( $tier['coupon_type'] ?? 'percent' ),
				'coupon_amount' => (float) ( $tier['coupon_amount'] ?? 0 ),
				'coupon_days'   => (int) ( $tier['coupon_days'] ?? 30 ),
			);
		}

		// مرتب‌سازی از پایین‌ترین آستانه به بالاترین تا محاسبه‌ی سطح قابل اتکا باشد.
		usort(
			$clean,
			static function ( $a, $b ) {
				$a_key = max( $a['min_amount'], 0 ) + $a['min_orders'];
				$b_key = max( $b['min_amount'], 0 ) + $b['min_orders'];

				return $a_key <=> $b_key;
			}
		);

		foreach ( $clean as $i => $tier ) {
			$clean[ $i ]['index'] = $i + 1;
		}

		return $clean;
	}

	/**
	 * اطلاعات یک سطح بر اساس شماره.
	 *
	 * @param int $index شماره‌ی سطح (۱ به بالا).
	 * @return array|null
	 */
	public static function tier( $index ) {
		$index = (int) $index;

		if ( $index < 1 ) {
			return null;
		}

		$tiers = self::tiers();

		return $tiers[ $index - 1 ] ?? null;
	}

	/**
	 * نام خوانای یک سطح.
	 *
	 * @param int $index شماره.
	 * @return string
	 */
	public static function tier_name( $index ) {
		$tier = self::tier( $index );

		return $tier ? $tier['name'] : 'بدون سطح';
	}

	/**
	 * آیا این مشتری شرایط سطح موردنظر را دارد؟
	 *
	 * @param array $tier   سطح.
	 * @param float $amount مجموع مبلغ.
	 * @param int   $orders تعداد سفارش.
	 * @return bool
	 */
	protected static function qualifies( array $tier, $amount, $orders ) {
		$basis = WCMA_Settings::get( 'vip_basis', 'amount' );

		$amount_ok = $tier['min_amount'] <= 0 || $amount >= $tier['min_amount'];
		$orders_ok = $tier['min_orders'] <= 0 || $orders >= $tier['min_orders'];

		switch ( $basis ) {
			case 'orders':
				return $orders_ok;
			case 'any':
				// اگر یکی از دو آستانه تعریف نشده باشد، همان دیگری ملاک است.
				if ( $tier['min_amount'] <= 0 ) {
					return $orders_ok;
				}
				if ( $tier['min_orders'] <= 0 ) {
					return $amount_ok;
				}
				return $amount_ok || $orders_ok;
			case 'all':
				return $amount_ok && $orders_ok;
			case 'amount':
			default:
				return $amount_ok;
		}
	}

	/**
	 * بالاترین سطحی که مشتری واجد آن است.
	 *
	 * @param float $amount مجموع مبلغ.
	 * @param int   $orders تعداد سفارش.
	 * @return int شماره‌ی سطح؛ صفر یعنی هیچ سطحی.
	 */
	public static function calculate_tier( $amount, $orders ) {
		$result = 0;

		foreach ( self::tiers() as $tier ) {
			if ( self::qualifies( $tier, (float) $amount, (int) $orders ) ) {
				$result = (int) $tier['index'];
			}
		}

		return $result;
	}

	/**
	 * سطح بعدی و فاصله‌ی مشتری تا آن.
	 *
	 * @param float $amount مجموع مبلغ.
	 * @param int   $orders تعداد سفارش.
	 * @return array|null
	 */
	public static function next_tier( $amount, $orders ) {
		$current = self::calculate_tier( $amount, $orders );
		$next    = self::tier( $current + 1 );

		if ( ! $next ) {
			return null;
		}

		return array(
			'tier'             => $next,
			'amount_remaining' => max( 0, $next['min_amount'] - (float) $amount ),
			'orders_remaining' => max( 0, $next['min_orders'] - (int) $orders ),
		);
	}

	/**
	 * وضعیت‌های سفارش که در محاسبه به‌حساب می‌آیند.
	 *
	 * @return array
	 */
	public static function counted_statuses() {
		$statuses = (array) WCMA_Settings::get( 'vip_order_statuses', array( 'completed', 'processing' ) );

		$statuses = array_filter( array_map( 'sanitize_key', $statuses ) );

		if ( ! $statuses ) {
			$statuses = array( 'completed' );
		}

		return array_map(
			static function ( $status ) {
				return 'wc-' . $status;
			},
			$statuses
		);
	}

	/**
	 * تجمیع خریدهای مشتریان در بازه‌ی تعیین‌شده.
	 *
	 * برای کارایی، محاسبه با یک کوئری تجمیعی روی جدول سفارش‌ها انجام می‌شود، نه با
	 * بارگذاری تک‌تک سفارش‌ها.
	 *
	 * @param int $limit سقف تعداد مشتری.
	 * @return array
	 */
	public static function aggregate( $limit = 5000 ) {
		global $wpdb;

		$statuses = self::counted_statuses();
		$days     = self::window_days();

		$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
		$params       = $statuses;

		$date_clause = '';

		if ( $days > 0 ) {
			$date_clause = ' AND %s <= ';
		}

		$cutoff = $days > 0 ? gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) ) : '';

		if ( WCMA_Workflow_Winback::hpos_enabled() ) {
			$table = $wpdb->prefix . 'wc_orders';

			$sql = "SELECT billing_email AS email, MAX(customer_id) AS user_id,
					COUNT(*) AS order_count, SUM(total_amount) AS total_amount,
					MAX(date_created_gmt) AS last_order_at
					FROM {$table}
					WHERE status IN ({$placeholders}) AND billing_email <> ''";

			if ( $days > 0 ) {
				$sql     .= ' AND date_created_gmt >= %s';
				$params[] = $cutoff;
			}

			$sql .= ' GROUP BY billing_email ORDER BY total_amount DESC LIMIT %d';
		} else {
			$sql = "SELECT pm_email.meta_value AS email, 0 AS user_id,
					COUNT(*) AS order_count, SUM(pm_total.meta_value) AS total_amount,
					MAX(p.post_date_gmt) AS last_order_at
					FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm_email ON pm_email.post_id = p.ID AND pm_email.meta_key = '_billing_email'
					INNER JOIN {$wpdb->postmeta} pm_total ON pm_total.post_id = p.ID AND pm_total.meta_key = '_order_total'
					WHERE p.post_type = 'shop_order' AND p.post_status IN ({$placeholders}) AND pm_email.meta_value <> ''";

			if ( $days > 0 ) {
				$sql     .= ' AND p.post_date_gmt >= %s';
				$params[] = $cutoff;
			}

			$sql .= ' GROUP BY pm_email.meta_value ORDER BY total_amount DESC LIMIT %d';
		}

		$params[] = (int) $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $rows ? $rows : array();
	}

	/**
	 * بازمحاسبه‌ی سطح همه‌ی مشتریان.
	 *
	 * @param int $limit سقف.
	 * @return array{scanned:int,promoted:array,demoted:array}
	 */
	public static function recalculate( $limit = 5000 ) {
		global $wpdb;

		$rows     = self::aggregate( $limit );
		$table    = self::table();
		$promoted = array();
		$demoted  = array();
		$now      = current_time( 'mysql' );

		foreach ( $rows as $row ) {
			$email = sanitize_email( (string) $row['email'] );

			if ( ! is_email( $email ) ) {
				continue;
			}

			$amount = (float) $row['total_amount'];
			$orders = (int) $row['order_count'];
			$tier   = self::calculate_tier( $amount, $orders );

			$existing = $wpdb->get_row( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s", $email ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);

			$previous = $existing ? (int) $existing['tier'] : 0;

			$user_id = (int) $row['user_id'];

			if ( ! $user_id ) {
				$user    = get_user_by( 'email', $email );
				$user_id = $user ? $user->ID : 0;
			}

			$contact = self::contact_for( $email, $user_id );

			$data = array(
				'user_id'       => $user_id,
				'email'         => $email,
				'phone'         => $contact['phone'],
				'first_name'    => $contact['first_name'],
				'tier'          => $tier,
				'previous_tier' => $previous,
				'total_amount'  => $amount,
				'order_count'   => $orders,
				'last_order_at' => $row['last_order_at'] ? get_date_from_gmt( $row['last_order_at'] ) : null,
				'updated_at'    => $now,
			);

			if ( $existing ) {
				if ( $tier !== $previous ) {
					$data['tier_since'] = $now;
				}

				$wpdb->update( $table, $data, array( 'id' => (int) $existing['id'] ) ); // phpcs:ignore WordPress.DB
				$member_id = (int) $existing['id'];
			} else {
				$data['tier_since'] = $now;
				$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB
				$member_id = (int) $wpdb->insert_id;
			}

			if ( $tier > $previous ) {
				$promoted[] = array(
					'id'    => $member_id,
					'email' => $email,
					'from'  => $previous,
					'to'    => $tier,
				);
			} elseif ( $tier < $previous ) {
				$demoted[] = array(
					'id'    => $member_id,
					'email' => $email,
					'from'  => $previous,
					'to'    => $tier,
				);
			}
		}

		update_option( 'wcma_vip_last_recalc', $now, false );

		return array(
			'scanned'  => count( $rows ),
			'promoted' => $promoted,
			'demoted'  => $demoted,
		);
	}

	/**
	 * یافتن شماره و نام مشتری.
	 *
	 * @param string $email   ایمیل.
	 * @param int    $user_id شناسه‌ی کاربر.
	 * @return array
	 */
	protected static function contact_for( $email, $user_id ) {
		$phone = '';
		$first = '';

		if ( $user_id ) {
			$phone = (string) get_user_meta( $user_id, 'billing_phone', true );
			$first = (string) get_user_meta( $user_id, 'billing_first_name', true );
		}

		if ( ! $phone || ! $first ) {
			$orders = wc_get_orders(
				array(
					'billing_email' => $email,
					'limit'         => 1,
					'orderby'       => 'date',
					'order'         => 'DESC',
				)
			);

			if ( ! empty( $orders[0] ) && $orders[0] instanceof WC_Order ) {
				$phone = $phone ? $phone : $orders[0]->get_billing_phone();
				$first = $first ? $first : $orders[0]->get_billing_first_name();
			}
		}

		return array(
			'phone'      => $phone,
			'first_name' => $first,
		);
	}

	/**
	 * دریافت یک عضو.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		$table = self::table();

		return $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * دریافت عضو بر اساس ایمیل.
	 *
	 * @param string $email ایمیل.
	 * @return array|null
	 */
	public static function get_by_email( $email ) {
		global $wpdb;

		$table = self::table();

		return $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s", sanitize_email( $email ) ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * دریافت عضو بر اساس کاربر.
	 *
	 * @param int $user_id شناسه.
	 * @return array|null
	 */
	public static function get_by_user( $user_id ) {
		global $wpdb;

		$table = self::table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d", (int) $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( $row ) {
			return $row;
		}

		$user = get_userdata( $user_id );

		return $user ? self::get_by_email( $user->user_email ) : null;
	}

	/**
	 * فهرست اعضا با فیلتر.
	 *
	 * @param array $args آرگومان‌ها.
	 * @return array
	 */
	public static function members( array $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'tier'     => null,
				'min_tier' => 1,
				'limit'    => 50,
				'orderby'  => 'total_amount',
			)
		);

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( null !== $args['tier'] ) {
			$where[]  = 'tier = %d';
			$params[] = (int) $args['tier'];
		} elseif ( $args['min_tier'] ) {
			$where[]  = 'tier >= %d';
			$params[] = (int) $args['min_tier'];
		}

		$order_by = in_array( $args['orderby'], array( 'total_amount', 'order_count', 'last_order_at', 'tier' ), true )
			? $args['orderby']
			: 'total_amount';

		$where_sql = implode( ' AND ', $where );
		$params[]  = (int) $args['limit'];

		$sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$order_by} DESC LIMIT %d";

		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB
	}

	/**
	 * گزارش سهم هر سطح از فروش، به‌همراه تحلیل ۲۰/۸۰.
	 *
	 * @return array
	 */
	public static function report() {
		global $wpdb;

		$table = self::table();

		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
			"SELECT tier, COUNT(*) AS members, SUM(total_amount) AS revenue, SUM(order_count) AS orders
			 FROM {$table} GROUP BY tier ORDER BY tier DESC",
			ARRAY_A
		);

		$total_members = 0;
		$total_revenue = 0.0;

		foreach ( $rows as $row ) {
			$total_members += (int) $row['members'];
			$total_revenue += (float) $row['revenue'];
		}

		// تحلیل ۲۰/۸۰: سهم ۲۰٪ برتر مشتریان از کل فروش.
		$top_count = (int) ceil( $total_members * 0.2 );
		$top_share = 0.0;

		if ( $top_count > 0 ) {
			$top_revenue = (float) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT SUM(total_amount) FROM (SELECT total_amount FROM {$table} ORDER BY total_amount DESC LIMIT %d) AS top_customers", // phpcs:ignore WordPress.DB
					$top_count
				)
			);

			$top_share = $total_revenue > 0 ? ( $top_revenue / $total_revenue ) * 100 : 0;
		}

		return array(
			'by_tier'       => $rows,
			'total_members' => $total_members,
			'total_revenue' => $total_revenue,
			'top_count'     => $top_count,
			'top_share'     => round( $top_share, 1 ),
			'last_recalc'   => get_option( 'wcma_vip_last_recalc' ),
		);
	}

	/**
	 * نمایش سطح مشتری در حساب کاربری.
	 */
	public static function render_account_section() {
		if ( ! WCMA_Settings::is( 'vip_enabled' ) || ! WCMA_Settings::is( 'vip_show_in_account' ) || ! is_user_logged_in() ) {
			return;
		}

		$member = self::get_by_user( get_current_user_id() );

		if ( ! $member || (int) $member['tier'] < 1 ) {
			return;
		}

		$tier = self::tier( (int) $member['tier'] );

		if ( ! $tier ) {
			return;
		}

		$next = self::next_tier( (float) $member['total_amount'], (int) $member['order_count'] );
		?>
		<div class="wcma-vip-card" style="border-color: <?php echo esc_attr( $tier['color'] ); ?>">
			<div class="wcma-vip-card__head">
				<span class="wcma-vip-card__badge" style="background: <?php echo esc_attr( $tier['color'] ); ?>">
					<?php echo esc_html( $tier['name'] ); ?>
				</span>
				<span class="wcma-vip-card__title">شما عضو باشگاه مشتریان <?php echo esc_html( get_bloginfo( 'name' ) ); ?> هستید</span>
			</div>

			<?php if ( $tier['perk'] ) : ?>
				<p class="wcma-vip-card__perk"><?php echo esc_html( $tier['perk'] ); ?></p>
			<?php endif; ?>

			<?php if ( $next ) : ?>
				<?php
				$basis = WCMA_Settings::get( 'vip_basis', 'amount' );
				$parts = array();

				if ( in_array( $basis, array( 'amount', 'any', 'all' ), true ) && $next['amount_remaining'] > 0 ) {
					$parts[] = sprintf( '%s خرید دیگر', wp_strip_all_tags( wc_price( $next['amount_remaining'] ) ) );
				}

				if ( in_array( $basis, array( 'orders', 'any', 'all' ), true ) && $next['orders_remaining'] > 0 ) {
					$parts[] = sprintf( '%s سفارش دیگر', number_format_i18n( $next['orders_remaining'] ) );
				}

				if ( $parts ) :
					$joiner = 'all' === $basis ? ' و ' : ' یا ';
					?>
					<p class="wcma-vip-card__next">
						تا رسیدن به سطح <strong><?php echo esc_html( $next['tier']['name'] ); ?></strong>:
						<?php echo esc_html( implode( $joiner, $parts ) ); ?>
					</p>
				<?php endif; ?>
			<?php endif; ?>
		</div>

		<style>
			.wcma-vip-card, .wcma-vip-card * { font-family: 'Vazirmatn WCMA', Vazirmatn, Vazir, Tahoma, sans-serif; }
			.wcma-vip-card { border: 2px solid #e5e7eb; border-radius: 12px; padding: 18px; margin: 20px 0; background: #fff; }
			.wcma-vip-card__head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
			.wcma-vip-card__badge { color: #fff; border-radius: 999px; padding: 4px 14px; font-size: 13px; font-weight: 700; }
			.wcma-vip-card__title { font-size: 14px; }
			.wcma-vip-card__perk { margin: 12px 0 0; font-size: 13px; color: #374151; line-height: 2; }
			.wcma-vip-card__next { margin: 10px 0 0; font-size: 13px; color: #6b7280; }
		</style>
		<?php
	}
}
