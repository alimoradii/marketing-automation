<?php
/**
 * ردیابی و ذخیره‌ی سبدهای خرید رها شده (شامل کاربران مهمان).
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Carts
 */
class WCMA_Carts {

	/**
	 * نام جدول سبدها.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcma_carts';
	}

	/**
	 * راه‌اندازی هوک‌ها.
	 */
	public static function init() {
		add_action( 'woocommerce_cart_updated', array( __CLASS__, 'capture' ) );
		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'capture' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_capture_script' ) );
		add_action( 'wp_ajax_wcma_capture_guest', array( __CLASS__, 'ajax_capture_guest' ) );
		add_action( 'wp_ajax_nopriv_wcma_capture_guest', array( __CLASS__, 'ajax_capture_guest' ) );
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'mark_purchased' ), 10, 3 );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'mark_purchased_thankyou' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle_recovery_link' ) );
	}

	/**
	 * شناسه‌ی نشست فعلی برای شناسایی سبد.
	 *
	 * @return string
	 */
	public static function session_key() {
		if ( is_user_logged_in() ) {
			return 'user_' . get_current_user_id();
		}

		if ( function_exists( 'WC' ) && WC()->session ) {
			$key = WC()->session->get_customer_id();
			if ( $key ) {
				return 'guest_' . $key;
			}
		}

		return '';
	}

	/**
	 * ذخیره‌ی سبد خرید جاری.
	 */
	public static function capture() {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		if ( ! WCMA_Settings::is( 'enabled' ) || ! WCMA_Settings::is( 'ab_enabled' ) ) {
			return;
		}
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$session_key = self::session_key();
		if ( ! $session_key ) {
			return;
		}

		$user_id = get_current_user_id();

		if ( ! $user_id && ! WCMA_Settings::is( 'ab_track_guests' ) ) {
			return;
		}

		$cart_contents = WC()->cart->get_cart();

		// سبد خالی: رکورد فعال را حذف کن.
		if ( empty( $cart_contents ) ) {
			self::delete_active( $session_key );
			return;
		}

		$contact = self::resolve_contact( $user_id );

		// برای مهمان‌ها بدون هیچ راه تماسی، ذخیره فایده‌ای ندارد.
		if ( ! $user_id && ! $contact['email'] && ! $contact['phone'] ) {
			return;
		}

		$data = array(
			'user_id'       => $user_id,
			'session_key'   => $session_key,
			'email'         => $contact['email'],
			'phone'         => $contact['phone'],
			'first_name'    => $contact['first_name'],
			'cart_contents' => maybe_serialize( self::simplify_cart( $cart_contents ) ),
			'cart_total'    => (float) WC()->cart->get_total( 'edit' ),
			'item_count'    => WC()->cart->get_cart_contents_count(),
			'status'        => 'active',
			'updated_at'    => current_time( 'mysql' ),
		);

		self::upsert( $session_key, $data );
	}

	/**
	 * ساده‌سازی محتویات سبد برای ذخیره‌سازی.
	 *
	 * @param array $cart_contents محتویات.
	 * @return array
	 */
	protected static function simplify_cart( array $cart_contents ) {
		$items = array();

		foreach ( $cart_contents as $key => $line ) {
			$items[ $key ] = array(
				'product_id'   => (int) ( $line['product_id'] ?? 0 ),
				'variation_id' => (int) ( $line['variation_id'] ?? 0 ),
				'quantity'     => (int) ( $line['quantity'] ?? 1 ),
				'line_total'   => (float) ( $line['line_total'] ?? 0 ),
				'variation'    => $line['variation'] ?? array(),
			);
		}

		return $items;
	}

	/**
	 * یافتن اطلاعات تماس مشتری جاری.
	 *
	 * @param int $user_id شناسه‌ی کاربر.
	 * @return array
	 */
	protected static function resolve_contact( $user_id ) {
		$email = '';
		$phone = '';
		$first = '';

		if ( $user_id ) {
			$user  = get_userdata( $user_id );
			$email = get_user_meta( $user_id, 'billing_email', true );
			$phone = get_user_meta( $user_id, 'billing_phone', true );
			$first = get_user_meta( $user_id, 'billing_first_name', true );

			if ( ! $email && $user ) {
				$email = $user->user_email;
			}
			if ( ! $first && $user ) {
				$first = $user->first_name ? $user->first_name : $user->display_name;
			}
		}

		if ( function_exists( 'WC' ) && WC()->customer ) {
			$email = $email ? $email : WC()->customer->get_billing_email();
			$phone = $phone ? $phone : WC()->customer->get_billing_phone();
			$first = $first ? $first : WC()->customer->get_billing_first_name();
		}

		// داده‌ی موقتی که از فرم پرداخت با ایجکس گرفته شده است.
		if ( function_exists( 'WC' ) && WC()->session ) {
			$pending = WC()->session->get( 'wcma_guest_contact' );
			if ( is_array( $pending ) ) {
				$email = $email ? $email : ( $pending['email'] ?? '' );
				$phone = $phone ? $phone : ( $pending['phone'] ?? '' );
				$first = $first ? $first : ( $pending['first_name'] ?? '' );
			}
		}

		return array(
			'email'      => sanitize_email( (string) $email ),
			'phone'      => sanitize_text_field( (string) $phone ),
			'first_name' => sanitize_text_field( (string) $first ),
		);
	}

	/**
	 * درج یا به‌روزرسانی رکورد سبد.
	 *
	 * @param string $session_key کلید نشست.
	 * @param array  $data        داده‌ها.
	 * @return int
	 */
	protected static function upsert( $session_key, array $data ) {
		global $wpdb;

		$table = self::table();

		$existing = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id, recovery_token FROM {$table} WHERE session_key = %s AND status IN ('active','abandoned') ORDER BY id DESC LIMIT 1", $session_key ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $existing['id'] ) ); // phpcs:ignore WordPress.DB
			return (int) $existing['id'];
		}

		$data['created_at']     = current_time( 'mysql' );
		$data['recovery_token'] = wp_generate_password( 32, false, false );

		$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB

		return (int) $wpdb->insert_id;
	}

	/**
	 * حذف رکورد فعال یک نشست.
	 *
	 * @param string $session_key کلید نشست.
	 */
	protected static function delete_active( $session_key ) {
		global $wpdb;

		$wpdb->delete( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'session_key' => $session_key,
				'status'      => 'active',
			)
		);
	}

	/**
	 * بارگذاری اسکریپت ثبت اطلاعات تماس مهمان‌ها.
	 */
	public static function enqueue_capture_script() {
		if ( ! WCMA_Settings::is( 'ab_enabled' ) || ! WCMA_Settings::is( 'ab_track_guests' ) ) {
			return;
		}
		if ( ! function_exists( 'is_checkout' ) || ! ( is_checkout() || is_cart() ) ) {
			return;
		}

		wp_enqueue_script( 'wcma-cart-capture', WCMA_URL . 'assets/js/cart-capture.js', array( 'jquery' ), WCMA_Plugin::asset_version( 'assets/js/cart-capture.js' ), true );
		wp_localize_script(
			'wcma-cart-capture',
			'wcmaCapture',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wcma_capture' ),
			)
		);
	}

	/**
	 * دریافت اطلاعات تماس مهمان از طریق ایجکس.
	 */
	public static function ajax_capture_guest() {
		check_ajax_referer( 'wcma_capture', 'nonce' );

		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			wp_send_json_error();
		}

		$contact = array(
			'email'      => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
			'phone'      => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
			'first_name' => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
		);

		WC()->session->set( 'wcma_guest_contact', $contact );
		self::capture();

		wp_send_json_success();
	}

	/**
	 * علامت‌گذاری سبد به‌عنوان خریداری‌شده هنگام ثبت سفارش.
	 *
	 * @param int      $order_id شناسه‌ی سفارش.
	 * @param array    $posted   داده‌های فرم.
	 * @param WC_Order $order    سفارش.
	 */
	public static function mark_purchased( $order_id, $posted = array(), $order = null ) {
		self::convert_session_cart( $order_id );
	}

	/**
	 * علامت‌گذاری در صفحه‌ی تشکر (پوشش درگاه‌های پرداخت).
	 *
	 * @param int $order_id شناسه‌ی سفارش.
	 */
	public static function mark_purchased_thankyou( $order_id ) {
		self::convert_session_cart( $order_id );
	}

	/**
	 * تبدیل سبد نشست جاری به وضعیت خریداری‌شده.
	 *
	 * @param int $order_id شناسه‌ی سفارش.
	 */
	protected static function convert_session_cart( $order_id ) {
		global $wpdb;

		$session_key = self::session_key();
		$order       = wc_get_order( $order_id );

		$ids = array();

		if ( $session_key ) {
			$table = self::table();
			$ids   = $wpdb->get_col( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT id FROM {$table} WHERE session_key = %s AND status IN ('active','abandoned')", $session_key ) // phpcs:ignore WordPress.DB
			);
		}

		// پوشش حالتی که نشست عوض شده اما ایمیل یکسان است.
		if ( ! $ids && $order && $order->get_billing_email() ) {
			$table = self::table();
			$ids   = $wpdb->get_col( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT id FROM {$table} WHERE email = %s AND status IN ('active','abandoned')", $order->get_billing_email() ) // phpcs:ignore WordPress.DB
			);
		}

		foreach ( (array) $ids as $cart_id ) {
			$wpdb->update( // phpcs:ignore WordPress.DB
				self::table(),
				array(
					'status'             => 'purchased',
					'recovered_order_id' => (int) $order_id,
					'updated_at'         => current_time( 'mysql' ),
				),
				array( 'id' => (int) $cart_id )
			);

			WCMA_Queue::cancel_for_object( 'cart', (int) $cart_id );
			self::attribute_recovery( (int) $cart_id, $order );
		}
	}

	/**
	 * نسبت دادن درآمد بازیابی‌شده به آخرین پیام ارسالی.
	 *
	 * @param int      $cart_id شناسه‌ی سبد.
	 * @param WC_Order $order   سفارش.
	 */
	protected static function attribute_recovery( $cart_id, $order ) {
		global $wpdb;

		if ( ! $order ) {
			return;
		}

		$logs  = WCMA_Logger::table();
		$log_id = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT id FROM {$logs} WHERE workflow = 'abandoned_cart' AND object_type = 'cart' AND object_id = %d AND status = 'sent' ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB
				$cart_id
			)
		);

		if ( $log_id ) {
			WCMA_Logger::mark_converted( (int) $log_id, (float) $order->get_total() );
			$order->update_meta_data( '_wcma_recovered', 'yes' );
			$order->save();
		}
	}

	/**
	 * ساخت لینک بازیابی سبد.
	 *
	 * @param array $cart رکورد سبد.
	 * @return string
	 */
	public static function recovery_url( array $cart ) {
		if ( empty( $cart['recovery_token'] ) ) {
			return wc_get_cart_url();
		}

		return add_query_arg( 'wcma_recover', $cart['recovery_token'], wc_get_cart_url() );
	}

	/**
	 * پردازش لینک بازیابی و بازسازی سبد.
	 */
	public static function handle_recovery_link() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['wcma_recover'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$token = sanitize_text_field( wp_unslash( $_GET['wcma_recover'] ) );
		$cart  = self::get_by_token( $token );

		if ( ! $cart || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$contents = maybe_unserialize( $cart['cart_contents'] );
		if ( ! is_array( $contents ) ) {
			return;
		}

		WC()->cart->empty_cart();

		foreach ( $contents as $line ) {
			$product_id = (int) ( $line['product_id'] ?? 0 );
			if ( ! $product_id ) {
				continue;
			}

			WC()->cart->add_to_cart(
				$product_id,
				max( 1, (int) ( $line['quantity'] ?? 1 ) ),
				(int) ( $line['variation_id'] ?? 0 ),
				(array) ( $line['variation'] ?? array() )
			);
		}

		// پر کردن اطلاعات مشتری برای سهولت تکمیل خرید.
		if ( WC()->customer && ! is_user_logged_in() ) {
			if ( ! empty( $cart['email'] ) ) {
				WC()->customer->set_billing_email( $cart['email'] );
			}
			if ( ! empty( $cart['phone'] ) ) {
				WC()->customer->set_billing_phone( $cart['phone'] );
			}
			if ( ! empty( $cart['first_name'] ) ) {
				WC()->customer->set_billing_first_name( $cart['first_name'] );
			}
			WC()->customer->save();
		}

		wc_add_notice( 'سبد خرید شما بازیابی شد. برای تکمیل خرید ادامه دهید.', 'success' );

		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}

	/**
	 * دریافت سبد با توکن.
	 *
	 * @param string $token توکن.
	 * @return array|null
	 */
	public static function get_by_token( $token ) {
		global $wpdb;

		$table = self::table();
		return $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE recovery_token = %s LIMIT 1", $token ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * دریافت سبد با شناسه.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		$table = self::table();
		return $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * علامت‌گذاری سبدهای بی‌حرکت به‌عنوان رها شده.
	 *
	 * @return array فهرست سبدهای تازه رها شده.
	 */
	public static function mark_abandoned() {
		global $wpdb;

		$timeout = max( 5, (int) WCMA_Settings::get( 'ab_cart_timeout', 60 ) );
		$table   = self::table();

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET status = 'abandoned' WHERE status = 'active' AND updated_at < DATE_SUB(%s, INTERVAL %d MINUTE)", // phpcs:ignore WordPress.DB
				current_time( 'mysql' ),
				$timeout
			)
		);

		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			"SELECT * FROM {$table} WHERE status = 'abandoned' ORDER BY updated_at DESC LIMIT 200", // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * آمار سبدهای رها شده.
	 *
	 * @return array
	 */
	public static function stats() {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_results( "SELECT status, COUNT(*) AS total, SUM(cart_total) AS value FROM {$table} GROUP BY status", ARRAY_A ); // phpcs:ignore WordPress.DB

		$stats = array(
			'active'    => 0,
			'abandoned' => 0,
			'purchased' => 0,
			'value'     => 0.0,
			'recovered' => 0.0,
		);

		foreach ( (array) $rows as $row ) {
			$stats[ $row['status'] ] = (int) $row['total'];

			if ( 'abandoned' === $row['status'] ) {
				$stats['value'] = (float) $row['value'];
			}
			if ( 'purchased' === $row['status'] ) {
				$stats['recovered'] = (float) $row['value'];
			}
		}

		return $stats;
	}

	/**
	 * فهرست سبدهای رها شده برای نمایش در پیشخوان.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public static function recent( $limit = 20 ) {
		global $wpdb;

		$table = self::table();
		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE status IN ('abandoned','purchased') ORDER BY updated_at DESC LIMIT %d", (int) $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * حذف سبدهای بسیار قدیمی.
	 */
	public static function purge_old() {
		global $wpdb;

		$table = self::table();
		$wpdb->query( "DELETE FROM {$table} WHERE updated_at < DATE_SUB(NOW(), INTERVAL 120 DAY)" ); // phpcs:ignore WordPress.DB
	}
}
