<?php
/**
 * چت آنلاین سایت: ویجت شناور برای بازدیدکننده و اتصال آن به همان صندوق گفتگوی پیشخوان.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_LiveChat
 */
class WCMA_LiveChat {

	const CHANNEL       = 'web';
	const COOKIE        = 'wcma_visitor';
	const MAX_LENGTH    = 2000;
	const RATE_LIMIT    = 20;
	const ONLINE_WINDOW = 120;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );

		// دیرتر از بررسی کوکیِ خود وردپرس اجرا می‌شود تا بتواند خطای آن را خنثی کند.
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'allow_public_chat' ), 99 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_root' ) );
	}

	/**
	 * آیا ویجت باید نمایش داده شود؟
	 *
	 * @return bool
	 */
	public static function is_active() {
		if ( ! WCMA_Settings::is( 'lc_enabled' ) ) {
			return false;
		}

		if ( is_admin() ) {
			return false;
		}

		// نمایش فقط برای کاربران وارد شده، اگر مدیر خواسته باشد.
		if ( WCMA_Settings::is( 'lc_logged_in_only' ) && ! is_user_logged_in() ) {
			return false;
		}

		/**
		 * امکان خاموش کردن ویجت در صفحه‌های خاص.
		 *
		 * @param bool $show نمایش.
		 */
		return (bool) apply_filters( 'wcma_livechat_show', true );
	}

	/**
	 * بارگذاری فایل‌های ویجت.
	 */
	public static function enqueue() {
		if ( ! self::is_active() ) {
			return;
		}

		wp_enqueue_style( 'wcma-font', WCMA_URL . 'assets/css/font.css', array(), WCMA_Plugin::asset_version( 'assets/css/font.css' ) );
		wp_enqueue_style( 'wcma-livechat', WCMA_URL . 'assets/css/livechat.css', array( 'wcma-font' ), WCMA_Plugin::asset_version( 'assets/css/livechat.css' ) );
		wp_enqueue_script( 'wcma-livechat', WCMA_URL . 'assets/js/livechat.js', array(), WCMA_Plugin::asset_version( 'assets/js/livechat.js' ), true );
		wp_localize_script( 'wcma-livechat', 'wcmaLiveChat', self::config() );
	}

	/**
	 * جای ویجت در فوتر.
	 */
	public static function render_root() {
		if ( ! self::is_active() ) {
			return;
		}

		echo '<div id="wcma-livechat"></div>';
	}

	/**
	 * پیکربندی ویجت برای مرورگر.
	 *
	 * @return array
	 */
	public static function config() {
		$user  = wp_get_current_user();
		$name  = '';
		$email = '';
		$phone = '';

		if ( $user && $user->ID ) {
			$first = isset( $user->first_name ) ? (string) $user->first_name : '';
			$last  = isset( $user->last_name ) ? (string) $user->last_name : '';
			$name  = trim( $first . ' ' . $last );
			$name  = $name ? $name : (string) $user->display_name;
			$email = (string) $user->user_email;
			$phone = (string) get_user_meta( $user->ID, 'billing_phone', true );
		}

		return array(
			'root'      => esc_url_raw( rest_url( 'wcma/v1' ) ),
			'css'       => WCMA_URL . 'assets/css/livechat.css?v=' . WCMA_VERSION,
			'font'      => WCMA_URL . 'assets/css/font.css?v=' . WCMA_VERSION,
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'online'    => self::agent_online(),
			'within'    => self::within_hours(),
			'position'  => WCMA_Settings::get( 'lc_position', 'left' ),
			'color'     => WCMA_Settings::get( 'lc_color', '#2563eb' ),
			'title'     => WCMA_Settings::get( 'lc_title', 'پشتیبانی آنلاین' ),
			'subtitle'  => WCMA_Settings::get( 'lc_subtitle', 'معمولاً در چند دقیقه پاسخ می‌دهیم' ),
			'welcome'   => WCMA_Settings::get( 'lc_welcome', 'سلام! چطور می‌توانیم کمکتان کنیم؟' ),
			'offline'   => WCMA_Settings::get( 'lc_offline_text', 'الان خارج از ساعت کاری هستیم. پیام بگذارید، به‌زودی پاسخ می‌دهیم.' ),
			'greeting'  => WCMA_Settings::get( 'lc_greeting', '' ),
			'delay'     => max( 0, (int) WCMA_Settings::get( 'lc_greeting_delay', 8 ) ),
			'askName'   => WCMA_Settings::is( 'lc_ask_name' ),
			'askPhone'  => WCMA_Settings::is( 'lc_ask_phone' ),
			'askEmail'  => WCMA_Settings::is( 'lc_ask_email' ),
			// فرم تماسِ خارج از ساعت کاری
			'leadForm'  => self::lead_form_config(),
			'rating'    => WCMA_Settings::is( 'lc_rating' ),
			'sound'     => WCMA_Settings::is( 'lc_sound' ),
			'quick'     => self::quick_replies(),
			'files'     => WCMA_Chat_Files::enabled(),
			'voice'     => WCMA_Chat_Files::voice_enabled(),
			'accept'    => WCMA_Chat_Files::accept_attr(),
			'maxFile'   => WCMA_Chat_Files::max_bytes(),
			'maxLabel'  => WCMA_Chat_Files::human_size( WCMA_Chat_Files::max_bytes() ),
			'avatar'    => esc_url_raw( (string) WCMA_Settings::get( 'lc_avatar', '' ) ),
			'team'      => self::team_avatars(),
			'me'        => array(
				'name'  => $name,
				'email' => $email,
				'phone' => $phone,
			),
			'i18n'      => array(
				'placeholder' => 'پیام خود را بنویسید...',
				'send'        => 'ارسال',
				'start'       => 'شروع گفتگو',
				'name'        => 'نام شما',
				'phone'       => 'شماره موبایل',
				'email'       => 'ایمیل',
				'typing'      => 'در حال نوشتن...',
				'online'      => 'آنلاین',
				'offlineTag'  => 'آفلاین',
				'sent'        => 'ارسال شد',
				'failed'      => 'ارسال نشد؛ دوباره تلاش کنید.',
				'rate'        => 'گفتگو چطور بود؟',
				'thanks'      => 'ممنون از بازخوردتان!',
				'close'       => 'بستن',
				'required'    => 'لطفاً این فیلد را پر کنید.',
				'badPhone'    => 'شماره موبایل معتبر نیست.',
				'badEmail'    => 'ایمیل معتبر نیست.',
				'newMessage'  => 'پیام تازه',
				'today'       => 'امروز',
				'quickTitle'  => 'پاسخ سریع',
				'play'        => 'پخش',
				'pause'       => 'توقف',
				'speed'       => 'سرعت پخش',
				'reply'       => 'پاسخ به این پیام',
				'quoteYou'    => 'شما',
				'kinds'       => array(
					'image' => 'عکس',
					'video' => 'ویدیو',
					'audio' => 'پیام صوتی',
					'doc'   => 'فایل',
					'zip'   => 'فایل فشرده',
				),
				'attach'      => 'پیوست فایل',
				'record'      => 'ضبط پیام صوتی',
				'stop'        => 'پایان ضبط',
				'recording'   => 'در حال ضبط…',
				'uploading'   => 'در حال ارسال فایل…',
				'tooBig'      => 'حجم فایل بیشتر از حد مجاز است.',
				'badType'     => 'این نوع فایل پذیرفته نمی‌شود.',
				'noMic'       => 'دسترسی به میکروفون ممکن نشد.',
				'download'    => 'دریافت فایل',
				'voiceNote'   => 'پیام صوتی',
				'voiceLength' => 'مدت ضبط:',
				'justNow'     => 'همین حالا',
				'leadPhone'   => 'وارد کردن شماره همراه',
				'leadOrder'   => 'شماره سفارش (اختیاری)',
				'leadName'    => 'نام و نام خانوادگی',
				'leadSend'    => 'ارسال',
				'minutesAgo'  => '%s دقیقه پیش',
				'hoursAgo'    => '%s ساعت پیش',
				'daysAgo'     => '%s روز پیش',
			),
		);
	}

	/**
	 * برچسب روزِ یک پیام، برای جداکننده‌ی بالای گروه پیام‌ها.
	 *
	 * روز جاری و دیروز با نام خودشان خوانده می‌شوند، چون در گفتگو طبیعی‌تر
	 * از خواندن تاریخ کامل است.
	 *
	 * @param string $mysql زمان دیتابیس.
	 * @return string
	 */
	public static function day_label( $mysql ) {
		$mysql = (string) $mysql;

		if ( '' === $mysql || '0000-00-00 00:00:00' === $mysql ) {
			return '';
		}

		// هر دو طرف با تاریخ محلی سایت سنجیده می‌شوند، نه UTC.
		$day   = substr( $mysql, 0, 10 );
		$today = current_time( 'Y-m-d' );
		$yest  = gmdate( 'Y-m-d', strtotime( $today . ' -1 day' ) );

		if ( $day === $today ) {
			return 'امروز';
		}

		if ( $day === $yest ) {
			return 'دیروز';
		}

		return WCMA_Date::mysql( $mysql, 'date_full', '' );
	}

	/**
	 * تصویر همکاران پشتیبانی، برای نشان دادن در سربرگ.
	 *
	 * ترتیب ثابت می‌ماند و جای خالی حذف می‌شود تا اگر مدیر فقط یکی را پر
	 * کرده باشد، دایره‌ی خالی روی سربرگ ننشیند.
	 *
	 * @return array
	 */
	public static function team_avatars() {
		$out = array();

		foreach ( array( 'lc_avatar', 'lc_avatar_2', 'lc_avatar_3' ) as $key ) {
			$url = trim( (string) WCMA_Settings::get( $key, '' ) );

			if ( $url ) {
				$out[] = esc_url_raw( $url );
			}
		}

		return $out;
	}

	/**
	 * پاسخ‌های سریع پیشنهادی زیر جعبه‌ی گفتگو.
	 *
	 * @return array
	 */
	public static function quick_replies() {
		$raw = (string) WCMA_Settings::get( 'lc_quick_replies', '' );

		if ( '' === trim( $raw ) ) {
			return array();
		}

		$items = preg_split( '/[\n،,]+/u', $raw );
		$items = array_filter( array_map( 'trim', (array) $items ) );

		return array_slice( array_values( $items ), 0, 6 );
	}

	/**
	 * آیا اپراتوری همین حالا پای پیشخوان است؟
	 *
	 * @return bool
	 */
	public static function agent_online() {
		$seen = (int) get_option( 'wcma_agent_seen', 0 );

		return ( time() - $seen ) < self::ONLINE_WINDOW;
	}

	/**
	 * ثبت حضور اپراتور.
	 */
	public static function mark_agent_seen() {
		update_option( 'wcma_agent_seen', time(), false );
	}

	/**
	 * آیا در ساعت کاری تعریف‌شده هستیم؟
	 *
	 * @return bool
	 */
	public static function within_hours() {
		$start = (int) WCMA_Settings::get( 'lc_hours_start', 0 );
		$end   = (int) WCMA_Settings::get( 'lc_hours_end', 0 );

		// ۰ تا ۰ یعنی محدودیتی در کار نیست.
		if ( $start === $end ) {
			return true;
		}

		$hour = (int) current_time( 'G' );

		if ( $start < $end ) {
			return $hour >= $start && $hour < $end;
		}

		// بازه‌ای که از نیمه‌شب می‌گذرد.
		return $hour >= $start || $hour < $end;
	}

	/**
	 * ساعت کاری، به زبان آدمیزاد.
	 *
	 * @return string
	 */
	public static function hours_label() {
		$start = (int) WCMA_Settings::get( 'lc_hours_start', 0 );
		$end   = (int) WCMA_Settings::get( 'lc_hours_end', 0 );

		if ( $start === $end ) {
			return 'شبانه‌روزی';
		}

		return sprintf(
			'%s الی %s',
			WCMA_Date::number( $start ),
			WCMA_Date::number( $end )
		);
	}

	/**
	 * پیکربندی فرم تماسِ خارج از ساعت کاری.
	 *
	 * بیرون از ساعت کاری، بازدیدکننده به‌جای پیامی که کسی نمی‌بیند، فرم
	 * کوتاهی پر می‌کند و پرونده‌اش در CRM ساخته می‌شود.
	 *
	 * @return array|null
	 */
	public static function lead_form_config() {
		if ( ! WCMA_Settings::is( 'lc_lead_form' ) ) {
			return null;
		}

		$text = (string) WCMA_Settings::get( 'lc_lead_form_text', '' );

		return array(
			'text'   => str_replace( '{hours}', self::hours_label(), $text ),
			'name'   => WCMA_Settings::is( 'lc_lead_form_name' ),
			'order'  => WCMA_Settings::is( 'lc_lead_form_order' ),
			'thanks' => (string) WCMA_Settings::get( 'lc_lead_form_thanks', '' ),
		);
	}

	/**
	 * ثبت مسیرهای REST.
	 */
	public static function register_routes() {
		$common = array(
			'permission_callback' => '__return_true',
		);

		register_rest_route(
			'wcma/v1',
			'/chat/open',
			array_merge( $common, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_open' ) ) )
		);

		register_rest_route(
			'wcma/v1',
			'/chat/send',
			array_merge( $common, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_send' ) ) )
		);

		register_rest_route(
			'wcma/v1',
			'/chat/poll',
			array_merge( $common, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_poll' ) ) )
		);

		register_rest_route(
			'wcma/v1',
			'/chat/meta',
			array_merge( $common, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_meta' ) ) )
		);

		register_rest_route(
			'wcma/v1',
			'/chat/upload',
			array_merge( $common, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_upload' ) ) )
		);

		register_rest_route(
			'wcma/v1',
			'/chat/lead',
			array_merge( $common, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_lead' ) ) )
		);
	}

	/**
	 * نگذاشتنِ خطای «بررسی کوکی انجام نشد» جلوی مسیرهای عمومی چت.
	 *
	 * وردپرس برای هر درخواست RESTی که کوکی ورود دارد، نانس می‌خواهد. نانس داخل
	 * صفحه ساخته می‌شود و روی سایت‌هایی که کش صفحه دارند کهنه می‌شود؛ آن‌وقت
	 * وردپرس درخواست را رد می‌کرد و بازدیدکننده به‌جای پاسخ، پیام
	 * «Cookie check failed» می‌دید. این مسیرها عمداً عمومی‌اند و خودشان با
	 * توکنِ گفتگو و محدودیت نرخ محافظت می‌شوند، پس نانس چیزی به آن‌ها اضافه
	 * نمی‌کرد.
	 *
	 * @param mixed $result نتیجه‌ی اعتبارسنجی پیشین.
	 * @return mixed
	 */
	public static function allow_public_chat( $result ) {
		if ( ! is_wp_error( $result ) ) {
			return $result;
		}

		if ( 'rest_cookie_invalid_nonce' !== $result->get_error_code() ) {
			return $result;
		}

		return self::is_chat_request() ? null : $result;
	}

	/**
	 * آیا درخواست جاری به یکی از مسیرهای چت است؟
	 *
	 * هنگام اجرای این فیلتر هنوز مسیر تجزیه نشده، پس از خودِ نشانی می‌خوانیم.
	 *
	 * @return bool
	 */
	protected static function is_chat_request() {
		$route = '';

		if ( isset( $_GET['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$route = (string) wp_unslash( $_GET['rest_route'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		} elseif ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$route = (string) wp_unslash( $_SERVER['REQUEST_URI'] );
		}

		if ( '' === $route ) {
			return false;
		}

		$route = strtok( $route, '?' );

		foreach ( array( 'open', 'send', 'poll', 'meta', 'upload' ) as $action ) {
			if ( false !== strpos( $route, 'wcma/v1/chat/' . $action ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * شناسه‌ی بازدیدکننده از درخواست.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return string
	 */
	protected static function visitor_token( $request ) {
		$token = (string) $request->get_param( 'token' );
		$token = preg_replace( '/[^A-Za-z0-9]/', '', $token );

		return substr( (string) $token, 0, 40 );
	}

	/**
	 * ساخت شناسه‌ی تازه.
	 *
	 * @return string
	 */
	public static function new_token() {
		return substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 32 );
	}

	/**
	 * محدودیت نرخ برای جلوگیری از هرزنامه.
	 *
	 * @param string $token شناسه.
	 * @return bool مجاز است؟
	 */
	protected static function rate_ok( $token ) {
		$key   = 'wcma_lc_' . md5( $token . '|' . self::client_ip() );
		$count = (int) get_transient( $key );

		if ( $count >= self::RATE_LIMIT ) {
			return false;
		}

		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );

		return true;
	}

	/**
	 * نشانی آی‌پی بازدیدکننده، کوتاه‌شده.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		return substr( $ip, 0, 60 );
	}

	/**
	 * تشخیص مرورگر و دستگاه از رشته‌ی عامل کاربر.
	 *
	 * @return array{browser:string,device:string}
	 */
	public static function client_agent() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

		$browser = 'نامشخص';

		foreach ( array( 'Edg' => 'Edge', 'OPR' => 'Opera', 'Chrome' => 'Chrome', 'Safari' => 'Safari', 'Firefox' => 'Firefox' ) as $needle => $label ) {
			if ( false !== strpos( $ua, $needle ) ) {
				$browser = $label;
				break;
			}
		}

		$device = 'رایانه';

		if ( preg_match( '/(iPad|Tablet)/i', $ua ) ) {
			$device = 'تبلت';
		} elseif ( preg_match( '/(Mobile|Android|iPhone)/i', $ua ) ) {
			$device = 'موبایل';
		}

		return array( 'browser' => $browser, 'device' => $device );
	}

	/**
	 * یافتن گفتگوی این بازدیدکننده.
	 *
	 * @param string $token شناسه.
	 * @return array|null
	 */
	public static function find( $token ) {
		global $wpdb;

		if ( ! $token || ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return null;
		}

		$table = WCMA_Chatbot::chats_table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s", self::CHANNEL, $token ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * شروع یا ادامه‌ی گفتگو.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_open( $request ) {
		if ( ! self::is_active() ) {
			return new WP_REST_Response( array( 'ok' => false ), 200 );
		}

		$token = self::visitor_token( $request );

		if ( ! $token ) {
			$token = self::new_token();
		}

		$chat = self::find( $token );

		if ( $chat ) {
			self::touch_visitor( (int) $chat['id'], $request );
		}

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'token'    => $token,
				'chat'     => $chat ? (int) $chat['id'] : 0,
				'online'   => self::agent_online(),
				'within'   => self::within_hours(),
				'messages' => $chat ? self::visible_messages( (int) $chat['id'] ) : array(),
				'rated'    => $chat ? (int) $chat['rating'] : 0,
			),
			200
		);
	}

	/**
	 * پیام تازه‌ی بازدیدکننده.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_send( $request ) {
		global $wpdb;

		if ( ! self::is_active() ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'گفتگوی آنلاین فعال نیست.' ), 200 );
		}

		$token = self::visitor_token( $request );

		if ( ! $token ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'نشست معتبر نیست.' ), 200 );
		}

		if ( ! self::rate_ok( $token ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'پیام‌های زیادی فرستاده‌اید. کمی صبر کنید.' ), 200 );
		}

		$text = trim( sanitize_textarea_field( (string) $request->get_param( 'text' ) ) );
		$text = mb_substr( $text, 0, self::MAX_LENGTH );

		if ( '' === $text ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'متن پیام خالی است.' ), 200 );
		}

		$chat = self::find( $token );

		if ( ! $chat ) {
			$chat = self::create( $token, $request );
		}

		if ( ! $chat ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'گفتگو ساخته نشد.' ), 200 );
		}

		$chat_id = (int) $chat['id'];

		self::touch_visitor( $chat_id, $request );

		$table = WCMA_Chatbot::chats_table();
		$now   = current_time( 'mysql' );

		// اگر فرم پیش از گفتگو همراه پیام آمده و پرونده هنوز خالی است، پرش می‌کنیم.
		self::fill_identity( $chat, $request );

		$wpdb->update( // phpcs:ignore WordPress.DB
			$table,
			array(
				'unread'          => (int) $chat['unread'] + 1,
				'status'          => 'open',
				'last_message'    => mb_substr( $text, 0, 300 ),
				'last_message_at' => $now,
			),
			array( 'id' => $chat_id )
		);

		$reply = (int) $request->get_param( 'reply' );

		WCMA_Chatbot::log_message( $chat_id, 'in', 'customer', $text, '', 'sent', array(), $reply );

		$replies = array();

		// وقتی اپراتور گفتگو را در دست گرفته، ربات دخالت نمی‌کند.
		if ( 'human' !== $chat['mode'] && WCMA_Settings::is( 'chat_enabled' ) ) {
			$chat['id'] = $chat_id;
			$reply      = WCMA_Chatbot::answer( $text, $chat );

			if ( ! empty( $reply['text'] ) ) {
				if ( ! empty( $reply['handover'] ) ) {
					WCMA_Chatbot::set_mode( $chat_id, 'human' );
				}

				WCMA_Chatbot::log_message( $chat_id, 'out', 'bot', $reply['text'], $reply['rule'] ?? '' );

				$replies[] = array(
					'body' => $reply['text'],
					'from' => 'bot',
					'date' => WCMA_Date::format( null, 'time' ),
				);
			}
		}

		if ( ! $replies || 'human' === $chat['mode'] ) {
			self::notify_agent( $chat_id, $text );
		}

		return new WP_REST_Response(
			array(
				'ok'      => true,
				'token'   => $token,
				'chat'    => $chat_id,
				'replies' => $replies,
				'online'  => self::agent_online(),
			),
			200
		);
	}

	/**
	 * ثبت فرم تماسِ خارج از ساعت کاری.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_lead( $request ) {
		global $wpdb;

		if ( ! self::is_active() || ! WCMA_Settings::is( 'lc_lead_form' ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'این فرم فعال نیست.' ), 200 );
		}

		$token = self::visitor_token( $request );
		$chat  = $token ? self::find( $token ) : null;

		if ( ! $chat ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'گفتگو پیدا نشد.' ), 200 );
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( (string) $request->get_param( 'phone' ) );
		$name  = trim( sanitize_text_field( (string) $request->get_param( 'name' ) ) );
		$order = trim( sanitize_text_field( (string) $request->get_param( 'order' ) ) );

		if ( ! $phone ) {
			return new WP_REST_Response(
				array( 'ok' => false, 'message' => 'شماره موبایل معتبر نیست.' ),
				200
			);
		}

		$chat_id = (int) $chat['id'];
		$update  = array( 'phone' => $phone );

		if ( $name ) {
			$update['name'] = mb_substr( $name, 0, 120 );
		}

		$wpdb->update( WCMA_Chatbot::chats_table(), $update, array( 'id' => $chat_id ) ); // phpcs:ignore WordPress.DB

		/*
		 * همان مسیر همیشگیِ ساخت پرونده از گفتگو؛ اینجا چیز تازه‌ای ساخته
		 * نمی‌شود تا دو جای مختلف پرونده نسازند و از هم جدا نیفتند.
		 */
		$contact_id = WCMA_Chatbot::link_contact(
			array_merge( $chat, $update, array( 'id' => $chat_id, 'contact_id' => 0 ) )
		);

		// شماره‌ی سفارش در پرونده می‌ماند تا اپراتور صبح بداند موضوع چیست.
		if ( $contact_id ) {
			$note = $order
				? sprintf( 'فرم خارج از ساعت کاری — شماره سفارش: %s', $order )
				: 'فرم خارج از ساعت کاری پر شد.';

			WCMA_CRM::add_note( $contact_id, $note, 'note', 0, 'چت آنلاین' );
		}

		// پاسخِ ثبت‌شده، تا در صندوق گفتگوها هم دیده شود.
		$summary = array( 'شماره: ' . $phone );

		if ( $name ) {
			array_unshift( $summary, 'نام: ' . $name );
		}

		if ( $order ) {
			$summary[] = 'شماره سفارش: ' . $order;
		}

		WCMA_Chatbot::log_message( $chat_id, 'in', 'visitor', implode( "\n", $summary ), 'lead_form' );

		$thanks = (string) WCMA_Settings::get( 'lc_lead_form_thanks', '' );

		if ( $thanks ) {
			WCMA_Chatbot::send( $chat_id, $thanks, 'bot', 'lead_form' );
		}

		self::touch_visitor( $chat_id, $request );

		return new WP_REST_Response(
			array( 'ok' => true, 'message' => $thanks, 'contact' => (int) $contact_id ),
			200
		);
	}

	/**
	 * دریافت فایل یا پیام صوتی از بازدیدکننده.
	 *
	 * فایل در همان لحظه به یک پیام تبدیل می‌شود تا فایلِ بی‌صاحب روی هاست
	 * نماند؛ اگر ثبت پیام شکست بخورد، فایل هم برداشته می‌شود.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_upload( $request ) {
		global $wpdb;

		if ( ! self::is_active() ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'گفتگوی آنلاین فعال نیست.' ), 200 );
		}

		if ( ! WCMA_Chat_Files::enabled() ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'ارسال فایل در گفتگو خاموش است.' ), 200 );
		}

		$token = self::visitor_token( $request );

		if ( ! $token ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'نشست معتبر نیست.' ), 200 );
		}

		if ( ! self::rate_ok( $token ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => 'ارسال‌های زیادی انجام شده. کمی صبر کنید.' ), 200 );
		}

		$files = $request->get_file_params();
		$file  = $files['file'] ?? null;
		$saved = WCMA_Chat_Files::store( $file, (int) $request->get_param( 'duration' ) );

		if ( is_wp_error( $saved ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'message' => $saved->get_error_message() ), 200 );
		}

		$chat = self::find( $token );

		if ( ! $chat ) {
			$chat = self::create( $token, $request );
		}

		if ( ! $chat ) {
			// گفتگو ساخته نشد؛ فایل نباید یتیم روی دیسک بماند.
			$path = WCMA_Chat_Files::path( $saved['file'] );

			if ( $path && file_exists( $path ) ) {
				@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}

			return new WP_REST_Response( array( 'ok' => false, 'message' => 'گفتگو ساخته نشد.' ), 200 );
		}

		$chat_id = (int) $chat['id'];
		$label   = 'audio' === $saved['kind'] ? WCMA_Chat_Files::VOICE_LABEL : $saved['name'];
		$now     = current_time( 'mysql' );

		self::touch_visitor( $chat_id, $request );
		self::fill_identity( $chat, $request );

		$wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_Chatbot::chats_table(),
			array(
				'unread'          => (int) $chat['unread'] + 1,
				'status'          => 'open',
				'last_message'    => mb_substr( $label, 0, 300 ),
				'last_message_at' => $now,
			),
			array( 'id' => $chat_id )
		);

		WCMA_Chatbot::log_message( $chat_id, 'in', 'customer', $label, '', 'sent', $saved, (int) $request->get_param( 'reply' ) );

		self::notify_agent( $chat_id, $label );

		return new WP_REST_Response(
			array(
				'ok'    => true,
				'token' => $token,
				'chat'  => $chat_id,
				'file'  => array(
					'url'   => $saved['url'],
					'name'  => $saved['name'],
					'kind'  => $saved['kind'],
					'mime'  => $saved['mime'],
					'size'  => $saved['size'],
					'human' => WCMA_Chat_Files::human_size( $saved['size'] ),
					'ms'    => $saved['ms'],
					'clock' => WCMA_Chat_Files::clock( $saved['ms'] ),
				),
				'body'  => $label,
				'date'  => WCMA_Date::format( null, 'time' ),
			),
			200
		);
	}

	/**
	 * تکمیل نام و راه تماس گفتگوی موجود از روی داده‌ی همراه پیام.
	 *
	 * مقدارهای موجود بازنویسی نمی‌شوند تا چیزی از دست نرود.
	 *
	 * @param array           $chat    گفتگو.
	 * @param WP_REST_Request $request درخواست.
	 */
	protected static function fill_identity( array &$chat, $request ) {
		global $wpdb;

		$update = array();
		$name   = trim( sanitize_text_field( (string) $request->get_param( 'name' ) ) );
		$phone  = WCMA_SMS_Gateways::normalize_phone( (string) $request->get_param( 'phone' ) );
		$email  = sanitize_email( (string) $request->get_param( 'email' ) );

		if ( $name && empty( $chat['name'] ) ) {
			$update['name'] = mb_substr( $name, 0, 120 );
		}

		if ( $phone && empty( $chat['phone'] ) ) {
			$update['phone'] = $phone;
		}

		if ( $email && is_email( $email ) && empty( $chat['email'] ) ) {
			$update['email'] = $email;
		}

		if ( ! $update ) {
			return;
		}

		$wpdb->update( WCMA_Chatbot::chats_table(), $update, array( 'id' => (int) $chat['id'] ) ); // phpcs:ignore WordPress.DB

		$chat = array_merge( $chat, $update );

		if ( empty( $chat['contact_id'] ) ) {
			WCMA_Chatbot::link_contact( $chat );
		}
	}

	/**
	 * دریافت پیام‌های تازه‌ی اپراتور.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_poll( $request ) {
		global $wpdb;

		$token = self::visitor_token( $request );
		$chat  = $token ? self::find( $token ) : null;

		if ( ! $chat ) {
			return new WP_REST_Response( array( 'ok' => true, 'messages' => array() ), 200 );
		}

		$chat_id = (int) $chat['id'];
		$since   = max( 0, (int) $request->get_param( 'since' ) );

		self::touch_visitor( $chat_id, $request );

		$table = WCMA_Chatbot::messages_table();

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT id, sender, direction, body, att_file, att_name, att_kind, att_mime, att_size, att_ms, reply_to, created_at FROM {$table} WHERE chat_id = %d AND id > %d AND direction = 'out' ORDER BY id ASC LIMIT 30", // phpcs:ignore WordPress.DB
				$chat_id,
				$since
			),
			ARRAY_A
		);

		$messages = self::shape_messages( (array) $rows, false );

		$typing = $chat['agent_typing_at'] && ( time() - strtotime( $chat['agent_typing_at'] ) ) < 8;

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'messages' => $messages,
				'typing'   => (bool) $typing,
				'online'   => self::agent_online(),
				'mode'     => $chat['mode'],
			),
			200
		);
	}

	/**
	 * به‌روزرسانی اطلاعات بازدیدکننده: صفحه، تایپ، مشخصات و امتیاز.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_meta( $request ) {
		global $wpdb;

		$token = self::visitor_token( $request );
		$chat  = $token ? self::find( $token ) : null;

		if ( ! $chat ) {
			return new WP_REST_Response( array( 'ok' => false ), 200 );
		}

		$chat_id = (int) $chat['id'];
		$table   = WCMA_Chatbot::chats_table();
		$update  = array();

		if ( $request->get_param( 'typing' ) ) {
			$update['visitor_typing_at'] = current_time( 'mysql' );
		}

		$name  = trim( sanitize_text_field( (string) $request->get_param( 'name' ) ) );
		$phone = WCMA_SMS_Gateways::normalize_phone( (string) $request->get_param( 'phone' ) );
		$email = sanitize_email( (string) $request->get_param( 'email' ) );

		if ( $name ) {
			$update['name'] = mb_substr( $name, 0, 120 );
		}

		if ( $phone ) {
			$update['phone'] = $phone;
		}

		if ( $email && is_email( $email ) ) {
			$update['email'] = $email;
		}

		$rating = (int) $request->get_param( 'rating' );

		if ( $rating >= 1 && $rating <= 5 ) {
			$update['rating']      = $rating;
			$update['rating_note'] = mb_substr( sanitize_text_field( (string) $request->get_param( 'note' ) ), 0, 250 );
		}

		if ( $update ) {
			$wpdb->update( $table, $update, array( 'id' => $chat_id ) ); // phpcs:ignore WordPress.DB
		}

		self::touch_visitor( $chat_id, $request );

		// با گرفتن نام و راه تماس، پرونده‌ی CRM هم ساخته یا کامل می‌شود.
		if ( $phone || $email ) {
			WCMA_Chatbot::link_contact( array_merge( $chat, $update, array( 'id' => $chat_id, 'contact_id' => 0 ) ) );
		}

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * ساخت گفتگوی تازه برای بازدیدکننده.
	 *
	 * @param string          $token   شناسه.
	 * @param WP_REST_Request $request درخواست.
	 * @return array|null
	 */
	protected static function create( $token, $request ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return null;
		}

		$agent = self::client_agent();
		$now   = current_time( 'mysql' );
		$user  = wp_get_current_user();

		$name  = trim( sanitize_text_field( (string) $request->get_param( 'name' ) ) );
		$phone = WCMA_SMS_Gateways::normalize_phone( (string) $request->get_param( 'phone' ) );
		$email = sanitize_email( (string) $request->get_param( 'email' ) );

		if ( $user && $user->ID ) {
			$name  = $name ? $name : $user->display_name;
			$email = $email ? $email : $user->user_email;
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			WCMA_Chatbot::chats_table(),
			array(
				'channel'         => self::CHANNEL,
				'chat_id'         => $token,
				'user_id'         => $user ? (int) $user->ID : 0,
				'name'            => mb_substr( $name, 0, 120 ),
				'phone'           => $phone,
				'email'           => is_email( $email ) ? $email : '',
				'mode'            => 'bot',
				'status'          => 'open',
				'unread'          => 0,
				'message_count'   => 0,
				'page_url'        => esc_url_raw( (string) $request->get_param( 'page' ) ),
				'page_title'      => mb_substr( sanitize_text_field( (string) $request->get_param( 'title' ) ), 0, 180 ),
				'referrer'        => esc_url_raw( (string) $request->get_param( 'referrer' ) ),
				'browser'         => $agent['browser'],
				'device'          => $agent['device'],
				'ip'              => self::client_ip(),
				'pages_seen'      => 1,
				'visitor_seen_at' => $now,
				'created_at'      => $now,
			)
		);

		$chat = self::find( $token );

		if ( $chat && ( $phone || $email ) ) {
			WCMA_Chatbot::link_contact( $chat );
		}

		return $chat;
	}

	/**
	 * ثبت آخرین حضور و صفحه‌ی بازدیدکننده.
	 *
	 * @param int             $chat_id گفتگو.
	 * @param WP_REST_Request $request درخواست.
	 */
	protected static function touch_visitor( $chat_id, $request ) {
		global $wpdb;

		$update = array( 'visitor_seen_at' => current_time( 'mysql' ) );
		$page   = esc_url_raw( (string) $request->get_param( 'page' ) );

		if ( $page ) {
			$update['page_url']   = $page;
			$update['page_title'] = mb_substr( sanitize_text_field( (string) $request->get_param( 'title' ) ), 0, 180 );
		}

		$wpdb->update( WCMA_Chatbot::chats_table(), $update, array( 'id' => (int) $chat_id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * پیام‌های قابل نمایش به بازدیدکننده.
	 *
	 * @param int $chat_id گفتگو.
	 * @return array
	 */
	public static function visible_messages( $chat_id ) {
		$rows = array_reverse( WCMA_Chatbot::recent_messages( $chat_id, 40 ) );

		return self::shape_messages( $rows, true );
	}

	/**
	 * تبدیل سطرهای پیام به شکلی که ویجت می‌فهمد.
	 *
	 * نقل‌قول‌ها با یک پرس‌وجو برای همه‌ی پیام‌ها گرفته می‌شود، نه یکی برای هر
	 * پیام.
	 *
	 * @param array $rows سطرها.
	 * @param bool  $mine آیا پیام بازدیدکننده باید «me» برچسب بخورد؟
	 * @return array
	 */
	protected static function shape_messages( array $rows, $mine = true ) {
		$refs = array();

		foreach ( $rows as $row ) {
			if ( ! empty( $row['reply_to'] ) ) {
				$refs[] = (int) $row['reply_to'];
			}
		}

		$quotes = $refs ? WCMA_Chatbot::quotes( $refs ) : array();
		$out    = array();

		foreach ( $rows as $row ) {
			$from = $mine && 'in' === $row['direction'] ? 'me' : $row['sender'];
			$ref  = (int) ( $row['reply_to'] ?? 0 );

			$out[] = array(
				'id'    => (int) $row['id'],
				'from'  => $from,
				'body'  => $row['body'],
				'file'  => WCMA_Chat_Files::shape( $row ),
				'date'  => WCMA_Date::mysql( $row['created_at'], 'time', '' ),
				'day'   => self::day_label( $row['created_at'] ),
				/*
				 * سنِ پیام به ثانیه، از دید خود سرور. فرستادن زمان مطلق
				 * مرورگر را درگیر منطقه‌ی زمانی و ساعت اشتباهِ دستگاه کاربر
				 * می‌کند؛ اختلاف، هر دو را دور می‌زند و مرورگر فقط زمانِ
				 * سپری‌شده از لحظه‌ی دریافت را به آن می‌افزاید.
				 */
				'ago'   => self::age( $row['created_at'] ),
				'reply' => ( $ref && isset( $quotes[ $ref ] ) ) ? array_merge( array( 'id' => $ref ), $quotes[ $ref ] ) : null,
			);
		}

		return $out;
	}

	/**
	 * سن یک پیام به ثانیه.
	 *
	 * @param string $mysql زمان ثبت.
	 * @return int
	 */
	public static function age( $mysql ) {
		$mysql = (string) $mysql;

		if ( '' === $mysql || 0 === strpos( $mysql, '0000' ) ) {
			return 0;
		}

		// created_at با current_time نوشته می‌شود، پس با همان مقیاس سنجیده می‌شود.
		$then = strtotime( $mysql );
		$now  = (int) current_time( 'timestamp' );

		if ( ! $then ) {
			return 0;
		}

		return max( 0, $now - $then );
	}

	/**
	 * خبر دادن به اپراتور که بازدیدکننده منتظر است.
	 *
	 * @param int    $chat_id گفتگو.
	 * @param string $text    متن.
	 */
	protected static function notify_agent( $chat_id, $text ) {
		if ( self::agent_online() ) {
			return;
		}

		$phone = WCMA_Settings::get( 'chat_notify_phone', '' );

		if ( ! $phone ) {
			return;
		}

		$key = 'wcma_lc_notify_' . (int) $chat_id;

		if ( get_transient( $key ) ) {
			return;
		}

		set_transient( $key, 1, 15 * MINUTE_IN_SECONDS );

		WCMA_Sender::send(
			array(
				'channel'  => 'sms',
				'to'       => $phone,
				'message'  => sprintf( 'بازدیدکننده‌ی سایت منتظر پاسخ است: %s', mb_substr( $text, 0, 80 ) ),
				'workflow' => 'livechat',
			)
		);
	}

	/**
	 * ثبت تایپ اپراتور تا بازدیدکننده «در حال نوشتن» ببیند.
	 *
	 * @param int $chat_id گفتگو.
	 */
	public static function agent_typing( $chat_id ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_Chatbot::chats_table(),
			array( 'agent_typing_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $chat_id )
		);
	}

	/**
	 * بازدیدکنندگانی که همین حالا روی سایت‌اند.
	 *
	 * @param int $limit سقف.
	 * @return array
	 */
	public static function online_visitors( $limit = 20 ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return array();
		}

		$table  = WCMA_Chatbot::chats_table();
		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - self::ONLINE_WINDOW );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE channel = %s AND visitor_seen_at >= %s ORDER BY visitor_seen_at DESC LIMIT %d", // phpcs:ignore WordPress.DB
				self::CHANNEL,
				$cutoff,
				(int) $limit
			),
			ARRAY_A
		);

		return $rows ? $rows : array();
	}

	/**
	 * آیا بازدیدکننده‌ی این گفتگو همین حالا آنلاین است؟
	 *
	 * @param array $chat گفتگو.
	 * @return bool
	 */
	public static function visitor_online( array $chat ) {
		if ( empty( $chat['visitor_seen_at'] ) ) {
			return false;
		}

		return ( time() - strtotime( $chat['visitor_seen_at'] ) ) < self::ONLINE_WINDOW;
	}

	/**
	 * میانگین رضایت از گفتگوها.
	 *
	 * @return array{avg:float,count:int}
	 */
	public static function rating_summary() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return array( 'avg' => 0.0, 'count' => 0 );
		}

		$table = WCMA_Chatbot::chats_table();

		$row = $wpdb->get_row( "SELECT AVG(rating) AS avg_rating, COUNT(*) AS c FROM {$table} WHERE rating > 0", ARRAY_A ); // phpcs:ignore WordPress.DB

		return array(
			'avg'   => round( (float) ( $row['avg_rating'] ?? 0 ), 1 ),
			'count' => (int) ( $row['c'] ?? 0 ),
		);
	}
}
