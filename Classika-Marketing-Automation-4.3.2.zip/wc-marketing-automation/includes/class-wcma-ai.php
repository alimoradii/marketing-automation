<?php
/**
 * تولید محتوای بازاریابی با هوش مصنوعی.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_AI
 */
class WCMA_AI {

	/**
	 * ارائه‌دهندگان پشتیبانی‌شده.
	 *
	 * @return array
	 */
	public static function providers() {
		return array(
			'openai'            => array(
				'label'   => 'ChatGPT — OpenAI',
				'models'  => array( 'gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1' ),
				'default' => 'gpt-4o-mini',
				'help'    => 'کلید را از platform.openai.com بخش API keys بگیرید.',
			),
			'anthropic'         => array(
				'label'   => 'Claude — Anthropic',
				'models'  => array( 'claude-sonnet-5', 'claude-opus-5', 'claude-haiku-4-5-20251001' ),
				'default' => 'claude-sonnet-5',
				'help'    => 'کلید را از console.anthropic.com بگیرید.',
			),
			'gemini'            => array(
				'label'   => 'Gemini — Google',
				'models'  => array( 'gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash' ),
				'default' => 'gemini-2.0-flash',
				'help'    => 'کلید را از aistudio.google.com بخش Get API key بگیرید.',
			),
			'openai_compatible' => array(
				'label'   => 'سرویس سازگار با OpenAI (آدرس دلخواه)',
				'models'  => array(),
				'default' => '',
				'help'    => 'برای سرویس‌های واسط داخلی؛ آدرس پایه را در فیلد مربوطه وارد کنید.',
			),
		);
	}

	/**
	 * مدل‌های پیشنهادی سرویس انتخاب‌شده.
	 *
	 * @param string $provider سرویس.
	 * @return array
	 */
	public static function models_for( $provider ) {
		$providers = self::providers();

		return $providers[ $provider ]['models'] ?? array();
	}

	/**
	 * آیا سرویس هوش مصنوعی آماده‌ی استفاده است؟
	 *
	 * @return bool
	 */
	public static function is_ready() {
		return WCMA_Settings::is( 'ai_enabled' ) && WCMA_Settings::get( 'ai_api_key' );
	}

	/**
	 * قالب‌های آماده‌ی تولید محتوا.
	 *
	 * @return array
	 */
	public static function templates() {
		return array(
			'abandoned_cart'  => 'متن یادآوری سبد خرید رها شده',
			'review_request'  => 'متن درخواست ثبت نظر',
			'winback'         => 'متن بازگرداندن مشتری غیرفعال',
			'campaign_email'  => 'ایمیل کمپین تبلیغاتی',
			'campaign_sms'    => 'پیامک کمپین تبلیغاتی (حداکثر ۲ بخش)',
			'discount_offer'  => 'اعلام تخفیف ویژه',
			'product_intro'   => 'معرفی محصول جدید',
			'birthday'        => 'پیام تبریک تولد',
			'chat_reply'      => 'پاسخ گفتگوی پشتیبانی',
		);
	}

	/**
	 * تولید محتوا.
	 *
	 * @param string $template نوع محتوا.
	 * @param array  $args     پارامترها.
	 * @return array{success:bool,content:string,message:string}
	 */
	public static function generate( $template, array $args = array() ) {
		if ( ! self::is_ready() ) {
			return self::fail( 'سرویس هوش مصنوعی فعال نیست یا کلید API وارد نشده است.' );
		}

		$args['template'] = $template;

		$prompt = self::build_prompt( $template, $args );
		$system = self::system_prompt( $args );

		$provider = WCMA_Settings::get( 'ai_provider', 'openai' );

		switch ( $provider ) {
			case 'anthropic':
				return self::call_anthropic( $system, $prompt );
			case 'gemini':
				return self::call_gemini( $system, $prompt );
		}

		return self::call_openai( $system, $prompt );
	}

	/**
	 * دستور سیستمی.
	 *
	 * @param array $args پارامترها.
	 * @return string
	 */
	protected static function system_prompt( array $args ) {
		$tone     = WCMA_Settings::get( 'ai_tone', 'صمیمی و حرفه‌ای' );
		$context  = WCMA_Settings::get( 'ai_business_context', '' );
		$store    = get_bloginfo( 'name' );
		$language = 'fa' === WCMA_Settings::get( 'ai_language', 'fa' ) ? 'فارسی' : 'انگلیسی';

		$system = "تو یک کپی‌رایتر حرفه‌ای بازاریابی برای فروشگاه اینترنتی «{$store}» هستی. "
			. "همه‌ی متن‌ها را به زبان {$language} و با لحن {$tone} بنویس. "
			. 'متن باید کوتاه، طبیعی، بدون اغراق و دارای دعوت به اقدام روشن باشد. '
			. 'فقط از این متغیرها و در جای مناسب استفاده کن، آن‌ها را ترجمه یا تغییر نده و متغیر جدیدی نساز:' . "\n"
			. self::placeholder_brief( $args['template'] ?? '' ) . "\n"
			. 'فقط خود متن نهایی را برگردان، بدون توضیح اضافه و بدون علامت نقل قول.';

		if ( $context ) {
			$system .= " اطلاعات کسب‌وکار: {$context}";
		}

		return $system;
	}

	/**
	 * ساخت پرامپت بر اساس نوع محتوا.
	 *
	 * @param string $template نوع.
	 * @param array  $args     پارامترها.
	 * @return string
	 */
	/**
	 * متغیرهای مناسب هر قالب، برای معرفی به مدل زبانی.
	 *
	 * @param string $template قالب.
	 * @return array
	 */
	protected static function template_placeholders( $template ) {
		$common = array( 'first_name', 'full_name', 'site_title', 'site_url', 'shop_phone', 'today', 'weekday' );

		$map = array(
			'abandoned_cart' => array( 'cart_items', 'cart_total', 'cart_count', 'recovery_link', 'coupon_code', 'coupon_expiry' ),
			'review_request' => array( 'product_name', 'product_link', 'order_number', 'order_date', 'order_items' ),
			'winback'        => array( 'order_date', 'order_count', 'customer_total', 'coupon_code', 'coupon_amount', 'coupon_expiry' ),
			'campaign_email' => array( 'coupon_code', 'coupon_amount', 'coupon_expiry', 'unsubscribe' ),
			'campaign_sms'   => array( 'coupon_code', 'coupon_expiry' ),
			'discount_offer' => array( 'coupon_code', 'coupon_amount', 'coupon_expiry', 'product_name', 'product_price' ),
			'product_intro'  => array( 'product_name', 'product_link', 'product_price', 'stock_qty' ),
			'birthday'       => array( 'coupon_code', 'coupon_amount', 'coupon_expiry' ),
			'chat_reply'     => array( 'order_number', 'order_status', 'order_link', 'product_name', 'product_price' ),
			'stock_alert'    => array( 'product_name', 'product_link', 'product_price', 'stock_qty', 'cancel_link' ),
			'vip'            => array( 'vip_tier', 'vip_perk', 'vip_total', 'vip_orders', 'vip_next_tier', 'vip_next_remaining', 'coupon_code' ),
			'order_status'   => array( 'order_number', 'order_total', 'order_status', 'order_date', 'order_items', 'order_link', 'payment_link' ),
		);

		return array_merge( $common, $map[ $template ] ?? array() );
	}

	/**
	 * فهرست متغیرها همراه با کارکردشان، به‌شکل متن کوتاه برای پرامپت.
	 *
	 * @param string $template قالب.
	 * @return string
	 */
	protected static function placeholder_brief( $template ) {
		$lines = array();

		foreach ( self::template_placeholders( $template ) as $tag ) {
			$info = WCMA_Placeholders::info( $tag );

			if ( $info ) {
				$lines[] = '- {' . trim( $tag, '{}' ) . '}: ' . $info['label'];
			}
		}

		return implode( "\n", $lines );
	}

	protected static function build_prompt( $template, array $args ) {
		$channel = $args['channel'] ?? 'email';
		$extra   = trim( (string) ( $args['brief'] ?? '' ) );

		$limit = 'sms' === $channel
			? 'متن باید حداکثر ۳۰۰ کاراکتر و بدون HTML باشد.'
			: 'متن را با تگ‌های ساده‌ی HTML مانند <p> و <strong> و <a> بنویس. از تصویر و CSS استفاده نکن.';

		$map = array(
			'abandoned_cart' => 'یک پیام یادآوری برای مشتری‌ای بنویس که محصولاتی را در سبد خرید رها کرده و خرید را تکمیل نکرده است. او را بدون فشار به تکمیل خرید تشویق کن و لینک {recovery_link} را قرار بده.',
			'review_request' => 'یک پیام بنویس که از مشتری بابت خرید {product_name} تشکر کند و مؤدبانه از او بخواهد نظرش را ثبت کند. لینک {product_link} را قرار بده.',
			'winback'        => 'یک پیام بنویس برای مشتری‌ای که مدتی است خرید نکرده است. با لحنی دوستانه او را به بازگشت دعوت کن و کد تخفیف {coupon_code} با اعتبار تا {coupon_expiry} را معرفی کن.',
			'campaign_email' => 'یک ایمیل تبلیغاتی کامل بنویس.',
			'campaign_sms'   => 'یک پیامک تبلیغاتی کوتاه و مؤثر بنویس.',
			'discount_offer' => 'یک پیام برای اعلام تخفیف ویژه بنویس و حس فوریت ملایمی ایجاد کن. کد تخفیف {coupon_code} را ذکر کن.',
			'product_intro'  => 'یک پیام برای معرفی محصول جدید {product_name} بنویس و مزیت اصلی آن را برجسته کن.',
			'birthday'       => 'یک پیام تبریک تولد گرم و کوتاه بنویس و هدیه‌ی کد تخفیف {coupon_code} را اعلام کن.',
			'chat_reply'     => 'به پیام مشتری در گفتگوی پشتیبانی پاسخ بده. کوتاه، محترمانه و دقیق باش و چیزی از خودت نساز.',
		);

		$base = $map[ $template ] ?? 'یک پیام بازاریابی مؤثر بنویس.';

		$prompt = $base . ' ' . $limit;

		if ( $extra ) {
			$prompt .= "\n\nنکات و اطلاعات تکمیلی که باید رعایت شود:\n" . $extra;
		}

		return $prompt;
	}

	/**
	 * فراخوانی OpenAI یا سرویس سازگار.
	 *
	 * @param string $system دستور سیستمی.
	 * @param string $prompt پرامپت.
	 * @return array
	 */
	protected static function call_openai( $system, $prompt ) {
		$base = WCMA_Settings::get( 'ai_base_url' );
		$url  = $base ? rtrim( $base, '/' ) . '/chat/completions' : 'https://api.openai.com/v1/chat/completions';

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 60,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . WCMA_Settings::get( 'ai_api_key' ),
				),
				'body'    => wp_json_encode(
					array(
						'model'       => WCMA_Settings::get( 'ai_model', 'gpt-4o-mini' ),
						'max_tokens'  => (int) WCMA_Settings::get( 'ai_max_tokens', 800 ),
						'temperature' => 0.8,
						'messages'    => array(
							array(
								'role'    => 'system',
								'content' => $system,
							),
							array(
								'role'    => 'user',
								'content' => $prompt,
							),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['error']['message'] ) ) {
			return self::fail( $body['error']['message'] );
		}

		$content = $body['choices'][0]['message']['content'] ?? '';

		if ( '' === trim( (string) $content ) ) {
			return self::fail( 'پاسخی از سرویس هوش مصنوعی دریافت نشد.' );
		}

		return self::ok( trim( $content ) );
	}

	/**
	 * فراخوانی Anthropic.
	 *
	 * @param string $system دستور سیستمی.
	 * @param string $prompt پرامپت.
	 * @return array
	 */
	protected static function call_anthropic( $system, $prompt ) {
		$response = wp_remote_post(
			'https://api.anthropic.com/v1/messages',
			array(
				'timeout' => 60,
				'headers' => array(
					'Content-Type'      => 'application/json',
					'x-api-key'         => WCMA_Settings::get( 'ai_api_key' ),
					'anthropic-version' => '2023-06-01',
				),
				'body'    => wp_json_encode(
					array(
						'model'      => WCMA_Settings::get( 'ai_model', 'claude-sonnet-5' ),
						'max_tokens' => (int) WCMA_Settings::get( 'ai_max_tokens', 800 ),
						'system'     => $system,
						'messages'   => array(
							array(
								'role'    => 'user',
								'content' => $prompt,
							),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['error']['message'] ) ) {
			return self::fail( $body['error']['message'] );
		}

		$content = '';
		foreach ( (array) ( $body['content'] ?? array() ) as $block ) {
			if ( isset( $block['text'] ) ) {
				$content .= $block['text'];
			}
		}

		if ( '' === trim( $content ) ) {
			return self::fail( 'پاسخی از سرویس هوش مصنوعی دریافت نشد.' );
		}

		return self::ok( trim( $content ) );
	}

	/**
	 * فراخوانی Google Gemini.
	 *
	 * @param string $system دستور سیستمی.
	 * @param string $prompt پرامپت.
	 * @return array
	 */
	protected static function call_gemini( $system, $prompt ) {
		$model = WCMA_Settings::get( 'ai_model' );
		$model = $model ? $model : 'gemini-2.0-flash';

		$url = sprintf(
			'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent',
			rawurlencode( $model )
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 60,
				'headers' => array(
					'Content-Type'   => 'application/json',
					'x-goog-api-key' => WCMA_Settings::get( 'ai_api_key' ),
				),
				'body'    => wp_json_encode(
					array(
						'systemInstruction' => array(
							'parts' => array( array( 'text' => $system ) ),
						),
						'contents'          => array(
							array(
								'role'  => 'user',
								'parts' => array( array( 'text' => $prompt ) ),
							),
						),
						'generationConfig'  => array(
							'temperature'     => 0.8,
							'maxOutputTokens' => (int) WCMA_Settings::get( 'ai_max_tokens', 800 ),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::fail( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['error']['message'] ) ) {
			return self::fail( $body['error']['message'] );
		}

		$content = '';

		foreach ( (array) ( $body['candidates'][0]['content']['parts'] ?? array() ) as $part ) {
			if ( isset( $part['text'] ) ) {
				$content .= $part['text'];
			}
		}

		if ( '' === trim( $content ) ) {
			// وقتی پاسخ به‌دلیل فیلترهای ایمنی متوقف شده باشد، علت را بگو.
			$reason = $body['candidates'][0]['finishReason'] ?? '';

			return self::fail(
				$reason
					? sprintf( 'پاسخی دریافت نشد (دلیل توقف: %s).', $reason )
					: 'پاسخی از سرویس هوش مصنوعی دریافت نشد.'
			);
		}

		return self::ok( trim( $content ) );
	}

	/**
	 * خروجی موفق.
	 *
	 * @param string $content محتوا.
	 * @return array
	 */
	protected static function ok( $content ) {
		return array(
			'success' => true,
			'content' => $content,
			'message' => 'محتوا با موفقیت تولید شد.',
		);
	}

	/**
	 * خروجی ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function fail( $message ) {
		return array(
			'success' => false,
			'content' => '',
			'message' => $message,
		);
	}
}
