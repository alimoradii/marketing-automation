<?php
/**
 * ثبت و بازیابی گزارش ارسال‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Logger
 */
class WCMA_Logger {

	/**
	 * نام جدول گزارش‌ها.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcma_logs';
	}

	/**
	 * ثبت یک رکورد گزارش.
	 *
	 * @param array $data داده‌ها.
	 * @return int شناسه‌ی رکورد.
	 */
	public static function add( array $data ) {
		global $wpdb;

		if ( ! WCMA_Settings::is( 'log_enabled' ) ) {
			return 0;
		}

		$row = wp_parse_args(
			$data,
			array(
				'workflow'      => '',
				'step'          => '',
				'channel'       => 'email',
				'object_type'   => 'order',
				'object_id'     => 0,
				'user_id'       => 0,
				'recipient'     => '',
				'subject'       => '',
				'message'       => '',
				'status'        => 'sent',
				'error_message' => '',
				'coupon_code'   => '',
				'converted'     => 0,
				'revenue'       => 0,
				'created_at'    => current_time( 'mysql' ),
			)
		);

		$row['subject'] = mb_substr( (string) $row['subject'], 0, 250 );

		$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB

		return (int) $wpdb->insert_id;
	}

	/**
	 * ثبت خطا و در صورت نیاز اطلاع به مدیر.
	 *
	 * @param array $data داده‌ها.
	 * @return int
	 */
	public static function add_error( array $data ) {
		$data['status'] = 'failed';
		$id             = self::add( $data );

		if ( WCMA_Settings::is( 'error_report_admin' ) ) {
			$to = WCMA_Settings::get( 'error_report_email' );
			if ( ! is_email( $to ) ) {
				$to = get_option( 'admin_email' );
			}

			$body = sprintf(
				"خطا در ارسال پیام اتوماسیون بازاریابی\n\nورک‌فلو: %s\nمرحله: %s\nکانال: %s\nگیرنده: %s\nخطا: %s\nزمان: %s",
				$data['workflow'] ?? '-',
				$data['step'] ?? '-',
				$data['channel'] ?? '-',
				$data['recipient'] ?? '-',
				$data['error_message'] ?? '-',
				current_time( 'mysql' )
			);

			wp_mail( $to, '[' . get_bloginfo( 'name' ) . '] خطای اتوماسیون بازاریابی', $body );
		}

		return $id;
	}

	/**
	 * آیا برای این شیء و مرحله قبلاً پیامی ارسال شده است؟
	 *
	 * @param string $workflow    نام ورک‌فلو.
	 * @param string $step        مرحله.
	 * @param string $object_type نوع شیء.
	 * @param int    $object_id   شناسه.
	 * @return bool
	 */
	public static function already_sent( $workflow, $step, $object_type, $object_id ) {
		global $wpdb;

		$table = self::table();
		$count = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE workflow = %s AND step = %s AND object_type = %s AND object_id = %d AND status IN ('sent','queued')", // phpcs:ignore WordPress.DB
				$workflow,
				$step,
				$object_type,
				$object_id
			)
		);

		return $count > 0;
	}

	/**
	 * آخرین ارسال به یک کاربر در یک ورک‌فلو.
	 *
	 * @param string $workflow نام ورک‌فلو.
	 * @param int    $user_id  شناسه‌ی کاربر.
	 * @return string|null تاریخ آخرین ارسال.
	 */
	public static function last_sent_to_user( $workflow, $user_id ) {
		global $wpdb;

		$table = self::table();
		return $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT created_at FROM {$table} WHERE workflow = %s AND user_id = %d AND status = 'sent' ORDER BY created_at DESC LIMIT 1", // phpcs:ignore WordPress.DB
				$workflow,
				$user_id
			)
		);
	}

	/**
	 * دریافت گزارش‌ها با فیلتر.
	 *
	 * @param array $args آرگومان‌ها.
	 * @return array{items:array,total:int}
	 */
	public static function query( array $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'workflow' => '',
				'channel'  => '',
				'status'   => '',
				'search'   => '',
				'from'     => '',
				'to'       => '',
				'per_page' => 25,
				'page'     => 1,
			)
		);

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $args['workflow'] ) {
			$where[]  = 'workflow = %s';
			$params[] = $args['workflow'];
		}
		if ( $args['channel'] ) {
			$where[]  = 'channel = %s';
			$params[] = $args['channel'];
		}
		if ( $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}
		if ( $args['search'] ) {
			$where[]  = '(recipient LIKE %s OR subject LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$params[] = $like;
			$params[] = $like;
		}
		if ( $args['from'] ) {
			$where[]  = 'created_at >= %s';
			$params[] = $args['from'] . ' 00:00:00';
		}
		if ( $args['to'] ) {
			$where[]  = 'created_at <= %s';
			$params[] = $args['to'] . ' 23:59:59';
		}

		$where_sql = implode( ' AND ', $where );
		$per_page  = max( 1, (int) $args['per_page'] );
		$offset    = ( max( 1, (int) $args['page'] ) - 1 ) * $per_page;

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total     = (int) $wpdb->get_var( $params ? $wpdb->prepare( $count_sql, $params ) : $count_sql ); // phpcs:ignore WordPress.DB

		$list_sql    = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";
		$list_params = array_merge( $params, array( $per_page, $offset ) );
		$items       = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return array(
			'items' => $items ? $items : array(),
			'total' => $total,
		);
	}

	/**
	 * آمار کلی برای داشبورد گزارش‌ها.
	 *
	 * @param int $days بازه‌ی زمانی به روز.
	 * @return array
	 */
	public static function stats( $days = 30 ) {
		global $wpdb;

		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( (int) $days * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DateTime

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT workflow, channel, status, COUNT(*) AS total, SUM(converted) AS conversions, SUM(revenue) AS revenue
				 FROM {$table} WHERE created_at >= %s GROUP BY workflow, channel, status", // phpcs:ignore WordPress.DB
				$since
			),
			ARRAY_A
		);

		$daily = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT DATE(created_at) AS day, COUNT(*) AS total, SUM(status = 'failed') AS failed
				 FROM {$table} WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY day ASC", // phpcs:ignore WordPress.DB
				$since
			),
			ARRAY_A
		);

		$summary = array(
			'sent'        => 0,
			'failed'      => 0,
			'conversions' => 0,
			'revenue'     => 0.0,
			'by_workflow' => array(),
			'by_channel'  => array(),
			'daily'       => $daily ? $daily : array(),
		);

		foreach ( (array) $rows as $row ) {
			$total = (int) $row['total'];

			if ( 'failed' === $row['status'] ) {
				$summary['failed'] += $total;
			} else {
				$summary['sent'] += $total;
			}

			$summary['conversions'] += (int) $row['conversions'];
			$summary['revenue']     += (float) $row['revenue'];

			$wf = $row['workflow'] ? $row['workflow'] : 'unknown';
			if ( ! isset( $summary['by_workflow'][ $wf ] ) ) {
				$summary['by_workflow'][ $wf ] = array(
					'sent'        => 0,
					'failed'      => 0,
					'conversions' => 0,
					'revenue'     => 0.0,
				);
			}
			if ( 'failed' === $row['status'] ) {
				$summary['by_workflow'][ $wf ]['failed'] += $total;
			} else {
				$summary['by_workflow'][ $wf ]['sent'] += $total;
			}
			$summary['by_workflow'][ $wf ]['conversions'] += (int) $row['conversions'];
			$summary['by_workflow'][ $wf ]['revenue']     += (float) $row['revenue'];

			$ch = $row['channel'] ? $row['channel'] : 'email';
			if ( ! isset( $summary['by_channel'][ $ch ] ) ) {
				$summary['by_channel'][ $ch ] = 0;
			}
			$summary['by_channel'][ $ch ] += $total;
		}

		return $summary;
	}

	/**
	 * آمار یک بازه‌ی دلخواه، برای گزارش رسمی مدیریت.
	 *
	 * @param string $from تاریخ شروع (Y-m-d) یا خالی.
	 * @param string $to   تاریخ پایان (Y-m-d) یا خالی.
	 * @return array
	 */
	public static function range_stats( $from = '', $to = '' ) {
		global $wpdb;

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $from ) {
			$where[]  = 'created_at >= %s';
			$params[] = $from . ' 00:00:00';
		}

		if ( $to ) {
			$where[]  = 'created_at <= %s';
			$params[] = $to . ' 23:59:59';
		}

		$clause = implode( ' AND ', $where );

		$sql = "SELECT workflow, channel, status, COUNT(*) AS total, SUM(converted) AS conversions, SUM(revenue) AS revenue
				FROM {$table} WHERE {$clause} GROUP BY workflow, channel, status";

		$rows = $params
			? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) // phpcs:ignore WordPress.DB
			: $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB

		$daily_sql = "SELECT DATE(created_at) AS day, COUNT(*) AS total,
					SUM(status = 'failed') AS failed, SUM(converted) AS conversions, SUM(revenue) AS revenue
					FROM {$table} WHERE {$clause} GROUP BY DATE(created_at) ORDER BY day ASC";

		$daily = $params
			? $wpdb->get_results( $wpdb->prepare( $daily_sql, $params ), ARRAY_A ) // phpcs:ignore WordPress.DB
			: $wpdb->get_results( $daily_sql, ARRAY_A ); // phpcs:ignore WordPress.DB

		$summary = array(
			'sent'        => 0,
			'failed'      => 0,
			'conversions' => 0,
			'revenue'     => 0.0,
			'by_workflow' => array(),
			'by_channel'  => array(),
			'daily'       => $daily ? $daily : array(),
			'from'        => $from,
			'to'          => $to,
		);

		foreach ( (array) $rows as $row ) {
			$total  = (int) $row['total'];
			$failed = 'failed' === $row['status'];

			if ( $failed ) {
				$summary['failed'] += $total;
			} else {
				$summary['sent'] += $total;
			}

			$summary['conversions'] += (int) $row['conversions'];
			$summary['revenue']     += (float) $row['revenue'];

			$wf = $row['workflow'] ? $row['workflow'] : 'unknown';

			if ( ! isset( $summary['by_workflow'][ $wf ] ) ) {
				$summary['by_workflow'][ $wf ] = array( 'sent' => 0, 'failed' => 0, 'conversions' => 0, 'revenue' => 0.0 );
			}

			$summary['by_workflow'][ $wf ][ $failed ? 'failed' : 'sent' ] += $total;
			$summary['by_workflow'][ $wf ]['conversions']                 += (int) $row['conversions'];
			$summary['by_workflow'][ $wf ]['revenue']                     += (float) $row['revenue'];

			$ch = $row['channel'] ? $row['channel'] : 'email';

			if ( ! isset( $summary['by_channel'][ $ch ] ) ) {
				$summary['by_channel'][ $ch ] = array( 'sent' => 0, 'failed' => 0 );
			}

			$summary['by_channel'][ $ch ][ $failed ? 'failed' : 'sent' ] += $total;
		}

		// پرکارترین ورک‌فلو بالا بیاید.
		uasort(
			$summary['by_workflow'],
			static function ( $a, $b ) {
				return ( $b['sent'] + $b['failed'] ) <=> ( $a['sent'] + $a['failed'] );
			}
		);

		return $summary;
	}

	/**
	 * علامت‌گذاری تبدیل (خرید انجام‌شده در پی یک پیام).
	 *
	 * @param int   $log_id  شناسه‌ی گزارش.
	 * @param float $revenue مبلغ.
	 */
	public static function mark_converted( $log_id, $revenue = 0 ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'converted' => 1,
				'revenue'   => (float) $revenue,
			),
			array( 'id' => (int) $log_id )
		);
	}

	/**
	 * حذف گزارش‌های قدیمی.
	 */
	public static function purge_old() {
		global $wpdb;

		$days = (int) WCMA_Settings::get( 'log_retention_days', 90 );
		if ( $days < 1 ) {
			return;
		}

		$table = self::table();
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "DELETE FROM {$table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)", $days ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * پاک کردن کل گزارش‌ها.
	 */
	public static function clear_all() {
		global $wpdb;
		$table = self::table();
		$wpdb->query( "TRUNCATE TABLE {$table}" ); // phpcs:ignore WordPress.DB
	}
}
