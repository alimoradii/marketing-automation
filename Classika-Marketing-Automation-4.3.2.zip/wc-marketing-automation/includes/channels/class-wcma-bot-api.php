<?php
/**
 * ارتباط با API ربات‌های تلگرام و بله.
 *
 * پیش‌تر هر پیام یک درخواست HTTP تازه بود: جستجوی DNS، اتصال TCP و دست‌دادن
 * TLS از نو. روی میزبانی که تا سرورهای تلگرام راه دوری دارد، همین سه کار
 * بیشترِ زمانِ هر پیام را می‌گرفت و در پاسخ‌های چندپیامی (مثل خبر دادن به
 * مدیران یا ارسال گروهی) روی هم جمع می‌شد. اینجا همه‌ی تماس‌های یک درخواست
 * PHP از یک اتصالِ باز می‌گذرند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Api
 */
class WCMA_Bot_Api {

	/**
	 * دسته‌ی cURL که در طول همین درخواست PHP باز می‌ماند.
	 *
	 * @var resource|CurlHandle|null
	 */
	protected static $curl = null;

	/**
	 * شمار و زمانِ تماس‌های همین درخواست، برای سنجش سرعت.
	 *
	 * @var array{calls:int,ms:float,slowest:float}
	 */
	protected static $stats = array(
		'calls'   => 0,
		'ms'      => 0.0,
		'slowest' => 0.0,
	);

	/**
	 * نشانی پایه‌ی سرور API (بدون توکن).
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return string
	 */
	public static function host( $messenger ) {
		if ( 'telegram' === $messenger ) {
			$relay = self::relay();

			return '' !== $relay ? $relay : 'https://api.telegram.org';
		}

		if ( 'bale' === $messenger ) {
			return 'https://tapi.bale.ai';
		}

		return '';
	}

	/**
	 * نشانیِ واسطِ دلخواه برای API تلگرام، اگر تنظیم شده باشد.
	 *
	 * @return string
	 */
	public static function relay() {
		return self::clean_relay( WCMA_Settings::get( 'telegram_api_base', '' ) );
	}

	/**
	 * پاک‌سازی نشانی واسط.
	 *
	 * توکن ربات از این نشانی می‌گذرد؛ پس فقط HTTPS پذیرفته می‌شود.
	 *
	 * @param mixed $url ورودی.
	 * @return string
	 */
	public static function clean_relay( $url ) {
		$url = trim( (string) $url );

		if ( '' === $url ) {
			return '';
		}

		// «my-relay.workers.dev» بی‌پیشوند هم پذیرفته می‌شود.
		if ( false === strpos( $url, '://' ) ) {
			$url = 'https://' . ltrim( $url, '/' );
		}

		$url = esc_url_raw( $url, array( 'https' ) );

		if ( '' === $url || 0 !== stripos( $url, 'https://' ) ) {
			return '';
		}

		// پرس‌وجو و # جایی در نشانی پایه ندارند؛ «/bot…» هم خودمان می‌افزاییم.
		$url = (string) preg_replace( '/[?#].*$/', '', $url );
		$url = (string) preg_replace( '#/bot[^/]*/?$#i', '', untrailingslashit( $url ) );

		return untrailingslashit( $url );
	}

	/**
	 * توکن ربات.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return string
	 */
	public static function token( $messenger ) {
		$def = WCMA_Messengers::get( $messenger );

		return $def && ! empty( $def['token_key'] ) ? trim( (string) WCMA_Settings::get( $def['token_key'] ) ) : '';
	}

	/**
	 * نشانی پایه‌ی متدها، با توکن و / پایانی.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return string خالی اگر پشتیبانی نشود یا توکن نباشد.
	 */
	public static function base( $messenger ) {
		$host  = self::host( $messenger );
		$token = $host ? self::token( $messenger ) : '';

		return '' === $token ? '' : $host . '/bot' . $token . '/';
	}

	/**
	 * نشانی دریافت یک فایل از سرور پیام‌رسان.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $path      file_path از getFile.
	 * @return string
	 */
	public static function file_url( $messenger, $path ) {
		$host  = self::host( $messenger );
		$token = $host ? self::token( $messenger ) : '';

		return '' === $token ? '' : $host . '/file/bot' . $token . '/' . ltrim( (string) $path, '/' );
	}

	/**
	 * فراخوانی یک متد.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $method    نام متد (مثل sendMessage).
	 * @param array  $params    پارامترها.
	 * @param array  $opts      timeout، و needs_result وقتی نتیجه‌ی واقعی لازم است.
	 * @return array پاسخ رمزگشایی‌شده؛ همیشه کلید ok دارد.
	 */
	public static function call( $messenger, $method, array $params = array(), array $opts = array() ) {
		$base = self::base( $messenger );

		if ( '' === $base ) {
			return array(
				'ok'          => false,
				'description' => 'توکن ربات وارد نشده است.',
			);
		}

		// پاسخ به کاربرِ همین وب‌هوک، اگر بشود، همراه پاسخ وب‌هوک می‌رود.
		$collected = WCMA_Bot_Reply::offer( $messenger, $method, $params, $opts );

		if ( null !== $collected ) {
			return $collected;
		}

		return self::decode( self::post( $base . $method, $params, (float) ( $opts['timeout'] ?? 12 ) ) );
	}

	/**
	 * پاسخ HTTP به آرایه‌ی API.
	 *
	 * @param array|WP_Error $response پاسخ.
	 * @return array
	 */
	public static function decode( $response ) {
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'          => false,
				'description' => $response->get_error_message(),
				'transport'   => true,
			);
		}

		$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( is_array( $decoded ) && isset( $decoded['ok'] ) ) {
			return $decoded;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		return array(
			'ok'          => false,
			'error_code'  => $code,
			'description' => $code ? 'پاسخ نامعتبر از سرور (HTTP ' . $code . ')' : 'پاسخ نامعتبر از سرور',
			'transport'   => true,
		);
	}

	/**
	 * فرستادن درخواست POST.
	 *
	 * با cURL و یک اتصال ماندگار؛ اگر cURL نباشد یا کسی آن را خاموش کرده
	 * باشد، همان wp_remote_post همیشگی.
	 *
	 * @param string $url     نشانی.
	 * @param array  $fields  پارامترها.
	 * @param float  $timeout مهلت (ثانیه).
	 * @return array|WP_Error
	 */
	public static function post( $url, array $fields, $timeout = 12 ) {
		$fields  = self::fields( $fields );
		$timeout = max( 1, (float) $timeout );
		$began   = microtime( true );

		if ( self::keepalive( $url ) ) {
			$args = self::args( $url, $fields, $timeout );

			// همان راهی که افزونه‌های دیگر (و آزمون‌ها) برای جایگزینی پاسخ دارند.
			$pre = apply_filters( 'pre_http_request', false, $args, $url );

			if ( false !== $pre ) {
				$response = $pre;
			} else {
				$response = self::curl( $url, $args );

				do_action( 'http_api_debug', $response, 'response', 'WCMA_Bot_Api', $args, $url );
			}
		} else {
			$response = wp_remote_post(
				$url,
				array(
					'timeout' => $timeout,
					'body'    => $fields,
				)
			);
		}

		$ms = ( microtime( true ) - $began ) * 1000;

		++self::$stats['calls'];
		self::$stats['ms']     += $ms;
		self::$stats['slowest'] = max( self::$stats['slowest'], $ms );

		return $response;
	}

	/**
	 * آرگومان‌های درخواست، از همان فیلتری که وردپرس به کار می‌برد.
	 *
	 * @param string $url     نشانی.
	 * @param array  $fields  پارامترها.
	 * @param float  $timeout مهلت.
	 * @return array
	 */
	public static function args( $url, array $fields, $timeout ) {
		$args = (array) apply_filters(
			'http_request_args',
			array(
				'method'              => 'POST',
				'timeout'             => $timeout,
				'redirection'         => 0,
				'httpversion'         => '1.1',
				'user-agent'          => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . home_url( '/' ),
				'reject_unsafe_urls'  => false,
				'blocking'            => true,
				'headers'             => array(),
				'cookies'             => array(),
				'body'                => $fields,
				'compress'            => false,
				'decompress'          => true,
				'sslverify'           => true,
				'sslcertificates'     => ABSPATH . WPINC . '/certificates/ca-bundle.crt',
				'stream'              => false,
				'filename'            => null,
				'limit_response_size' => null,
			),
			$url
		);

		// همان فیلتری که wp_remote_post می‌گذراند؛ بعضی میزبان‌ها با آن مشکل گواهی را دور می‌زنند.
		$args['sslverify'] = (bool) apply_filters( 'https_ssl_verify', ! empty( $args['sslverify'] ), $url );

		return $args;
	}

	/**
	 * آمار تماس‌های همین درخواست.
	 *
	 * @return array{calls:int,ms:float,slowest:float}
	 */
	public static function stats() {
		return self::$stats;
	}

	/**
	 * آیا تماس از اتصال ماندگار بگذرد؟
	 *
	 * @param string $url نشانی.
	 * @return bool
	 */
	protected static function keepalive( $url ) {
		if ( ! function_exists( 'curl_init' ) || ! function_exists( 'curl_reset' ) || ! function_exists( 'curl_setopt_array' ) ) {
			return false;
		}

		// WP_HTTP_BLOCK_EXTERNAL: بگذار خودِ وردپرس درخواست را رد کند.
		if ( class_exists( 'WP_Http' ) ) {
			$http = new WP_Http();

			if ( $http->block_request( $url ) ) {
				return false;
			}
		}

		/**
		 * خاموش کردن اتصال ماندگار و برگشت به wp_remote_post.
		 *
		 * @param bool   $on  روشن.
		 * @param string $url نشانی.
		 */
		return (bool) apply_filters( 'wcma_bot_keepalive', true, $url );
	}

	/**
	 * پارامترها به شکلی که API می‌پذیرد.
	 *
	 * @param array $fields پارامترها.
	 * @return array
	 */
	protected static function fields( array $fields ) {
		foreach ( $fields as $key => $value ) {
			if ( is_array( $value ) || is_object( $value ) ) {
				$fields[ $key ] = wp_json_encode( $value );
			} elseif ( is_bool( $value ) ) {
				$fields[ $key ] = $value ? 'true' : 'false';
			} elseif ( null === $value ) {
				unset( $fields[ $key ] );
			}
		}

		return $fields;
	}

	/**
	 * گزینه‌ی «فقط IPv4».
	 *
	 * روی میزبان‌هایی که IPv6 دارند ولی مسیرش تا تلگرام خراب است، هر اتصال
	 * اول به IPv6 می‌رود و تا رسیدن به IPv4 معطل می‌ماند.
	 *
	 * @return bool
	 */
	public static function ipv4() {
		return WCMA_Settings::is( 'tg_ipv4' );
	}

	/**
	 * اجرای درخواست روی دسته‌ی ماندگار.
	 *
	 * @param string $url  نشانی.
	 * @param array  $args آرگومان‌های درخواست (پس از فیلتر).
	 * @return array|WP_Error
	 */
	protected static function curl( $url, array $args ) {
		if ( null === self::$curl ) {
			self::$curl = curl_init();
		} else {
			// گزینه‌ها پاک می‌شوند ولی اتصال باز، کش DNS و نشست TLS می‌مانند.
			curl_reset( self::$curl );
		}

		$handle = self::$curl;

		self::prepare( $handle, $url, $args );

		$result = curl_exec( $handle );

		if ( false === $result ) {
			$error = new WP_Error( 'http_request_failed', 'cURL error ' . curl_errno( $handle ) . ': ' . curl_error( $handle ) );

			// اتصالِ خراب نباید تماس بعدی را هم خراب کند.
			self::close();

			return $error;
		}

		$code = (int) curl_getinfo( $handle, CURLINFO_HTTP_CODE );

		return array(
			'headers'  => array(),
			'body'     => (string) $result,
			'response' => array(
				'code'    => $code,
				'message' => get_status_header_desc( $code ),
			),
			'cookies'  => array(),
			'filename' => null,
		);
	}

	/**
	 * گزینه‌های cURL یک درخواست.
	 *
	 * @param resource|CurlHandle $handle دسته.
	 * @param string              $url    نشانی.
	 * @param array               $args   آرگومان‌ها (پس از فیلتر).
	 * @param bool|null           $ipv4   فقط IPv4؛ null یعنی از تنظیمات.
	 */
	public static function prepare( $handle, $url, array $args, $ipv4 = null ) {
		$timeout = max( 1, (float) ( $args['timeout'] ?? 12 ) );
		$verify  = ! empty( $args['sslverify'] );
		$body    = is_array( $args['body'] ?? null ) ? http_build_query( $args['body'], '', '&' ) : (string) ( $args['body'] ?? '' );

		$options = array(
			CURLOPT_URL               => $url,
			CURLOPT_POST              => true,
			CURLOPT_POSTFIELDS        => $body,
			CURLOPT_RETURNTRANSFER    => true,
			CURLOPT_HEADER            => false,
			CURLOPT_FOLLOWLOCATION    => false,
			CURLOPT_CONNECTTIMEOUT_MS => (int) ( min( $timeout, 10 ) * 1000 ),
			CURLOPT_TIMEOUT_MS        => (int) ( $timeout * 1000 ),
			CURLOPT_NOSIGNAL          => true,
			CURLOPT_SSL_VERIFYPEER    => $verify,
			CURLOPT_SSL_VERIFYHOST    => $verify ? 2 : 0,
			CURLOPT_USERAGENT         => (string) ( $args['user-agent'] ?? 'WordPress' ),
			CURLOPT_ENCODING          => '',
			CURLOPT_HTTPHEADER        => array( 'Expect:', 'Content-Type: application/x-www-form-urlencoded' ),
		);

		if ( $verify && ! empty( $args['sslcertificates'] ) && is_readable( $args['sslcertificates'] ) ) {
			$options[ CURLOPT_CAINFO ] = $args['sslcertificates'];
		}

		if ( null === $ipv4 ) {
			$ipv4 = self::ipv4();
		}

		if ( defined( 'CURL_IPRESOLVE_V4' ) ) {
			$options[ CURLOPT_IPRESOLVE ] = $ipv4 ? CURL_IPRESOLVE_V4 : CURL_IPRESOLVE_WHATEVER;
		}

		curl_setopt_array( $handle, $options );

		// پراکسیِ تعریف‌شده در wp-config.php (WP_PROXY_HOST و …).
		if ( class_exists( 'WP_HTTP_Proxy' ) ) {
			$proxy = new WP_HTTP_Proxy();

			if ( $proxy->is_enabled() && $proxy->send_through_proxy( $url ) ) {
				curl_setopt( $handle, CURLOPT_PROXYTYPE, CURLPROXY_HTTP );
				curl_setopt( $handle, CURLOPT_PROXY, $proxy->host() );
				curl_setopt( $handle, CURLOPT_PROXYPORT, (int) $proxy->port() );

				if ( $proxy->use_authentication() ) {
					curl_setopt( $handle, CURLOPT_PROXYAUTH, CURLAUTH_ANY );
					curl_setopt( $handle, CURLOPT_PROXYUSERPWD, $proxy->authentication() );
				}
			}
		}

		// افزونه‌هایی که گزینه‌ی cURL می‌افزایند (پراکسی، رابط شبکه و …) اینجا هم کار کنند.
		do_action_ref_array( 'http_api_curl', array( &$handle, $args, $url ) );
	}

	/**
	 * بستن اتصال ماندگار.
	 */
	public static function close() {
		if ( null !== self::$curl ) {
			if ( PHP_VERSION_ID < 80000 ) {
				curl_close( self::$curl ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}

			self::$curl = null;
		}
	}
}
