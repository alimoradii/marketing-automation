<?php
/**
 * مدیریت کامل ربات از درون خودِ تلگرام.
 *
 * هر چیزی که در برگه‌ی «ربات تلگرام» پیشخوان ساخته می‌شود، اینجا هم از راه
 * دکمه‌های شیشه‌ای ساخته و ویرایش می‌شود: دکمه‌های منو، پیام‌های آماده (با
 * عکس، ویدیو و فایلی که مستقیم در ربات فرستاده می‌شود)، متن‌های ربات، پیام‌های
 * روزانه، مدیران ربات و سرعت ربات.
 *
 * هر ذخیره از همان پاک‌سازی‌ای می‌گذرد که پیشخوان به کار می‌برد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Editor
 */
class WCMA_Bot_Editor extends WCMA_Bot_Admin {

	/**
	 * شماره‌ی بازنگری تنظیمات ربات؛ با هر ذخیره از تلگرام بالا می‌رود.
	 *
	 * برگه‌ای از پیشخوان که پیش از آن باز شده بود، با ذخیره‌ی خودکارش
	 * تغییرات تلگرام را برنمی‌گرداند.
	 */
	const REV = 'wcma_bot_rev';

	/**
	 * دستورهای منوی مدیریت که این کلاس پاسخ می‌دهد.
	 *
	 * @return array کلید ⇐ برچسب دکمه.
	 */
	public static function commands() {
		return array(
			'buttons_edit' => '🧩 دکمه‌های منو',
			'canned_edit'  => '🗂 پیام‌های آماده',
			'texts'        => '💬 متن‌های ربات',
			'days'         => '📅 پیام‌های روزانه',
			'admins'       => '👤 مدیران ربات',
			'speed'        => '⚡️ سرعت ربات',
		);
	}

	/**
	 * تنظیم‌هایی که از تلگرام عوض می‌شوند.
	 *
	 * @return string[]
	 */
	public static function keys() {
		return array(
			'tg_menu',
			'tg_menu_cols',
			'tg_messages',
			'tg_sequence',
			'tg_seq_enabled',
			'tg_seq_time',
			'tg_seq_first_now',
			'tg_welcome_text',
			'tg_welcome_type',
			'tg_welcome_file',
			'tg_ask_phone',
			'tg_phone_button',
			'tg_phone_thanks',
			'tg_known_text',
			'tg_bot_enabled',
			'tg_admin_notify',
			'tg_ipv4',
			'tg_fastlane',
		);
	}

	/**
	 * شماره‌ی بازنگری فعلی.
	 *
	 * @return int
	 */
	public static function rev() {
		return (int) get_option( self::REV, 0 );
	}

	/* ------------------------------------------------------------------ */
	/* ورودی‌ها                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * اجرای یک دستور منو.
	 *
	 * @param string $command دستور.
	 * @param string $chat_id چت.
	 * @return bool
	 */
	public static function run_command( $command, $chat_id ) {
		switch ( $command ) {
			case 'buttons_edit':
				self::buttons_list( $chat_id );
				return true;

			case 'canned_edit':
				self::canned_list( $chat_id );
				return true;

			case 'texts':
				self::texts_screen( $chat_id );
				return true;

			case 'days':
				self::days_list( $chat_id );
				return true;

			case 'admins':
				self::admins_list( $chat_id );
				return true;

			case 'speed':
				self::speed_run( $chat_id );
				return true;
		}

		return false;
	}

	/**
	 * دکمه‌های شیشه‌ای ویرایشگر.
	 *
	 * @param string $action بخش.
	 * @param array  $parts  تکه‌های داده‌ی دکمه.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 * @return bool
	 */
	public static function run_callback( $action, array $parts, $chat_id, array $parsed ) {
		$op = (string) ( $parts[1] ?? '' );
		$a  = (string) ( $parts[2] ?? '' );
		$b  = (string) ( $parts[3] ?? '' );
		$c  = (string) ( $parts[4] ?? '' );

		switch ( $action ) {
			case 'mb':
				self::buttons_callback( $op, $a, $b, $chat_id, $parsed );
				return true;

			case 'ms':
				self::canned_callback( $op, $a, $b, $c, $chat_id, $parsed );
				return true;

			case 'tx':
				self::texts_callback( $op, $a, $chat_id, $parsed );
				return true;

			case 'sq':
				self::days_callback( $op, $a, $b, $chat_id, $parsed );
				return true;

			case 'ad':
				self::admins_callback( $op, $a, $chat_id, $parsed );
				return true;

			case 'sp':
				self::speed_callback( $op, $a, $chat_id, $parsed );
				return true;

			case 'cl':
				self::out( $chat_id, '✔️ بسته شد.', array(), $parsed );
				return true;
		}

		return false;
	}

	/**
	 * گام بعدیِ گفتگوهای ویرایشگر.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param array  $parsed  پیام.
	 * @return bool
	 */
	public static function run_step( array $flow, $chat_id, array $parsed ) {
		$step = (string) ( $flow['step'] ?? '' );
		$text = trim( (string) ( $parsed['text'] ?? '' ) );

		switch ( $step ) {
			case 'mb_label':
				self::buttons_label( $flow, $chat_id, $text );
				return true;

			case 'mb_value':
				self::buttons_value( $flow, $chat_id, $text );
				return true;

			case 'ms_title':
				self::canned_title( $flow, $chat_id, $text );
				return true;

			case 'ms_body':
				self::canned_body( $flow, $chat_id, $parsed );
				return true;

			case 'ms_url':
				self::canned_urls( $flow, $chat_id, $text );
				return true;

			case 'ms_blabel':
				self::canned_button_label( $flow, $chat_id, $text );
				return true;

			case 'tx':
				self::texts_save( $flow, $chat_id, $parsed );
				return true;

			case 'sq_day':
				self::days_number( $chat_id, $text );
				return true;

			case 'sq_body':
				self::days_body( $flow, $chat_id, $parsed );
				return true;

			case 'sq_time':
				self::days_time( $chat_id, $text );
				return true;

			case 'ad_who':
				self::admins_add( $chat_id, $text );
				return true;
		}

		return false;
	}

	/* ------------------------------------------------------------------ */
	/* دکمه‌های منو                                                         */
	/* ------------------------------------------------------------------ */

	/**
	 * فهرست دکمه‌های منو.
	 *
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی (برای ویرایش همان پیام).
	 * @param string $note    یادداشت بالای فهرست.
	 */
	protected static function buttons_list( $chat_id, array $parsed = array(), $note = '' ) {
		$menu  = WCMA_Bot_Manager::menu();
		$lines = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>🧩 دکمه‌های منوی ربات</b> (' . WCMA_Date::number( count( $menu ) ) . ' از ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_BUTTONS ) . ')';
		$lines[] = '';

		if ( ! $menu ) {
			$lines[] = 'هنوز دکمه‌ای ندارید. با «➕ دکمه‌ی تازه» بسازید.';
		}

		foreach ( $menu as $i => $item ) {
			$lines[] = WCMA_Date::number( $i + 1 ) . '. ' . self::e( $item['label'] ) . ' — ' . self::e( self::action_summary( $item ) );
		}

		$lines[] = '';
		$lines[] = 'چینش: ' . WCMA_Date::number( WCMA_Bot_Manager::menu_columns() ) . ' دکمه در هر ردیف. روی هر دکمه بزنید تا نام، کار یا جایش را عوض کنید.';

		if ( ! WCMA_Bot_Manager::is_enabled() ) {
			$lines[] = '';
			$lines[] = '⚠️ مدیریت ربات خاموش است؛ تا روشنش نکنید (⚙️ تنظیمات) منو به کاربران نشان داده نمی‌شود.';
		}

		$rows = array();

		foreach ( array_chunk( $menu, 2, true ) as $chunk ) {
			$row = array();

			foreach ( $chunk as $i => $item ) {
				$row[] = array( self::short( $item['label'], 28 ), 'mb:o:' . $i . ':' . self::hash_button( $item ) );
			}

			$rows[] = $row;
		}

		$cols   = WCMA_Bot_Manager::menu_columns();
		$rows[] = array(
			array( '➕ دکمه‌ی تازه', 'mb:a' ),
			array( '▦ ستون‌ها: ' . WCMA_Date::number( $cols ), 'mb:c:' . ( $cols % 3 + 1 ) ),
		);
		$rows[] = array( array( '✖️ بستن', 'cl' ) );

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * خلاصه‌ی کار یک دکمه.
	 *
	 * @param array $item دکمه.
	 * @return string
	 */
	protected static function action_summary( array $item ) {
		switch ( $item['action'] ) {
			case 'message':
				$message = WCMA_Bot_Manager::get_message( $item['message'] );

				return $message ? 'پیام آماده‌ی «' . WCMA_Bot_Manager::message_title( $message ) . '»' : '⚠️ پیام آماده‌اش پاک شده';

			case 'link':
				return 'لینک ' . $item['value'];

			case 'phone':
				return 'درخواست شماره';

			case 'day':
				return 'پیام روز ' . WCMA_Date::number( (int) $item['value'] ) . ' دنباله';

			case 'stop':
				return 'لغو پیام‌های روزانه';

			case 'restart':
				return 'شروع دوباره‌ی دنباله';
		}

		return '' === trim( $item['value'] ) ? '⚠️ پاسخ ندارد' : 'پاسخ: «' . self::excerpt( $item['value'], 40 ) . '»';
	}

	/**
	 * نمایش یک دکمه.
	 *
	 * @param string $chat_id چت.
	 * @param int    $index   جای دکمه.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function button_screen( $chat_id, $index, array $parsed = array(), $note = '' ) {
		$menu = WCMA_Bot_Manager::menu();

		if ( ! isset( $menu[ $index ] ) ) {
			self::buttons_list( $chat_id, $parsed, 'این دکمه دیگر نیست.' );

			return;
		}

		$item    = $menu[ $index ];
		$ref     = $index . ':' . self::hash_button( $item );
		$actions = WCMA_Bot_Manager::button_actions();
		$lines   = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>دکمه‌ی «' . self::e( $item['label'] ) . '»</b>';
		$lines[] = 'کار: ' . self::e( $actions[ $item['action'] ] ?? $item['action'] );

		if ( 'reply' === $item['action'] || ( in_array( $item['action'], array( 'phone', 'stop', 'restart' ), true ) && '' !== $item['value'] ) ) {
			$lines[] = 'متن: ' . self::e( self::excerpt( $item['value'], 600 ) );
		} elseif ( 'message' === $item['action'] || 'link' === $item['action'] || 'day' === $item['action'] ) {
			$lines[] = self::e( self::action_summary( $item ) );
		}

		$rows = array(
			array( array( '✏️ تغییر نام', 'mb:r:' . $ref ), array( '🎯 تغییر کار', 'mb:t:' . $ref ) ),
			array( array( '⬆️ بالاتر', 'mb:u:' . $ref ), array( '⬇️ پایین‌تر', 'mb:d:' . $ref ) ),
			array( array( '🗑 حذف', 'mb:x:' . $ref ) ),
			array( array( '↩️ فهرست دکمه‌ها', 'mb:l' ) ),
		);

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * دکمه‌های شیشه‌ایِ بخش منو.
	 *
	 * @param string $op      کار.
	 * @param string $a       آرگومان اول.
	 * @param string $b       آرگومان دوم.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function buttons_callback( $op, $a, $b, $chat_id, array $parsed ) {
		if ( 'l' === $op ) {
			self::buttons_list( $chat_id, $parsed );

			return;
		}

		if ( 'a' === $op ) {
			if ( count( WCMA_Bot_Manager::menu() ) >= WCMA_Bot_Manager::MAX_BUTTONS ) {
				self::buttons_list( $chat_id, $parsed, '⚠️ منو پر است (' . WCMA_Date::number( WCMA_Bot_Manager::MAX_BUTTONS ) . ' دکمه). اول یکی را حذف کنید.' );

				return;
			}

			self::set_flow( $chat_id, array( 'step' => 'mb_label', 'mode' => 'add' ) );
			self::ask( $chat_id, "➕ <b>دکمه‌ی تازه</b>\nنام دکمه را بنویسید؛ همان چیزی که کاربر زیر کادر تایپ می‌بیند (حداکثر ۶۰ نویسه).\nمثال: 📞 تماس با ما", $parsed );

			return;
		}

		if ( 'c' === $op ) {
			self::save( array( 'tg_menu_cols' => max( 1, min( 3, (int) $a ) ) ) );
			self::buttons_list( $chat_id, $parsed, '✅ چینش منو عوض شد.' );

			return;
		}

		if ( 'k' === $op ) {
			self::buttons_kind( $chat_id, $a, $parsed );

			return;
		}

		if ( 'm' === $op ) {
			$flow = self::flow( $chat_id );

			if ( ! $flow || 'mb_value' !== ( $flow['step'] ?? '' ) || 'message' !== ( $flow['action'] ?? '' ) || ! WCMA_Bot_Manager::get_message( $a ) ) {
				self::out( $chat_id, 'این گفتگو منقضی شده است. دوباره از «' . self::commands()['buttons_edit'] . '» شروع کنید.', array(), $parsed );

				return;
			}

			self::buttons_finish( $chat_id, $flow, 'message', '', WCMA_Bot_Manager::clean_message_id( $a ), $parsed );

			return;
		}

		$menu  = WCMA_Bot_Manager::menu();
		$index = (int) $a;

		if ( ! isset( $menu[ $index ] ) || ! hash_equals( self::hash_button( $menu[ $index ] ), $b ) ) {
			self::buttons_list( $chat_id, $parsed, 'این دکمه در این فاصله تغییر کرده است؛ فهرست تازه:' );

			return;
		}

		$item = $menu[ $index ];

		switch ( $op ) {
			case 'o':
				self::button_screen( $chat_id, $index, $parsed );
				break;

			case 'r':
				self::set_flow( $chat_id, array( 'step' => 'mb_label', 'mode' => 'ren', 'i' => $index, 'h' => $b ) );
				self::ask( $chat_id, '✏️ نام تازه‌ی دکمه‌ی «' . self::e( $item['label'] ) . '» را بنویسید (حداکثر ۶۰ نویسه):', $parsed );
				break;

			case 't':
				self::set_flow( $chat_id, array( 'step' => 'mb_kind', 'mode' => 'edit', 'i' => $index, 'h' => $b, 'label' => $item['label'] ) );
				self::kind_menu( $chat_id, $item['label'], $parsed );
				break;

			case 'u':
			case 'd':
				$to = 'u' === $op ? $index - 1 : $index + 1;

				if ( isset( $menu[ $to ] ) ) {
					$menu[ $index ] = $menu[ $to ];
					$menu[ $to ]    = $item;

					self::save( array( 'tg_menu' => $menu ) );
				}

				self::buttons_list( $chat_id, $parsed, isset( $menu[ $to ] ) ? '✅ جای «' . self::e( $item['label'] ) . '» عوض شد.' : '' );
				break;

			case 'x':
				self::out(
					$chat_id,
					'🗑 دکمه‌ی «' . self::e( $item['label'] ) . '» از منو حذف شود؟',
					array(
						array( array( '✅ بله، حذف کن', 'mb:X:' . $index . ':' . $b ), array( '↩️ نه', 'mb:o:' . $index . ':' . $b ) ),
					),
					$parsed
				);
				break;

			case 'X':
				array_splice( $menu, $index, 1 );
				self::save( array( 'tg_menu' => $menu ) );
				self::buttons_list( $chat_id, $parsed, '✅ دکمه‌ی «' . self::e( $item['label'] ) . '» حذف شد.' );
				break;
		}
	}

	/**
	 * انتخاب کار دکمه.
	 *
	 * @param string $chat_id چت.
	 * @param string $label   نام دکمه.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function kind_menu( $chat_id, $label, array $parsed = array() ) {
		$rows = array();

		foreach ( WCMA_Bot_Manager::button_actions() as $key => $title ) {
			$rows[] = array( array( $title, 'mb:k:' . $key ) );
		}

		$rows[] = array( array( '❌ انصراف', 'x' ) );

		self::out( $chat_id, '🎯 با زدن «' . self::e( $label ) . '» چه شود؟', $rows, $parsed );
	}

	/**
	 * نام دکمه دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function buttons_label( array $flow, $chat_id, $text ) {
		$label = mb_substr( trim( sanitize_text_field( $text ) ), 0, 60 );
		$index = isset( $flow['i'] ) ? (int) $flow['i'] : -1;
		$error = self::label_error( $label, $index );

		if ( '' !== $error ) {
			self::ask( $chat_id, '⚠️ ' . $error . "\nنام دیگری بنویسید:" );

			return;
		}

		if ( 'ren' === ( $flow['mode'] ?? '' ) ) {
			$menu = WCMA_Bot_Manager::menu();

			if ( ! isset( $menu[ $index ] ) || ! hash_equals( self::hash_button( $menu[ $index ] ), (string) ( $flow['h'] ?? '' ) ) ) {
				self::clear_flow( $chat_id );
				self::buttons_list( $chat_id, array(), 'این دکمه در این فاصله تغییر کرده است؛ فهرست تازه:' );

				return;
			}

			$menu[ $index ]['label'] = $label;

			self::clear_flow( $chat_id );
			self::save( array( 'tg_menu' => $menu ) );
			self::button_screen( $chat_id, $index, array(), '✅ نام دکمه عوض شد. کاربران با پیام بعدی ربات، منوی تازه را می‌بینند.' );

			return;
		}

		self::set_flow(
			$chat_id,
			array(
				'step'  => 'mb_kind',
				'mode'  => 'add',
				'label' => $label,
			)
		);
		self::kind_menu( $chat_id, $label );
	}

	/**
	 * اشکالِ نام یک دکمه، یا خالی.
	 *
	 * @param string $label نام.
	 * @param int    $index جای همین دکمه (برای تغییر نام)، یا -۱.
	 * @return string
	 */
	protected static function label_error( $label, $index = -1 ) {
		if ( '' === $label ) {
			return 'نام دکمه خالی است.';
		}

		$loose = WCMA_Bot_Manager::loose( $label );

		if ( '' === $loose ) {
			return 'نام دکمه باید دست‌کم یک حرف یا عدد داشته باشد؛ ایموجیِ تنها را ربات نمی‌تواند از پیام‌های دیگر جدا کند.';
		}

		$reserved = array_merge( array_values( self::buttons() ), array_values( self::commands() ), array( self::ENTRY, (string) WCMA_Settings::get( 'tg_phone_button' ) ) );

		foreach ( $reserved as $word ) {
			if ( WCMA_Bot_Manager::loose( $word ) === $loose ) {
				return 'این نام مال دکمه‌های مدیریت یا دکمه‌ی شماره است.';
			}
		}

		foreach ( WCMA_Bot_Manager::menu() as $i => $item ) {
			if ( $i !== $index && WCMA_Bot_Manager::loose( $item['label'] ) === $loose ) {
				return 'دکمه‌ی دیگری با همین نام هست.';
			}
		}

		return '';
	}

	/**
	 * کار دکمه انتخاب شد.
	 *
	 * @param string $chat_id چت.
	 * @param string $action  کار.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function buttons_kind( $chat_id, $action, array $parsed ) {
		$flow = self::flow( $chat_id );

		if ( ! $flow || 'mb_kind' !== ( $flow['step'] ?? '' ) || ! isset( WCMA_Bot_Manager::button_actions()[ $action ] ) ) {
			self::out( $chat_id, 'این گفتگو منقضی شده است. دوباره از «' . self::commands()['buttons_edit'] . '» شروع کنید.', array(), $parsed );

			return;
		}

		$flow['step']   = 'mb_value';
		$flow['action'] = $action;

		self::set_flow( $chat_id, $flow );

		$label = self::e( (string) $flow['label'] );

		switch ( $action ) {
			case 'message':
				$messages = WCMA_Bot_Manager::messages();

				if ( ! $messages ) {
					self::clear_flow( $chat_id );
					self::out( $chat_id, 'هنوز پیام آماده‌ای ندارید. اول از «' . self::commands()['canned_edit'] . '» یک پیام بسازید.', array( array( array( '🗂 پیام‌های آماده', 'ms:l' ) ) ), $parsed );

					return;
				}

				$rows = array();

				foreach ( $messages as $message ) {
					$rows[] = array( array( '📨 ' . self::short( WCMA_Bot_Manager::message_title( $message ), 40 ), 'mb:m:' . $message['id'] ) );
				}

				$rows[] = array( array( '❌ انصراف', 'x' ) );

				self::out( $chat_id, '📨 با زدن «' . $label . '» کدام پیام آماده فرستاده شود؟', $rows, $parsed );
				break;

			case 'link':
				self::ask( $chat_id, '🔗 نشانی لینک را بفرستید (با https://):', $parsed );
				break;

			case 'day':
				$days = array_keys( WCMA_Bot_Manager::sequence() );

				self::ask( $chat_id, '📅 پیام کدام روز دنباله فرستاده شود؟ شماره‌ی روز را بنویسید.' . ( $days ? "\nروزهای موجود: " . implode( '، ', array_map( array( 'WCMA_Date', 'number' ), $days ) ) : '' ), $parsed );
				break;

			case 'reply':
				self::ask( $chat_id, "💬 متن پاسخ را بفرستید.\nمی‌توانید از {first_name}، {full_name} و {phone} استفاده کنید.", $parsed );
				break;

			default:
				self::ask( $chat_id, "💬 متنی را که پس از زدن دکمه فرستاده می‌شود بنویسید،\nیا «-» تا متن پیش‌فرض بماند.", $parsed );
		}
	}

	/**
	 * مقدار کار دکمه دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function buttons_value( array $flow, $chat_id, $text ) {
		$action = (string) ( $flow['action'] ?? '' );
		$value  = $text;

		if ( 'message' === $action ) {
			self::ask( $chat_id, 'یکی از پیام‌های بالا را با دکمه‌اش انتخاب کنید، یا /cancel.' );

			return;
		}

		if ( '' === $text ) {
			self::ask( $chat_id, 'لطفاً به‌شکل متن بنویسید، یا /cancel.' );

			return;
		}

		if ( 'link' === $action ) {
			$value = esc_url_raw( $text, array( 'http', 'https' ) );

			if ( '' === $value || ! preg_match( '#^https?://[^\s/]+\.[^\s]+#i', $value ) ) {
				self::ask( $chat_id, '⚠️ نشانی معتبر نیست. نشانی کامل با https:// بفرستید:' );

				return;
			}
		} elseif ( 'day' === $action ) {
			$day = (int) WCMA_Date::to_latin_digits( $text );

			if ( $day < 1 || $day > WCMA_Bot_Manager::MAX_DAYS ) {
				self::ask( $chat_id, '⚠️ شماره‌ی روز باید بین ۱ و ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_DAYS ) . ' باشد:' );

				return;
			}

			$value = (string) $day;
		} elseif ( 'reply' !== $action && in_array( $text, array( '-', '—', '–' ), true ) ) {
			$value = '';
		} elseif ( mb_strlen( $text ) > 3500 ) {
			self::ask( $chat_id, '⚠️ متن خیلی بلند است؛ کوتاه‌ترش کنید (حداکثر ۳۵۰۰ نویسه):' );

			return;
		}

		self::buttons_finish( $chat_id, $flow, $action, $value, '' );
	}

	/**
	 * ذخیره‌ی دکمه‌ی تازه یا کار تازه‌ی یک دکمه.
	 *
	 * @param string $chat_id چت.
	 * @param array  $flow    وضعیت.
	 * @param string $action  کار.
	 * @param string $value   مقدار.
	 * @param string $message پیام آماده.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function buttons_finish( $chat_id, array $flow, $action, $value, $message, array $parsed = array() ) {
		$menu = WCMA_Bot_Manager::menu();
		$item = array(
			'label'   => (string) $flow['label'],
			'action'  => $action,
			'value'   => $value,
			'message' => $message,
		);

		self::clear_flow( $chat_id );

		if ( 'edit' === ( $flow['mode'] ?? '' ) ) {
			$index = (int) $flow['i'];

			if ( ! isset( $menu[ $index ] ) || ! hash_equals( self::hash_button( $menu[ $index ] ), (string) ( $flow['h'] ?? '' ) ) ) {
				self::buttons_list( $chat_id, $parsed, 'این دکمه در این فاصله تغییر کرده است؛ فهرست تازه:' );

				return;
			}

			$item['label']  = $menu[ $index ]['label'];
			$menu[ $index ] = $item;
		} else {
			if ( count( $menu ) >= WCMA_Bot_Manager::MAX_BUTTONS ) {
				self::buttons_list( $chat_id, $parsed, '⚠️ منو پر است.' );

				return;
			}

			// نام در فاصله‌ی گفتگو ممکن است تکراری شده باشد.
			$error = self::label_error( $item['label'] );

			if ( '' !== $error ) {
				self::buttons_list( $chat_id, $parsed, '⚠️ ' . $error );

				return;
			}

			$menu[] = $item;
			$index  = count( $menu ) - 1;
		}

		self::save( array( 'tg_menu' => $menu ) );

		$note = '✅ ذخیره شد. کاربران با پیام بعدی ربات، منوی تازه را می‌بینند.';

		if ( 'day' === $action && ! isset( WCMA_Bot_Manager::sequence()[ (int) $value ] ) ) {
			$note .= "
⚠️ روز " . WCMA_Date::number( (int) $value ) . ' هنوز پیامی ندارد؛ تا آن را در «' . self::commands()['days'] . '» نسازید، این دکمه چیزی نمی‌فرستد.';
		}

		self::button_screen( $chat_id, $index, $parsed, $note );
	}

	/**
	 * نشانه‌ی کوتاهِ محتوای یک دکمه، تا دکمه‌ی شیشه‌ایِ کهنه دکمه‌ی دیگری را عوض نکند.
	 *
	 * @param array $item دکمه.
	 * @return string
	 */
	protected static function hash_button( array $item ) {
		return substr( md5( wp_json_encode( array( $item['label'] ?? '', $item['action'] ?? '', $item['value'] ?? '', $item['message'] ?? '' ) ) ), 0, 6 );
	}

	/* ------------------------------------------------------------------ */
	/* پیام‌های آماده                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * فهرست پیام‌های آماده.
	 *
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function canned_list( $chat_id, array $parsed = array(), $note = '' ) {
		$messages = WCMA_Bot_Manager::messages();
		$types    = WCMA_Messengers::content_types();
		$lines    = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>🗂 پیام‌های آماده</b> (' . WCMA_Date::number( count( $messages ) ) . ' از ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_MESSAGES ) . ')';
		$lines[] = 'پیامی که یک بار می‌سازید (متن، عکس، ویدیو، صوت یا فایل، با دکمه‌ی شیشه‌ای) به دکمه‌های منو داده یا برای مشترکان فرستاده می‌شود.';
		$lines[] = '';

		if ( ! $messages ) {
			$lines[] = 'هنوز پیامی ندارید.';
		}

		$rows = array();
		$n    = 0;

		foreach ( $messages as $message ) {
			$extra   = $message['buttons'] ? '، ' . WCMA_Date::number( count( $message['buttons'] ) ) . ' دکمه' : '';
			$lines[] = WCMA_Date::number( ++$n ) . '. ' . self::e( WCMA_Bot_Manager::message_title( $message ) ) . ' — ' . self::e( $types[ $message['type'] ]['label'] ?? $message['type'] ) . $extra;
			$rows[]  = array( array( '📝 ' . self::short( WCMA_Bot_Manager::message_title( $message ), 40 ), 'ms:o:' . $message['id'] ) );
		}

		$rows[] = array( array( '➕ پیام آماده‌ی تازه', 'ms:n' ) );
		$rows[] = array( array( '✖️ بستن', 'cl' ) );

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * نمایش یک پیام آماده.
	 *
	 * @param string $chat_id چت.
	 * @param string $id      شناسه.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function canned_screen( $chat_id, $id, array $parsed = array(), $note = '' ) {
		$message = WCMA_Bot_Manager::get_message( $id );

		if ( ! $message ) {
			self::canned_list( $chat_id, $parsed, 'این پیام دیگر نیست.' );

			return;
		}

		$types = WCMA_Messengers::content_types();
		$lines = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>پیام آماده‌ی «' . self::e( WCMA_Bot_Manager::message_title( $message ) ) . '»</b>';
		$lines[] = 'نوع: ' . self::e( $types[ $message['type'] ]['label'] ?? $message['type'] ) . ( '' !== $message['file'] && 'text' !== $message['type'] ? ( self::is_file_id( $message['file'] ) ? ' (فرستاده‌شده در ربات)' : ' (از نشانی)' ) : '' );
		$lines[] = 'متن: ' . ( '' !== trim( $message['text'] ) ? self::e( self::excerpt( $message['text'], 700 ) ) : '—' );

		if ( $message['buttons'] ) {
			$lines[] = 'دکمه‌ها (' . ( 2 === (int) $message['cols'] ? 'دوستونی' : 'یک‌ستونی' ) . '): ' . self::e( implode( '، ', wp_list_pluck( $message['buttons'], 'label' ) ) );
		}

		$used = self::menu_users( $message['id'] );

		if ( $used ) {
			$lines[] = 'در منو: ' . self::e( implode( '، ', $used ) );
		}

		$id   = $message['id'];
		$rows = array(
			array( array( '👁 پیش‌نمایش', 'ms:v:' . $id ), array( '✏️ تغییر محتوا', 'ms:b:' . $id ) ),
			array( array( '🏷 تغییر عنوان', 'ms:t:' . $id ), array( '🔘 دکمه‌ها', 'ms:k:' . $id ) ),
			array( array( '📣 ارسال برای مشترکان', 'pm:' . $id ) ),
			array( array( '🗑 حذف', 'ms:x:' . $id ) ),
			array( array( '↩️ فهرست پیام‌ها', 'ms:l' ) ),
		);

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * دکمه‌های منویی که این پیام را می‌فرستند.
	 *
	 * @param string $id شناسه.
	 * @return string[]
	 */
	protected static function menu_users( $id ) {
		$out = array();

		foreach ( WCMA_Bot_Manager::menu() as $item ) {
			if ( 'message' === $item['action'] && $item['message'] === $id ) {
				$out[] = $item['label'];
			}
		}

		return $out;
	}

	/**
	 * فهرست خامِ پیام‌های آماده، آماده‌ی ذخیره‌ی دوباره.
	 *
	 * @return array
	 */
	protected static function canned_raw() {
		$raw = WCMA_Settings::get( 'tg_messages', array() );

		return is_array( $raw ) ? array_values( array_filter( $raw, 'is_array' ) ) : array();
	}

	/**
	 * جای یک پیام در فهرست خام.
	 *
	 * @param array  $raw فهرست.
	 * @param string $id  شناسه.
	 * @return int -۱ اگر نباشد.
	 */
	protected static function canned_index( array $raw, $id ) {
		foreach ( $raw as $i => $item ) {
			if ( (string) ( $item['id'] ?? '' ) === (string) $id ) {
				return $i;
			}
		}

		return -1;
	}

	/**
	 * دکمه‌های شیشه‌ایِ بخش پیام‌های آماده.
	 *
	 * @param string $op      کار.
	 * @param string $a       شناسه‌ی پیام.
	 * @param string $b       آرگومان دوم.
	 * @param string $c       آرگومان سوم.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function canned_callback( $op, $a, $b, $c, $chat_id, array $parsed ) {
		if ( 'l' === $op ) {
			self::canned_list( $chat_id, $parsed );

			return;
		}

		if ( 'n' === $op ) {
			if ( count( WCMA_Bot_Manager::messages() ) >= WCMA_Bot_Manager::MAX_MESSAGES ) {
				self::canned_list( $chat_id, $parsed, '⚠️ به سقف ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_MESSAGES ) . ' پیام آماده رسیده‌اید؛ اول یکی را حذف کنید.' );

				return;
			}

			self::set_flow( $chat_id, array( 'step' => 'ms_title', 'mode' => 'new' ) );
			self::ask( $chat_id, "➕ <b>پیام آماده‌ی تازه</b>\nیک عنوان کوتاه بنویسید (فقط برای شما در فهرست‌ها دیده می‌شود):", $parsed );

			return;
		}

		$message = WCMA_Bot_Manager::get_message( $a );

		if ( ! $message ) {
			self::canned_list( $chat_id, $parsed, 'این پیام دیگر نیست.' );

			return;
		}

		$id = $message['id'];

		switch ( $op ) {
			case 'o':
				self::canned_screen( $chat_id, $id, $parsed );
				break;

			case 'v':
				self::preview_message( $chat_id, $message );
				self::canned_screen( $chat_id, $id, array(), '👆 پیش‌نمایش، همان‌طور که مشترکان می‌بینند.' );
				break;

			case 'b':
				self::set_flow( $chat_id, array( 'step' => 'ms_body', 'mode' => 'edit', 'id' => $id ) );
				self::ask( $chat_id, self::body_prompt( '✏️ محتوای تازه‌ی «' . self::e( WCMA_Bot_Manager::message_title( $message ) ) . '» را بفرستید.', $message['text'] ), $parsed );
				break;

			case 't':
				self::set_flow( $chat_id, array( 'step' => 'ms_title', 'mode' => 'ren', 'id' => $id ) );
				self::ask( $chat_id, '🏷 عنوان تازه را بنویسید:', $parsed );
				break;

			case 'k':
				self::canned_buttons( $chat_id, $id, $parsed );
				break;

			case 'c':
				self::canned_update( $id, array( 'cols' => 2 === (int) $b ? 2 : 1 ) );
				self::canned_buttons( $chat_id, $id, $parsed, '✅ چینش دکمه‌ها عوض شد.' );
				break;

			case 'bu':
				if ( count( $message['buttons'] ) >= WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS ) {
					self::canned_buttons( $chat_id, $id, $parsed, '⚠️ این پیام به سقف ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS ) . ' دکمه رسیده است.' );
					break;
				}

				self::set_flow( $chat_id, array( 'step' => 'ms_url', 'id' => $id ) );
				self::ask( $chat_id, "🔗 هر دکمه را در یک خط بنویسید: متن دکمه - نشانی\nمثال:\nسایت ما - https://example.com\nاینستاگرام - https://instagram.com/name", $parsed );
				break;

			case 'bm':
				$rows = array();

				foreach ( WCMA_Bot_Manager::messages() as $other ) {
					if ( $other['id'] !== $id ) {
						$rows[] = array( array( '📨 ' . self::short( WCMA_Bot_Manager::message_title( $other ), 40 ), 'ms:bp:' . $id . ':' . $other['id'] ) );
					}
				}

				if ( ! $rows ) {
					self::canned_buttons( $chat_id, $id, $parsed, 'پیام آماده‌ی دیگری نیست که این دکمه بفرستد.' );
					break;
				}

				$rows[] = array( array( '↩️ بازگشت', 'ms:k:' . $id ) );

				self::out( $chat_id, '📨 زدن این دکمه کدام پیام آماده را بفرستد؟', $rows, $parsed );
				break;

			case 'bp':
				$target = WCMA_Bot_Manager::get_message( $b );

				if ( ! $target || $target['id'] === $id ) {
					self::canned_buttons( $chat_id, $id, $parsed, 'آن پیام دیگر نیست.' );
					break;
				}

				self::set_flow( $chat_id, array( 'step' => 'ms_blabel', 'id' => $id, 'target' => $target['id'] ) );
				self::ask( $chat_id, '🔘 متن دکمه را بنویسید (حداکثر ۶۰ نویسه).' . "\nپیشنهاد: " . self::e( WCMA_Bot_Manager::message_title( $target ) ), $parsed );
				break;

			case 'bd':
				$index   = (int) $b;
				$buttons = $message['buttons'];

				if ( ! isset( $buttons[ $index ] ) || ! hash_equals( self::hash_link( $buttons[ $index ] ), $c ) ) {
					self::canned_buttons( $chat_id, $id, $parsed, 'این دکمه در این فاصله تغییر کرده است.' );
					break;
				}

				array_splice( $buttons, $index, 1 );
				self::canned_update( $id, array( 'buttons' => $buttons ) );
				self::canned_buttons( $chat_id, $id, $parsed, '✅ دکمه حذف شد.' );
				break;

			case 'x':
				$used = self::menu_users( $id );

				if ( $used ) {
					self::out(
						$chat_id,
						'⚠️ این پیام را دکمه‌ی منوی «' . self::e( implode( '»، «', $used ) ) . '» می‌فرستد. اول کار آن دکمه را عوض کنید یا حذفش کنید.',
						array( array( array( '🧩 دکمه‌های منو', 'mb:l' ), array( '↩️ بازگشت', 'ms:o:' . $id ) ) ),
						$parsed
					);
					break;
				}

				self::out(
					$chat_id,
					'🗑 پیام آماده‌ی «' . self::e( WCMA_Bot_Manager::message_title( $message ) ) . '» حذف شود؟',
					array( array( array( '✅ بله، حذف کن', 'ms:X:' . $id ), array( '↩️ نه', 'ms:o:' . $id ) ) ),
					$parsed
				);
				break;

			case 'X':
				if ( self::menu_users( $id ) ) {
					self::canned_screen( $chat_id, $id, $parsed, '⚠️ یک دکمه‌ی منو هنوز این پیام را می‌فرستد.' );
					break;
				}

				$raw = array();

				foreach ( self::canned_raw() as $item ) {
					if ( (string) ( $item['id'] ?? '' ) === $id ) {
						continue;
					}

					// دکمه‌هایی که به این پیام می‌رفتند، بی‌مقصد نمی‌مانند.
					if ( ! empty( $item['buttons'] ) && is_array( $item['buttons'] ) ) {
						$item['buttons'] = array_values(
							array_filter(
								$item['buttons'],
								static function ( $button ) use ( $id ) {
									return ! ( is_array( $button ) && 'message' === ( $button['kind'] ?? '' ) && (string) ( $button['message'] ?? '' ) === $id );
								}
							)
						);
					}

					$raw[] = $item;
				}

				self::save( array( 'tg_messages' => $raw ) );
				self::canned_list( $chat_id, $parsed, '✅ پیام «' . self::e( WCMA_Bot_Manager::message_title( $message ) ) . '» حذف شد.' );
				break;
		}
	}

	/**
	 * دکمه‌های شیشه‌ای یک پیام آماده.
	 *
	 * @param string $chat_id چت.
	 * @param string $id      شناسه.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function canned_buttons( $chat_id, $id, array $parsed = array(), $note = '' ) {
		$message = WCMA_Bot_Manager::get_message( $id );

		if ( ! $message ) {
			self::canned_list( $chat_id, $parsed, 'این پیام دیگر نیست.' );

			return;
		}

		$lines = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>🔘 دکمه‌های «' . self::e( WCMA_Bot_Manager::message_title( $message ) ) . '»</b> (' . WCMA_Date::number( count( $message['buttons'] ) ) . ' از ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS ) . ')';
		$lines[] = 'دکمه‌های شیشه‌ای زیر خود پیام می‌آیند: لینک، یا فرستادن یک پیام آماده‌ی دیگر.';
		$lines[] = '';

		$rows = array();

		foreach ( $message['buttons'] as $i => $button ) {
			if ( 'message' === $button['kind'] ) {
				$target = WCMA_Bot_Manager::get_message( $button['message'] );
				$where  = $target ? 'پیام «' . WCMA_Bot_Manager::message_title( $target ) . '»' : '⚠️ پیام پاک‌شده';
			} else {
				$where = $button['url'];
			}

			$lines[] = WCMA_Date::number( $i + 1 ) . '. ' . self::e( $button['label'] ) . ' ← ' . self::e( $where );
			$rows[]  = array( array( '🗑 ' . self::short( $button['label'], 30 ), 'ms:bd:' . $id . ':' . $i . ':' . self::hash_link( $button ) ) );
		}

		if ( ! $message['buttons'] ) {
			$lines[] = 'این پیام هنوز دکمه ندارد.';
		}

		$rows[] = array( array( '➕ دکمه‌ی لینک', 'ms:bu:' . $id ), array( '➕ دکمه‌ی پیام دیگر', 'ms:bm:' . $id ) );

		if ( count( $message['buttons'] ) > 1 ) {
			$rows[] = array( array( 2 === (int) $message['cols'] ? '▤ یک‌ستونی کن' : '▦ دوستونی کن', 'ms:c:' . $id . ':' . ( 2 === (int) $message['cols'] ? 1 : 2 ) ) );
		}

		$rows[] = array( array( '↩️ بازگشت به پیام', 'ms:o:' . $id ) );

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * نشانه‌ی کوتاه یک دکمه‌ی شیشه‌ای.
	 *
	 * @param array $button دکمه.
	 * @return string
	 */
	protected static function hash_link( array $button ) {
		return substr( md5( wp_json_encode( array( $button['label'] ?? '', $button['kind'] ?? '', $button['url'] ?? '', $button['message'] ?? '' ) ) ), 0, 6 );
	}

	/**
	 * تغییر چند فیلد یک پیام آماده و ذخیره.
	 *
	 * @param string $id     شناسه.
	 * @param array  $fields فیلدها.
	 * @return bool
	 */
	protected static function canned_update( $id, array $fields ) {
		$raw   = self::canned_raw();
		$index = self::canned_index( $raw, $id );

		if ( $index < 0 ) {
			return false;
		}

		$raw[ $index ] = array_merge( $raw[ $index ], $fields );

		self::save( array( 'tg_messages' => $raw ) );

		return true;
	}

	/**
	 * عنوان پیام دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function canned_title( array $flow, $chat_id, $text ) {
		$title = mb_substr( trim( sanitize_text_field( $text ) ), 0, 80 );

		if ( '' === $title ) {
			self::ask( $chat_id, 'عنوان را به‌شکل متن بنویسید، یا /cancel.' );

			return;
		}

		if ( 'ren' === ( $flow['mode'] ?? '' ) ) {
			self::clear_flow( $chat_id );

			if ( ! self::canned_update( (string) $flow['id'], array( 'title' => $title ) ) ) {
				self::canned_list( $chat_id, array(), 'این پیام دیگر نیست.' );

				return;
			}

			self::canned_screen( $chat_id, (string) $flow['id'], array(), '✅ عنوان عوض شد.' );

			return;
		}

		self::set_flow(
			$chat_id,
			array(
				'step'  => 'ms_body',
				'mode'  => 'new',
				'title' => $title,
			)
		);
		self::ask( $chat_id, self::body_prompt( '✍️ حالا خود پیام را بفرستید.' ) );
	}

	/**
	 * راهنمای فرستادن محتوای پیام.
	 *
	 * @param string $head    سطر نخست.
	 * @param string $current متن فعلی (برای کپی).
	 * @return string
	 */
	protected static function body_prompt( $head, $current = '' ) {
		$text = $head . "\nمتن، یا عکس، ویدیو، صوت، ویس یا فایل (با توضیح زیرش). می‌توانید از {first_name}، {full_name} و {phone} استفاده کنید.";

		if ( '' !== trim( (string) $current ) ) {
			$text .= "\n\nمتن فعلی (با لمس، کپی می‌شود):\n<code>" . self::e( mb_substr( (string) $current, 0, 3000 ) ) . '</code>';
		}

		return $text;
	}

	/**
	 * محتوای پیام آماده دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param array  $parsed  پیام.
	 */
	protected static function canned_body( array $flow, $chat_id, array $parsed ) {
		$content = self::content_of( $parsed );
		$error   = self::content_error( $content );

		if ( '' !== $error ) {
			self::ask( $chat_id, '⚠️ ' . $error );

			return;
		}

		$fields = array(
			'type' => $content['type'],
			'text' => $content['text'],
			'file' => $content['file'],
		);

		self::clear_flow( $chat_id );

		if ( 'edit' === ( $flow['mode'] ?? '' ) ) {
			if ( ! self::canned_update( (string) $flow['id'], $fields ) ) {
				self::canned_list( $chat_id, array(), 'این پیام دیگر نیست.' );

				return;
			}

			self::canned_screen( $chat_id, (string) $flow['id'], array(), '✅ محتوای پیام عوض شد.' );

			return;
		}

		$raw = self::canned_raw();

		if ( count( $raw ) >= WCMA_Bot_Manager::MAX_MESSAGES ) {
			self::canned_list( $chat_id, array(), '⚠️ به سقف پیام‌های آماده رسیده‌اید.' );

			return;
		}

		$id    = WCMA_Bot_Manager::new_message_id();
		$raw[] = array_merge(
			$fields,
			array(
				'id'      => $id,
				'title'   => (string) ( $flow['title'] ?? '' ),
				'cols'    => 1,
				'buttons' => array(),
			)
		);

		self::save( array( 'tg_messages' => $raw ) );
		self::canned_screen( $chat_id, $id, array(), '✅ پیام آماده ساخته شد. حالا می‌توانید دکمه بیفزایید، آن را به یک دکمه‌ی منو بدهید یا برای مشترکان بفرستید.' );
	}

	/**
	 * اشکالِ محتوایی که مدیر فرستاده، یا خالی.
	 *
	 * @param array|null $content محتوا.
	 * @return string
	 */
	protected static function content_error( $content ) {
		if ( ! $content ) {
			return 'این نوع پیام پذیرفته نمی‌شود. متن، عکس، ویدیو، صوت، ویس یا فایل بفرستید، یا /cancel.';
		}

		if ( 'text' === $content['type'] && mb_strlen( $content['text'] ) > 3500 ) {
			return 'متن خیلی بلند است (حداکثر ۳۵۰۰ نویسه)؛ کوتاه‌ترش کنید و دوباره بفرستید.';
		}

		if ( 'text' !== $content['type'] && mb_strlen( $content['text'] ) > 900 ) {
			return 'توضیح زیر رسانه حداکثر ۹۰۰ نویسه می‌تواند باشد؛ کوتاه‌ترش کنید و دوباره بفرستید.';
		}

		return '';
	}

	/**
	 * دکمه‌های لینک دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function canned_urls( array $flow, $chat_id, $text ) {
		$id      = (string) ( $flow['id'] ?? '' );
		$message = WCMA_Bot_Manager::get_message( $id );

		if ( ! $message ) {
			self::clear_flow( $chat_id );
			self::canned_list( $chat_id, array(), 'این پیام دیگر نیست.' );

			return;
		}

		$buttons = $message['buttons'];
		$added   = 0;
		$bad     = array();

		foreach ( preg_split( '/\R/u', $text ) as $line ) {
			$line = trim( $line );

			if ( '' === $line ) {
				continue;
			}

			if ( ! preg_match( '#^(.+?)\s*(?:\||-|—|–|:)\s*(https?://\S+)$#u', $line, $m ) ) {
				$bad[] = $line;
				continue;
			}

			$label = mb_substr( trim( sanitize_text_field( $m[1] ) ), 0, 60 );
			$url   = esc_url_raw( $m[2], array( 'http', 'https' ) );

			if ( '' === $label || '' === $url ) {
				$bad[] = $line;
				continue;
			}

			if ( count( $buttons ) >= WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS ) {
				$bad[] = $line;
				continue;
			}

			$buttons[] = array(
				'label'   => $label,
				'kind'    => 'url',
				'url'     => $url,
				'message' => '',
			);
			++$added;
		}

		if ( ! $added ) {
			self::ask( $chat_id, "⚠️ دکمه‌ای خوانده نشد. هر خط به این شکل باشد:\nمتن دکمه - https://example.com" );

			return;
		}

		self::clear_flow( $chat_id );
		self::canned_update( $id, array( 'buttons' => $buttons ) );

		$note = '✅ ' . WCMA_Date::number( $added ) . ' دکمه افزوده شد.';

		if ( $bad ) {
			$note .= "\n⚠️ این خط‌ها خوانده نشدند یا جا نبود:\n" . self::e( implode( "\n", array_slice( $bad, 0, 5 ) ) );
		}

		self::canned_buttons( $chat_id, $id, array(), $note );
	}

	/**
	 * متن دکمه‌ی «پیام دیگر» دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function canned_button_label( array $flow, $chat_id, $text ) {
		$id      = (string) ( $flow['id'] ?? '' );
		$message = WCMA_Bot_Manager::get_message( $id );
		$target  = WCMA_Bot_Manager::get_message( (string) ( $flow['target'] ?? '' ) );
		$label   = mb_substr( trim( sanitize_text_field( $text ) ), 0, 60 );

		if ( '' === $label ) {
			self::ask( $chat_id, 'متن دکمه را بنویسید، یا /cancel.' );

			return;
		}

		self::clear_flow( $chat_id );

		if ( ! $message || ! $target ) {
			self::canned_list( $chat_id, array(), 'آن پیام دیگر نیست.' );

			return;
		}

		$buttons = $message['buttons'];

		if ( count( $buttons ) >= WCMA_Bot_Manager::MAX_MESSAGE_BUTTONS ) {
			self::canned_buttons( $chat_id, $id, array(), '⚠️ این پیام به سقف دکمه‌ها رسیده است.' );

			return;
		}

		$buttons[] = array(
			'label'   => $label,
			'kind'    => 'message',
			'url'     => '',
			'message' => $target['id'],
		);

		self::canned_update( $id, array( 'buttons' => $buttons ) );
		self::canned_buttons( $chat_id, $id, array(), '✅ دکمه افزوده شد.' );
	}

	/**
	 * پیش‌نمایش یک پیام آماده برای مدیر.
	 *
	 * @param string $chat_id چت.
	 * @param array  $message پیام.
	 */
	protected static function preview_message( $chat_id, array $message ) {
		// نتیجه‌ی واقعی لازم است؛ پیام خراب باید همین‌جا معلوم شود.
		WCMA_Bot_Reply::release();

		$sub    = WCMA_Bot_Manager::guest_sub( self::channel(), $chat_id );
		$markup = WCMA_Bot_Manager::message_markup( $message );
		$result = WCMA_Messengers::send_content(
			self::channel(),
			$chat_id,
			array(
				'type'         => $message['type'],
				'text'         => WCMA_Bot_Manager::personalize( $message['text'], $sub ),
				'file'         => $message['file'],
				'plain'        => ! empty( $message['plain'] ),
				// بی‌دکمه، کیبورد مدیریت سر جایش می‌ماند.
				'reply_markup' => $markup ? $markup : self::menu_markup(),
			)
		);

		if ( empty( $result['success'] ) ) {
			self::say( $chat_id, '❌ این پیام فرستاده نشد: ' . self::plain( (string) ( $result['message'] ?? '' ) ) );
		}
	}

	/* ------------------------------------------------------------------ */
	/* متن‌های ربات                                                         */
	/* ------------------------------------------------------------------ */

	/**
	 * متن‌های قابل ویرایش.
	 *
	 * @return array کلید ⇐ [تنظیم، عنوان].
	 */
	protected static function text_fields() {
		return array(
			'welcome' => array( 'tg_welcome_text', 'پیام شروع' ),
			'button'  => array( 'tg_phone_button', 'دکمه‌ی اشتراک شماره' ),
			'thanks'  => array( 'tg_phone_thanks', 'پیام تشکر پس از گرفتن شماره' ),
			'known'   => array( 'tg_known_text', 'پیام شناختن مشتری' ),
		);
	}

	/**
	 * نمایش متن‌های ربات.
	 *
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function texts_screen( $chat_id, array $parsed = array(), $note = '' ) {
		$types = WCMA_Messengers::content_types();
		$type  = (string) WCMA_Settings::get( 'tg_welcome_type', 'text' );
		$ask   = WCMA_Settings::is( 'tg_ask_phone' );
		$lines = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>💬 متن‌های ربات</b>';
		$lines[] = '';
		$lines[] = '<b>پیام شروع</b>' . ( 'text' !== $type && '' !== (string) WCMA_Settings::get( 'tg_welcome_file' ) ? ' (' . self::e( $types[ $type ]['label'] ?? $type ) . ')' : '' ) . ': ' . self::e( self::excerpt( (string) WCMA_Settings::get( 'tg_welcome_text' ), 160 ) );
		$lines[] = '<b>گرفتن شماره:</b> ' . ( $ask ? 'روشن ✅' : 'خاموش ⏸' );
		$lines[] = '<b>دکمه‌ی اشتراک شماره:</b> ' . self::e( (string) WCMA_Settings::get( 'tg_phone_button' ) );
		$lines[] = '<b>پیام تشکر:</b> ' . self::e( self::excerpt( (string) WCMA_Settings::get( 'tg_phone_thanks' ), 160 ) );
		$lines[] = '<b>پیام شناختن مشتری:</b> ' . self::e( self::excerpt( (string) WCMA_Settings::get( 'tg_known_text' ), 160 ) );

		$rows = array(
			array( array( '✏️ پیام شروع', 'tx:e:welcome' ), array( '👁 دیدن پیام شروع', 'tx:v' ) ),
			array( array( $ask ? '📱 گرفتن شماره: روشن ✅' : '📱 گرفتن شماره: خاموش ⏸', 'tx:a:' . ( $ask ? 'off' : 'on' ) ) ),
			array( array( '✏️ دکمه‌ی شماره', 'tx:e:button' ), array( '✏️ پیام تشکر', 'tx:e:thanks' ) ),
			array( array( '✏️ پیام شناختن مشتری', 'tx:e:known' ) ),
			array( array( '✖️ بستن', 'cl' ) ),
		);

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * دکمه‌های شیشه‌ایِ بخش متن‌ها.
	 *
	 * @param string $op      کار.
	 * @param string $a       آرگومان.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function texts_callback( $op, $a, $chat_id, array $parsed ) {
		$fields = self::text_fields();

		if ( 'a' === $op ) {
			self::save( array( 'tg_ask_phone' => 'on' === $a ? 'yes' : 'no' ) );
			self::texts_screen( $chat_id, $parsed, 'on' === $a ? '✅ ربات از کاربران تازه شماره می‌خواهد.' : '✅ ربات دیگر شماره نمی‌خواهد.' );

			return;
		}

		if ( 'v' === $op ) {
			WCMA_Bot_Reply::release();

			$sub    = WCMA_Bot_Manager::guest_sub( self::channel(), $chat_id );
			$result = WCMA_Messengers::send_content(
				self::channel(),
				$chat_id,
				array(
					'type'         => (string) WCMA_Settings::get( 'tg_welcome_type', 'text' ),
					'text'         => WCMA_Bot_Manager::personalize( (string) WCMA_Settings::get( 'tg_welcome_text' ), $sub ),
					'file'         => (string) WCMA_Settings::get( 'tg_welcome_file' ),
					'reply_markup' => self::menu_markup(),
				)
			);

			self::texts_screen( $chat_id, array(), ! empty( $result['success'] ) ? '👆 پیام شروع، همان‌طور که کاربر تازه می‌بیند.' : '❌ پیام شروع فرستاده نشد: ' . self::e( (string) ( $result['message'] ?? '' ) ) );

			return;
		}

		if ( 'e' === $op && isset( $fields[ $a ] ) ) {
			self::set_flow( $chat_id, array( 'step' => 'tx', 'key' => $a ) );

			$current = (string) WCMA_Settings::get( $fields[ $a ][0] );
			$head    = '✏️ <b>' . self::e( $fields[ $a ][1] ) . '</b>';

			if ( 'welcome' === $a ) {
				self::ask( $chat_id, self::body_prompt( $head . "\nپیام تازه را بفرستید.", $current ), $parsed );
			} elseif ( 'button' === $a ) {
				self::ask( $chat_id, $head . "\nمتن تازه‌ی دکمه را بنویسید (یک خط، حداکثر ۶۰ نویسه).\nفعلی: <code>" . self::e( $current ) . '</code>', $parsed );
			} else {
				self::ask( $chat_id, $head . "\nمتن تازه را بفرستید. می‌توانید از {first_name}، {full_name} و {phone} استفاده کنید." . ( '' !== $current ? "\n\nمتن فعلی (با لمس، کپی می‌شود):\n<code>" . self::e( $current ) . '</code>' : '' ), $parsed );
			}
		}
	}

	/**
	 * ذخیره‌ی یک متن.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param array  $parsed  پیام.
	 */
	protected static function texts_save( array $flow, $chat_id, array $parsed ) {
		$fields = self::text_fields();
		$key    = (string) ( $flow['key'] ?? '' );

		if ( ! isset( $fields[ $key ] ) ) {
			self::clear_flow( $chat_id );

			return;
		}

		if ( 'welcome' === $key ) {
			$content = self::content_of( $parsed );
			$error   = self::content_error( $content );

			if ( '' !== $error ) {
				self::ask( $chat_id, '⚠️ ' . $error );

				return;
			}

			self::clear_flow( $chat_id );
			self::save(
				array(
					'tg_welcome_type' => $content['type'],
					'tg_welcome_file' => $content['file'],
					'tg_welcome_text' => $content['text'],
				)
			);
			self::texts_screen( $chat_id, array(), '✅ پیام شروع عوض شد.' );

			return;
		}

		$text = trim( (string) ( $parsed['text'] ?? '' ) );

		if ( '' === $text ) {
			self::ask( $chat_id, 'لطفاً به‌شکل متن بنویسید، یا /cancel.' );

			return;
		}

		if ( 'button' === $key ) {
			$text = mb_substr( trim( sanitize_text_field( $text ) ), 0, 60 );

			if ( '' === WCMA_Bot_Manager::loose( $text ) ) {
				self::ask( $chat_id, '⚠️ متن دکمه باید دست‌کم یک حرف داشته باشد:' );

				return;
			}
		} elseif ( mb_strlen( $text ) > 3500 ) {
			self::ask( $chat_id, '⚠️ متن خیلی بلند است؛ کوتاه‌ترش کنید:' );

			return;
		}

		self::clear_flow( $chat_id );
		self::save( array( $fields[ $key ][0] => $text ) );
		self::texts_screen( $chat_id, array(), '✅ «' . self::e( $fields[ $key ][1] ) . '» عوض شد.' );
	}

	/* ------------------------------------------------------------------ */
	/* پیام‌های روزانه                                                      */
	/* ------------------------------------------------------------------ */

	/**
	 * فهرست روزهای دنباله.
	 *
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function days_list( $chat_id, array $parsed = array(), $note = '' ) {
		$days  = WCMA_Bot_Manager::sequence();
		$types = WCMA_Messengers::content_types();
		$on    = WCMA_Settings::is( 'tg_seq_enabled' );
		$first = WCMA_Settings::is( 'tg_seq_first_now' );
		$time  = WCMA_Bot_Manager::clean_time( '' );
		$lines = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>📅 پیام‌های روزانه</b>';
		$lines[] = 'هر مشترک از روز عضویتش، هر روز پیام همان روز را می‌گیرد.';
		$lines[] = 'وضعیت: ' . ( $on ? 'روشن ✅' : 'خاموش ⏸' ) . ' — ساعت ارسال: ' . WCMA_Date::digits( $time ) . ' — روز اول: ' . ( $first ? 'بی‌درنگ پس از عضویت' : 'در ساعت ارسال' );
		$lines[] = '';

		if ( ! $days ) {
			$lines[] = 'هنوز روزی تعریف نشده است.';
		}

		$rows = array();

		foreach ( $days as $day => $item ) {
			$what    = 'text' === $item['type'] ? '' : ( $types[ $item['type'] ]['label'] ?? $item['type'] ) . ': ';
			$lines[] = 'روز ' . WCMA_Date::number( $day ) . ' ' . ( $item['active'] ? '✅' : '⏸' ) . ' — ' . self::e( $what . self::excerpt( $item['text'], 60 ) );
		}

		foreach ( array_chunk( array_keys( $days ), 4 ) as $chunk ) {
			$row = array();

			foreach ( $chunk as $day ) {
				$row[] = array( 'روز ' . WCMA_Date::number( $day ) . ( $days[ $day ]['active'] ? '' : ' ⏸' ), 'sq:o:' . $day );
			}

			$rows[] = $row;
		}

		$rows[] = array( array( '➕ روز تازه', 'sq:n' ), array( '🕙 ساعت ارسال', 'sq:t' ) );
		$rows[] = array(
			array( $on ? '⏸ خاموش کردن دنباله' : '▶️ روشن کردن دنباله', 'sq:s:' . ( $on ? 'off' : 'on' ) ),
			array( $first ? 'روز اول: در ساعت ارسال' : 'روز اول: بی‌درنگ', 'sq:f:' . ( $first ? 'off' : 'on' ) ),
		);
		$rows[] = array( array( '✖️ بستن', 'cl' ) );

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * نمایش یک روز.
	 *
	 * @param string $chat_id چت.
	 * @param int    $day     روز.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function day_screen( $chat_id, $day, array $parsed = array(), $note = '' ) {
		$days = WCMA_Bot_Manager::sequence();

		if ( ! isset( $days[ $day ] ) ) {
			self::days_list( $chat_id, $parsed, 'این روز دیگر نیست.' );

			return;
		}

		$item  = $days[ $day ];
		$types = WCMA_Messengers::content_types();
		$lines = array();

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>روز ' . WCMA_Date::number( $day ) . '</b> — ' . ( $item['active'] ? 'فعال ✅' : 'خاموش ⏸' );
		$lines[] = 'date' === $item['mode']
			? 'زمان: ' . self::e( WCMA_Date::format( $item['date'] . ' 12:00:00', 'date' ) ) . '، ساعت ' . WCMA_Date::digits( $item['time'] )
			: 'زمان: ساعت ' . WCMA_Date::digits( $item['time'] );
		$lines[] = 'نوع: ' . self::e( $types[ $item['type'] ]['label'] ?? $item['type'] );
		$lines[] = 'متن: ' . ( '' !== trim( $item['text'] ) ? self::e( self::excerpt( $item['text'], 700 ) ) : '—' );

		if ( $item['buttons'] ) {
			$lines[] = 'دکمه‌ها: ' . self::e( implode( '، ', wp_list_pluck( $item['buttons'], 'label' ) ) ) . ' (از پیشخوان سایت ویرایش می‌شوند)';
		}

		$rows = array(
			array( array( '👁 پیش‌نمایش', 'sq:v:' . $day ), array( '✏️ تغییر محتوا', 'sq:b:' . $day ) ),
			array( array( $item['active'] ? '⏸ خاموش کردن این روز' : '▶️ روشن کردن این روز', 'sq:a:' . $day . ':' . ( $item['active'] ? 'off' : 'on' ) ) ),
			array( array( '🗑 حذف', 'sq:x:' . $day ) ),
			array( array( '↩️ فهرست روزها', 'sq:l' ) ),
		);

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * فهرست خامِ روزها، آماده‌ی ذخیره‌ی دوباره.
	 *
	 * خواننده‌ی دنباله active را true/false برمی‌گرداند ولی پاک‌سازی فقط «yes»
	 * را روشن می‌داند؛ بی‌این تبدیل، هر ذخیره همه‌ی روزها را خاموش می‌کرد.
	 *
	 * @return array
	 */
	protected static function days_raw() {
		$raw = WCMA_Settings::get( 'tg_sequence', array() );
		$out = array();

		foreach ( is_array( $raw ) ? $raw : array() as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$item['active'] = ( true === ( $item['active'] ?? false ) || 'yes' === ( $item['active'] ?? '' ) ) ? 'yes' : 'no';
			$out[]          = $item;
		}

		return $out;
	}

	/**
	 * دکمه‌های شیشه‌ایِ بخش روزها.
	 *
	 * @param string $op      کار.
	 * @param string $a       آرگومان.
	 * @param string $b       آرگومان دوم.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function days_callback( $op, $a, $b, $chat_id, array $parsed ) {
		switch ( $op ) {
			case 'l':
				self::days_list( $chat_id, $parsed );
				return;

			case 's':
				self::save( array( 'tg_seq_enabled' => 'on' === $a ? 'yes' : 'no' ) );
				self::days_list( $chat_id, $parsed, 'on' === $a ? '✅ پیام‌های روزانه روشن شد.' : '✅ پیام‌های روزانه خاموش شد.' );
				return;

			case 'f':
				self::save( array( 'tg_seq_first_now' => 'on' === $a ? 'yes' : 'no' ) );
				self::days_list( $chat_id, $parsed, '✅ ذخیره شد.' );
				return;

			case 't':
				self::set_flow( $chat_id, array( 'step' => 'sq_time' ) );
				self::ask( $chat_id, '🕙 ساعت ارسال را به‌شکل ۱۰:۰۰ بنویسید (۲۴ ساعته):', $parsed );
				return;

			case 'n':
				$days = WCMA_Bot_Manager::sequence();

				self::set_flow( $chat_id, array( 'step' => 'sq_day' ) );
				self::ask( $chat_id, '➕ شماره‌ی روز را بنویسید (۱ تا ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_DAYS ) . ').' . ( $days ? "\nروزهای موجود: " . implode( '، ', array_map( array( 'WCMA_Date', 'number' ), array_keys( $days ) ) ) : '' ), $parsed );
				return;
		}

		$day  = (int) $a;
		$days = WCMA_Bot_Manager::sequence();

		if ( ! isset( $days[ $day ] ) ) {
			self::days_list( $chat_id, $parsed, 'این روز دیگر نیست.' );

			return;
		}

		switch ( $op ) {
			case 'o':
				self::day_screen( $chat_id, $day, $parsed );
				break;

			case 'v':
				self::preview_day( $chat_id, $day, $days[ $day ] );
				self::day_screen( $chat_id, $day, array(), '👆 پیش‌نمایش روز ' . WCMA_Date::number( $day ) . '.' );
				break;

			case 'b':
				self::set_flow( $chat_id, array( 'step' => 'sq_body', 'day' => $day ) );
				self::ask( $chat_id, self::body_prompt( '✏️ محتوای تازه‌ی روز ' . WCMA_Date::number( $day ) . ' را بفرستید.', $days[ $day ]['text'] ), $parsed );
				break;

			case 'a':
				self::days_update( $day, array( 'active' => 'on' === $b ? 'yes' : 'no' ) );
				self::day_screen( $chat_id, $day, $parsed, 'on' === $b ? '✅ این روز روشن شد.' : '✅ این روز خاموش شد.' );
				break;

			case 'x':
				self::out(
					$chat_id,
					'🗑 پیام روز ' . WCMA_Date::number( $day ) . ' حذف شود؟',
					array( array( array( '✅ بله، حذف کن', 'sq:X:' . $day ), array( '↩️ نه', 'sq:o:' . $day ) ) ),
					$parsed
				);
				break;

			case 'X':
				$raw = array_values(
					array_filter(
						self::days_raw(),
						static function ( $item ) use ( $day ) {
							return (int) ( $item['day'] ?? 0 ) !== $day;
						}
					)
				);

				self::save( array( 'tg_sequence' => $raw ) );
				self::days_list( $chat_id, $parsed, '✅ روز ' . WCMA_Date::number( $day ) . ' حذف شد.' );
				break;
		}
	}

	/**
	 * تغییر فیلدهای یک روز.
	 *
	 * @param int   $day    روز.
	 * @param array $fields فیلدها.
	 */
	protected static function days_update( $day, array $fields ) {
		$raw = self::days_raw();

		foreach ( $raw as $i => $item ) {
			if ( (int) ( $item['day'] ?? 0 ) === (int) $day ) {
				$raw[ $i ] = array_merge( $item, $fields );
			}
		}

		self::save( array( 'tg_sequence' => $raw ) );
	}

	/**
	 * شماره‌ی روز تازه دریافت شد.
	 *
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function days_number( $chat_id, $text ) {
		$day = (int) WCMA_Date::to_latin_digits( trim( $text ) );

		if ( $day < 1 || $day > WCMA_Bot_Manager::MAX_DAYS ) {
			self::ask( $chat_id, '⚠️ عددی بین ۱ و ' . WCMA_Date::number( WCMA_Bot_Manager::MAX_DAYS ) . ' بنویسید:' );

			return;
		}

		if ( isset( WCMA_Bot_Manager::sequence()[ $day ] ) ) {
			self::clear_flow( $chat_id );
			self::day_screen( $chat_id, $day, array(), 'روز ' . WCMA_Date::number( $day ) . ' از پیش هست؛ اینجا ویرایشش کنید:' );

			return;
		}

		self::set_flow(
			$chat_id,
			array(
				'step' => 'sq_body',
				'day'  => $day,
				'new'  => true,
			)
		);
		self::ask( $chat_id, self::body_prompt( '✍️ پیام روز ' . WCMA_Date::number( $day ) . ' را بفرستید.' ) );
	}

	/**
	 * محتوای یک روز دریافت شد.
	 *
	 * @param array  $flow    وضعیت.
	 * @param string $chat_id چت.
	 * @param array  $parsed  پیام.
	 */
	protected static function days_body( array $flow, $chat_id, array $parsed ) {
		$day     = (int) ( $flow['day'] ?? 0 );
		$content = self::content_of( $parsed );
		$error   = self::content_error( $content );

		if ( '' !== $error ) {
			self::ask( $chat_id, '⚠️ ' . $error );

			return;
		}

		$fields = array(
			'type' => $content['type'],
			'text' => $content['text'],
			'file' => $content['file'],
		);

		self::clear_flow( $chat_id );

		if ( isset( WCMA_Bot_Manager::sequence()[ $day ] ) ) {
			self::days_update( $day, $fields );
			self::day_screen( $chat_id, $day, array(), '✅ محتوای روز ' . WCMA_Date::number( $day ) . ' عوض شد.' );

			return;
		}

		$raw   = self::days_raw();
		$raw[] = array_merge(
			array(
				'day'     => $day,
				'active'  => 'yes',
				'mode'    => 'offset',
				'date'    => '',
				'time'    => '',
				'buttons' => array(),
			),
			$fields
		);

		self::save( array( 'tg_sequence' => $raw ) );

		$note = '✅ روز ' . WCMA_Date::number( $day ) . ' ساخته شد.';

		if ( ! WCMA_Settings::is( 'tg_seq_enabled' ) ) {
			$note .= "\n⚠️ پیام‌های روزانه خاموش است؛ از فهرست روزها روشنش کنید.";
		}

		self::day_screen( $chat_id, $day, array(), $note );
	}

	/**
	 * ساعت ارسال دریافت شد.
	 *
	 * @param string $chat_id چت.
	 * @param string $text    متن.
	 */
	protected static function days_time( $chat_id, $text ) {
		$time = WCMA_Date::to_latin_digits( trim( $text ) );

		if ( ! preg_match( '/^([01]?\d|2[0-3])[:٫.](\d{2})$/u', $time, $m ) || (int) $m[2] > 59 ) {
			self::ask( $chat_id, '⚠️ ساعت را به‌شکل ۱۰:۰۰ بنویسید:' );

			return;
		}

		self::clear_flow( $chat_id );
		self::save( array( 'tg_seq_time' => sprintf( '%02d:%02d', (int) $m[1], (int) $m[2] ) ) );
		self::days_list( $chat_id, array(), '✅ ساعت ارسال ذخیره شد.' );
	}

	/**
	 * پیش‌نمایش یک روز برای مدیر.
	 *
	 * @param string $chat_id چت.
	 * @param int    $day     روز.
	 * @param array  $item    روز.
	 */
	protected static function preview_day( $chat_id, $day, array $item ) {
		WCMA_Bot_Reply::release();

		$sub     = WCMA_Bot_Manager::guest_sub( self::channel(), $chat_id );
		$buttons = array();

		foreach ( $item['buttons'] as $button ) {
			$buttons[] = array( array( 'text' => $button['label'], 'url' => $button['url'] ) );
		}

		$result = WCMA_Messengers::send_content(
			self::channel(),
			$chat_id,
			array(
				'type'         => $item['type'],
				'text'         => WCMA_Bot_Manager::personalize( $item['text'], $sub, $day ),
				'file'         => $item['file'],
				'reply_markup' => $buttons ? array( 'inline_keyboard' => $buttons ) : self::menu_markup(),
			)
		);

		if ( empty( $result['success'] ) ) {
			self::say( $chat_id, '❌ این روز فرستاده نشد: ' . self::plain( (string) ( $result['message'] ?? '' ) ) );
		}
	}

	/* ------------------------------------------------------------------ */
	/* مدیران                                                               */
	/* ------------------------------------------------------------------ */

	/**
	 * فهرست مدیران.
	 *
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 * @param string $note    یادداشت.
	 */
	protected static function admins_list( $chat_id, array $parsed = array(), $note = '' ) {
		$admins = self::current_admins();
		$lines  = array();
		$rows   = array();
		$n      = 0;

		if ( '' !== $note ) {
			$lines[] = $note;
			$lines[] = '';
		}

		$lines[] = '<b>👤 مدیران ربات</b> (' . WCMA_Date::number( count( $admins ) ) . ')';
		$lines[] = 'مدیران از همین ربات آمار می‌بینند، پیام می‌فرستند و ربات را ویرایش می‌کنند.';
		$lines[] = '';

		foreach ( $admins as $admin ) {
			$me      = (string) $admin['chat_id'] === (string) $chat_id;
			$who     = '' !== (string) ( $admin['name'] ?? '' ) ? $admin['name'] : $admin['chat_id'];
			$lines[] = WCMA_Date::number( ++$n ) . '. ' . self::e( $who ) . ( $me ? ' (شما)' : '' ) . ( ! empty( $admin['telegram'] ) ? ' — ' . self::e( $admin['telegram'] ) : '' );

			if ( ! $me ) {
				$rows[] = array( array( '🗑 برداشتن ' . self::short( $who, 24 ), 'ad:x:' . $admin['chat_id'] ) );
			}
		}

		$rows[] = array( array( '🔗 لینک دعوت مدیر تازه', 'ad:i' ) );
		$rows[] = array( array( '➕ افزودن با شماره یا نام کاربری', 'ad:n' ) );
		$rows[] = array( array( '✖️ بستن', 'cl' ) );

		self::out( $chat_id, implode( "\n", $lines ), $rows, $parsed );
	}

	/**
	 * دکمه‌های شیشه‌ایِ بخش مدیران.
	 *
	 * @param string $op      کار.
	 * @param string $a       شناسه‌ی چت.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function admins_callback( $op, $a, $chat_id, array $parsed ) {
		switch ( $op ) {
			case 'l':
				self::admins_list( $chat_id, $parsed );
				return;

			case 'i':
				$invite = self::new_invite();
				$lines  = array( '🔗 <b>لینک دعوت مدیر</b> (یک‌بار مصرف، تا ۲۴ ساعت)' );

				if ( '' !== $invite['link'] ) {
					$lines[] = self::e( $invite['link'] );
				}

				$lines[] = '';
				$lines[] = ( '' !== $invite['link'] ? 'اگر لینک کار نکرد، ' : '' ) . 'کسی که می‌خواهید مدیر شود این را برای ربات بفرستد:';
				$lines[] = '<code>/start ' . self::e( self::START_PREFIX . $invite['code'] ) . '</code>';
				$lines[] = '';
				$lines[] = '⚠️ هر کس این لینک را باز کند مدیر ربات می‌شود؛ فقط برای کسی بفرستید که به او اعتماد دارید.';

				// لینک تازه پیام جداست تا بشود آن را برای دیگری فرستاد.
				self::out( $chat_id, implode( "\n", $lines ) );
				self::audit( '🔗 ' . self::who( $chat_id ) . ' یک لینک دعوت مدیر ساخت.', $chat_id );
				return;

			case 'n':
				self::set_flow( $chat_id, array( 'step' => 'ad_who' ) );
				self::ask( $chat_id, "➕ شماره‌ی موبایل (همان که در ربات داده)، ‎@نام‌کاربری یا شناسه‌ی چتِ کسی را بنویسید که می‌خواهید مدیر شود.\nاو باید پیش‌تر ربات را استارت کرده باشد؛ وگرنه «لینک دعوت» بسازید.", $parsed );
				return;
		}

		$admins = self::current_admins();
		$key    = self::key( self::channel(), $a );
		$target = $admins[ $key ] ?? null;

		if ( ! $target ) {
			self::admins_list( $chat_id, $parsed, 'این حساب دیگر مدیر نیست.' );

			return;
		}

		if ( (string) $target['chat_id'] === (string) $chat_id ) {
			self::admins_list( $chat_id, $parsed, 'خودتان را از اینجا نمی‌توانید بردارید؛ مدیر دیگری یا پیشخوان سایت این کار را می‌کند.' );

			return;
		}

		$who = '' !== (string) ( $target['name'] ?? '' ) ? $target['name'] : $target['chat_id'];

		if ( 'x' === $op ) {
			self::out(
				$chat_id,
				'🗑 دسترسی مدیریت از «' . self::e( $who ) . '» برداشته شود؟',
				array( array( array( '✅ بله، بردار', 'ad:X:' . $target['chat_id'] ), array( '↩️ نه', 'ad:l' ) ) ),
				$parsed
			);

			return;
		}

		if ( 'X' === $op ) {
			self::remove( $key );
			self::audit( '🛠 ' . self::who( $chat_id ) . ' دسترسی مدیریت «' . self::plain( $who ) . '» را برداشت.', array( $chat_id, $target['chat_id'] ) );
			self::admins_list( $chat_id, $parsed, '✅ «' . self::e( $who ) . '» دیگر مدیر نیست.' );
		}
	}

	/**
	 * افزودن مدیر با شماره یا نام کاربری.
	 *
	 * @param string $chat_id چت.
	 * @param string $text    ورودی.
	 */
	protected static function admins_add( $chat_id, $text ) {
		$found = self::resolve( $text );

		if ( empty( $found['success'] ) ) {
			self::ask( $chat_id, '⚠️ ' . self::e( (string) $found['message'] ) . "\nدوباره بنویسید، یا /cancel." );

			return;
		}

		self::clear_flow( $chat_id );

		if ( self::is_admin( self::channel(), $found['chat_id'] ) ) {
			self::admins_list( $chat_id, array(), 'این حساب از پیش مدیر است.' );

			return;
		}

		self::add( self::channel(), $found['chat_id'], (string) $found['name'], true, (string) ( $found['telegram'] ?? '' ) );

		$who = '' !== (string) $found['name'] ? $found['name'] : $found['chat_id'];

		self::audit( '🛠 ' . self::who( $chat_id ) . ' «' . self::plain( $who ) . '» را مدیر ربات کرد.', array( $chat_id, $found['chat_id'] ) );
		self::admins_list( $chat_id, array(), '✅ «' . self::e( $who ) . '» مدیر شد و منوی مدیریت برایش فرستاده شد.' );
	}

	/**
	 * نام یک مدیر برای خبرها.
	 *
	 * @param string $chat_id چت.
	 * @return string
	 */
	protected static function who( $chat_id ) {
		$admin = self::admins()[ self::key( self::channel(), $chat_id ) ] ?? array();

		return self::plain( '' !== (string) ( $admin['name'] ?? '' ) ? $admin['name'] : (string) $chat_id );
	}

	/**
	 * خبر کارهای حساس برای بقیه‌ی مدیران (بی‌توجه به خاموش بودن خبرها).
	 *
	 * @param string $text   متن.
	 * @param string $except کسی که خودش کار را کرد.
	 */
	protected static function audit( $text, $except ) {
		WCMA_Bot_Reply::later( array( __CLASS__, 'audit_now' ), array( $text, array_map( 'strval', (array) $except ) ) );
	}

	/**
	 * فرستادن خبر کار حساس.
	 *
	 * @param string   $text   متن.
	 * @param string[] $except چت‌هایی که خبر برایشان نمی‌رود.
	 */
	public static function audit_now( $text, array $except ) {
		foreach ( self::current_admins() as $admin ) {
			if ( ! in_array( (string) $admin['chat_id'], $except, true ) ) {
				self::say( $admin['chat_id'], $text );
			}
		}
	}

	/* ------------------------------------------------------------------ */
	/* سرعت                                                                 */
	/* ------------------------------------------------------------------ */

	/**
	 * سنجش سرعت و نمایش نتیجه.
	 *
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function speed_run( $chat_id, array $parsed = array() ) {
		self::out( $chat_id, '⏳ در حال سنجش سرعت ربات… چند ثانیه طول می‌کشد.', array(), $parsed );

		// سنجش چند درخواست بیرونی دارد؛ تلگرام نباید پشتش منتظر بماند.
		WCMA_Bot_Reply::release();

		$result = WCMA_Bot_Speed::check( self::channel() );

		self::say( $chat_id, WCMA_Bot_Speed::text( $result ), self::inline( self::speed_rows() ) );
	}

	/**
	 * دکمه‌های بخش سرعت.
	 *
	 * @return array
	 */
	protected static function speed_rows() {
		$v4   = WCMA_Bot_Api::ipv4();
		$fast = WCMA_Settings::is( 'tg_fastlane' );

		$rows = array(
			array( array( '🔁 سنجش دوباره', 'sp:r' ), array( '🧹 ثبت دوباره‌ی وب‌هوک', 'sp:w' ) ),
			array( array( $v4 ? 'فقط IPv4: روشن ✅' : 'فقط IPv4: خاموش', 'sp:4:' . ( $v4 ? 'off' : 'on' ) ) ),
		);

		// حالت سریع در وردپرس چندسایته به کار نمی‌رود.
		if ( ! is_multisite() ) {
			$rows[] = array( array( $fast ? '⚡️ حالت سریع: روشن ✅' : '⚡️ حالت سریع: خاموش', 'sp:f:' . ( $fast ? 'off' : 'on' ) ) );
		}

		$rows[] = array( array( '✖️ بستن', 'cl' ) );

		return $rows;
	}

	/**
	 * دکمه‌های شیشه‌ایِ بخش سرعت.
	 *
	 * @param string $op      کار.
	 * @param string $a       آرگومان.
	 * @param string $chat_id چت.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function speed_callback( $op, $a, $chat_id, array $parsed ) {
		switch ( $op ) {
			case 'r':
				self::speed_run( $chat_id, $parsed );
				return;

			case 'w':
				self::out( $chat_id, '⏳ در حال ثبت دوباره‌ی وب‌هوک…', array(), $parsed );
				WCMA_Bot_Reply::release();

				$result = WCMA_Bot_Link::register_webhook( self::channel() );

				self::say( $chat_id, ( ! empty( $result['success'] ) ? '✅ ' : '❌ ' ) . self::plain( (string) $result['message'] ), self::inline( self::speed_rows() ) );
				return;

			case '4':
				self::save( array( 'tg_ipv4' => 'on' === $a ? 'yes' : 'no' ) );
				self::out(
					$chat_id,
					'on' === $a ? '✅ ارتباط با تلگرام فقط از IPv4 انجام می‌شود.' : '✅ ارتباط با تلگرام به حالت عادی برگشت.',
					self::speed_rows(),
					$parsed
				);
				return;

			case 'f':
				if ( is_multisite() ) {
					self::out( $chat_id, 'حالت سریع در وردپرس چندسایته (شبکه) پشتیبانی نمی‌شود.', self::speed_rows(), $parsed );
					return;
				}

				self::save( array( 'tg_fastlane' => 'on' === $a ? 'yes' : 'no' ) );

				if ( 'on' === $a && ! WCMA_Bot_Fastlane::installed() ) {
					$text = '❌ حالت سریع روشن نشد: ' . self::e( WCMA_Bot_Fastlane::error() );
				} elseif ( 'on' === $a ) {
					$text = "✅ حالت سریع روشن شد.\nاز پیام بعدی، برای پیام‌های ربات فقط ووکامرس و همین افزونه بار می‌شوند. اگر چیزی در پاسخ‌های ربات درست کار نکرد، خاموشش کنید یا افزونه‌ی لازم را در پیشخوان (برگه‌ی ربات، بخش سرعت) به فهرست نگه‌داشتنی‌ها بیفزایید.";
				} else {
					$text = '✅ حالت سریع خاموش شد.';
				}

				self::out( $chat_id, $text, self::speed_rows(), $parsed );
				return;
		}
	}

	/* ------------------------------------------------------------------ */
	/* ابزارها                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * فرستادن یا (در پاسخ به دکمه‌ی شیشه‌ای) جایگزین کردن یک صفحه.
	 *
	 * متن، HTML آماده‌ی تلگرام است؛ ورودی‌های بیرونی پیش‌تر با e() کدگذاری شده‌اند.
	 *
	 * @param string $chat_id چت.
	 * @param string $html    متن.
	 * @param array  $rows    ردیف‌های دکمه‌ی شیشه‌ای.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function out( $chat_id, $html, array $rows = array(), array $parsed = array() ) {
		$params = array(
			'chat_id'                  => (string) $chat_id,
			'text'                     => $html,
			'parse_mode'               => 'HTML',
			'disable_web_page_preview' => true,
		);

		if ( $rows ) {
			$params['reply_markup'] = self::inline( $rows );
		}

		$message_id = (int) ( $parsed['message_id'] ?? 0 );

		// دکمه‌ی شیشه‌ای همان صفحه را عوض می‌کند تا گفتگو پر از پیام‌های کهنه نشود.
		if ( $message_id > 0 && '' !== (string) ( $parsed['callback'] ?? '' ) ) {
			$result = WCMA_Bot_Api::call( self::channel(), 'editMessageText', array_merge( $params, array( 'message_id' => $message_id ) ) );

			if ( ! empty( $result['ok'] ) || false !== stripos( (string) ( $result['description'] ?? '' ), 'not modified' ) ) {
				return;
			}
		}

		WCMA_Bot_Api::call( self::channel(), 'sendMessage', $params );
	}

	/**
	 * پرسیدن یک ورودی، با دکمه‌ی انصراف.
	 *
	 * @param string $chat_id چت.
	 * @param string $html    متن.
	 * @param array  $parsed  به‌روزرسانی.
	 */
	protected static function ask( $chat_id, $html, array $parsed = array() ) {
		self::out( $chat_id, $html, array( array( array( '❌ انصراف', 'x' ) ) ), $parsed );
	}

	/**
	 * ذخیره‌ی یک تنظیم از ربات (برای بخش تنظیمات منوی مدیریت).
	 *
	 * @param array $values تنظیم ⇐ مقدار.
	 * @return array
	 */
	public static function store( array $values ) {
		return self::save( $values );
	}

	/**
	 * ذخیره با همان پاک‌سازیِ پیشخوان.
	 *
	 * @param array $values تنظیم ⇐ مقدار.
	 * @return array مقدارهای پاک‌شده.
	 */
	protected static function save( array $values ) {
		if ( ! class_exists( 'WCMA_Admin_Fields' ) ) {
			require_once WCMA_PATH . 'includes/admin/class-wcma-admin-fields.php';
		}

		$clean = array();

		foreach ( $values as $key => $value ) {
			$clean[ $key ] = WCMA_Admin_Fields::sanitize_value( $key, $value );
		}

		/*
		 * تنظیمات یک گزینه‌ی یکجاست؛ پیش از نوشتن، نسخه‌ی تازه‌ی پایگاه داده
		 * خوانده می‌شود تا تغییر همزمان دیگری (از پیشخوان یا مدیر دیگر) پاک نشود.
		 */
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( WCMA_Settings::OPTION, 'options' );
		WCMA_Settings::flush();

		$changed = array();

		foreach ( $clean as $key => $value ) {
			if ( WCMA_Settings::get( $key ) !== $value ) {
				$changed[] = $key;
			}
		}

		WCMA_Settings::update( $clean );

		/*
		 * فقط تنظیم‌هایی که واقعاً عوض شدند نشان می‌خورند؛ برگه‌ی بازِ پیشخوان فقط
		 * همان‌ها را برنمی‌گرداند و بقیه‌ی تغییرهایش ذخیره می‌شود.
		 */
		if ( $changed ) {
			$rev  = self::rev() + 1;
			$keys = get_option( self::REV . '_keys', array() );
			$keys = is_array( $keys ) ? $keys : array();

			foreach ( $changed as $key ) {
				$keys[ $key ] = $rev;
			}

			update_option( self::REV . '_keys', $keys, false );
			update_option( self::REV, $rev );
		}

		return $clean;
	}

	/**
	 * تنظیم‌هایی که پس از یک بازنگری، از تلگرام عوض شده‌اند.
	 *
	 * @param int $since شماره‌ی بازنگریِ برگه‌ی پیشخوان.
	 * @return string[]
	 */
	public static function changed_since( $since ) {
		$keys = get_option( self::REV . '_keys', array() );
		$out  = array();

		foreach ( is_array( $keys ) ? $keys : array() as $key => $rev ) {
			if ( (int) $rev > (int) $since ) {
				$out[] = (string) $key;
			}
		}

		return $out;
	}

	/**
	 * کدگذاری متن برای HTML تلگرام.
	 *
	 * متن‌های ذخیره‌شده ممکن است &lt; داشته باشند؛ اول باز و بعد کدگذاری می‌شوند.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	protected static function e( $text ) {
		return htmlspecialchars( html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' ), ENT_NOQUOTES, 'UTF-8' );
	}

	/**
	 * بخش آغازین یک متن.
	 *
	 * @param string $text متن.
	 * @param int    $max  سقف.
	 * @return string
	 */
	protected static function excerpt( $text, $max ) {
		$text = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' ) ) );

		if ( '' === $text ) {
			return '—';
		}

		return mb_strlen( $text ) > $max ? mb_substr( $text, 0, $max ) . '…' : $text;
	}

	/**
	 * برچسب کوتاه برای دکمه‌ی شیشه‌ای.
	 *
	 * @param string $text متن.
	 * @param int    $max  سقف.
	 * @return string
	 */
	protected static function short( $text, $max ) {
		$text = html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' );

		return mb_strlen( $text ) > $max ? mb_substr( $text, 0, $max ) . '…' : $text;
	}

	/**
	 * آیا مقدار، شناسه‌ی فایلِ تلگرام است (نه نشانی)؟
	 *
	 * @param string $file فایل.
	 * @return bool
	 */
	protected static function is_file_id( $file ) {
		return (bool) preg_match( '/^[A-Za-z0-9_\-]{20,255}$/', (string) $file );
	}
}
