<?php
/**
 * سنجش سرعت ربات.
 *
 * «ربات دیر جواب می‌دهد» چند علت جدا دارد که از بیرون یکسان دیده می‌شوند:
 * بالا آمدن کند وردپرس، ارتباط کند سرور با تلگرام، یا صفِ پیام‌هایی که
 * تلگرام دیر به سایت می‌رساند. اینجا هر کدام جدا اندازه گرفته می‌شود تا
 * معلوم شود کدام را باید درست کرد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Speed
 */
class WCMA_Bot_Speed {

	/**
	 * گزینه‌ی کارنامه‌ی زمان‌بندی پیام‌های اخیر.
	 */
	const LOG = 'wcma_bot_speed_log';

	/**
	 * شمار پیام‌هایی که زمان‌بندی‌شان نگه داشته می‌شود.
	 */
	const KEEP = 40;

	/**
	 * ثبت زمان‌بندیِ یک به‌روزرسانی.
	 *
	 * پس از رسیدن پاسخ به کاربر اجرا می‌شود و چیزی از سرعتش کم نمی‌کند.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    به‌روزرسانی.
	 */
	public static function record( $messenger, array $parsed ) {
		$timing = WCMA_Bot_Reply::timing();
		$api    = WCMA_Bot_Api::stats();
		$date   = (int) ( $parsed['date'] ?? 0 );
		$start  = defined( 'WCMA_WEBHOOK_STARTED' ) ? WCMA_WEBHOOK_STARTED : microtime( true );

		if ( '' !== ( $parsed['callback'] ?? '' ) ) {
			$kind = 'button';
		} elseif ( '' !== ( $parsed['phone'] ?? '' ) ) {
			$kind = 'contact';
		} elseif ( 0 === stripos( (string) ( $parsed['text'] ?? '' ), '/start' ) ) {
			$kind = 'start';
		} elseif ( ! empty( $parsed['media'] ) ) {
			$kind = 'media';
		} else {
			$kind = 'text';
		}

		$entry = array(
			'at'    => time(),
			'm'     => (string) $messenger,
			'kind'  => $kind,
			'boot'  => WCMA_Bot_Link::boot_ms(),
			'work'  => (float) $timing['work'],
			'route' => (string) $timing['route'],
			'calls' => (int) $api['calls'],
			'api'   => round( (float) $api['ms'] ),
			'slow'  => round( (float) $api['slowest'] ),
			// تأخیر رسیدن پیام از تلگرام تا سایت؛ تاریخ پیام‌ها ثانیه‌ای است.
			'lag'   => $date > 0 ? max( 0, (int) floor( $start ) - $date ) : null,
		);

		$log = get_option( self::LOG, array() );
		$log = is_array( $log ) ? $log : array();

		$log[] = $entry;

		if ( count( $log ) > self::KEEP ) {
			$log = array_slice( $log, -self::KEEP );
		}

		update_option( self::LOG, $log, false );
	}

	/**
	 * کارنامه‌ی پیام‌های اخیر.
	 *
	 * @return array
	 */
	public static function log() {
		$log = get_option( self::LOG, array() );

		return is_array( $log ) ? $log : array();
	}

	/**
	 * خلاصه‌ی کارنامه.
	 *
	 * @return array|null
	 */
	public static function summary() {
		$log = self::log();

		if ( ! $log ) {
			return null;
		}

		$boot  = array();
		$reply = array();
		$lag   = array();
		$fast  = 0;
		$calls = array();

		foreach ( $log as $row ) {
			$boot[] = (float) ( $row['boot'] ?? 0 );

			// زمانی که کاربر منتظر ماند: بالا آمدن وردپرس + کار تا رفتن پاسخ.
			if ( 'none' !== ( $row['route'] ?? 'none' ) ) {
				$reply[] = (float) ( $row['boot'] ?? 0 ) + (float) ( $row['work'] ?? 0 );
			}

			if ( null !== ( $row['lag'] ?? null ) ) {
				$lag[] = (int) $row['lag'];
			}

			if ( 'webhook' === ( $row['route'] ?? '' ) ) {
				++$fast;
			}

			if ( ! empty( $row['calls'] ) && ! empty( $row['api'] ) ) {
				$calls[] = (float) $row['api'] / max( 1, (int) $row['calls'] );
			}
		}

		return array(
			'count'    => count( $log ),
			'last'     => (int) ( end( $log )['at'] ?? 0 ),
			'boot'     => self::median( $boot ),
			'reply'    => $reply ? self::median( $reply ) : null,
			'reply_hi' => $reply ? max( $reply ) : null,
			'lag'      => $lag ? self::median( $lag ) : null,
			'lag_hi'   => $lag ? max( $lag ) : null,
			'fast'     => $fast,
			'api_call' => $calls ? self::median( $calls ) : null,
		);
	}

	/**
	 * میانه.
	 *
	 * @param array $values اعداد.
	 * @return float
	 */
	protected static function median( array $values ) {
		if ( ! $values ) {
			return 0.0;
		}

		sort( $values );

		$n   = count( $values );
		$mid = (int) floor( $n / 2 );

		return (float) ( $n % 2 ? $values[ $mid ] : ( $values[ $mid - 1 ] + $values[ $mid ] ) / 2 );
	}

	/* ------------------------------------------------------------------ */
	/* سنجش                                                                */
	/* ------------------------------------------------------------------ */

	/**
	 * سنجش کامل.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return array
	 */
	public static function check( $messenger ) {
		$messenger = sanitize_key( $messenger );

		// افزونه بی‌باز شدن پیشخوان به‌روز شده باشد، فایل حالت سریع هنوز کهنه است.
		WCMA_Bot_Fastlane::maybe_refresh();

		// پیش از سنجش: اگر حالت سریع در خودِ سنجش خطا بدهد، همان‌جا کنار می‌رود.
		$fast_on = WCMA_Bot_Fastlane::installed() && ! WCMA_Bot_Fastlane::failure();

		$result = array(
			'messenger' => $messenger,
			'api'       => self::measure_api( $messenger, null ),
			'api_v4'    => null,
			'webhook'   => self::measure_webhook( $messenger ),
			'full'      => null,
			'info'      => WCMA_Bot_Link::webhook_info( $messenger ),
			'summary'   => self::summary(),
			'server'    => self::server(),
		);

		WCMA_Bot_Fastlane::refresh();

		// با حالت سریع، بالا آمدنِ کامل هم سنجیده می‌شود تا فرقش دیده شود.
		if ( $fast_on && WCMA_Bot_Fastlane::failure() ) {
			// خودِ سنجش حالت سریع را به خطا انداخت و حالا خاموش است؛ بار کامل سنجیده می‌شود.
			$result['webhook'] = self::measure_webhook( $messenger, true );
		} elseif ( $fast_on ) {
			$result['full'] = self::measure_webhook( $messenger, true );

			/*
			 * حالت سریع وب‌هوک را خراب کرده ولی بار کامل کار می‌کند: حالت سریع همین
			 * حالا کنار می‌رود تا پیام‌های ربات بی‌پاسخ نمانند.
			 */
			if ( empty( $result['webhook']['ok'] ) && ! empty( $result['full']['ok'] ) ) {
				WCMA_Bot_Fastlane::fail( 'سنجش سرعت: ' . (string) ( $result['webhook']['error'] ?? '' ) );

				$result['webhook'] = $result['full'];
				$result['full']    = null;
			}
		}

		WCMA_Bot_Fastlane::refresh();

		/*
		 * خطای حالت سریع تا وقتی روشن است «کنار رفت» گزارش می‌شود (مثل برگه‌ی ربات)؛
		 * وقتی خاموش است فقط کنار پیشنهادِ روشن کردنش می‌آید. خطایی که خودِ سنجش بار
		 * کامل ساخته، خطای پیام واقعی نیست.
		 */
		$fast_set               = WCMA_Settings::is( 'tg_fastlane' );
		$failure                = WCMA_Bot_Fastlane::failure();
		$fatal                  = self::fatal();
		$test                   = $fatal && ! empty( $fatal['test'] );
		$result['fast_failure'] = $fast_set ? $failure : null;
		$result['fast_past']    = $fast_set ? null : $failure;
		$result['test_fatal']   = $test && time() - (int) $fatal['time'] < 600 ? $fatal : null;
		$result['fatal']        = ( $test || ( ! $fast_set && $fatal && ! empty( $fatal['fast'] ) ) ) ? null : $fatal;

		// اگر اتصال با IPv6 بود یا شکست خورد، IPv4 جدا سنجیده می‌شود.
		$api = $result['api'];

		if ( ! WCMA_Bot_Api::ipv4() && ( empty( $api['ok'] ) || false !== strpos( (string) ( $api['ip'] ?? '' ), ':' ) ) ) {
			$result['api_v4'] = self::measure_api( $messenger, true );
		}

		$result['advice'] = self::advice( $result );

		return $result;
	}

	/**
	 * سنجش ارتباط سرور با API پیام‌رسان.
	 *
	 * یک اتصال تازه (همان کاری که هر درخواست PHP باید بکند) و یک تماس دوم روی
	 * همان اتصال، تا تفاوت «اتصال تازه» و «اتصال باز» دیده شود.
	 *
	 * @param string    $messenger پیام‌رسان.
	 * @param bool|null $ipv4      فقط IPv4.
	 * @return array
	 */
	public static function measure_api( $messenger, $ipv4 ) {
		$base = WCMA_Bot_Api::base( $messenger );

		if ( '' === $base ) {
			return array(
				'ok'    => false,
				'error' => 'توکن ربات وارد نشده است.',
			);
		}

		if ( ! function_exists( 'curl_init' ) ) {
			$began    = microtime( true );
			$response = WCMA_Bot_Api::decode( wp_remote_post( $base . 'getMe', array( 'timeout' => 15 ) ) );

			return array(
				'ok'    => ! empty( $response['ok'] ),
				'total' => round( ( microtime( true ) - $began ) * 1000 ),
				'error' => empty( $response['ok'] ) ? (string) ( $response['description'] ?? '' ) : '',
			);
		}

		$url    = $base . 'getMe';
		$handle = curl_init();
		$args   = WCMA_Bot_Api::args( $url, array(), 15 );

		WCMA_Bot_Api::prepare( $handle, $url, $args, $ipv4 );

		$body = curl_exec( $handle );
		$info = curl_getinfo( $handle );
		$err  = false === $body ? curl_error( $handle ) : '';
		$out  = array(
			'ok'      => false,
			'ip'      => (string) ( $info['primary_ip'] ?? '' ),
			'dns'     => round( (float) ( $info['namelookup_time'] ?? 0 ) * 1000 ),
			'connect' => round( (float) ( $info['connect_time'] ?? 0 ) * 1000 ),
			'tls'     => round( (float) ( $info['appconnect_time'] ?? 0 ) * 1000 ),
			'total'   => round( (float) ( $info['total_time'] ?? 0 ) * 1000 ),
			'warm'    => null,
			'error'   => $err,
		);

		if ( false !== $body ) {
			$decoded = json_decode( (string) $body, true );

			if ( ! empty( $decoded['ok'] ) ) {
				$out['ok']  = true;
				$out['bot'] = (string) ( $decoded['result']['username'] ?? '' );
			} else {
				$out['error'] = (string) ( $decoded['description'] ?? ( 'HTTP ' . (int) ( $info['http_code'] ?? 0 ) ) );
			}

			// تماس دوم روی همان اتصال.
			$began = microtime( true );

			if ( false !== curl_exec( $handle ) ) {
				$out['warm'] = round( ( microtime( true ) - $began ) * 1000 );
			}
		}

		if ( PHP_VERSION_ID < 80000 ) {
			curl_close( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		return $out;
	}

	/**
	 * سنجش بالا آمدن وردپرس برای وب‌هوک، با یک درخواست آزمایشی از خود سایت.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param bool   $full      بی‌حالت سریع (بالا آمدن کامل).
	 * @return array
	 */
	public static function measure_webhook( $messenger, $full = false ) {
		$best  = null;
		$error = '';
		$url   = WCMA_Bot_Link::webhook_url( $messenger );

		if ( $full ) {
			$url = add_query_arg( 'wcma_full', '1', $url );
		}

		// بار اول کش‌ها گرم می‌شوند؛ بهترینِ دو بار، تصویر درست‌تری است.
		for ( $i = 0; $i < 2; $i++ ) {
			$began    = microtime( true );
			$response = wp_remote_post(
				$url,
				array(
					'timeout'   => 20,
					'headers'   => array( 'Content-Type' => 'application/json' ),
					'body'      => wp_json_encode( array( 'wcma_selftest' => 1 ) ),
					'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
				)
			);
			$total    = round( ( microtime( true ) - $began ) * 1000 );

			if ( is_wp_error( $response ) ) {
				$error = $response->get_error_message();
				continue;
			}

			$raw  = (string) wp_remote_retrieve_body( $response );
			$body = json_decode( $raw, true );

			if ( empty( $body['selftest'] ) ) {
				$error = self::bad_response( $response, $body, $raw );
				$http  = (int) wp_remote_retrieve_response_code( $response );
				continue;
			}

			$boot = isset( $body['boot_ms'] ) ? (float) $body['boot_ms'] : (float) $total;

			if ( null === $best || $boot < $best['boot'] ) {
				$best = array(
					'ok'    => true,
					'boot'  => round( $boot ),
					'total' => $total,
					'fast'  => ! empty( $body['fast'] ),
					'theme' => isset( $body['theme'] ) ? (int) $body['theme'] : null,
				);
			}
		}

		return $best ? $best : array(
			'ok'    => false,
			'error' => $error,
			'http'  => isset( $http ) ? $http : 0,
		);
	}

	/**
	 * شرح پاسخی که از نشانی وب‌هوک انتظار نمی‌رفت.
	 *
	 * کد HTTP به‌تنهایی نمی‌گوید خطا از کجاست؛ نام سرور (مثلاً CDN) و کد خطای
	 * وردپرس یا آغاز متن پاسخ، علت را نشان می‌دهند.
	 *
	 * @param array      $response پاسخ.
	 * @param array|null $body     بدنه‌ی JSON.
	 * @param string     $raw      بدنه‌ی خام.
	 * @return string
	 */
	protected static function bad_response( $response, $body, $raw ) {
		$code   = (int) wp_remote_retrieve_response_code( $response );
		$server = trim( (string) wp_remote_retrieve_header( $response, 'server' ) );
		$detail = '';

		if ( is_array( $body ) && ! empty( $body['code'] ) ) {
			$detail = (string) $body['code'];
		} else {
			$plain  = trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $raw ) ) );
			$detail = '' !== $plain ? mb_substr( $plain, 0, 140 ) : '';
		}

		return 'پاسخ نامنتظره (HTTP ' . $code . ( '' !== $server ? '، ' . $server : '' ) . ')' . ( '' !== $detail ? ': ' . $detail : '' );
	}

	/**
	 * آخرین خطای مهلکِ وب‌هوک در هفت روز اخیر.
	 *
	 * @return array|null
	 */
	public static function fatal() {
		$row = get_option( 'wcma_bot_fatal' );

		return is_array( $row ) && time() - (int) ( $row['time'] ?? 0 ) < WEEK_IN_SECONDS ? $row : null;
	}

	/**
	 * وضعیت سرور که روی سرعت بالا آمدن وردپرس اثر دارد.
	 *
	 * @return array
	 */
	public static function server() {
		// در حالت سریع، get_option فهرست کوتاه‌شده را می‌دهد؛ شمار واقعی لازم است.
		$plugins = WCMA_Bot_Fastlane::active_plugins();

		$opcache = function_exists( 'opcache_get_status' ) && filter_var( ini_get( 'opcache.enable' ), FILTER_VALIDATE_BOOLEAN );

		return array(
			'php'          => PHP_VERSION,
			'opcache'      => $opcache,
			'object_cache' => (bool) wp_using_ext_object_cache(),
			'plugins'      => count( $plugins ),
			'finish'       => function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' ),
			'ipv4'         => WCMA_Bot_Api::ipv4(),
			'relay'        => '' !== WCMA_Bot_Api::relay(),
		);
	}

	/**
	 * پیشنهادها، از مهم به کم‌اهمیت.
	 *
	 * @param array $r نتیجه‌ی سنجش.
	 * @return array[] هر کدام level (bad|warn|good) و text.
	 */
	public static function advice( array $r ) {
		$out     = array();
		$api     = (array) $r['api'];
		$v4      = is_array( $r['api_v4'] ) ? $r['api_v4'] : null;
		$hook    = (array) $r['webhook'];
		$info    = is_array( $r['info'] ) ? $r['info'] : array();
		$summary = is_array( $r['summary'] ) ? $r['summary'] : array();
		$server  = (array) $r['server'];
		$name    = 'bale' === ( $r['messenger'] ?? '' ) ? 'بله' : 'تلگرام';

		// ۰) خطاهایی که ربات را از کار می‌اندازند.
		$failed = is_array( $r['fast_failure'] ?? null ) ? $r['fast_failure'] : null;
		$fatal  = is_array( $r['fatal'] ?? null ) ? $r['fatal'] : null;

		if ( $failed ) {
			$out[] = array(
				'level' => 'bad',
				'text'  => 'حالت سریع روی این سایت خطا داد و خودکار کنار رفت تا ربات کار کند. علت: ' . WCMA_Bot_Fastlane::describe( $failed )
					. '. ' . WCMA_Bot_Fastlane::remedy( $failed ),
				'fix'   => 'fastlane',
			);
		}

		if ( $fatal && ( ! $failed || empty( $fatal['fast'] ) ) ) {
			$out[] = array(
				'level' => 'bad',
				'text'  => sprintf(
					'آخرین بار که پیامی به ربات رسید (%s)، وردپرس با خطای PHP متوقف شد: %s. تا این خطا درست نشود، تلگرام همان پیام را بارها دوباره می‌فرستد و ربات دیر یا اصلاً جواب نمی‌دهد.',
					WCMA_Date::format( (int) $fatal['time'], 'datetime' ),
					WCMA_Bot_Fastlane::describe( $fatal )
				),
			);
		}

		// ۱) ارتباط با سرور پیام‌رسان.
		if ( empty( $api['ok'] ) ) {
			if ( $v4 && ! empty( $v4['ok'] ) ) {
				$out[] = array( 'level' => 'bad', 'text' => 'اتصال معمولی به ' . $name . ' برقرار نشد ولی با IPv4 برقرار شد. گزینه‌ی «فقط IPv4» را روشن کنید.', 'fix' => 'ipv4' );
			} else {
				$out[] = array( 'level' => 'bad', 'text' => 'سرور سایت به ' . $name . ' وصل نمی‌شود: ' . (string) ( $api['error'] ?? '' ) . ( 'telegram' === ( $r['messenger'] ?? '' ) ? ' اگر میزبان در ایران است، دسترسی به api.telegram.org بسته است؛ نشانی یک «واسط» (مثلاً Cloudflare Worker) بگذارید یا میزبان خارج از ایران بگیرید.' : '' ) );
			}
		} else {
			$total = (int) ( $api['total'] ?? 0 );

			if ( $v4 && ! empty( $v4['ok'] ) && (int) $v4['total'] + 150 < $total ) {
				$out[] = array( 'level' => 'warn', 'text' => sprintf( 'اتصال با IPv4 سریع‌تر است (%s در برابر %s میلی‌ثانیه). گزینه‌ی «فقط IPv4» را روشن کنید.', WCMA_Date::number( (int) $v4['total'] ), WCMA_Date::number( $total ) ), 'fix' => 'ipv4' );
			}

			if ( $total > 1500 ) {
				$out[] = array( 'level' => 'bad', 'text' => sprintf( 'ارتباط سرور با %s خیلی کند است (%s میلی‌ثانیه برای هر اتصال تازه). سرور سایت از سرورهای %s دور است یا مسیرش کند است؛ میزبانی در اروپا یا یک واسط سریع‌تر، بیشترین اثر را دارد.', $name, WCMA_Date::number( $total ), $name ) );
			} elseif ( $total > 600 ) {
				$out[] = array( 'level' => 'warn', 'text' => sprintf( 'ارتباط سرور با %s کمی کند است (%s میلی‌ثانیه برای هر اتصال تازه). ربات پاسخ اول را از راه خودِ وب‌هوک می‌فرستد و این زمان بیشتر روی پیام‌های بعدی اثر دارد.', $name, WCMA_Date::number( $total ) ) );
			} else {
				$out[] = array( 'level' => 'good', 'text' => sprintf( 'ارتباط سرور با %s خوب است (%s میلی‌ثانیه).', $name, WCMA_Date::number( $total ) ) );
			}
		}

		// ۲) بالا آمدن وردپرس.
		$boot      = ! empty( $hook['ok'] ) ? (int) $hook['boot'] : ( isset( $summary['boot'] ) ? (int) $summary['boot'] : 0 );
		$full_r    = is_array( $r['full'] ?? null ) ? $r['full'] : null;
		$full      = $full_r && ! empty( $full_r['ok'] ) ? (int) $full_r['boot'] : 0;
		$fast_set  = WCMA_Settings::is( 'tg_fastlane' );
		$fast_live = WCMA_Bot_Fastlane::installed() && empty( $r['fast_failure'] );
		$past      = is_array( $r['fast_past'] ?? null ) ? $r['fast_past'] : null;

		// سنجشِ همین حالا ممکن نشد (عدد زیر، اگر باشد، از پیام‌های پیشین است).
		if ( empty( $hook['ok'] ) && ! empty( $hook['error'] ) ) {
			$out[] = array( 'level' => 'warn', 'text' => 'سنجش بالا آمدن وردپرس ممکن نشد: ' . $hook['error'] );
		}

		if ( $boot > 0 ) {
			if ( $boot > 1500 ) {
				$level = 'bad';
			} elseif ( $boot > 700 ) {
				$level = 'warn';
			} else {
				$level = 'good';
			}

			$text = sprintf( 'وردپرس برای هر پیام %s میلی‌ثانیه طول می‌کشد تا بالا بیاید (%s افزونه‌ی فعال).', WCMA_Date::number( $boot ), WCMA_Date::number( (int) $server['plugins'] ) );

			if ( $full && ! empty( $hook['fast'] ) ) {
				$text .= $full > $boot
					? sprintf( ' حالت سریع روشن است؛ بی‌آن %s میلی‌ثانیه می‌شد.', WCMA_Date::number( $full ) )
					: ' حالت سریع روشن است.';
			} elseif ( ! empty( $r['fast_failure'] ) ) {
				$text .= ' حالت سریع به‌خاطر خطای بالا کنار رفته و ربات با بار کامل وردپرس پاسخ می‌دهد.';
			} elseif ( $fast_live || is_multisite() ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
				// حالت سریع روشن است، یا در چندسایته به کار نمی‌رود؛ پیشنهادِ روشن کردنش بی‌معناست.
			} elseif ( $fast_set ) {
				$error = WCMA_Bot_Fastlane::error();
				$out[] = array(
					'level' => 'warn',
					'text'  => 'حالت سریع روشن است ولی فایلش در پوشه‌ی mu-plugins نصب نیست' . ( '' !== $error ? ': ' . $error : '؛ یک بار حالت سریع را خاموش و دوباره روشن کنید.' ),
				);
			} elseif ( 'good' !== $level || $boot > 400 ) {
				$text .= $past
					? ' «حالت سریع» این زمان را کم می‌کند، ولی پیش‌تر روی این سایت خطا داد (' . WCMA_Bot_Fastlane::describe( $past ) . ')؛ ' . WCMA_Bot_Fastlane::remedy( $past )
					: ' کش صفحه روی ربات اثری ندارد. «حالت سریع» را روشن کنید تا برای پیام‌های ربات فقط ووکامرس و همین افزونه بار شوند؛ یا افزونه‌های سنگینی را که لازم ندارید غیرفعال کنید.';
				$out[] = array(
					'level' => $level,
					'text'  => $text,
					'fix'   => 'fastlane',
				);
				$text  = '';
			}

			if ( '' !== $text ) {
				$out[] = array(
					'level' => $level,
					'text'  => $text,
				);
			}

			// حالت سریع کار می‌کند ولی بار کامل نه: اگر حالت سریع کنار برود، ربات از کار می‌افتد.
			if ( ! empty( $hook['ok'] ) && ! empty( $hook['fast'] ) && $full_r && empty( $full_r['ok'] ) && ! empty( $full_r['error'] ) ) {
				$crash = is_array( $r['test_fatal'] ?? null ) ? $r['test_fatal'] : null;
				$http  = (int) ( $full_r['http'] ?? 0 );

				if ( $crash ) {
					$why = 'با بار کامل وردپرس، وب‌هوک ربات با خطای PHP از کار می‌افتد: ' . WCMA_Bot_Fastlane::describe( $crash ) . '. حالت سریع این افزونه یا پوسته را بار نمی‌کند و جلوی خطا را گرفته است؛ همان را درست یا غیرفعال کنید.';
				} elseif ( in_array( $http, array( 401, 403, 429 ), true ) ) {
					$why = 'وب‌هوک با بار کامل وردپرس پاسخ درست نداد: ' . $full_r['error'] . '. افزونه‌ی امنیتی یا فایروالی که این پاسخ را می‌دهد، برای /wp-json/wcma/ باز کنید.';
				} else {
					$why = 'وب‌هوک با بار کامل وردپرس پاسخ درست نداد: ' . $full_r['error'] . '.';
				}

				$out[] = array(
					'level' => 'warn',
					'text'  => 'حالت سریع کار می‌کند، ولی ' . $why . ' اگر حالت سریع خاموش شود یا خودکار کنار برود، ربات از کار می‌افتد.',
				);
			}

			if ( ! empty( $hook['fast'] ) && ! empty( $hook['theme'] ) ) {
				$out[] = array(
					'level' => 'warn',
					'text'  => sprintf( 'در حالت سریع هم %s پرونده از پوسته بار شد؛ چیزی جز خود وردپرس (مثلاً افزونه‌ای در mu-plugins) پوسته را بار می‌کند و حالت سریع کامل اثر نمی‌کند.', WCMA_Date::number( (int) $hook['theme'] ) ),
				);
			} elseif ( WCMA_Bot_Fastlane::installed() && empty( $r['fast_failure'] ) && ! empty( $hook['ok'] ) && isset( $hook['fast'] ) && ! $hook['fast'] ) {
				$out[] = array(
					'level' => 'warn',
					'text'  => 'حالت سریع روشن است ولی در سنجش به کار نرفت؛ یکی از افزونه‌هایی که حالت سریع باید بار کند سر جایش نیست. یک بار حالت سریع را خاموش و دوباره روشن کنید.',
				);
			}
		}

		if ( empty( $server['opcache'] ) ) {
			$out[] = array( 'level' => 'bad', 'text' => 'OPcache روی PHP خاموش است؛ بدون آن وردپرس برای هر پیام چند برابر کندتر بالا می‌آید. از پشتیبانی میزبان بخواهید روشنش کند.' );
		}

		if ( version_compare( (string) $server['php'], '8.0', '<' ) ) {
			$out[] = array( 'level' => 'warn', 'text' => 'نسخه‌ی PHP (' . $server['php'] . ') قدیمی است؛ PHP 8.1 یا بالاتر محسوس سریع‌تر است.' );
		}

		// ۳) صف تلگرام و تأخیر رسیدن پیام‌ها.
		$pending = (int) ( $info['pending_update_count'] ?? 0 );

		if ( $pending > 3 ) {
			$out[] = array( 'level' => 'bad', 'text' => sprintf( '%s پیام در صف %s مانده و هنوز به سایت نرسیده است. «ثبت دوباره‌ی وب‌هوک» صف را خالی می‌کند.', WCMA_Date::number( $pending ), $name ), 'fix' => 'webhook' );
		}

		if ( ! empty( $info['last_error_date'] ) && time() - (int) $info['last_error_date'] < DAY_IN_SECONDS ) {
			$out[] = array( 'level' => 'bad', 'text' => sprintf( '%s آخرین بار %s نتوانست پیام را به سایت برساند: %s. هر بار که این خطا رخ دهد، %s با فاصله‌ی زیاد دوباره تلاش می‌کند و پیام‌ها دیر می‌رسند.', $name, 'در ' . WCMA_Date::format( (int) $info['last_error_date'], 'datetime' ), (string) ( $info['last_error_message'] ?? '' ), $name ) . ' ' . self::webhook_error_hint( (string) ( $info['last_error_message'] ?? '' ), $name ) );
		}

		if ( 'telegram' === ( $r['messenger'] ?? '' ) && isset( $info['allowed_updates'] ) && is_array( $info['allowed_updates'] ) && array_diff( $info['allowed_updates'], WCMA_Bot_Link::allowed_updates() ) ) {
			$out[] = array( 'level' => 'warn', 'text' => 'وب‌هوک با تنظیمات قدیمی ثبت شده و تلگرام انواع پیامی را هم می‌فرستد که ربات لازم ندارد. «ثبت دوباره‌ی وب‌هوک» را بزنید.', 'fix' => 'webhook' );
		} elseif ( 'telegram' === ( $r['messenger'] ?? '' ) && $info && ! isset( $info['allowed_updates'] ) ) {
			$out[] = array( 'level' => 'warn', 'text' => 'وب‌هوک با تنظیمات قدیمی ثبت شده است؛ یک بار «ثبت دوباره‌ی وب‌هوک» را بزنید تا فقط پیام‌ها و دکمه‌ها به سایت بیایند.', 'fix' => 'webhook' );
		}

		if ( isset( $summary['lag'] ) && null !== $summary['lag'] && $summary['lag'] >= 4 ) {
			$out[] = array( 'level' => 'bad', 'text' => sprintf( 'پیام‌ها به‌طور میانه %s ثانیه پس از فرستاده شدن به سایت می‌رسند. یعنی تأخیر پیش از سایت است: وب‌هوک خطا داده یا کند پاسخ داده و %s دارد صفش را آرام خالی می‌کند.', WCMA_Date::number( (int) $summary['lag'] ), $name ) );
		}

		if ( empty( $server['finish'] ) ) {
			$out[] = array( 'level' => 'warn', 'text' => 'PHP این میزبان امکان بستن زودهنگام پاسخ (PHP-FPM یا LiteSpeed) را ندارد؛ ربات تا پایان کارِ هر پیام، تلگرام را منتظر نگه می‌دارد.' );
		}

		// ۴) جمع‌بندی پیام‌های واقعی.
		if ( ! empty( $summary['count'] ) && null !== ( $summary['reply'] ?? null ) ) {
			$out[] = array(
				'level' => (float) $summary['reply'] > 2000 ? 'warn' : 'good',
				'text'  => sprintf(
					'در %s پیام اخیر، پاسخ ربات به‌طور میانه %s میلی‌ثانیه پس از رسیدن پیام به سایت فرستاده شد (%s پیام از راه سریعِ پاسخ وب‌هوک).',
					WCMA_Date::number( (int) $summary['count'] ),
					WCMA_Date::number( (int) round( (float) $summary['reply'] ) ),
					WCMA_Date::number( (int) $summary['fast'] )
				),
			);
		}

		return $out;
	}

	/**
	 * راهنمای یک خطای تحویل وب‌هوک از نگاه تلگرام.
	 *
	 * @param string $error متن خطا.
	 * @param string $name  نام پیام‌رسان.
	 * @return string
	 */
	protected static function webhook_error_hint( $error, $name ) {
		$error = strtolower( $error );

		if ( false !== strpos( $error, 'timed out' ) || false !== strpos( $error, 'refused' ) || false !== strpos( $error, 'resolve' ) ) {
			return sprintf(
				'یعنی سرورهای %1$s نتوانستند به سرور سایت وصل شوند: فایروال میزبان، CDN (مثل ابر آروان یا کلادفلر) یا محدودیت اینترنت بین‌الملل، درخواست‌های %1$s را راه نمی‌دهد. از پشتیبانی میزبان بخواهید دسترسی ورودی از IPهای تلگرام (149.154.160.0/20 و 91.108.4.0/22) را باز کند و اگر سایت پشت CDN است، چالش و فایروال را برای نشانی‌های /wp-json/wcma/ خاموش کنید. میزبان‌های داخل ایران معمولاً همین مشکل را دارند.',
				$name
			);
		}

		if ( false !== strpos( $error, 'ssl' ) || false !== strpos( $error, 'certificate' ) ) {
			return sprintf( 'گواهی SSL سایت از نگاه %s معتبر نیست؛ گواهی کامل (همراه زنجیره‌ی میانی) نصب کنید.', $name );
		}

		if ( preg_match( '/\b5\d\d\b/', $error ) ) {
			return 'یعنی سایت به پیام تلگرام خطای سرور داد؛ اگر «حالت سریع» روشن است، خاموشش کنید و سنجش را دوباره بزنید.';
		}

		if ( preg_match( '/\b40[134]\b/', $error ) ) {
			return 'یعنی افزونه‌ی امنیتی، فایروال یا CDN جلوی نشانی وب‌هوک را گرفته است؛ نشانی‌های /wp-json/wcma/ را از محدودیت معاف کنید.';
		}

		return '';
	}

	/**
	 * گزارش متنی کوتاه برای ربات.
	 *
	 * @param array $r نتیجه‌ی سنجش.
	 * @return string
	 */
	public static function text( array $r ) {
		$api   = (array) $r['api'];
		$hook  = (array) $r['webhook'];
		$lines = array( '⚡️ سنجش سرعت ربات', '' );

		if ( ! empty( $api['ok'] ) ) {
			$lines[] = sprintf(
				'🌐 اتصال سرور به تلگرام: %s میلی‌ثانیه (اتصال باز: %s)',
				WCMA_Date::number( (int) $api['total'] ),
				null !== ( $api['warm'] ?? null ) ? WCMA_Date::number( (int) $api['warm'] ) : '—'
			);
		} else {
			$lines[] = '🌐 اتصال سرور به تلگرام: برقرار نشد';
		}

		$lines[] = ! empty( $hook['ok'] )
			? '🧩 بالا آمدن وردپرس برای هر پیام: ' . WCMA_Date::number( (int) $hook['boot'] ) . ' میلی‌ثانیه'
			: '🧩 بالا آمدن وردپرس: سنجیده نشد';

		if ( is_array( $r['info'] ) ) {
			$lines[] = '📨 پیام‌های معطل در صف تلگرام: ' . WCMA_Date::number( (int) ( $r['info']['pending_update_count'] ?? 0 ) );
		}

		$lines[] = '';

		foreach ( (array) $r['advice'] as $item ) {
			$icon    = 'good' === $item['level'] ? '✅' : ( 'warn' === $item['level'] ? '⚠️' : '❌' );
			$lines[] = $icon . ' ' . $item['text'];
		}

		return implode( "\n", $lines );
	}
}
