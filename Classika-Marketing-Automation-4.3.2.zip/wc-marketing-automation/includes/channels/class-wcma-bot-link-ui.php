<?php
/**
 * بخش «اتصال پیام‌رسان» در حساب کاربری مشتری.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Link_UI
 */
class WCMA_Bot_Link_UI {

	/**
	 * راه‌اندازی هوک‌ها.
	 */
	public static function init() {
		add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'render' ), 20 );
		add_action( 'woocommerce_edit_account_form', array( __CLASS__, 'render' ), 20 );
		add_action( 'template_redirect', array( __CLASS__, 'handle_disconnect' ) );
	}

	/**
	 * پیام‌رسان‌هایی که هم‌اکنون آماده‌ی اتصال‌اند.
	 *
	 * @return array
	 */
	protected static function available() {
		$available = array();

		foreach ( array_keys( WCMA_Bot_Link::linkable() ) as $key ) {
			if ( ! WCMA_Messengers::is_ready( $key ) ) {
				continue;
			}

			if ( ! WCMA_Settings::get( $key . '_bot_username' ) ) {
				continue;
			}

			$available[ $key ] = WCMA_Messengers::get( $key );
		}

		return $available;
	}

	/**
	 * نمایش کارت اتصال در حساب کاربری.
	 */
	public static function render() {
		if ( ! WCMA_Settings::is( 'bot_connect_prompt' ) || ! is_user_logged_in() ) {
			return;
		}

		$available = self::available();

		if ( ! $available ) {
			return;
		}

		$user_id = get_current_user_id();
		?>
		<div class="wcma-connect">
			<h3>دریافت پیام در پیام‌رسان‌ها</h3>
			<p>با اتصال حساب خود، وضعیت سفارش‌ها و تخفیف‌های اختصاصی را در پیام‌رسان دلخواهتان دریافت می‌کنید.</p>

			<ul class="wcma-connect__list">
				<?php
				foreach ( $available as $key => $def ) :
					$connected = WCMA_Bot_Link::is_connected( $key, $user_id );
					$url       = WCMA_Bot_Link::connect_url( $key, $user_id );
					?>
					<li class="wcma-connect__item">
						<span class="wcma-connect__name"><?php echo esc_html( $def['label'] ); ?></span>

						<?php if ( $connected ) : ?>
							<span class="wcma-connect__badge">متصل است</span>
							<a
								class="wcma-connect__unlink"
								href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'wcma_disconnect', $key ), 'wcma_disconnect_' . $key ) ); ?>"
							>قطع اتصال</a>
						<?php else : ?>
							<a class="button wcma-connect__btn" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">
								اتصال به <?php echo esc_html( $def['label'] ); ?>
							</a>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>

			<p class="wcma-connect__hint">
				پس از باز شدن پیام‌رسان، دکمه‌ی «شروع» یا Start را بزنید تا اتصال کامل شود.
			</p>
		</div>

		<style>
			.wcma-connect { border: 1px solid #e5e7eb; border-radius: 12px; padding: 18px; margin: 22px 0; }
			.wcma-connect h3 { margin: 0 0 6px; font-size: 16px; }
			.wcma-connect > p { margin: 0 0 14px; font-size: 13px; color: #6b7280; line-height: 2; }
			.wcma-connect__list { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
			.wcma-connect__item { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; background: #f9fafb; border-radius: 9px; padding: 11px 14px; }
			.wcma-connect__name { flex: 1; font-weight: 600; font-size: 14px; }
			.wcma-connect__badge { background: #ecfdf5; color: #059669; border-radius: 6px; padding: 3px 10px; font-size: 12px; font-weight: 600; }
			.wcma-connect__unlink { font-size: 12px; color: #dc2626; text-decoration: none; }
			.wcma-connect__hint { margin: 14px 0 0; font-size: 12px; color: #9ca3af; }
		</style>
		<?php
	}

	/**
	 * قطع اتصال به درخواست مشتری.
	 */
	public static function handle_disconnect() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['wcma_disconnect'] ) || ! is_user_logged_in() ) {
			return;
		}

		$key = sanitize_key( wp_unslash( $_GET['wcma_disconnect'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		check_admin_referer( 'wcma_disconnect_' . $key );

		if ( ! WCMA_Bot_Link::is_linkable( $key ) ) {
			return;
		}

		WCMA_Bot_Link::unlink( $key, get_current_user_id() );

		wc_add_notice( 'اتصال با موفقیت قطع شد.', 'success' );

		wp_safe_redirect( remove_query_arg( array( 'wcma_disconnect', '_wpnonce' ) ) );
		exit;
	}
}
