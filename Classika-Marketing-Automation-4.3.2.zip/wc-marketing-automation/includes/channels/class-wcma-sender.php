<?php
/**
 * ارسال‌کننده‌ی یکپارچه‌ی پیام‌ها روی کانال‌های مختلف.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Sender
 */
class WCMA_Sender {

	/**
	 * فهرست کانال‌های موجود.
	 *
	 * @return array
	 */
	public static function channels() {
		$channels = array(
			'sms'   => 'پیامک',
			'email' => 'ایمیل',
			'both'  => 'پیامک و ایمیل',
		);

		foreach ( WCMA_Messengers::all() as $key => $def ) {
			$channels[ $key ] = $def['label'];
		}

		/**
		 * فیلتر فهرست کانال‌های ارسال.
		 *
		 * @param array $channels کانال‌ها.
		 */
		return apply_filters( 'wcma_channels', $channels );
	}

	/**
	 * کانال‌هایی که می‌توانند مقصد شخصی داشته باشند، به ترتیب اولویت پیش‌فرض.
	 *
	 * @return array
	 */
	public static function priority_channels() {
		$channels = array( 'sms', 'email' );

		foreach ( WCMA_Messengers::all() as $key => $def ) {
			$channels[] = $key;
		}

		return $channels;
	}

	/**
	 * ترتیب اولویت ارسال که مدیر تعیین کرده است.
	 *
	 * وقتی کانال انتخابیِ یک ورک‌فلو برای مشتری قابل استفاده نباشد، افزونه به ترتیب
	 * همین فهرست جایگزین می‌گردد.
	 *
	 * @return array
	 */
	public static function priority() {
		$saved = WCMA_Settings::get( 'channel_priority', array() );
		$valid = self::priority_channels();
		$order = array();

		foreach ( (array) $saved as $key ) {
			$key = sanitize_key( $key );

			if ( in_array( $key, $valid, true ) && ! in_array( $key, $order, true ) ) {
				$order[] = $key;
			}
		}

		// کانال‌هایی که در تنظیمات نیامده‌اند، ته فهرست می‌روند تا هیچ راهی از دست نرود.
		foreach ( $valid as $key ) {
			if ( ! in_array( $key, $order, true ) ) {
				$order[] = $key;
			}
		}

		/**
		 * فیلتر ترتیب اولویت کانال‌ها.
		 *
		 * @param array $order ترتیب.
		 */
		return apply_filters( 'wcma_channel_priority', $order );
	}

	/**
	 * آیا با این کانال می‌توان به این مشتری پیام داد؟
	 *
	 * @param string $channel کانال.
	 * @param array  $contact اطلاعات تماس.
	 * @return bool
	 */
	public static function can_reach( $channel, array $contact ) {
		$has_email = ! empty( $contact['email'] ) && is_email( $contact['email'] );
		$has_phone = ! empty( $contact['phone'] );
		$user_id   = (int) ( $contact['user_id'] ?? 0 );

		if ( 'email' === $channel ) {
			return $has_email;
		}

		if ( 'sms' === $channel ) {
			return $has_phone;
		}

		if ( 'both' === $channel ) {
			return $has_email && $has_phone;
		}

		if ( ! WCMA_Messengers::is_messenger( $channel ) ) {
			return false;
		}

		if ( ! WCMA_Messengers::is_ready( $channel ) ) {
			return false;
		}

		// واتساپ با شماره کار می‌کند؛ بقیه‌ی پیام‌رسان‌ها شناسه‌ی چت لازم دارند.
		if ( 'whatsapp' === $channel ) {
			return $has_phone;
		}

		if ( ! $user_id ) {
			return false;
		}

		return (bool) get_user_meta( $user_id, 'wcma_' . $channel . '_chat_id', true );
	}

	/**
	 * نخستین کانالی که با آن می‌توان به مشتری رسید.
	 *
	 * @param array  $contact  اطلاعات تماس.
	 * @param string $fallback اگر هیچ کانالی ممکن نبود.
	 * @return string
	 */
	public static function first_reachable( array $contact, $fallback = 'email' ) {
		foreach ( self::priority() as $channel ) {
			if ( self::can_reach( $channel, $contact ) ) {
				return $channel;
			}
		}

		return $fallback;
	}

	/**
	 * ارسال یک پیام.
	 *
	 * @param array $args پارامترهای ارسال.
	 * @return array{success:bool,message:string,channels:array}
	 */
	public static function send( array $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'channel'      => 'email',
				'email'        => '',
				'phone'        => '',
				'subject'      => '',
				'html'         => '',
				'text'         => '',
				'workflow'     => '',
				'step'         => '',
				'object_type'  => 'order',
				'object_id'    => 0,
				'user_id'      => 0,
				'coupon_code'  => '',
				'skip_optout'  => false,
				'log'          => true,
				'messenger_target' => '',
			)
		);

		$results  = array();
		$any_sent = false;
		$errors   = array();

		// احترام به لغو اشتراک.
		if ( ! $args['skip_optout'] && $args['email'] && WCMA_Subscribers::is_opted_out( $args['email'] ) ) {
			return array(
				'success'  => false,
				'message'  => 'مشتری اشتراک پیام‌های تبلیغاتی را لغو کرده است.',
				'channels' => array(),
			);
		}

		$channel = $args['channel'];
		$targets = ( 'both' === $channel ) ? array( 'sms', 'email' ) : array( $channel );

		foreach ( $targets as $target ) {
			$result = self::dispatch( $target, $args );

			$results[ $target ] = $result;

			if ( $result['success'] ) {
				$any_sent = true;
			} else {
				$labels   = self::channels();
				$errors[] = ( $labels[ $target ] ?? $target ) . ': ' . $result['message'];
			}

			// پشتیبان ایمیل در صورت شکست پیامک.
			if ( 'sms' === $target && ! $result['success'] && 'both' !== $channel && WCMA_Settings::is( 'sms_fallback_email' ) && $args['email'] ) {
				$fallback = self::dispatch( 'email', $args );

				$results['email_fallback'] = $fallback;

				if ( $fallback['success'] ) {
					$any_sent = true;
					$errors[] = 'ایمیل جایگزین ارسال شد.';
				} else {
					$errors[] = 'email: ' . $fallback['message'];
				}
			}
		}

		$message = $any_sent ? 'پیام ارسال شد.' : implode( ' | ', $errors );

		if ( $args['log'] ) {
			$log_data = array(
				'workflow'      => $args['workflow'],
				'step'          => $args['step'],
				'channel'       => $channel,
				'object_type'   => $args['object_type'],
				'object_id'     => (int) $args['object_id'],
				'user_id'       => (int) $args['user_id'],
				'recipient'     => $args['email'] ? $args['email'] : $args['phone'],
				'subject'       => $args['subject'],
				'message'       => $args['text'] ? $args['text'] : wp_strip_all_tags( $args['html'] ),
				'coupon_code'   => $args['coupon_code'],
				'error_message' => $any_sent ? '' : implode( ' | ', $errors ),
			);

			if ( $any_sent ) {
				$log_data['status'] = 'sent';
				WCMA_Logger::add( $log_data );
			} else {
				WCMA_Logger::add_error( $log_data );
			}
		}

		return array(
			'success'  => $any_sent,
			'message'  => $message,
			'channels' => $results,
		);
	}

	/**
	 * ارسال روی یک کانال مشخص.
	 *
	 * @param string $channel کانال.
	 * @param array  $args    پارامترها.
	 * @return array
	 */
	protected static function dispatch( $channel, array $args ) {
		if ( 'sms' === $channel ) {
			return self::send_sms( $args );
		}

		if ( 'email' === $channel ) {
			return self::send_email( $args );
		}

		if ( WCMA_Messengers::is_messenger( $channel ) ) {
			return self::send_messenger( $channel, $args );
		}

		return array(
			'success' => false,
			'message' => 'کانال نامعتبر است.',
		);
	}

	/**
	 * ارسال پیامک.
	 *
	 * @param array $args پارامترها.
	 * @return array
	 */
	public static function send_sms( array $args ) {
		if ( ! WCMA_Settings::is( 'sms_enabled' ) ) {
			return array(
				'success' => false,
				'message' => 'پنل پیامک فعال نیست.',
			);
		}

		if ( empty( $args['phone'] ) ) {
			return array(
				'success' => false,
				'message' => 'شماره موبایل گیرنده موجود نیست.',
			);
		}

		$text = $args['text'] ? $args['text'] : WCMA_Placeholders::to_plain( $args['html'] );
		$text = trim( $text );

		if ( '' === $text ) {
			return array(
				'success' => false,
				'message' => 'متن پیامک خالی است.',
			);
		}

		return WCMA_SMS_Gateways::send( $args['phone'], $text );
	}

	/**
	 * ارسال ایمیل با قالب زیبا.
	 *
	 * @param array $args پارامترها.
	 * @return array
	 */
	public static function send_email( array $args ) {
		if ( empty( $args['email'] ) || ! is_email( $args['email'] ) ) {
			return array(
				'success' => false,
				'message' => 'ایمیل گیرنده معتبر نیست.',
			);
		}

		$subject = $args['subject'] ? $args['subject'] : get_bloginfo( 'name' );
		$content = $args['html'] ? $args['html'] : wpautop( esc_html( $args['text'] ) );
		$body    = self::wrap_email( $subject, $content, $args );

		$from_name  = WCMA_Settings::get( 'from_name' );
		$from_email = WCMA_Settings::get( 'from_email' );

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( is_email( $from_email ) ) {
			$headers[] = sprintf( 'From: %s <%s>', $from_name, $from_email );
		}

		$sent = wp_mail( $args['email'], $subject, $body, $headers );

		return array(
			'success' => (bool) $sent,
			'message' => $sent ? 'ایمیل ارسال شد.' : 'ارسال ایمیل توسط وردپرس ناموفق بود (تنظیمات SMTP را بررسی کنید).',
		);
	}

	/**
	 * ارسال از طریق یکی از پیام‌رسان‌ها (تلگرام، بله، ایتا، روبیکا، واتساپ).
	 *
	 * @param string $channel کلید پیام‌رسان.
	 * @param array  $args    پارامترها.
	 * @return array
	 */
	public static function send_messenger( $channel, array $args ) {
		$target = WCMA_Messengers::resolve_target( $channel, $args );

		$text = $args['text'] ? $args['text'] : WCMA_Placeholders::to_plain( $args['html'] );

		return WCMA_Messengers::send( $channel, $target, $text, $args['html'] );
	}

	/**
	 * ارسال پیام تلگرام.
	 *
	 * برای حفظ سازگاری با کدهای قدیمی نگه داشته شده است.
	 *
	 * @param array $args پارامترها.
	 * @return array
	 */
	public static function send_telegram( array $args ) {
		if ( ! empty( $args['telegram_chat_id'] ) ) {
			$args['messenger_target'] = $args['telegram_chat_id'];
		}

		return self::send_messenger( 'telegram', $args );
	}

	/**
	 * قرار دادن محتوا در قالب ایمیل راست‌چین.
	 *
	 * @param string $subject موضوع.
	 * @param string $content محتوا.
	 * @param array  $args    پارامترها.
	 * @return string
	 */
	public static function wrap_email( $subject, $content, array $args = array() ) {
		$site   = get_bloginfo( 'name' );
		$logo   = '';
		$footer = '';

		$logo_id = get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$src = wp_get_attachment_image_url( $logo_id, 'medium' );
			if ( $src ) {
				$logo = '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $site ) . '" style="max-height:52px;margin-bottom:8px" />';
			}
		}

		if ( WCMA_Settings::is( 'unsubscribe_enabled' ) && ! empty( $args['email'] ) ) {
			$footer = '<p style="margin:12px 0 0;font-size:12px;color:#8a8f98">اگر تمایلی به دریافت این پیام‌ها ندارید، <a href="' . esc_url( WCMA_Subscribers::unsubscribe_url( $args['email'] ) ) . '" style="color:#8a8f98">لغو اشتراک</a> کنید.</p>';
		}

		$html = '<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="UTF-8" />'
			. '<meta name="viewport" content="width=device-width,initial-scale=1" />'
			. '<title>' . esc_html( $subject ) . '</title></head>'
			. '<body style="margin:0;padding:24px 12px;background:#f4f6f8;font-family:Tahoma,IRANSans,Vazirmatn,Arial,sans-serif;direction:rtl;text-align:right">'
			. '<table role="presentation" style="max-width:600px;margin:0 auto;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 2px 12px rgba(16,24,40,.06)">'
			. '<tr><td style="padding:24px 28px;background:linear-gradient(135deg,#2563eb,#4f46e5);color:#fff;text-align:center">'
			. $logo
			. '<div style="font-size:18px;font-weight:bold">' . esc_html( $site ) . '</div></td></tr>'
			. '<tr><td style="padding:28px;color:#1f2937;font-size:14px;line-height:2">' . $content . '</td></tr>'
			. '<tr><td style="padding:18px 28px;background:#f9fafb;color:#6b7280;font-size:12px;text-align:center">'
			. '<p style="margin:0"><a href="' . esc_url( home_url() ) . '" style="color:#2563eb;text-decoration:none">' . esc_html( $site ) . '</a></p>'
			. $footer
			. '</td></tr></table></body></html>';

		/**
		 * فیلتر قالب نهایی ایمیل.
		 *
		 * @param string $html    HTML نهایی.
		 * @param string $subject موضوع.
		 * @param string $content محتوا.
		 */
		return apply_filters( 'wcma_email_template', $html, $subject, $content );
	}
}
