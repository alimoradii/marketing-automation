<?php
/**
 * درگاه‌های پیامک پشتیبانی‌شده.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_SMS_Gateways
 */
class WCMA_SMS_Gateways {

	/**
	 * فهرست درگاه‌ها و فیلدهای موردنیاز هرکدام.
	 *
	 * @return array
	 */
	public static function all() {
		return array(
			'kavenegar'   => array(
				'label'  => 'کاوه‌نگار (Kavenegar)',
				'fields' => array( 'sms_api_key', 'sms_sender' ),
				'help'   => 'کلید API را از پنل کاوه‌نگار بخش «تنظیمات حساب کاربری» دریافت کنید.',
			),
			'melipayamak' => array(
				'label'  => 'ملی پیامک (MeliPayamak)',
				'fields' => array( 'sms_username', 'sms_password', 'sms_sender' ),
				'help'   => 'نام کاربری و رمز عبور پنل ملی پیامک را وارد کنید.',
			),
			'smsir'       => array(
				'label'  => 'اس ام اس دات آی آر (SMS.ir)',
				'fields' => array( 'sms_api_key', 'sms_sender' ),
				'help'   => 'کلید API نسخه ۳ پنل SMS.ir را وارد کنید.',
			),
			'ippanel'     => array(
				'label'  => 'فراز اس ام اس / IPPanel',
				'fields' => array( 'sms_api_key', 'sms_sender', 'sms_ippanel_api' ),
				'help'   => 'کلید API را از پنل IPPanel بگیرید. اگر کلید شما به‌صورت base64 است (به = ختم می‌شود) نسل جدید را انتخاب کنید؛ حالت خودکار هر دو را امتحان می‌کند.',
			),
			'farapayamak' => array(
				'label'  => 'فراپیامک (SOAP/REST)',
				'fields' => array( 'sms_username', 'sms_password', 'sms_sender' ),
				'help'   => 'نام کاربری و رمز عبور پنل فراپیامک را وارد کنید.',
			),
			'custom'      => array(
				'label'  => 'درگاه سفارشی (Webhook)',
				'fields' => array( 'sms_custom_url', 'sms_custom_method', 'sms_custom_body', 'sms_custom_headers' ),
				'help'   => 'در آدرس و بدنه‌ی درخواست می‌توانید از {phone} و {message} و {sender} استفاده کنید.',
			),
		);
	}

	/**
	 * ارسال پیامک از طریق درگاه انتخاب‌شده.
	 *
	 * @param string $phone   شماره گیرنده.
	 * @param string $message متن پیام.
	 * @return array{success:bool,message:string}
	 */
	public static function send( $phone, $message ) {
		$gateway = WCMA_Settings::get( 'sms_gateway', 'kavenegar' );
		$phone   = self::normalize_phone( $phone );

		if ( '' === $phone ) {
			return array(
				'success' => false,
				'message' => 'شماره موبایل معتبر نیست.',
			);
		}

		/**
		 * امکان پیاده‌سازی درگاه دلخواه توسط توسعه‌دهنده.
		 *
		 * @param array|null $result  نتیجه.
		 * @param string     $gateway درگاه.
		 * @param string     $phone   شماره.
		 * @param string     $message متن.
		 */
		$pre = apply_filters( 'wcma_pre_send_sms', null, $gateway, $phone, $message );
		if ( is_array( $pre ) ) {
			return $pre;
		}

		switch ( $gateway ) {
			case 'kavenegar':
				return self::send_kavenegar( $phone, $message );
			case 'melipayamak':
				return self::send_melipayamak( $phone, $message );
			case 'smsir':
				return self::send_smsir( $phone, $message );
			case 'ippanel':
				return self::send_ippanel( $phone, $message );
			case 'farapayamak':
				return self::send_farapayamak( $phone, $message );
			case 'custom':
				return self::send_custom( $phone, $message );
		}

		return array(
			'success' => false,
			'message' => 'درگاه پیامک انتخاب‌شده پشتیبانی نمی‌شود.',
		);
	}

	/**
	 * آیا پنل پیامک آماده‌ی ارسال است؟
	 *
	 * @return bool
	 */
	public static function is_ready() {
		if ( ! WCMA_Settings::is( 'sms_enabled' ) ) {
			return false;
		}

		return '' !== trim( (string) WCMA_Settings::get( 'sms_api_key', '' ) );
	}

	/**
	 * نرمال‌سازی شماره موبایل ایرانی.
	 *
	 * @param string $phone شماره.
	 * @return string
	 */
	public static function normalize_phone( $phone ) {
		$phone = (string) $phone;

		// تبدیل ارقام فارسی و عربی به لاتین.
		$persian = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		$arabic  = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$latin   = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$phone   = str_replace( $persian, $latin, $phone );
		$phone   = str_replace( $arabic, $latin, $phone );

		$phone = preg_replace( '/[^0-9+]/', '', $phone );
		$phone = ltrim( $phone, '+' );

		if ( 0 === strpos( $phone, '0098' ) ) {
			$phone = '0' . substr( $phone, 4 );
		} elseif ( 0 === strpos( $phone, '98' ) && 12 === strlen( $phone ) ) {
			$phone = '0' . substr( $phone, 2 );
		} elseif ( 0 === strpos( $phone, '9' ) && 10 === strlen( $phone ) ) {
			$phone = '0' . $phone;
		}

		if ( ! preg_match( '/^09\d{9}$/', $phone ) ) {
			return '';
		}

		return $phone;
	}

	/**
	 * ارسال با کاوه‌نگار.
	 *
	 * @param string $phone   شماره.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function send_kavenegar( $phone, $message ) {
		$api_key = WCMA_Settings::get( 'sms_api_key' );
		if ( ! $api_key ) {
			return self::error( 'کلید API کاوه‌نگار وارد نشده است.' );
		}

		$url = sprintf( 'https://api.kavenegar.com/v1/%s/sms/send.json', rawurlencode( $api_key ) );

		$response = self::request(
			$url,
			array(
				'body' => array(
					'receptor' => $phone,
					'message'  => $message,
					'sender'   => WCMA_Settings::get( 'sms_sender' ),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$code = isset( $body['return']['status'] ) ? (int) $body['return']['status'] : 0;

		if ( 200 === $code ) {
			return self::success();
		}

		return self::error( self::describe_error( $response, 'پاسخ نامعتبر از کاوه‌نگار.' ) );
	}

	/**
	 * ارسال با ملی پیامک.
	 *
	 * @param string $phone   شماره.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function send_melipayamak( $phone, $message ) {
		$username = WCMA_Settings::get( 'sms_username' );
		$password = WCMA_Settings::get( 'sms_password' );

		if ( ! $username || ! $password ) {
			return self::error( 'نام کاربری یا رمز عبور ملی پیامک وارد نشده است.' );
		}

		$response = self::request(
			'https://rest.payamak-panel.com/api/SendSMS/SendSMS',
			array(
				'body' => array(
					'username' => $username,
					'password' => $password,
					'to'       => $phone,
					'from'     => WCMA_Settings::get( 'sms_sender' ),
					'text'     => $message,
					'isflash'  => 'false',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		$status = isset( $body['RetStatus'] ) ? (int) $body['RetStatus'] : 0;

		if ( 1 === $status ) {
			return self::success();
		}

		return self::error( self::describe_error( $response, 'ارسال ملی پیامک ناموفق بود.' ) );
	}

	/**
	 * ارسال با SMS.ir.
	 *
	 * @param string $phone   شماره.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function send_smsir( $phone, $message ) {
		$api_key = WCMA_Settings::get( 'sms_api_key' );
		if ( ! $api_key ) {
			return self::error( 'کلید API سرویس SMS.ir وارد نشده است.' );
		}

		$response = self::request(
			'https://api.sms.ir/v1/send/bulk',
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
					'x-api-key'    => $api_key,
				),
				'body'    => wp_json_encode(
					array(
						'lineNumber'  => WCMA_Settings::get( 'sms_sender' ),
						'messageText' => $message,
						'mobiles'     => array( $phone ),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		$status = isset( $body['status'] ) ? (int) $body['status'] : 0;

		if ( 1 === $status ) {
			return self::success();
		}

		return self::error( self::describe_error( $response, 'ارسال از طریق SMS.ir ناموفق بود.' ) );
	}

	/**
	 * ساخت پیام خطای گویا از پاسخ سرویس‌دهنده.
	 *
	 * سرویس‌های پیامکی خطا را در ساختارهای بسیار متفاوتی برمی‌گردانند؛ گاهی رشته،
	 * گاهی آرایه‌ی خطاهای هر فیلد. اگر فقط دنبال یک کلید مشخص بگردیم، در بقیه‌ی حالت‌ها
	 * پیام واقعی دور ریخته می‌شود و مدیر سایت هیچ سرنخی برای عیب‌یابی ندارد.
	 *
	 * @param array|WP_Error $response پاسخ.
	 * @param string         $fallback پیام پیش‌فرض.
	 * @return string
	 */
	protected static function describe_error( $response, $fallback = '' ) {
		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$body = json_decode( $raw, true );

		$parts = array();

		if ( $code ) {
			$parts[] = 'کد ' . $code;
		}

		$message = self::message_from_body( $body );

		if ( '' === $message && '' !== trim( $raw ) ) {
			$message = mb_substr( trim( wp_strip_all_tags( $raw ) ), 0, 250 );
		}

		if ( '' !== $message ) {
			$parts[] = $message;
		}

		$hint = self::hint_for_code( $code );

		if ( '' !== $hint ) {
			$parts[] = $hint;
		}

		if ( ! $parts ) {
			return $fallback ? $fallback : 'پاسخ نامعتبری از سرویس دریافت شد.';
		}

		return implode( ' — ', $parts );
	}

	/**
	 * یافتن متن خطا در ساختارهای تودرتوی پاسخ.
	 *
	 * @param mixed $body بدنه‌ی decode شده.
	 * @param int   $depth عمق بازگشتی.
	 * @return string
	 */
	protected static function message_from_body( $body, $depth = 0 ) {
		if ( ! is_array( $body ) || $depth > 3 ) {
			return '';
		}

		$keys = array( 'message', 'error', 'errorMessage', 'error_message', 'description', 'detail', 'status_det', 'StrRetStatus', 'msg' );

		foreach ( $keys as $key ) {
			if ( ! isset( $body[ $key ] ) ) {
				continue;
			}

			$flat = self::flatten_value( $body[ $key ] );

			if ( '' !== $flat ) {
				return $flat;
			}
		}

		foreach ( array( 'return', 'meta', 'errors', 'error', 'data', 'result', 'response' ) as $wrapper ) {
			if ( ! isset( $body[ $wrapper ] ) || ! is_array( $body[ $wrapper ] ) ) {
				continue;
			}

			$nested = self::message_from_body( $body[ $wrapper ], $depth + 1 );

			if ( '' === $nested ) {
				$nested = self::flatten_value( $body[ $wrapper ] );
			}

			if ( '' !== $nested ) {
				return $nested;
			}
		}

		return '';
	}

	/**
	 * تبدیل مقدار (رشته، عدد یا آرایه‌ی تودرتو) به یک خط متن خوانا.
	 *
	 * @param mixed $value مقدار.
	 * @param int   $depth عمق.
	 * @return string
	 */
	protected static function flatten_value( $value, $depth = 0 ) {
		if ( is_string( $value ) ) {
			return trim( $value );
		}

		if ( is_bool( $value ) ) {
			return '';
		}

		if ( is_scalar( $value ) ) {
			return (string) $value;
		}

		if ( is_array( $value ) && $depth < 3 ) {
			$out = array();

			foreach ( $value as $key => $item ) {
				$flat = self::flatten_value( $item, $depth + 1 );

				if ( '' === $flat ) {
					continue;
				}

				$out[] = is_string( $key ) ? $key . ': ' . $flat : $flat;
			}

			return implode( '، ', array_slice( $out, 0, 5 ) );
		}

		return '';
	}

	/**
	 * راهنمای کوتاه بر اساس کد وضعیت HTTP.
	 *
	 * @param int $code کد.
	 * @return string
	 */
	protected static function hint_for_code( $code ) {
		switch ( (int) $code ) {
			case 400:
				return 'درخواست نامعتبر است';
			case 401:
			case 403:
				return 'کلید API نامعتبر است یا برای این عملیات دسترسی ندارد';
			case 402:
				return 'اعتبار پنل کافی نیست';
			case 404:
				return 'نشانی سرویس پیدا نشد؛ نسل API را در تنظیمات تغییر دهید';
			case 422:
				return 'شماره‌ی فرستنده یا گیرنده مورد قبول سرویس نیست';
			case 429:
				return 'تعداد درخواست بیش از حد مجاز';
		}

		if ( $code >= 500 ) {
			return 'خطای داخلی سرور سرویس‌دهنده';
		}

		return '';
	}

	/**
	 * ارسال با IPPanel / فراز اس ام اس.
	 *
	 * @param string $phone   شماره.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function send_ippanel( $phone, $message ) {
		$api_key = WCMA_Settings::get( 'sms_api_key' );

		if ( ! $api_key ) {
			return self::error( 'کلید API درگاه IPPanel وارد نشده است.' );
		}

		$sender = trim( (string) WCMA_Settings::get( 'sms_sender' ) );

		if ( '' === $sender ) {
			return self::error( 'شماره‌ی خط فرستنده‌ی IPPanel وارد نشده است.' );
		}

		$variant = WCMA_Settings::get( 'sms_ippanel_api', 'auto' );

		// آی‌پی‌پنل دو نسل API فعال دارد و کلیدها بین آن‌ها جابه‌جا نمی‌شوند.
		// در حالت خودکار هر دو امتحان می‌شوند تا کاربر درگیر تشخیص نسل نشود.
		$order = array( 'edge', 'legacy' );

		if ( 'edge' === $variant ) {
			$order = array( 'edge' );
		} elseif ( 'legacy' === $variant ) {
			$order = array( 'legacy' );
		}

		$errors = array();

		foreach ( $order as $api ) {
			$result = ( 'edge' === $api )
				? self::ippanel_edge( $api_key, $sender, $phone, $message )
				: self::ippanel_legacy( $api_key, $sender, $phone, $message );

			if ( $result['success'] ) {
				return $result;
			}

			$label    = ( 'edge' === $api ) ? 'نسل جدید' : 'نسل قدیمی';
			$errors[] = $label . ' → ' . $result['message'];

			// خطاهایی که با عوض کردن نسل API حل نمی‌شوند؛ تکرار بی‌فایده است.
			if ( ! empty( $result['final'] ) ) {
				break;
			}
		}

		return self::error( implode( ' | ', $errors ) );
	}

	/**
	 * نسل جدید آی‌پی‌پنل (edge.ippanel.com).
	 *
	 * کلیدهای این نسل به‌صورت base64 هستند و با هدر ApiKey احراز هویت می‌شوند.
	 *
	 * @param string $api_key کلید.
	 * @param string $sender  خط فرستنده.
	 * @param string $phone   گیرنده.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function ippanel_edge( $api_key, $sender, $phone, $message ) {
		$payload = wp_json_encode(
			array(
				'sending_type' => 'webservice',
				'from_number'  => $sender,
				'message'      => $message,
				'params'       => array(
					'recipients' => array( $phone ),
				),
			)
		);

		return self::ippanel_try_auth( 'https://edge.ippanel.com/v1/api/send', $payload, $api_key );
	}

	/**
	 * نسل قدیمی آی‌پی‌پنل (api2.ippanel.com).
	 *
	 * @param string $api_key کلید.
	 * @param string $sender  خط فرستنده.
	 * @param string $phone   گیرنده.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function ippanel_legacy( $api_key, $sender, $phone, $message ) {
		$payload = wp_json_encode(
			array(
				'recipient' => array( $phone ),
				'sender'    => $sender,
				'message'   => $message,
			)
		);

		return self::ippanel_try_auth( 'https://api2.ippanel.com/api/v1/sms/send/webservice/single', $payload, $api_key );
	}

	/**
	 * قالب‌های احراز هویتی که آی‌پی‌پنل در نسخه‌های مختلف مستندات خود معرفی کرده است.
	 *
	 * @param string $api_key کلید.
	 * @return array
	 */
	protected static function ippanel_auth_schemes( $api_key ) {
		return array(
			'ApiKey'    => array( 'Authorization' => 'ApiKey ' . $api_key ),
			'بدون پیشوند' => array( 'Authorization' => $api_key ),
			'AccessKey' => array( 'Authorization' => 'AccessKey ' . $api_key ),
			'هدر apikey' => array( 'apikey' => $api_key ),
			'Bearer'    => array( 'Authorization' => 'Bearer ' . $api_key ),
		);
	}

	/**
	 * ارسال به آی‌پی‌پنل با امتحان کردن قالب‌های مختلف احراز هویت.
	 *
	 * مستندات آی‌پی‌پنل در نسخه‌های مختلف پیشوندهای متفاوتی برای هدر Authorization
	 * معرفی کرده است و کلیدها بین آن‌ها جابه‌جا نمی‌شوند. پاسخ ۴۰۱ یعنی همین قالب
	 * پذیرفته نشد و چون چیزی ارسال نشده، امتحان قالب بعدی بی‌خطر است.
	 *
	 * @param string $url     نشانی.
	 * @param string $payload بدنه‌ی JSON.
	 * @param string $api_key کلید.
	 * @return array
	 */
	protected static function ippanel_try_auth( $url, $payload, $api_key ) {
		$rejected = array();

		foreach ( self::ippanel_auth_schemes( $api_key ) as $label => $auth_headers ) {
			$response = self::request(
				$url,
				array(
					'headers' => array_merge(
						array(
							'Content-Type' => 'application/json',
							'Accept'       => 'application/json',
						),
						$auth_headers
					),
					'body'    => $payload,
				)
			);

			if ( is_wp_error( $response ) ) {
				return self::error( $response->get_error_message() );
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( self::ippanel_is_success( $code, $body ) ) {
				return self::success();
			}

			// فقط ۴۰۱ و ۴۰۳ یعنی «این قالب احراز هویت را نمی‌شناسم»؛ بقیه خطای واقعی‌اند.
			if ( 401 !== $code && 403 !== $code ) {
				$result          = self::error( self::describe_error( $response, 'ارسال از طریق IPPanel ناموفق بود.' ) );
				$result['final'] = ( 404 !== $code );

				return $result;
			}

			$rejected[ $label ] = self::describe_error( $response, 'رد شد' );
		}

		$unique = array_unique( array_values( $rejected ) );

		// وقتی همه‌ی قالب‌ها یک پاسخ می‌گیرند، تکرار آن پیام فقط شلوغی است.
		if ( 1 === count( $unique ) ) {
			$summary = sprintf(
				'هر %d قالب احراز هویت رد شد (%s). آخرین پاسخ سرویس: %s',
				count( $rejected ),
				implode( '، ', array_keys( $rejected ) ),
				reset( $unique )
			);
		} else {
			$detail = array();

			foreach ( $rejected as $label => $message ) {
				$detail[] = $label . ' (' . $message . ')';
			}

			$summary = 'هیچ‌کدام از قالب‌های احراز هویت پذیرفته نشد: ' . implode( '، ', $detail );
		}

		return self::error(
			$summary . ' — یعنی کلید به سرویس رسید ولی پذیرفته نشد؛ معمولاً یا کلید متعلق به'
			. ' حساب دیگری است، یا دسترسی «وب‌سرویس / API» هنوز روی حساب شما فعال نشده است.'
		);
	}

	/**
	 * تشخیص موفقیت در پاسخ آی‌پی‌پنل.
	 *
	 * کد ۲۰۰ به‌تنهایی کافی نیست؛ این سرویس گاهی خطا را با وضعیت ۲۰۰ برمی‌گرداند.
	 *
	 * @param int   $code کد HTTP.
	 * @param mixed $body بدنه‌ی decode شده.
	 * @return bool
	 */
	protected static function ippanel_is_success( $code, $body ) {
		if ( $code < 200 || $code >= 300 ) {
			return false;
		}

		if ( ! is_array( $body ) ) {
			// پاسخ ۲xx بدون بدنه‌ی JSON را می‌پذیریم.
			return true;
		}

		// نشانه‌های صریح خطا.
		if ( isset( $body['meta']['status'] ) && ! $body['meta']['status'] ) {
			return false;
		}

		if ( isset( $body['status'] ) && is_string( $body['status'] ) && 'OK' !== strtoupper( $body['status'] ) ) {
			return false;
		}

		if ( ! empty( $body['errors'] ) ) {
			return false;
		}

		// نشانه‌های صریح موفقیت.
		if ( ! empty( $body['data']['message_id'] ) || ! empty( $body['message_id'] ) ) {
			return true;
		}

		if ( isset( $body['meta']['status'] ) && $body['meta']['status'] ) {
			return true;
		}

		if ( isset( $body['status'] ) && is_string( $body['status'] ) && 'OK' === strtoupper( $body['status'] ) ) {
			return true;
		}

		return true;
	}

	/**
	 * ارسال با فراپیامک (REST).
	 *
	 * @param string $phone   شماره.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function send_farapayamak( $phone, $message ) {
		$username = WCMA_Settings::get( 'sms_username' );
		$password = WCMA_Settings::get( 'sms_password' );

		if ( ! $username || ! $password ) {
			return self::error( 'نام کاربری یا رمز عبور فراپیامک وارد نشده است.' );
		}

		$response = self::request(
			'https://rest.payamak-panel.com/api/SendSMS/SendSMS',
			array(
				'body' => array(
					'username' => $username,
					'password' => $password,
					'to'       => $phone,
					'from'     => WCMA_Settings::get( 'sms_sender' ),
					'text'     => $message,
					'isflash'  => 'false',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( isset( $body['RetStatus'] ) && 1 === (int) $body['RetStatus'] ) {
			return self::success();
		}

		return self::error( self::describe_error( $response, 'ارسال فراپیامک ناموفق بود.' ) );
	}

	/**
	 * ارسال با درگاه سفارشی.
	 *
	 * @param string $phone   شماره.
	 * @param string $message متن.
	 * @return array
	 */
	protected static function send_custom( $phone, $message ) {
		$url = WCMA_Settings::get( 'sms_custom_url' );
		if ( ! $url ) {
			return self::error( 'آدرس درگاه سفارشی وارد نشده است.' );
		}

		$replace = array(
			'{phone}'   => $phone,
			'{message}' => $message,
			'{sender}'  => (string) WCMA_Settings::get( 'sms_sender' ),
		);

		$json_replace = array(
			'{phone}'   => $phone,
			'{message}' => trim( wp_json_encode( $message ), '"' ),
			'{sender}'  => (string) WCMA_Settings::get( 'sms_sender' ),
		);

		$url    = strtr( $url, array_map( 'rawurlencode', $replace ) );
		$method = strtoupper( WCMA_Settings::get( 'sms_custom_method', 'POST' ) );
		$body   = strtr( (string) WCMA_Settings::get( 'sms_custom_body' ), $json_replace );

		$headers = array( 'Content-Type' => 'application/json' );
		$raw     = trim( (string) WCMA_Settings::get( 'sms_custom_headers' ) );
		if ( $raw ) {
			foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
				if ( false !== strpos( $line, ':' ) ) {
					list( $key, $value ) = explode( ':', $line, 2 );
					$headers[ trim( $key ) ] = trim( strtr( $value, $replace ) );
				}
			}
		}

		$args = array(
			'method'  => $method,
			'headers' => $headers,
		);

		if ( 'GET' !== $method ) {
			$args['body'] = $body;
		}

		$response = self::request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return self::error( $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			return self::success();
		}

		return self::error( self::describe_error( $response, sprintf( 'درگاه سفارشی کد %d برگرداند.', $code ) ) );
	}

	/**
	 * آیا درگاه انتخاب‌شده استعلام اعتبار دارد و اطلاعاتش وارد شده است؟
	 *
	 * @return bool
	 */
	public static function has_balance() {
		if ( ! WCMA_Settings::is( 'sms_enabled' ) ) {
			return false;
		}

		$gateway = WCMA_Settings::get( 'sms_gateway' );

		if ( ! in_array( $gateway, array( 'kavenegar', 'melipayamak', 'farapayamak', 'smsir', 'ippanel' ), true ) ) {
			return false;
		}

		// بدون اطلاعات ورود، استعلام فقط یک خطای بی‌فایده می‌شود.
		if ( in_array( $gateway, array( 'melipayamak', 'farapayamak' ), true ) ) {
			return (bool) WCMA_Settings::get( 'sms_username' ) && (bool) WCMA_Settings::get( 'sms_password' );
		}

		return (bool) WCMA_Settings::get( 'sms_api_key' );
	}

	/**
	 * استعلام اعتبار پنل پیامکی.
	 *
	 * هر سرویس واحد خودش را دارد: کاوه‌نگار و SMS.ir ریال می‌دهند و ملی‌پیامک
	 * و فراپیامک تعداد پیامک. واحد همراه عدد برمی‌گردد تا چیزی جعل نشود.
	 *
	 * @param string $gateway درگاه؛ خالی یعنی درگاه انتخاب‌شده.
	 * @return array{success:bool,message:string,amount:string,unit:string}
	 */
	public static function balance( $gateway = '' ) {
		$gateway = $gateway ? $gateway : WCMA_Settings::get( 'sms_gateway' );

		switch ( $gateway ) {
			case 'kavenegar':
				return self::balance_kavenegar();
			case 'melipayamak':
			case 'farapayamak':
				return self::balance_payamak();
			case 'smsir':
				return self::balance_smsir();
			case 'ippanel':
				return self::balance_ippanel();
		}

		return self::balance_error( 'این درگاه استعلام اعتبار ندارد.' );
	}

	/**
	 * خروجی ناموفقِ استعلام.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function balance_error( $message ) {
		return array( 'success' => false, 'message' => $message, 'amount' => '', 'unit' => '' );
	}

	/**
	 * خروجی موفقِ استعلام.
	 *
	 * @param float  $amount مقدار.
	 * @param string $unit   واحد.
	 * @return array
	 */
	protected static function balance_ok( $amount, $unit ) {
		return array(
			'success' => true,
			'message' => '',
			'amount'  => WCMA_Date::number( round( (float) $amount ) ),
			'unit'    => $unit,
		);
	}

	/**
	 * اعتبار کاوه‌نگار.
	 *
	 * @return array
	 */
	protected static function balance_kavenegar() {
		$api_key = WCMA_Settings::get( 'sms_api_key' );

		if ( ! $api_key ) {
			return self::balance_error( 'کلید API کاوه‌نگار وارد نشده است.' );
		}

		$response = self::request(
			sprintf( 'https://api.kavenegar.com/v1/%s/account/info.json', rawurlencode( $api_key ) ),
			array( 'method' => 'GET' )
		);

		if ( is_wp_error( $response ) ) {
			return self::balance_error( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['entries']['remaincredit'] ) ) {
			return self::balance_ok( $body['entries']['remaincredit'], 'ریال' );
		}

		return self::balance_error( $body['return']['message'] ?? 'پاسخ نامعتبر از کاوه‌نگار.' );
	}

	/**
	 * اعتبار ملی‌پیامک و فراپیامک (هر دو روی همان پنل).
	 *
	 * @return array
	 */
	protected static function balance_payamak() {
		$username = WCMA_Settings::get( 'sms_username' );
		$password = WCMA_Settings::get( 'sms_password' );

		if ( ! $username || ! $password ) {
			return self::balance_error( 'نام کاربری یا رمز عبور وارد نشده است.' );
		}

		$response = self::request(
			'https://rest.payamak-panel.com/api/SendSMS/GetCredit',
			array( 'body' => array( 'username' => $username, 'password' => $password ) )
		);

		if ( is_wp_error( $response ) ) {
			return self::balance_error( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['Value'] ) && 1 === (int) ( $body['RetStatus'] ?? 0 ) ) {
			return self::balance_ok( $body['Value'], 'پیامک' );
		}

		return self::balance_error( $body['StrRetStatus'] ?? 'استعلام اعتبار ناموفق بود.' );
	}

	/**
	 * اعتبار SMS.ir.
	 *
	 * @return array
	 */
	protected static function balance_smsir() {
		$api_key = WCMA_Settings::get( 'sms_api_key' );

		if ( ! $api_key ) {
			return self::balance_error( 'کلید API سرویس SMS.ir وارد نشده است.' );
		}

		$response = self::request(
			'https://api.sms.ir/v1/credit',
			array(
				'method'  => 'GET',
				'headers' => array( 'Accept' => 'application/json', 'x-api-key' => $api_key ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::balance_error( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $body['data'] ) && 1 === (int) ( $body['status'] ?? 0 ) ) {
			return self::balance_ok( $body['data'], 'ریال' );
		}

		return self::balance_error( $body['message'] ?? 'استعلام اعتبار SMS.ir ناموفق بود.' );
	}

	/**
	 * اعتبار IPPanel.
	 *
	 * @return array
	 */
	protected static function balance_ippanel() {
		$api_key = WCMA_Settings::get( 'sms_api_key' );

		if ( ! $api_key ) {
			return self::balance_error( 'کلید API درگاه IPPanel وارد نشده است.' );
		}

		$response = self::request(
			'https://edge.ippanel.com/v1/api/credit',
			array(
				'method'  => 'GET',
				'headers' => array( 'Authorization' => 'AccessKey ' . $api_key, 'Accept' => 'application/json' ),
			)
		);

		if ( ! is_wp_error( $response ) ) {
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( isset( $body['data']['credit'] ) ) {
				return self::balance_ok( $body['data']['credit'], 'ریال' );
			}
		}

		// نسل قدیمی‌تر همان کلید را با ساختار دیگری می‌پذیرد.
		$legacy = self::request(
			'https://rest.ippanel.com/v1/credit',
			array( 'method' => 'GET', 'headers' => array( 'apikey' => $api_key ) )
		);

		if ( is_wp_error( $legacy ) ) {
			return self::balance_error( $legacy->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $legacy ), true );

		if ( isset( $body['data']['credit'] ) ) {
			return self::balance_ok( $body['data']['credit'], 'ریال' );
		}

		return self::balance_error( 'استعلام اعتبار IPPanel ناموفق بود؛ کلید یا نسل API را بررسی کنید.' );
	}

	/**
	 * ارسال درخواست HTTP با تنظیمات یکسان.
	 *
	 * @param string $url  آدرس.
	 * @param array  $args آرگومان‌ها.
	 * @return array|WP_Error
	 */
	protected static function request( $url, array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'timeout'   => 20,
				'method'    => 'POST',
				'sslverify' => true,
			)
		);

		return wp_remote_request( $url, $args );
	}

	/**
	 * خروجی موفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function success( $message = 'پیامک با موفقیت ارسال شد.' ) {
		return array(
			'success' => true,
			'message' => $message,
		);
	}

	/**
	 * خروجی ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function error( $message, $final = false ) {
		return array(
			'success' => false,
			'message' => $message,
			'final'   => (bool) $final,
		);
	}
}
