<?php
/**
 * کنسول تلگرامی کارکنان.
 *
 * مدیر و اپراتورها حساب کنسولشان را به ربات وصل می‌کنند و از همان‌جا سرنخ
 * ثبت می‌کنند، کارهای امروزشان را می‌بینند و یادآوری می‌گیرند — بدون باز
 * کردن پیشخوان وردپرس.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Staff
 */
class WCMA_Bot_Staff {

	/**
	 * کدهای اتصالِ صادرشده و هنوز مصرف‌نشده.
	 */
	const CODES = 'wcma_staff_codes';

	/**
	 * پیشوند گفتگوی چندمرحله‌ای هر کارمند.
	 */
	const FLOW = 'wcma_staff_flow_';

	/**
	 * اعتبار کد اتصال، به ثانیه.
	 */
	const CODE_TTL = 86400;

	/**
	 * مهلت هر گفتگوی چندمرحله‌ای، به ثانیه.
	 */
	const FLOW_TTL = 1800;

	/**
	 * سقف کارهایی که یک‌جا در ربات فهرست می‌شود.
	 */
	const LIST_MAX = 10;

	/**
	 * دکمه‌های منوی کارکنان.
	 *
	 * @return array
	 */
	public static function buttons() {
		return array(
			'lead'  => '➕ ثبت سرنخ تازه',
			'today' => '📋 کارهای امروز',
			'who'   => '👤 حساب من',
		);
	}

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		/*
		 * زودتر از مدیریت ربات می‌نشیند: پیام یک کارمند نباید به مسیر
		 * مشتری‌ها برود و دو پاسخ همزمان بگیرد.
		 */
		add_action( 'wcma_bot_started', array( __CLASS__, 'on_start' ), 1, 2 );
		add_action( 'wcma_bot_message', array( __CLASS__, 'on_message' ), 1, 2 );
	}

	/**
	 * آیا کنسول کارکنان روشن است؟
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'staff_bot' ) && WCMA_Install::table_exists( 'wcma_app_users' );
	}

	/**
	 * پیام‌رسان پیش‌فرض کنسول.
	 *
	 * وقتی جایی فقط یک نام لازم است (مثلاً کد اتصالی که هنوز مصرف نشده)،
	 * همان پیام‌رسانِ مدیریت ربات برداشته می‌شود.
	 *
	 * @return string
	 */
	public static function channel() {
		$ready = self::channels();

		if ( class_exists( 'WCMA_Bot_Manager' ) ) {
			$main = WCMA_Bot_Manager::channel();

			if ( isset( $ready[ $main ] ) ) {
				return $main;
			}
		}

		return $ready ? (string) key( $ready ) : 'telegram';
	}

	/**
	 * پیام‌رسان‌هایی که کنسول روی آن‌ها کار می‌کند.
	 *
	 * هر پیام‌رسانی که وب‌هوکش به افزونه می‌رسد و توکنش وارد شده، می‌تواند
	 * میزبان کنسول باشد — بله و روبیکا هم مثل تلگرام.
	 *
	 * @return array کلید ⇐ برچسب.
	 */
	public static function channels() {
		$out = array();

		if ( ! class_exists( 'WCMA_Bot_Link' ) || ! class_exists( 'WCMA_Messengers' ) ) {
			return $out;
		}

		foreach ( array_keys( WCMA_Bot_Link::linkable() ) as $key ) {
			if ( WCMA_Messengers::is_ready( $key ) ) {
				$def         = WCMA_Messengers::get( $key );
				$out[ $key ] = $def ? (string) $def['label'] : $key;
			}
		}

		return $out;
	}

	/**
	 * آیا کنسول باید به پیام این پیام‌رسان پاسخ بدهد؟
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return bool
	 */
	public static function is_for( $messenger ) {
		return isset( self::channels()[ (string) $messenger ] );
	}

	/* ------------------------------------------------------------------ */
	/* اتصال حساب                                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * کدهای معتبر، پس از دور ریختن منقضی‌ها.
	 *
	 * @return array
	 */
	protected static function codes() {
		$codes = get_option( self::CODES, array() );
		$codes = is_array( $codes ) ? $codes : array();
		$now   = time();
		$live  = array();

		foreach ( $codes as $code => $row ) {
			if ( is_array( $row ) && (int) ( $row['expires'] ?? 0 ) > $now ) {
				$live[ $code ] = $row;
			}
		}

		if ( count( $live ) !== count( $codes ) ) {
			update_option( self::CODES, $live, false );
		}

		return $live;
	}

	/**
	 * ساخت کد اتصال تازه برای یک حساب کنسول.
	 *
	 * @param int $app_user_id حساب.
	 * @return string
	 */
	public static function new_code( $app_user_id ) {
		$app_user_id = (int) $app_user_id;
		$user        = WCMA_App_Users::get( $app_user_id );

		if ( ! $user ) {
			return '';
		}

		$codes = self::codes();

		// کد قبلیِ همین حساب باطل می‌شود تا دو کد همزمان در گردش نباشد.
		foreach ( $codes as $code => $row ) {
			if ( (int) ( $row['user'] ?? 0 ) === $app_user_id ) {
				unset( $codes[ $code ] );
			}
		}

		$fresh = strtoupper( wp_generate_password( 8, false, false ) );

		$codes[ $fresh ] = array(
			'user'    => $app_user_id,
			'expires' => time() + self::CODE_TTL,
		);

		update_option( self::CODES, $codes, false );

		return $fresh;
	}

	/**
	 * مصرف یک کد و بستن حساب به این چت.
	 *
	 * @param string $code    کد.
	 * @param string $chat_id شناسه‌ی چت.
	 * @return array|null حساب، یا null اگر کد درست نبود.
	 */
	public static function redeem( $code, $chat_id, $messenger = '' ) {
		global $wpdb;

		$code      = strtoupper( trim( (string) $code ) );
		$chat_id   = trim( (string) $chat_id );
		$messenger = trim( (string) $messenger );
		$messenger = $messenger ? $messenger : self::channel();
		$codes     = self::codes();

		if ( '' === $code || '' === $chat_id || ! isset( $codes[ $code ] ) ) {
			return null;
		}

		$user = WCMA_App_Users::get( (int) $codes[ $code ]['user'] );

		unset( $codes[ $code ] );
		update_option( self::CODES, $codes, false );

		if ( ! $user || empty( $user['active'] ) ) {
			return null;
		}

		/*
		 * یک چت فقط به یک حساب وصل می‌ماند؛ اتصال قبلیِ همین چت به حساب
		 * دیگر باز می‌شود تا دو نفر روی یک گوشی قاطی نشوند.
		 */
		$wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_App_Users::table(),
			array( 'tg_chat_id' => '', 'tg_channel' => '' ),
			array( 'tg_chat_id' => $chat_id, 'tg_channel' => $messenger ),
			array( '%s', '%s' ),
			array( '%s', '%s' )
		);

		$wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_App_Users::table(),
			array( 'tg_chat_id' => $chat_id, 'tg_channel' => $messenger ),
			array( 'id' => (int) $user['id'] ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		WCMA_App_Users::log(
			(int) $user['id'],
			$user['name'],
			'اتصال به ربات',
			'bot',
			0,
			sprintf( '%s — شناسه‌ی چت: %s', self::label( $messenger ), $chat_id )
		);

		$user['tg_chat_id'] = $chat_id;
		$user['tg_channel'] = $messenger;

		return $user;
	}

	/**
	 * باز کردن اتصال یک حساب.
	 *
	 * @param int $app_user_id حساب.
	 * @return bool
	 */
	public static function unlink( $app_user_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return false;
		}

		$done = $wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_App_Users::table(),
			array( 'tg_chat_id' => '', 'tg_channel' => '' ),
			array( 'id' => (int) $app_user_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		return false !== $done;
	}

	/**
	 * حساب کارمندی که این چت به آن وصل است.
	 *
	 * @param string $chat_id شناسه‌ی چت.
	 * @return array|null
	 */
	public static function by_chat( $chat_id, $messenger = '' ) {
		global $wpdb;

		$chat_id = trim( (string) $chat_id );

		if ( '' === $chat_id || ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return null;
		}

		$table = WCMA_App_Users::table();

		/*
		 * شناسه‌ی چت در تلگرام و بله می‌تواند عدد یکسانی باشد و مال دو نفر
		 * جدا؛ پس کانال هم در جستجو می‌آید. ردیف‌های قدیمی کانال ندارند و
		 * برای سازگاری، خالی هم پذیرفته می‌شود.
		 */
		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE tg_chat_id = %s AND active = 1 AND ( tg_channel = %s OR tg_channel = '' ) LIMIT 1", // phpcs:ignore WordPress.DB
				$chat_id,
				$messenger ? $messenger : self::channel()
			),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * برچسب فارسی یک پیام‌رسان.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return string
	 */
	public static function label( $messenger ) {
		$def = class_exists( 'WCMA_Messengers' ) ? WCMA_Messengers::get( $messenger ) : null;

		return $def ? (string) $def['label'] : (string) $messenger;
	}

	/**
	 * چتِ وصل‌شده‌ی یک حساب.
	 *
	 * @param int $app_user_id حساب.
	 * @return string
	 */
	public static function chat_of( $app_user_id ) {
		$user = WCMA_App_Users::get( (int) $app_user_id );

		return $user ? (string) ( $user['tg_chat_id'] ?? '' ) : '';
	}

	/**
	 * پیام‌رسانی که این حساب رویش وصل است.
	 *
	 * @param array $user حساب کنسول.
	 * @return string
	 */
	public static function channel_of( array $user ) {
		$stored = trim( (string) ( $user['tg_channel'] ?? '' ) );

		// حساب‌هایی که پیش از پشتیبانی چندکاناله وصل شده‌اند، کانال ندارند.
		return $stored ? $stored : self::channel();
	}

	/**
	 * نشانی یک‌بارمصرفِ اتصال، برای گذاشتن در پیشخوان.
	 *
	 * @param string $code کد.
	 * @return string
	 */
	public static function deep_link( $code, $messenger = '' ) {
		$messenger = $messenger ? $messenger : self::channel();
		$patterns  = WCMA_Bot_Link::linkable();
		$name      = ltrim( trim( (string) WCMA_Settings::get( $messenger . '_bot_username', '' ) ), '@' );
		$code      = trim( (string) $code );

		if ( ! $name || ! $code || ! isset( $patterns[ $messenger ] ) ) {
			return '';
		}

		return sprintf( $patterns[ $messenger ], rawurlencode( $name ), rawurlencode( self::START_PREFIX . $code ) );
	}

	/**
	 * پیشوند کدِ کارکنان در دستور شروع.
	 */
	const START_PREFIX = 'staff-';

	/* ------------------------------------------------------------------ */
	/* گفتگو در ربات                                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * دستور /start.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    پیام.
	 */
	public static function on_start( $messenger, array $parsed ) {
		if ( ! self::is_on() || ! self::is_for( $messenger ) ) {
			return;
		}

		$chat_id = (string) ( $parsed['chat_id'] ?? '' );
		$text    = trim( (string) ( $parsed['text'] ?? '' ) );

		if ( '' === $chat_id ) {
			return;
		}

		$code = '';

		if ( preg_match( '/^\/start\s+' . preg_quote( self::START_PREFIX, '/' ) . '(\S+)/i', $text, $m ) ) {
			$code = $m[1];
		}

		if ( $code ) {
			$user = self::redeem( $code, $chat_id, $messenger );

			self::mine( $messenger );

			if ( $user ) {
				self::say(
					$messenger,
					$chat_id,
					sprintf(
						"سلام %s 👋\nحساب شما به ربات وصل شد.\nنقش: %s",
						$user['name'],
						WCMA_App_Users::roles()[ $user['role'] ] ?? $user['role']
					)
				);
				self::menu( $messenger, $chat_id );
			} else {
				self::say( $messenger, $chat_id, 'این کد معتبر نیست یا منقضی شده. از پیشخوان یک کد تازه بگیرید.' );
			}

			return;
		}

		// بدون کد: اگر از قبل وصل است، منوی خودش را می‌بیند.
		$user = self::by_chat( $chat_id, $messenger );

		if ( $user ) {
			self::mine( $messenger );
			self::menu( $messenger, $chat_id, sprintf( 'سلام %s 👋', $user['name'] ) );
		}
	}

	/**
	 * پیام‌های یک کارمندِ وصل‌شده.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    پیام.
	 */
	public static function on_message( $messenger, array $parsed ) {
		if ( ! self::is_on() || ! self::is_for( $messenger ) ) {
			return;
		}

		$chat_id = (string) ( $parsed['chat_id'] ?? '' );
		$text    = trim( (string) ( $parsed['text'] ?? '' ) );

		if ( '' === $chat_id || '' === $text ) {
			return;
		}

		$user = self::by_chat( $chat_id, $messenger );

		if ( ! $user ) {
			return;
		}

		// از اینجا به بعد پیام مال کنسول است، نه مشتری.
		self::mine( $messenger );

		$flow = self::flow( $chat_id );

		if ( $flow ) {
			self::step( $messenger, $user, $chat_id, $text, $flow );

			return;
		}

		self::command( $messenger, $user, $chat_id, $text );
	}

	/**
	 * دستور یا دکمه‌ی منو.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 * @param string $text      متن.
	 */
	protected static function command( $messenger, array $user, $chat_id, $text ) {
		$loose   = class_exists( 'WCMA_Bot_Manager' ) ? WCMA_Bot_Manager::loose( $text ) : $text;
		$buttons = self::buttons();

		// «/done 12» و «/lead نام | شماره | یادداشت» برای کسانی که تایپ را ترجیح می‌دهند.
		if ( preg_match( '/^\/done\s+(\d+)/i', $text, $m ) ) {
			self::close_task( $messenger, $user, $chat_id, (int) $m[1] );

			return;
		}

		if ( preg_match( '/^\/lead\s+(.+)$/isu', $text, $m ) ) {
			self::quick_lead( $messenger, $user, $chat_id, $m[1] );

			return;
		}

		if ( preg_match( '/^\/(menu|help|start)\b/i', $text ) ) {
			self::menu( $messenger, $chat_id );

			return;
		}

		if ( self::matches( $loose, $buttons['lead'] ) ) {
			if ( ! WCMA_App_Users::role_can( $user['role'], 'contact_read' ) ) {
				self::say( $messenger, $chat_id, 'حساب شما اجازه‌ی کار با پرونده‌ی مشتریان را ندارد.' );

				return;
			}

			self::start_lead( $messenger, $chat_id );

			return;
		}

		if ( self::matches( $loose, $buttons['today'] ) ) {
			self::today( $messenger, $user, $chat_id );

			return;
		}

		if ( self::matches( $loose, $buttons['who'] ) ) {
			self::whoami( $messenger, $user, $chat_id );

			return;
		}

		self::menu( $messenger, $chat_id, 'متوجه نشدم. یکی از گزینه‌های زیر را بزنید:' );
	}

	/**
	 * آیا متن با یک برچسب می‌خواند؟
	 *
	 * @param string $loose متن ساده‌شده.
	 * @param string $label برچسب دکمه.
	 * @return bool
	 */
	protected static function matches( $loose, $label ) {
		if ( ! class_exists( 'WCMA_Bot_Manager' ) ) {
			return trim( $loose ) === trim( $label );
		}

		return '' !== $loose && WCMA_Bot_Manager::loose( $label ) === $loose;
	}

	/* ------------------------------------------------------------------ */
	/* ثبت سرنخ                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * آغاز گفتگوی ثبت سرنخ.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   چت.
	 */
	protected static function start_lead( $messenger, $chat_id ) {
		self::set_flow( $chat_id, array( 'step' => 'name', 'data' => array() ) );

		self::say( $messenger, $chat_id, "نام و نام خانوادگی سرنخ را بفرستید.\n(برای انصراف «لغو» بنویسید)" );
	}

	/**
	 * یک گام از گفتگوی چندمرحله‌ای.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 * @param string $text      متن.
	 * @param array  $flow      وضعیت.
	 */
	protected static function step( $messenger, array $user, $chat_id, $text, array $flow ) {
		if ( in_array( trim( $text ), array( 'لغو', 'انصراف', '/cancel' ), true ) ) {
			self::clear_flow( $chat_id );
			self::menu( $messenger, $chat_id, 'باشد، ثبت سرنخ لغو شد.' );

			return;
		}

		$data = is_array( $flow['data'] ?? null ) ? $flow['data'] : array();

		switch ( $flow['step'] ?? '' ) {
			case 'name':
				$parts              = preg_split( '/\s+/u', trim( $text ), 2 );
				$data['first_name'] = $parts[0] ?? '';
				$data['last_name']  = $parts[1] ?? '';

				self::set_flow( $chat_id, array( 'step' => 'phone', 'data' => $data ) );
				self::say( $messenger, $chat_id, 'شماره‌ی موبایل را بفرستید. اگر ندارید «-» بزنید.' );

				return;

			case 'phone':
				$phone = self::clean_phone( $text );

				if ( '' === $phone && '-' !== trim( $text ) ) {
					self::say( $messenger, $chat_id, 'این شماره درست نیست. دوباره بفرستید یا «-» بزنید.' );

					return;
				}

				$data['phone'] = $phone;

				self::set_flow( $chat_id, array( 'step' => 'note', 'data' => $data ) );
				self::say( $messenger, $chat_id, 'یک یادداشت کوتاه درباره‌ی این سرنخ بنویسید. اگر چیزی ندارید «-» بزنید.' );

				return;

			case 'note':
				$data['note'] = ( '-' === trim( $text ) ) ? '' : trim( $text );

				self::set_flow( $chat_id, array( 'step' => 'due', 'data' => $data ) );
				self::say(
					$messenger,
					$chat_id,
					"چه زمانی پیگیری کنم؟\nمثال: فردا / ۱۴۰۵/۰۷/۰۲ / ۳ روز دیگر\nاگر پیگیری لازم نیست «-» بزنید."
				);

				return;

			case 'due':
				$data['due'] = ( '-' === trim( $text ) ) ? '' : self::parse_when( $text );

				if ( '' !== trim( $text ) && '-' !== trim( $text ) && '' === $data['due'] ) {
					self::say( $messenger, $chat_id, 'این تاریخ را نفهمیدم. مثلاً «فردا» یا «۱۴۰۵/۰۷/۰۲» بنویسید، یا «-» بزنید.' );

					return;
				}

				self::clear_flow( $chat_id );
				self::save_lead( $messenger, $user, $chat_id, $data );

				return;
		}

		self::clear_flow( $chat_id );
		self::menu( $messenger, $chat_id );
	}

	/**
	 * ثبت سرنخ تک‌خطی: نام | شماره | یادداشت | تاریخ.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 * @param string $line      متن پس از دستور.
	 */
	protected static function quick_lead( $messenger, array $user, $chat_id, $line ) {
		$parts = array_map( 'trim', preg_split( '/[|،]/u', $line ) );
		$name  = preg_split( '/\s+/u', (string) ( $parts[0] ?? '' ), 2 );

		$data = array(
			'first_name' => $name[0] ?? '',
			'last_name'  => $name[1] ?? '',
			'phone'      => self::clean_phone( $parts[1] ?? '' ),
			'note'       => (string) ( $parts[2] ?? '' ),
			'due'        => isset( $parts[3] ) ? self::parse_when( $parts[3] ) : '',
		);

		self::save_lead( $messenger, $user, $chat_id, $data );
	}

	/**
	 * نوشتن سرنخ در پرونده‌ی مشتریان.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 * @param array  $data      داده.
	 */
	protected static function save_lead( $messenger, array $user, $chat_id, array $data ) {
		$phone = (string) ( $data['phone'] ?? '' );
		$name  = trim( ( $data['first_name'] ?? '' ) . ' ' . ( $data['last_name'] ?? '' ) );

		if ( '' === $phone ) {
			self::say( $messenger, $chat_id, 'بدون شماره‌ی موبایل نمی‌شود پرونده ساخت. دوباره از «ثبت سرنخ تازه» شروع کنید.' );

			return;
		}

		$contact_id = WCMA_CRM::upsert(
			array(
				'first_name' => $data['first_name'] ?? '',
				'last_name'  => $data['last_name'] ?? '',
				'phone'      => $phone,
				'source'     => 'bot',
				'stage'      => 'lead',
			)
		);

		if ( ! $contact_id ) {
			self::say( $messenger, $chat_id, 'ثبت نشد. شماره را بررسی کنید و دوباره تلاش کنید.' );

			return;
		}

		$body = trim( (string) ( $data['note'] ?? '' ) );
		$body = '' !== $body ? $body : sprintf( 'سرنخ تازه از ربات، ثبت %s.', $user['name'] );
		$due  = (string) ( $data['due'] ?? '' );

		$note_id = WCMA_CRM::add_note( $contact_id, $body, $due ? 'followup' : 'note', 0, $user['name'], $due );

		// کار از ربات ثبت شده، پس یادآوری‌اش هم باید به همین حساب برسد.
		if ( $note_id && $due ) {
			self::own_note( $note_id, (int) $user['id'] );
		}

		WCMA_App_Users::log( (int) $user['id'], $user['name'], 'ثبت سرنخ از ربات', 'contact', $contact_id, $name );

		$lines = array(
			'✅ سرنخ ثبت شد.',
			'نام: ' . ( $name ? $name : '—' ),
			'موبایل: ' . WCMA_Date::digits( $phone ),
		);

		if ( $due ) {
			$lines[] = 'پیگیری: ' . WCMA_Date::mysql( $due, 'datetime' );
		}

		self::say( $messenger, $chat_id, implode( "\n", $lines ) );
		self::menu( $messenger, $chat_id );
	}

	/**
	 * سپردن یک کار به حساب کنسول.
	 *
	 * @param int $note_id     یادداشت.
	 * @param int $app_user_id حساب.
	 */
	public static function own_note( $note_id, $app_user_id ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_CRM::notes_table(),
			array( 'assignee' => 'app:' . (int) $app_user_id ),
			array( 'id' => (int) $note_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/* ------------------------------------------------------------------ */
	/* کارهای امروز                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * فهرست کارهای سررسیدشده‌ی این کارمند.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 */
	protected static function today( $messenger, array $user, $chat_id ) {
		$rows = WCMA_CRM::due_items(
			array(
				'assignee' => 'app:' . (int) $user['id'],
				'limit'    => self::LIST_MAX,
			)
		);

		if ( ! $rows ) {
			self::say( $messenger, $chat_id, 'کاری برای امروز ندارید. 🎉' );
			self::menu( $messenger, $chat_id );

			return;
		}

		$lines = array( '📋 کارهای امروز شما:', '' );

		foreach ( $rows as $row ) {
			$lines[] = sprintf(
				"#%d — %s\n%s\n⏰ %s\n",
				(int) $row['id'],
				WCMA_CRM::display_name( $row ),
				wp_trim_words( wp_strip_all_tags( (string) $row['body'] ), 14, '…' ),
				WCMA_Date::mysql( $row['due_at'], 'datetime' )
			);
		}

		$lines[] = 'برای بستن هر کار بنویسید: /done شماره';

		self::say( $messenger, $chat_id, implode( "\n", $lines ) );
	}

	/**
	 * بستن یک کار از ربات.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 * @param int    $note_id   کار.
	 */
	protected static function close_task( $messenger, array $user, $chat_id, $note_id ) {
		$note = WCMA_CRM::note( $note_id );

		if ( ! $note || empty( $note['due_at'] ) ) {
			self::say( $messenger, $chat_id, 'کاری با این شماره پیدا نشد.' );

			return;
		}

		// هرکس فقط کار خودش را می‌بندد، مگر مدیر باشد.
		$mine    = 'app:' . (int) $user['id'] === (string) $note['assignee'];
		$manager = WCMA_App_Users::role_can( $user['role'], 'team_history' );

		if ( ! $mine && ! $manager ) {
			self::say( $messenger, $chat_id, 'این کار به شما سپرده نشده است.' );

			return;
		}

		WCMA_CRM::mark_done( $note_id );
		WCMA_App_Users::log( (int) $user['id'], $user['name'], 'بستن کار', 'note', $note_id );

		self::say( $messenger, $chat_id, sprintf( '✅ کار #%d بسته شد.', $note_id ) );
	}

	/**
	 * معرفی حساب.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $user      کارمند.
	 * @param string $chat_id   چت.
	 */
	protected static function whoami( $messenger, array $user, $chat_id ) {
		$open = count(
			WCMA_CRM::due_items( array( 'assignee' => 'app:' . (int) $user['id'], 'limit' => 200 ) )
		);

		self::say(
			$messenger,
			$chat_id,
			sprintf(
				"👤 %s\nنام کاربری: %s\nنقش: %s\nکار باز: %s",
				$user['name'],
				$user['username'],
				WCMA_App_Users::roles()[ $user['role'] ] ?? $user['role'],
				WCMA_Date::number( $open )
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* ابزارها                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * خواندن تاریخ از زبان روزمره.
	 *
	 * کارمندی که در تلگرام تایپ می‌کند «فردا» می‌نویسد، نه «۱۴۰۵/۰۷/۰۲».
	 *
	 * @param string $text متن.
	 * @return string خالی یا Y-m-d H:i:s.
	 */
	public static function parse_when( $text ) {
		$text = trim( (string) $text );

		if ( '' === $text ) {
			return '';
		}

		$plain = WCMA_Date::to_latin_digits( $text );
		$today = (int) current_time( 'timestamp' );
		$day   = DAY_IN_SECONDS;

		/*
		 * ترتیب مهم است: «پس فردا» خودش «فردا» را در خود دارد، پس اگر
		 * کوتاه‌تر زودتر بررسی شود، پس‌فردا یک روز جلوتر می‌افتد. بلندترها
		 * اول می‌آیند.
		 */
		$words = array(
			'پس فردا' => 2,
			'پس‌فردا' => 2,
			'پسفردا'  => 2,
			'فردا'    => 1,
			'امروز'   => 0,
		);

		foreach ( $words as $word => $offset ) {
			if ( false !== mb_strpos( $text, $word ) ) {
				return gmdate( 'Y-m-d', $today + $offset * $day ) . ' ' . WCMA_CRM::default_due_time();
			}
		}

		// «۳ روز دیگر» و «۲ هفته دیگر».
		if ( preg_match( '/(\d+)\s*(روز|هفته)/u', $plain, $m ) ) {
			$count = (int) $m[1];
			$span  = ( 'هفته' === $m[2] ) ? 7 : 1;

			return gmdate( 'Y-m-d', $today + $count * $span * $day ) . ' ' . WCMA_CRM::default_due_time();
		}

		return WCMA_CRM::clean_due( $text );
	}

	/**
	 * شماره‌ی موبایل، به شکل یکدست.
	 *
	 * @param string $text ورودی.
	 * @return string
	 */
	protected static function clean_phone( $text ) {
		$phone = WCMA_SMS_Gateways::normalize_phone( WCMA_Date::to_latin_digits( (string) $text ) );

		return $phone ? $phone : '';
	}

	/**
	 * نشان‌دار کردن پیام به‌عنوان «مال کنسول».
	 *
	 * مدیریت ربات و چت‌بات هر دو روی همان پیام می‌نشینند؛ بدون این، کارمند
	 * برای یک دکمه دو پاسخ می‌گیرد: یکی مال کنسول و یکی مال مسیر مشتری.
	 *
	 * @param string $messenger پیام‌رسان.
	 */
	protected static function mine( $messenger ) {
		unset( $messenger );

		if ( class_exists( 'WCMA_Bot_Manager' ) ) {
			remove_action( 'wcma_bot_message', array( 'WCMA_Bot_Manager', 'on_message' ), 5 );
			remove_action( 'wcma_bot_started', array( 'WCMA_Bot_Manager', 'on_start' ), 10 );
		}

		add_filter( 'wcma_chatbot_skip', '__return_true' );
	}

	/**
	 * فرستادن پیام به کارمند.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   چت.
	 * @param string $text      متن.
	 * @return array
	 */
	public static function say( $messenger, $chat_id, $text ) {
		return WCMA_Messengers::send( $messenger, $chat_id, $text );
	}

	/**
	 * فرستادن منو با کیبورد.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   چت.
	 * @param string $intro     پیام بالای منو.
	 */
	public static function menu( $messenger, $chat_id, $intro = '' ) {
		$buttons  = array_values( self::buttons() );
		$keyboard = array(
			'keyboard'        => array( array( $buttons[0] ), array( $buttons[1], $buttons[2] ) ),
			'resize_keyboard' => true,
		);

		$text = $intro ? $intro : 'چه کاری انجام دهم؟';
		$def  = WCMA_Messengers::get( $messenger );

		if ( ! $def || ! in_array( $messenger, array( 'telegram', 'bale' ), true ) ) {
			self::say( $messenger, $chat_id, $text . "\n\n" . implode( "\n", $buttons ) );

			return;
		}

		// پیش‌تر توکن دو بار در نشانی می‌آمد (api_base خودش توکن دارد) و منوی کارکنان هرگز نمی‌رسید.
		WCMA_Bot_Api::call(
			$messenger,
			'sendMessage',
			array(
				'chat_id'      => $chat_id,
				'text'         => $text,
				'reply_markup' => wp_json_encode( $keyboard ),
			),
			array( 'timeout' => 15 )
		);
	}

	/* ------------------------------------------------------------------ */
	/* وضعیت گفتگوی چندمرحله‌ای                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * وضعیت جاری.
	 *
	 * @param string $chat_id چت.
	 * @return array|null
	 */
	protected static function flow( $chat_id ) {
		$flow = get_transient( self::FLOW . md5( (string) $chat_id ) );

		return is_array( $flow ) ? $flow : null;
	}

	/**
	 * ثبت وضعیت.
	 *
	 * @param string $chat_id چت.
	 * @param array  $flow    وضعیت.
	 */
	protected static function set_flow( $chat_id, array $flow ) {
		set_transient( self::FLOW . md5( (string) $chat_id ), $flow, self::FLOW_TTL );
	}

	/**
	 * پاک کردن وضعیت.
	 *
	 * @param string $chat_id چت.
	 */
	protected static function clear_flow( $chat_id ) {
		delete_transient( self::FLOW . md5( (string) $chat_id ) );
	}
}
