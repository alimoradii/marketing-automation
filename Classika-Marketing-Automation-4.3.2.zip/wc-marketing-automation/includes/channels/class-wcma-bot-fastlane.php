<?php
/**
 * حالت سریع وب‌هوک ربات.
 *
 * برای هر پیامی که کاربر به ربات می‌دهد، وردپرس از صفر بالا می‌آید: همه‌ی
 * افزونه‌ها (صفحه‌ساز، سئو، کش، فرم‌ساز و …) و پوسته بار می‌شوند، در حالی که
 * ربات جز ووکامرس و همین افزونه به هیچ‌کدام نیازی ندارد. روی سایتی با چند ده
 * افزونه، همین بالا آمدن بیشترِ زمانِ پاسخ ربات است.
 *
 * این حالت یک فایل کوچک در mu-plugins می‌گذارد که فقط برای درخواست‌های
 * وب‌هوک ربات، فهرست افزونه‌های فعال را کوتاه می‌کند و functions.php پوسته را
 * بار نمی‌کند. بقیه‌ی سایت هیچ تغییری نمی‌بیند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Fastlane
 */
class WCMA_Bot_Fastlane {

	/**
	 * نام فایل در mu-plugins.
	 */
	const FILE = 'wcma-bot-fastlane.php';

	/**
	 * نشانه‌ای که فایل را از آنِ همین افزونه می‌داند.
	 */
	const MARK = 'WCMA_FASTLANE_FILE';

	/**
	 * گزینه‌ی آخرین خطای نوشتن فایل.
	 */
	const ERROR = 'wcma_fastlane_error';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		// تنظیمات از هر راهی (پیشخوان یا ربات) عوض شود، فایل همگام می‌شود.
		add_action( 'update_option_' . WCMA_Settings::OPTION, array( __CLASS__, 'on_update' ), 20, 2 );
		add_action( 'add_option_' . WCMA_Settings::OPTION, array( __CLASS__, 'on_add' ), 20, 2 );

		// فهرست افزونه‌ها که عوض شود، فهرست نگه‌داشتنی‌ها هم باید تازه شود.
		add_action( 'activated_plugin', array( __CLASS__, 'on_plugins' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'on_plugins' ) );

		// پس از به‌روزرسانی افزونه، فایل با کد تازه نوشته می‌شود.
		add_action( 'admin_init', array( __CLASS__, 'maybe_refresh' ) );
	}

	/**
	 * پس از تغییر تنظیمات.
	 *
	 * @param mixed $old   مقدار پیشین.
	 * @param mixed $value مقدار تازه.
	 */
	public static function on_update( $old, $value ) {
		$old   = is_array( $old ) ? $old : array();
		$value = is_array( $value ) ? $value : null;

		/*
		 * روشن کردنِ دوباره یا تغییر فهرست نگه‌داشتنی‌ها یعنی مدیر می‌خواهد دوباره
		 * امتحان کند؛ نشانِ «حالت سریع خطا داد» پاک می‌شود.
		 */
		if ( $value && 'yes' === ( $value['tg_fastlane'] ?? 'no' ) ) {
			$turned_on = 'yes' !== ( $old['tg_fastlane'] ?? 'no' );
			$new_keep  = (array) ( $value['tg_fastlane_keep'] ?? array() );
			$old_keep  = (array) ( $old['tg_fastlane_keep'] ?? array() );

			sort( $new_keep );
			sort( $old_keep );

			if ( $turned_on || $new_keep !== $old_keep ) {
				delete_option( 'wcma_fastlane_failed' );

				$fatal = get_option( 'wcma_bot_fatal' );

				if ( is_array( $fatal ) && ! empty( $fatal['fast'] ) ) {
					delete_option( 'wcma_bot_fatal' );
				}
			}
		}

		self::sync( $value );
	}

	/**
	 * اگر حالت سریع روی این سایت خطا داده و کنار رفته، جزئیات آن خطا.
	 *
	 * @return array|null
	 */
	public static function failure() {
		$row = get_option( 'wcma_fastlane_failed' );

		return is_array( $row ) ? $row : null;
	}

	/**
	 * فراموش کردن خطاهای ثبت‌شده در کش همین درخواست.
	 *
	 * خطا را درخواست دیگری (وب‌هوکی که از کار افتاد) در پایگاه داده می‌نویسد؛
	 * بی‌این کار، این درخواست همان «نبودنِ» پیشین را از کش می‌خواند.
	 */
	public static function refresh() {
		$missing = wp_cache_get( 'notoptions', 'options' );

		foreach ( array( 'wcma_fastlane_failed', 'wcma_bot_fatal' ) as $option ) {
			wp_cache_delete( $option, 'options' );

			if ( is_array( $missing ) ) {
				unset( $missing[ $option ] );
			}
		}

		if ( is_array( $missing ) ) {
			wp_cache_set( 'notoptions', $missing, 'options' );
		}
	}

	/**
	 * کنار گذاشتن حالت سریع به‌خاطر یک خطا (تا روشن کردنِ دوباره).
	 *
	 * @param string $message علت.
	 */
	public static function fail( $message ) {
		if ( ! self::failure() ) {
			update_option(
				'wcma_fastlane_failed',
				array(
					'time'    => time(),
					'fast'    => true,
					'ver'     => WCMA_VERSION,
					'message' => (string) $message,
					'file'    => '',
					'line'    => 0,
				),
				false
			);
		}
	}

	/**
	 * متن کوتاه یک خطای ثبت‌شده.
	 *
	 * @param array $row خطا.
	 * @return string
	 */
	public static function describe( array $row ) {
		$text = (string) ( $row['message'] ?? '' );

		if ( ! empty( $row['file'] ) && false === strpos( $text, (string) $row['file'] ) ) {
			$text .= ' — ' . $row['file'] . ( ! empty( $row['line'] ) ? ':' . (int) $row['line'] : '' );
		}

		return $text;
	}

	/**
	 * راه درست کردنِ یک خطای حالت سریع، به زبان ساده.
	 *
	 * @param array $row خطا.
	 * @return string
	 */
	public static function remedy( array $row ) {
		$file = str_replace( '\\', '/', (string) ( $row['file'] ?? '' ) );

		if ( self::own_bug( $row ) ) {
			return 'این خطا از خود حالت سریع بود (پوسته کامل کنار گذاشته نمی‌شد) و در نسخه‌ی تازه‌ی افزونه درست شده است؛ حالت سریع را یک بار خاموش و دوباره روشن کنید.';
		}

		if ( preg_match( '#(^|/)themes/#', $file ) ) {
			return 'این خطا از پوسته‌ی سایت است و حالت سریع پوسته را بار نمی‌کند؛ حالت سریع را خاموش بگذارید.';
		}

		$plugin = self::culprit( (string) ( $row['message'] ?? '' ) );

		if ( 'theme' === $plugin ) {
			return 'چیزی که کم بود در پوسته‌ی سایت است و حالت سریع پوسته را بار نمی‌کند؛ حالت سریع را خاموش بگذارید.';
		}

		if ( '' !== $plugin ) {
			$data = get_file_data( WP_PLUGIN_DIR . '/' . $plugin, array( 'name' => 'Plugin Name' ) );
			$name = '' !== trim( (string) $data['name'] ) ? trim( (string) $data['name'] ) : dirname( $plugin );

			return 'چیزی که کم بود در افزونه‌ی «' . $name . '» است؛ آن را در «افزونه‌هایی که در حالت سریع هم بار شوند» تیک بزنید تا حالت سریع دوباره امتحان شود.';
		}

		return 'اگر نام افزونه‌ای در این خطا هست، آن را در «افزونه‌هایی که در حالت سریع هم بار شوند» تیک بزنید تا حالت سریع دوباره امتحان شود؛ اگر نمی‌دانید کدام افزونه لازم است، حالت سریع را خاموش بگذارید.';
	}

	/**
	 * افزونه‌ای که تابع یا کلاسِ ناپیدای یک خطا را می‌سازد.
	 *
	 * فقط افزونه‌های فعالی گشته می‌شوند که حالت سریع کنار می‌گذارد؛ نتیجه یک
	 * روز نگه داشته می‌شود تا هر بار باز شدن برگه پوشه‌ها را نگردد.
	 *
	 * @param string $message پیام خطا.
	 * @return string پایه‌نامِ افزونه یا رشته‌ی خالی.
	 */
	public static function culprit( $message ) {
		if ( preg_match( '/undefined function ([A-Za-z0-9_\\\\]+)\s*\(/i', $message, $m ) ) {
			$kind = 'function';
		} elseif ( preg_match( '/(?:Class|Interface|Trait) ["\']?([A-Za-z0-9_\\\\]+)["\']? not found/i', $message, $m ) ) {
			$kind = 'class';
		} else {
			return '';
		}

		$parts = explode( '\\', trim( $m[1], '\\' ) );
		$short = (string) end( $parts );
		$cache = 'wcma_fl_culprit_' . md5( $kind . strtolower( $m[1] ) );
		$hit   = get_transient( $cache );

		if ( false !== $hit ) {
			return (string) $hit;
		}

		$pattern = 'function' === $kind
			? '/(?:^|<\?php)[ \t]*function[ \t]+&?[ \t]*' . preg_quote( $short, '/' ) . '[ \t]*\(/mi'
			: '/(?:^|<\?php)[ \t]*(?:(?:abstract|final|readonly)[ \t]+)*(?:class|interface|trait|enum)[ \t]+' . preg_quote( $short, '/' ) . '\b/mi';

		$keep  = self::keep();
		$found = '';
		$spent = array( 0, 0 );

		foreach ( self::active_plugins() as $plugin ) {
			if ( in_array( $plugin, $keep, true ) ) {
				continue;
			}

			$where = '.' === dirname( $plugin ) ? WP_PLUGIN_DIR . '/' . $plugin : WP_PLUGIN_DIR . '/' . dirname( $plugin );
			$hit   = self::scan( $where, $short, $pattern, $spent );

			if ( null === $hit ) {
				break;
			}

			if ( $hit ) {
				$found = $plugin;
				break;
			}
		}

		// حالت سریع پوسته را هم بار نمی‌کند.
		if ( '' === $found ) {
			foreach ( array_unique( array( get_stylesheet_directory(), get_template_directory() ) ) as $theme ) {
				if ( $theme && self::scan( $theme, $short, $pattern, $spent ) ) {
					$found = 'theme';
					break;
				}
			}
		}

		set_transient( $cache, $found, DAY_IN_SECONDS );

		return $found;
	}

	/**
	 * گشتن پرونده‌های PHP یک پوشه یا یک پرونده برای یک الگو.
	 *
	 * @param string $where  پوشه یا پرونده.
	 * @param string $needle واژه‌ای که باید در پرونده باشد.
	 * @param string $regex  الگو.
	 * @param array  $spent  شمار پرونده‌ها و بایت‌های خوانده‌شده تا اینجا.
	 * @return bool|null پیدا شد؟ null وقتی سقف خواندن پر شد.
	 */
	protected static function scan( $where, $needle, $regex, array &$spent ) {
		$list = array();

		if ( is_file( $where ) ) {
			$list[] = $where;
		} elseif ( is_dir( $where ) ) {
			try {
				$walk = new RecursiveIteratorIterator(
					new RecursiveCallbackFilterIterator(
						new RecursiveDirectoryIterator( $where, FilesystemIterator::SKIP_DOTS ),
						static function ( $entry ) {
							return ! $entry->isDir() || ! in_array( strtolower( $entry->getFilename() ), array( 'node_modules', 'tests', 'test', '.git', 'assets', 'languages' ), true );
						}
					)
				);

				foreach ( $walk as $entry ) {
					if ( $entry->isFile() && 'php' === strtolower( $entry->getExtension() ) && $entry->getSize() < 2097152 ) {
						$list[] = $entry->getPathname();
					}
				}
			} catch ( Exception $e ) {
				return false;
			}
		}

		foreach ( $list as $path ) {
			if ( ++$spent[0] > 6000 || $spent[1] > 80 * 1048576 ) {
				return null;
			}

			$code = (string) @file_get_contents( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions

			$spent[1] += strlen( $code );

			if ( false !== stripos( $code, $needle ) && preg_match( $regex, $code ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * پس از فعال یا غیرفعال شدن یک افزونه.
	 *
	 * @param string $plugin افزونه.
	 */
	public static function on_plugins( $plugin ) {
		// غیرفعال شدنِ خودِ این افزونه: فایل نباید دوباره ساخته شود.
		if ( defined( 'WCMA_BASENAME' ) && WCMA_BASENAME === $plugin && 'deactivated_plugin' === current_action() ) {
			self::remove();

			return;
		}

		self::sync();
	}

	/**
	 * پس از ساخته شدن تنظیمات.
	 *
	 * @param string $option نام.
	 * @param mixed  $value  مقدار.
	 */
	public static function on_add( $option, $value ) {
		self::sync( is_array( $value ) ? $value : null );
	}

	/**
	 * مسیر فایل.
	 *
	 * @return string
	 */
	public static function path() {
		$dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';

		return trailingslashit( $dir ) . self::FILE;
	}

	/**
	 * آیا فایلِ همین افزونه در جای خودش است؟
	 *
	 * @return bool
	 */
	public static function installed() {
		$path = self::path();

		return is_readable( $path ) && false !== strpos( (string) file_get_contents( $path ), self::MARK ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * آیا همین درخواست با حالت سریع بالا آمده است؟
	 *
	 * @return bool
	 */
	public static function active_now() {
		return defined( 'WCMA_FASTLANE' ) && WCMA_FASTLANE;
	}

	/**
	 * افزونه‌هایی که در حالت سریع هم بار می‌شوند.
	 *
	 * @param array|null $settings تنظیمات (اگر تازه ذخیره شده و هنوز در کش نیست).
	 * @return string[]
	 */
	public static function keep( $settings = null ) {
		$active = self::active_plugins();
		$keep   = array();

		if ( defined( 'WCMA_BASENAME' ) ) {
			$keep[] = WCMA_BASENAME;
		}

		// ووکامرس هر جا نصب شده باشد (حتی با نام پوشه‌ی دیگر)؛ این افزونه بی آن بار نمی‌شود.
		if ( defined( 'WC_PLUGIN_FILE' ) ) {
			$wc = plugin_basename( WC_PLUGIN_FILE );

			if ( in_array( $wc, $active, true ) ) {
				$keep[] = $wc;
			}
		}

		foreach ( $active as $plugin ) {
			$slug = strtolower( dirname( $plugin ) );

			// خودِ ووکامرس و فارسی‌ساز آن (واحد پول تومان، تاریخ شمسی سفارش‌ها).
			if ( 'woocommerce/woocommerce.php' === $plugin || in_array( $slug, array( 'persian-woocommerce', 'woocommerce-persian', 'parsi-woocommerce' ), true ) ) {
				$keep[] = $plugin;
			}
		}

		$extra = is_array( $settings ) && isset( $settings['tg_fastlane_keep'] ) ? $settings['tg_fastlane_keep'] : WCMA_Settings::get( 'tg_fastlane_keep', array() );

		foreach ( (array) $extra as $plugin ) {
			if ( in_array( $plugin, $active, true ) ) {
				$keep[] = $plugin;
			}
		}

		return array_values( array_unique( $keep ) );
	}

	/**
	 * افزونه‌های فعال سایت (بی‌اثر از خودِ حالت سریع).
	 *
	 * @return string[]
	 */
	public static function active_plugins() {
		global $wpdb;

		// در درخواستِ حالت سریع، get_option فهرست کوتاه‌شده را می‌دهد.
		$raw     = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'active_plugins' ) ); // phpcs:ignore WordPress.DB
		$plugins = is_string( $raw ) ? maybe_unserialize( $raw ) : array();
		$plugins = is_array( $plugins ) ? $plugins : array();

		if ( is_multisite() ) {
			$raw     = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key = %s AND site_id = %d", 'active_sitewide_plugins', get_current_network_id() ) ); // phpcs:ignore WordPress.DB
			$network = is_string( $raw ) ? maybe_unserialize( $raw ) : array();
			$plugins = array_merge( $plugins, array_keys( is_array( $network ) ? $network : array() ) );
		}

		return array_values(
			array_filter(
				array_unique( array_map( 'strval', $plugins ) ),
				static function ( $plugin ) {
					return (bool) preg_match( '#^[A-Za-z0-9._\-]+(/[A-Za-z0-9._\-]+)?\.php$#', $plugin );
				}
			)
		);
	}

	/**
	 * همگام کردن فایل با تنظیمات.
	 *
	 * @param array|null $settings تنظیمات تازه.
	 * @return bool آیا وضعیت فایل همان شد که باید؟
	 */
	public static function sync( $settings = null ) {
		$settings = is_array( $settings ) ? $settings : null;
		$want     = $settings ? ( 'yes' === ( $settings['tg_fastlane'] ?? 'no' ) ) : WCMA_Settings::is( 'tg_fastlane' );

		if ( ! $want ) {
			self::remove();
			delete_option( self::ERROR );

			return true;
		}

		// یک فایل mu-plugins برای همه‌ی سایت‌های شبکه است؛ حالت سریع در چندسایته به کار نمی‌رود.
		if ( is_multisite() ) {
			self::remove();
			update_option( self::ERROR, 'حالت سریع در وردپرسِ چندسایته (شبکه) پشتیبانی نمی‌شود.', false );

			return false;
		}

		$code = self::code( self::keep( $settings ) );
		$path = self::path();

		if ( is_readable( $path ) && (string) file_get_contents( $path ) === $code ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			// شاید فایل را فرایند دیگری (مثلاً WP-CLI) نوشته باشد و OPcache این فرایند هنوز نسخه‌ی پیشین را داشته باشد.
			if ( function_exists( 'opcache_invalidate' ) ) {
				@opcache_invalidate( $path, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}

			delete_option( self::ERROR );

			return true;
		}

		// فایلی با همین نام که مال ما نیست، دست نمی‌خورد.
		if ( file_exists( $path ) && ! self::installed() ) {
			update_option( self::ERROR, 'فایلی با نام ' . self::FILE . ' در mu-plugins هست که مال این افزونه نیست.', false );

			return false;
		}

		$dir = dirname( $path );

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// اول در فایل موقت و بعد جابه‌جایی، تا درخواستِ همزمان فایلِ نیمه‌نوشته را بار نکند.
		$tmp     = $path . '.' . wp_generate_password( 6, false, false ) . '.tmp';
		$written = is_dir( $dir ) && is_writable( $dir ) && false !== @file_put_contents( $tmp, $code ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions

		if ( $written && @rename( $tmp, $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
			if ( function_exists( 'opcache_invalidate' ) ) {
				@opcache_invalidate( $path, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}

			delete_option( self::ERROR );

			return true;
		}

		if ( file_exists( $tmp ) ) {
			wp_delete_file( $tmp );
		}

		update_option( self::ERROR, 'پوشه‌ی ' . $dir . ' قابل نوشتن نیست؛ حالت سریع نصب نشد.', false );

		return false;
	}

	/**
	 * پس از به‌روزرسانی افزونه، کد فایل تازه می‌شود.
	 */
	public static function maybe_refresh( $force = false ) {
		// در چندسایته حالت سریع به کار نمی‌رود؛ فایلی که نسخه‌های پیشین ساخته بودند برداشته می‌شود.
		if ( is_multisite() ) {
			if ( self::installed() ) {
				self::remove();
			}

			return;
		}

		if ( ! WCMA_Settings::is( 'tg_fastlane' ) || ( ! $force && WCMA_VERSION === get_option( 'wcma_fastlane_version' ) ) || ! self::sync() ) {
			return;
		}

		update_option( 'wcma_fastlane_version', WCMA_VERSION, false );

		/*
		 * پیش از ۴٫۳٫۲ حالت سریع روی وردپرس ۶٫۳ و پیش از آن و ۶٫۵ به بعد پوسته را
		 * باز هم بار می‌کرد؛ خطایی که آن نسخه‌ها در پوسته یا در سنجش سرعت ثبت
		 * کرده‌اند، با فایل تازه دیگر رخ نمی‌دهد و حالت سریع خودش دوباره امتحان
		 * می‌شود. خطاهایی که از ۴٫۳٫۲ به بعد ثبت شده‌اند (با نشان نسخه) دست نمی‌خورند.
		 */
		$stale = static function ( $row ) {
			if ( ! is_array( $row ) ) {
				return false;
			}

			if ( self::own_bug( $row ) ) {
				return true;
			}

			if ( ! empty( $row['ver'] ) && version_compare( (string) $row['ver'], '4.3.2', '>=' ) ) {
				return false;
			}

			$file = str_replace( '\\', '/', (string) ( $row['file'] ?? '' ) );

			return ( ! empty( $row['fast'] ) && preg_match( '#(^|/)themes/#', $file ) ) || 0 === strpos( (string) ( $row['message'] ?? '' ), 'سنجش سرعت:' );
		};

		if ( $stale( self::failure() ) ) {
			delete_option( 'wcma_fastlane_failed' );
		}

		if ( $stale( get_option( 'wcma_bot_fatal' ) ) ) {
			delete_option( 'wcma_bot_fatal' );
		}
	}

	/**
	 * آیا فایل حالت سریع کهنه است، نیست یا نباید باشد؟
	 *
	 * فقط در درخواست وب‌هوک معنا دارد: فایل در آن درخواست نسخه‌ی سازنده‌اش را تعریف می‌کند.
	 *
	 * @return bool
	 */
	public static function stale_file() {
		if ( is_multisite() ) {
			return self::installed();
		}

		return WCMA_Settings::is( 'tg_fastlane' )
			&& ( ! defined( 'WCMA_FASTLANE_FOR' ) || WCMA_VERSION !== WCMA_FASTLANE_FOR );
	}

	/**
	 * ترمیم فایل حالت سریع از درخواست وب‌هوک (پس از رفتن پاسخ).
	 *
	 * هر ده دقیقه یک بار، تا اگر نوشتن فایل ممکن نیست، هر پیام دوباره امتحان نکند.
	 */
	public static function heal() {
		if ( get_transient( 'wcma_fastlane_heal' ) ) {
			return;
		}

		set_transient( 'wcma_fastlane_heal', 1, 10 * MINUTE_IN_SECONDS );

		self::maybe_refresh( true );
	}

	/**
	 * آیا این خطا از کنار گذاشتنِ ناقصِ پوسته در حالت سریع بوده است؟
	 *
	 * در آن صورت پوسته با وجود حالت سریع بار شده و مسیر پوشه‌ی خالی را گرفته است.
	 *
	 * @param array $row خطا.
	 * @return bool
	 */
	public static function own_bug( array $row ) {
		return false !== strpos( (string) ( $row['message'] ?? '' ), 'wcma-fastlane-no-theme' );
	}

	/**
	 * برداشتن فایل (فقط اگر مال همین افزونه باشد).
	 */
	public static function remove() {
		if ( self::installed() ) {
			@unlink( self::path() ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}

		// پس از فعال‌سازی دوباره، فایل از نو ساخته می‌شود.
		delete_option( 'wcma_fastlane_version' );
	}

	/**
	 * آخرین خطا.
	 *
	 * @return string
	 */
	public static function error() {
		return (string) get_option( self::ERROR, '' );
	}

	/**
	 * کد فایل mu-plugin.
	 *
	 * فهرست افزونه‌ها از active_plugins خودِ سایت می‌آید و با الگوی سخت
	 * بررسی شده است؛ هیچ ورودیِ دیگری در کد نوشته نمی‌شود.
	 *
	 * @param string[] $keep افزونه‌هایی که بار می‌شوند.
	 * @return string
	 */
	public static function code( array $keep ) {
		$list    = var_export( array_values( $keep ), true ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
		$version = var_export( (string) WCMA_VERSION, true ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions

		return <<<PHP
<?php
/**
 * Plugin Name: حالت سریع ربات — اتوماسیون بازاریابی کلاسیکا
 * Description: فقط برای پیام‌هایی که از ربات تلگرام/بله به سایت می‌رسد، افزونه‌های غیرضروری و پوسته بار نمی‌شوند. این فایل را خودِ افزونه ساخته و با خاموش کردن «حالت سریع» یا غیرفعال کردن افزونه پاک می‌شود.
 *
 * @package WCMA
 */

// WCMA_FASTLANE_FILE 5

defined( 'ABSPATH' ) || exit;

/*
 * فقط پیامِ واقعیِ وب‌هوک: درخواست POST به خودِ مسیر REST ربات (نه هر نشانی‌ای
 * که این عبارت را در پرس‌وجویش دارد) از راه index.php و با کلید مخفی وب‌هوک که
 * فقط تلگرام و سنجش سرعت آن را دارند. وگرنه کسی می‌توانست مثلاً ورود به سایت را
 * بی‌افزونه‌های امنیتی (ورود دومرحله‌ای، کپچا، محدودیت تلاش) بار کند.
 */
\$wcma_fastlane_hit = false;

if (
	isset( \$_SERVER['REQUEST_METHOD'], \$_SERVER['REQUEST_URI'], \$_GET['s'] ) // phpcs:ignore WordPress.Security.NonceVerification
	&& 'POST' === \$_SERVER['REQUEST_METHOD']
	&& ! defined( 'WP_ADMIN' )
	&& ! is_multisite()
	&& is_string( \$_GET['s'] ) // phpcs:ignore WordPress.Security.NonceVerification
	&& in_array( 'index.php', array( basename( (string) ( \$_SERVER['SCRIPT_FILENAME'] ?? '' ) ), basename( (string) ( \$_SERVER['SCRIPT_NAME'] ?? '' ) ) ), true )
	&& (
		false !== strpos( rawurldecode( (string) parse_url( (string) \$_SERVER['REQUEST_URI'], PHP_URL_PATH ) ), '/wcma/v1/bot/' ) // phpcs:ignore WordPress.WP.AlternativeFunctions
		|| ( isset( \$_GET['rest_route'] ) && is_string( \$_GET['rest_route'] ) && 0 === strpos( \$_GET['rest_route'], '/wcma/v1/bot/' ) ) // phpcs:ignore WordPress.Security.NonceVerification
	)
) {
	\$wcma_fastlane_settings = get_option( 'wcma_settings' );
	\$wcma_fastlane_secret   = is_array( \$wcma_fastlane_settings ) ? (string) ( \$wcma_fastlane_settings['bot_webhook_secret'] ?? '' ) : '';
	\$wcma_fastlane_hit      = '' !== \$wcma_fastlane_secret && hash_equals( \$wcma_fastlane_secret, \$_GET['s'] ); // phpcs:ignore WordPress.Security.NonceVerification

	unset( \$wcma_fastlane_settings, \$wcma_fastlane_secret );
}

if ( \$wcma_fastlane_hit ) {
	// نسخه‌ی افزونه‌ای که این فایل را ساخته؛ افزونه‌ی تازه‌تر فایل را خودش تازه می‌کند.
	define( 'WCMA_FASTLANE_FOR', {$version} );

	\$wcma_fastlane_keep = {$list};

	/*
	 * اگر حالت سریع روی این سایت یک بار باعث خطای PHP شده باشد، دیگر به کار
	 * نمی‌رود تا مدیر دوباره روشنش کند؛ ربات با بار کامل وردپرس کار می‌کند.
	 */
	\$wcma_fastlane_ok = ! isset( \$_GET['wcma_full'] ) && ! get_option( 'wcma_fastlane_failed' ); // phpcs:ignore WordPress.Security.NonceVerification

	// خطای مهلکِ این درخواست ثبت می‌شود تا در پیشخوان (سرعت ربات) دیده شود.
	add_filter(
		'wp_php_error_message',
		static function ( \$message, \$error ) {
			if ( is_array( \$error ) ) {
				\$row = array(
					'time'    => time(),
					'fast'    => defined( 'WCMA_FASTLANE' ),
					// سنجش بار کامل در سنجش سرعت، نه پیام واقعی.
					'test'    => isset( \$_GET['wcma_full'] ), // phpcs:ignore WordPress.Security.NonceVerification
					'ver'     => WCMA_FASTLANE_FOR,
					'message' => substr( str_replace( ABSPATH, '', strtok( (string) ( \$error['message'] ?? '' ), "\n" ) ), 0, 300 ),
					'file'    => str_replace( ABSPATH, '', (string) ( \$error['file'] ?? '' ) ),
					'line'    => (int) ( \$error['line'] ?? 0 ),
				);

				update_option( 'wcma_bot_fatal', \$row, false );

				if ( defined( 'WCMA_FASTLANE' ) ) {
					update_option( 'wcma_fastlane_failed', \$row, false );
				}
			}

			return \$message;
		},
		1,
		2
	);

	// اگر یکی از افزونه‌های لازم دیگر سر جایش نیست، حالت سریع کنار می‌رود تا ربات از کار نیفتد.
	foreach ( \$wcma_fastlane_keep as \$wcma_fastlane_plugin ) {
		if ( ! file_exists( WP_PLUGIN_DIR . '/' . \$wcma_fastlane_plugin ) ) {
			\$wcma_fastlane_ok = false;
		}
	}
}

if ( ! empty( \$wcma_fastlane_ok ) ) {
	define( 'WCMA_FASTLANE', true );

	add_filter(
		'option_active_plugins',
		static function ( \$plugins ) use ( \$wcma_fastlane_keep ) {
			return is_array( \$plugins ) ? array_values( array_intersect( \$plugins, \$wcma_fastlane_keep ) ) : \$plugins;
		},
		1
	);

	add_filter(
		'site_option_active_sitewide_plugins',
		static function ( \$plugins ) use ( \$wcma_fastlane_keep ) {
			return is_array( \$plugins ) ? array_intersect_key( \$plugins, array_flip( \$wcma_fastlane_keep ) ) : \$plugins;
		},
		1
	);

	// فهرست کوتاه‌شده هرگز ذخیره نمی‌شود.
	add_filter( 'pre_update_option_active_plugins', static function ( \$value, \$old ) { return \$old; }, 1, 2 );
	add_filter( 'pre_update_site_option_active_sitewide_plugins', static function ( \$value, \$old ) { return \$old; }, 1, 2 );

	/*
	 * پوسته و بیشتر افزونه‌ها اینجا بار نشده‌اند؛ چیزی که بر پایه‌ی آن‌ها ساخته
	 * می‌شود نباید ذخیره شود (ووکامرس هم همین را برای WP-CLI و کرون می‌کند):
	 * - ووکامرس «پوسته از ووکامرس پشتیبانی نمی‌کند» را ثبت و پیوندهای یکتا را بازسازی می‌کرد؛
	 * - پیوندهای یکتای ساخته‌شده در اینجا پیوندهای پوسته و افزونه‌های کنارگذاشته را ندارند؛
	 *   پس ذخیره نمی‌شوند و فقط پاک می‌شوند تا نخستین درخواست کامل آن‌ها را بسازد؛
	 * - کارهای پس از عوض شدن پوسته (جابه‌جایی ابزارک‌ها و فهرست‌ها) به درخواست کامل بعدی می‌ماند.
	 */
	add_filter( 'pre_update_option_current_theme_supports_woocommerce', static function ( \$value, \$old ) { return \$old; }, 1, 2 );
	add_filter( 'pre_update_option_rewrite_rules', static function ( \$value, \$old ) { return empty( \$old ) ? \$old : ''; }, 1, 2 );
	remove_action( 'init', 'check_theme_switched', 99 );

	/*
	 * functions.php پوسته و پوسته‌ی فرزند بار نمی‌شود: میان setup_theme و
	 * after_setup_theme مسیر پوسته به پوشه‌ای خالی اشاره می‌کند، پس وردپرس
	 * functions.php را پیدا نمی‌کند. وردپرس مسیر را در هر نسخه از جای دیگری
	 * می‌خواند و همه باید پوشه‌ی خالی را ببینند:
	 * - تا ۶٫۳: ثابت‌های TEMPLATEPATH و STYLESHEETPATH (که همان‌جا تعریف می‌شوند؛
	 *   پس در این نسخه‌ها تا پایان همین درخواست به پوشه‌ی خالی اشاره می‌کنند)؛
	 * - ۶٫۴: خودِ get_template_directory() و get_stylesheet_directory()؛
	 * - ۶٫۵ به بعد: \$wp_template_path و \$wp_stylesheet_path که درست پس از تعریف
	 *   ثابت‌ها پر می‌شوند.
	 * از ۶٫۴ به بعد ثابت‌ها مسیر واقعی را نگه می‌دارند و پس از after_setup_theme
	 * همه‌چیز به مسیر واقعی برمی‌گردد.
	 */
	\$wcma_fastlane_legacy = version_compare( (string) ( \$GLOBALS['wp_version'] ?? '' ), '6.4-alpha', '<' );

	\$wcma_fastlane_dir = static function ( \$dir ) use ( \$wcma_fastlane_legacy ) {
		\$constant = 'stylesheet_directory' === current_filter() ? 'STYLESHEETPATH' : 'TEMPLATEPATH';

		if ( did_action( 'after_setup_theme' ) || ( ! \$wcma_fastlane_legacy && ! defined( \$constant ) ) ) {
			return \$dir;
		}

		return WP_CONTENT_DIR . '/wcma-fastlane-no-theme';
	};

	add_action(
		'setup_theme',
		static function () use ( \$wcma_fastlane_dir ) {
			// وردپرس ۶٫۴٫۰ و ۶٫۴٫۱ مسیر پوسته را در این دو متغیر نگه می‌دارند و پس از آن فیلتر نمی‌کنند.
			\$GLOBALS['wp_template_path']   = null;
			\$GLOBALS['wp_stylesheet_path'] = null;

			add_filter( 'template_directory', \$wcma_fastlane_dir, PHP_INT_MAX );
			add_filter( 'stylesheet_directory', \$wcma_fastlane_dir, PHP_INT_MAX );
		},
		PHP_INT_MAX
	);

	add_action(
		'after_setup_theme',
		static function () use ( \$wcma_fastlane_dir ) {
			remove_filter( 'template_directory', \$wcma_fastlane_dir, PHP_INT_MAX );
			remove_filter( 'stylesheet_directory', \$wcma_fastlane_dir, PHP_INT_MAX );

			if ( function_exists( 'wp_set_template_globals' ) ) {
				wp_set_template_globals();
			}

			// الگوهای بلوکی پوسته در ۶٫۴ و پیش از آن هنگام init اجرا می‌شوند و ممکن است به functions.php نیاز داشته باشند.
			remove_action( 'init', '_register_theme_block_patterns' );
		},
		PHP_INT_MIN
	);
}

PHP;
	}
}
