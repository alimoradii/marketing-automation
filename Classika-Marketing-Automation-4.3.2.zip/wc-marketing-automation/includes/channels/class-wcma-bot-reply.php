<?php
/**
 * پاسخ سریع به وب‌هوک ربات.
 *
 * تلگرام اجازه می‌دهد پاسخِ وب‌هوک خودش یک فراخوانی API باشد. پیام اولی که
 * ربات برای همان کاربر می‌فرستد، به‌جای یک درخواست جدا از سرور سایت به
 * api.telegram.org، همراه همان پاسخ برمی‌گردد و تلگرام بی‌درنگ اجرایش می‌کند.
 * رفت‌وبرگشتِ کامل تا تلگرام (که روی بسیاری از میزبان‌ها کندترین بخش کار است)
 * از مسیر پاسخ کاربر حذف می‌شود.
 *
 * کارهای جانبی (مثل خبر دادن به مدیران) هم پس از رسیدن پاسخ کاربر انجام
 * می‌شوند، نه پیش از آن.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Reply
 */
class WCMA_Bot_Reply {

	/**
	 * متدهایی که می‌شود در پاسخ وب‌هوک گذاشت (نتیجه‌شان لازم نیست).
	 */
	const SLOTTABLE = array(
		'sendMessage',
		'sendPhoto',
		'sendVideo',
		'sendAudio',
		'sendVoice',
		'sendDocument',
		'sendAnimation',
		'sendChatAction',
		'editMessageText',
		'editMessageCaption',
		'editMessageReplyMarkup',
		'deleteMessage',
		'answerCallbackQuery',
	);

	/**
	 * آیا پردازش یک وب‌هوک در جریان است؟
	 *
	 * @var bool
	 */
	protected static $active = false;

	/**
	 * آیا پاسخ وب‌هوک تصمیمش گرفته شده (فرستاده یا رها) است؟
	 *
	 * @var bool
	 */
	protected static $released = false;

	/**
	 * آیا اتصال تلگرام بسته شد و کار در پس‌زمینه ادامه دارد؟
	 *
	 * @var bool
	 */
	protected static $responded = false;

	/**
	 * پیام‌رسان و چتِ همین وب‌هوک.
	 *
	 * @var string
	 */
	protected static $messenger   = '';
	protected static $chat_id     = '';
	protected static $callback_id = '';

	/**
	 * فراخوانی‌ای که همراه پاسخ وب‌هوک می‌رود.
	 *
	 * @var array{0:string,1:array}|null
	 */
	protected static $slot = null;

	/**
	 * فراخوانی‌های بی‌ترتیب (پاسخ دکمه‌ی شیشه‌ای) برای پس از پاسخ.
	 *
	 * @var array
	 */
	protected static $deferred = array();

	/**
	 * کارهای جانبی برای پس از پاسخ کاربر.
	 *
	 * @var array
	 */
	protected static $later = array();

	/**
	 * آیا کارهای جانبی در حال اجرا هستند؟
	 *
	 * @var bool
	 */
	protected static $running_later = false;

	/**
	 * آیا PHP می‌تواند اتصال را ببندد و ادامه دهد؟
	 *
	 * @var bool
	 */
	protected static $can_finish = false;

	/**
	 * آیا پیام می‌تواند در پاسخ وب‌هوک برود؟ (فقط تلگرام)
	 *
	 * @var bool
	 */
	protected static $use_slot = false;

	/**
	 * زمان آغاز پردازش و زمان پاسخ (میکروثانیه).
	 *
	 * @var float
	 */
	protected static $began    = 0.0;
	protected static $answered = 0.0;

	/**
	 * پاسخ کاربر از کدام راه رفت: webhook یا api یا none.
	 *
	 * @var string
	 */
	protected static $route = 'none';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		// هر درخواست بیرونیِ دیگر (هوش مصنوعی، پیامک و …) کند است؛ کاربر نباید پشتش بماند.
		add_filter( 'pre_http_request', array( __CLASS__, 'guard' ), -9999, 3 );
	}

	/**
	 * آغاز پردازش یک به‌روزرسانی.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    به‌روزرسانیِ استخراج‌شده.
	 */
	public static function begin( $messenger, array $parsed ) {
		self::$active        = true;
		self::$released      = false;
		self::$responded     = false;
		self::$messenger     = (string) $messenger;
		self::$chat_id       = (string) ( $parsed['chat_id'] ?? '' );
		self::$callback_id   = (string) ( $parsed['callback_id'] ?? '' );
		self::$slot          = null;
		self::$deferred      = array();
		self::$later         = array();
		self::$running_later = false;
		self::$began         = microtime( true );
		self::$answered      = 0.0;
		self::$route         = 'none';
		self::$can_finish    = ! headers_sent() && ( function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' ) );

		/**
		 * فرستادن پیام اول در پاسخ خودِ وب‌هوک.
		 *
		 * بله این قابلیت را مستند نکرده است؛ فقط برای تلگرام روشن است.
		 *
		 * @param bool   $on        روشن.
		 * @param string $messenger پیام‌رسان.
		 */
		self::$use_slot = 'telegram' === self::$messenger && (bool) apply_filters( 'wcma_bot_webhook_reply', true, self::$messenger );

		/*
		 * اگر کدی در میانه‌ی کار exit کند، پاسخ نگه‌داشته‌شده همچنان به تلگرام
		 * می‌رسد. (خطای PHP در route_message گرفته می‌شود؛ پیش از رفتن پاسخ فقط
		 * کارهای سبک پایگاه داده انجام می‌شود و هر کار کند پیش از آغاز، پاسخ را می‌فرستد.)
		 */
		register_shutdown_function( array( __CLASS__, 'shutdown' ) );
	}

	/**
	 * آیا وب‌هوکی در جریان است که هنوز پاسخش نرفته؟
	 *
	 * @return bool
	 */
	public static function pending() {
		return self::$active && ! self::$released;
	}

	/**
	 * پیشنهاد یک فراخوانی API.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $method    متد.
	 * @param array  $params    پارامترها.
	 * @param array  $opts      needs_result وقتی نتیجه‌ی واقعی لازم است.
	 * @return array|null نتیجه‌ی ساختگی اگر نگه داشته شد؛ null یعنی همین حالا بفرست.
	 */
	public static function offer( $messenger, $method, array $params, array $opts = array() ) {
		if ( ! self::pending() ) {
			return null;
		}

		$needs = ! empty( $opts['needs_result'] );
		$same  = (string) $messenger === self::$messenger;

		// پاسخ دکمه‌ی شیشه‌ایِ همین به‌روزرسانی: ترتیبش با پیام‌ها مهم نیست.
		if ( ! $needs && $same && 'answerCallbackQuery' === $method && '' !== self::$callback_id
			&& (string) ( $params['callback_query_id'] ?? '' ) === self::$callback_id ) {
			self::$deferred[] = array( $method, $params );

			return self::held();
		}

		$current = $same && '' !== self::$chat_id && (string) ( $params['chat_id'] ?? '' ) === self::$chat_id;

		// نخستین پیام برای همین کاربر، همراه پاسخ وب‌هوک می‌رود.
		if ( ! $needs && $current && self::$use_slot && null === self::$slot && in_array( $method, self::SLOTTABLE, true ) ) {
			self::$slot = array( $method, $params );

			return self::held();
		}

		/*
		 * پیام دوم برای همین کاربر، پیامی برای کس دیگر، یا فراخوانی‌ای که نتیجه‌اش
		 * لازم است: پاسخ وب‌هوک (با پیام اول) همین حالا می‌رود تا ترتیب پیام‌ها
		 * حفظ شود و تلگرام پشت کارهای کند منتظر نماند.
		 */
		self::release();

		return null;
	}

	/**
	 * نتیجه‌ی ساختگی برای فراخوانیِ نگه‌داشته.
	 *
	 * @return array
	 */
	protected static function held() {
		return array(
			'ok'     => true,
			'result' => true,
			'held'   => true,
		);
	}

	/**
	 * اجرای یک کار جانبی پس از رسیدن پاسخ به کاربر.
	 *
	 * بیرون از وب‌هوک، کار همان‌دم اجرا می‌شود.
	 *
	 * @param callable $callback کار.
	 * @param array    $args     آرگومان‌ها.
	 * @param bool     $quiet    کار فقط پایگاه داده است و پیامی نمی‌فرستد.
	 */
	public static function later( $callback, array $args = array(), $quiet = false ) {
		if ( self::$active && ! self::$running_later ) {
			self::$later[] = array( $callback, $args, (bool) $quiet );

			return;
		}

		call_user_func_array( $callback, $args );
	}

	/**
	 * پیش از هر درخواست بیرونیِ دیگر، پاسخ وب‌هوک فرستاده می‌شود.
	 *
	 * @param mixed  $pre  پاسخ جایگزین.
	 * @param array  $args آرگومان‌ها.
	 * @param string $url  نشانی.
	 * @return mixed
	 */
	public static function guard( $pre, $args, $url ) {
		if ( self::pending() ) {
			// کاربر تا رسیدن پاسخ، «در حال نوشتن…» می‌بیند.
			if ( self::$use_slot && null === self::$slot && '' !== self::$chat_id ) {
				self::$slot = array(
					'sendChatAction',
					array(
						'chat_id' => self::$chat_id,
						'action'  => 'typing',
					),
				);
			}

			self::release();
		}

		return $pre;
	}

	/**
	 * فرستادن پاسخ وب‌هوک (اگر بشود) و آزاد کردن هر چه نگه داشته شده.
	 */
	public static function release() {
		if ( ! self::$active || self::$released ) {
			return;
		}

		self::$released = true;

		$slot = self::$slot;

		self::$slot = null;

		// اگر پیامی نبود، دست‌کم پاسخ دکمه همراه وب‌هوک می‌رود.
		if ( null === $slot && self::$use_slot && self::$deferred ) {
			$slot = array_shift( self::$deferred );
		}

		if ( self::$can_finish && self::finish( $slot ) ) {
			self::$responded = true;
			self::mark( $slot ? 'webhook' : 'none' );
		} elseif ( $slot ) {
			// اتصال را نمی‌شود زودتر بست؛ آنچه نگه داشته شده، همین حالا و به ترتیب می‌رود.
			self::direct( $slot );
			self::mark( 'api' );
		}

		$deferred       = self::$deferred;
		self::$deferred = array();

		foreach ( $deferred as $call ) {
			self::direct( $call );
		}
	}

	/**
	 * پایان پردازش به‌روزرسانی.
	 *
	 * @return array|null بدنه‌ی پاسخ REST، یا null اگر پاسخ پیش‌تر فرستاده شده.
	 */
	public static function end() {
		if ( ! self::$active ) {
			return null;
		}

		$body = null;

		/*
		 * بی امکان بستن زودهنگام، پیام اول خودِ پاسخ وب‌هوک است و فقط پس از پایان
		 * همه‌ی کارها به تلگرام می‌رسد. اگر کار جانبی‌ای پیام می‌فرستد (خبر مدیران)،
		 * پیام کاربر جدا و پیش از آن می‌رود تا پشتش منتظر نماند.
		 */
		$loud = false;

		foreach ( self::$later as $job ) {
			if ( empty( $job[2] ) ) {
				$loud = true;
			}
		}

		if ( ! self::$released ) {
			if ( self::$can_finish || $loud ) {
				self::release();
			} else {
				// بدون امکان بستن زودهنگام: پیام اول خودِ پاسخ است؛ پاسخ دکمه پیش از آن می‌رود.
				self::$released = true;

				$slot = self::$slot;

				self::$slot = null;

				if ( null === $slot && self::$use_slot && self::$deferred ) {
					$slot = array_shift( self::$deferred );
				}

				foreach ( self::$deferred as $call ) {
					self::direct( $call );
				}

				self::$deferred = array();

				if ( $slot ) {
					$body = self::payload( $slot );
					self::mark( 'webhook' );
				}
			}
		}

		self::$running_later = true;

		// کارهای جانبی ممکن است کار جانبیِ تازه بسازند؛ همه اجرا می‌شوند.
		while ( self::$later ) {
			$job = array_shift( self::$later );

			try {
				call_user_func_array( $job[0], $job[1] );
			} catch ( Throwable $e ) {
				self::log( $e );
			}
		}

		self::$running_later = false;

		// از اینجا به بعد، کار جانبیِ تازه همان‌دم اجرا می‌شود و چیزی در صف نمی‌ماند.
		self::$active = false;

		return $body;
	}

	/**
	 * آیا اتصال تلگرام بسته شده و کار طولانی بی‌خطر است؟
	 *
	 * اگر هنوز پاسخ نرفته ولی می‌شود بست، همین حالا بسته می‌شود.
	 *
	 * @return bool
	 */
	public static function detach() {
		if ( self::pending() && self::$can_finish ) {
			self::release();
		}

		return self::$responded;
	}

	/**
	 * آیا پاسخ با بستن زودهنگام فرستاده شده است؟
	 *
	 * @return bool
	 */
	public static function responded() {
		return self::$responded;
	}

	/**
	 * گزارش زمان‌بندی همین وب‌هوک.
	 *
	 * @return array{work:float,route:string}
	 */
	public static function timing() {
		$answered = self::$answered ? self::$answered : microtime( true );

		return array(
			'work'  => round( ( $answered - self::$began ) * 1000, 1 ),
			'route' => self::$route,
		);
	}

	/**
	 * ثبت لحظه‌ی رسیدن پاسخ.
	 *
	 * @param string $route راه.
	 */
	protected static function mark( $route ) {
		if ( ! self::$answered ) {
			self::$answered = microtime( true );
			self::$route    = $route;
		}
	}

	/**
	 * بدنه‌ی پاسخ وب‌هوک برای یک فراخوانی.
	 *
	 * @param array $call متد و پارامترها.
	 * @return array
	 */
	protected static function payload( array $call ) {
		$body = array( 'method' => $call[0] );

		foreach ( $call[1] as $key => $value ) {
			if ( null === $value ) {
				continue;
			}

			// کیبورد به‌شکل شیء JSON، نه رشته‌ای درون JSON.
			if ( 'reply_markup' === $key && is_string( $value ) ) {
				$decoded = json_decode( $value, true );
				$value   = is_array( $decoded ) ? $decoded : $value;
			}

			$body[ $key ] = $value;
		}

		return $body;
	}

	/**
	 * فرستادن یک فراخوانی از راه API.
	 *
	 * @param array $call متد و پارامترها.
	 */
	protected static function direct( array $call ) {
		$base = WCMA_Bot_Api::base( self::$messenger );

		if ( '' !== $base ) {
			WCMA_Bot_Api::post( $base . $call[0], $call[1], 'answerCallbackQuery' === $call[0] ? 8 : 12 );
		}
	}

	/**
	 * بستن اتصال با پاسخ ۲۰۰ و ادامه‌ی کار در پس‌زمینه.
	 *
	 * @param array|null $slot فراخوانی‌ای که همراه پاسخ می‌رود.
	 * @return bool
	 */
	protected static function finish( $slot ) {
		if ( headers_sent() ) {
			return false;
		}

		$closer = function_exists( 'fastcgi_finish_request' ) ? 'fastcgi_finish_request' : ( function_exists( 'litespeed_finish_request' ) ? 'litespeed_finish_request' : '' );

		if ( '' === $closer ) {
			return false;
		}

		$body = wp_json_encode( $slot ? self::payload( $slot ) : array( 'ok' => true ) );

		status_header( 200 );
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Length: ' . strlen( $body ) );
		header( 'Connection: close' );

		// چیزی که پیش‌تر در بافر مانده (مثلاً هشدار PHP) نباید JSON را خراب کند.
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput

		flush();
		$closer();

		// کار پس‌زمینه نباید با محدودیت زمانیِ کوتاه نصفه بماند.
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 90 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}

		ignore_user_abort( true );

		return true;
	}

	/**
	 * اگر پردازش پیش از رفتن پاسخ با exit تمام شد، پاسخ (و پیام نگه‌داشته) فرستاده می‌شود.
	 */
	public static function shutdown() {
		if ( ! self::pending() ) {
			return;
		}

		self::$released = true;

		if ( headers_sent() ) {
			return;
		}

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		$slot = self::$slot ? self::$slot : ( self::$use_slot && self::$deferred ? self::$deferred[0] : null );

		status_header( 200 );
		header( 'Content-Type: application/json; charset=utf-8' );

		echo wp_json_encode( $slot ? self::payload( $slot ) : array( 'ok' => true ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/**
	 * ثبت خطا در گزارش PHP.
	 *
	 * @param Throwable $e خطا.
	 */
	protected static function log( $e ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions
		error_log( 'WCMA bot webhook: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine() );
	}
}
