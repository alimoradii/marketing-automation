<?php
/**
 * فایل‌های پیوست گفتگو: پذیرش، نگهداری امن و پاک‌سازی دوره‌ای.
 *
 * پذیرفتن فایل از بازدیدکننده یعنی هر کسی می‌تواند چیزی روی هاست بنویسد، پس
 * اینجا سه چیز جدی گرفته شده است:
 *
 * ۱. فهرست سفید پسوند و نوع؛ هر چیز دیگری رد می‌شود.
 * ۲. نام تازه‌ی تصادفی و پوشه‌ای که اجرای PHP در آن بسته است.
 * ۳. سقف حجم و پاک‌سازی دوره‌ای تا هاست پر نشود.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Chat_Files
 */
class WCMA_Chat_Files {

	const DIR      = 'wcma-chat';
	const MAX_NAME = 120;

	/*
	 * متنی که برای ویسِ بدون توضیح ذخیره می‌شود. چون همین رشته هم هنگام ثبت
	 * و هم هنگام نمایش لازم است، یک‌جا نگه داشته می‌شود تا زیر حباب دوباره
	 * تکرار نشود.
	 */
	const VOICE_LABEL = 'پیام صوتی';

	/*
	 * ثابت‌های KB_IN_BYTES و MB_IN_BYTES و DAY_IN_SECONDS وردپرس همیشه پیش از
	 * این کلاس تعریف نشده‌اند و نبودشان به خطای کشنده تبدیل می‌شد؛ عددها را
	 * خودمان نگه می‌داریم.
	 */
	const KB  = 1024;
	const MB  = 1048576;
	const DAY = 86400;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		// همان زمان‌بند روزانه‌ی خود افزونه؛ رویداد کرون تازه‌ای لازم نیست.
		add_action( 'wcma_daily_scan', array( __CLASS__, 'cleanup' ) );
	}

	/* ---------------------------------------------------------------------
	 * انواع مجاز
	 * ------------------------------------------------------------------ */

	/**
	 * گروه‌های مجاز فایل.
	 *
	 * مدیر خواسته فقط عکس، متن، ویدیو و زیپ پذیرفته شود؛ صدا هم برای ویس
	 * لازم است ولی جدا نگه داشته می‌شود تا در تنظیمات جداگانه دیده شود.
	 *
	 * @return array
	 */
	public static function kinds() {
		return array(
			'image' => array(
				'label' => 'عکس',
				'ext'   => array( 'jpg', 'jpeg', 'png', 'gif', 'webp' ),
				'mime'  => array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ),
			),
			'doc'   => array(
				'label' => 'فایل متنی',
				'ext'   => array( 'txt', 'pdf', 'doc', 'docx', 'rtf', 'csv' ),
				'mime'  => array(
					'text/plain',
					'text/csv',
					'application/pdf',
					'application/rtf',
					'application/msword',
					'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				),
			),
			'video' => array(
				'label' => 'ویدیو',
				'ext'   => array( 'mp4', 'webm', 'ogv', 'mov' ),
				'mime'  => array( 'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime' ),
			),
			'zip'   => array(
				'label' => 'فایل فشرده',
				'ext'   => array( 'zip' ),
				'mime'  => array( 'application/zip', 'application/x-zip-compressed', 'multipart/x-zip' ),
			),
			'audio' => array(
				'label' => 'پیام صوتی',
				'ext'   => array( 'webm', 'ogg', 'oga', 'mp3', 'm4a', 'wav' ),
				'mime'  => array( 'audio/webm', 'audio/ogg', 'audio/mpeg', 'audio/mp4', 'audio/wav', 'audio/x-wav' ),
			),
		);
	}

	/**
	 * فهرست پسوندهای مجاز، برای نمایش و برای صفت accept در مرورگر.
	 *
	 * @return array
	 */
	public static function allowed_ext() {
		$out = array();

		foreach ( self::kinds() as $kind ) {
			$out = array_merge( $out, $kind['ext'] );
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * رشته‌ی accept برای فیلد فایل.
	 *
	 * @return string
	 */
	public static function accept_attr() {
		$out = array();

		foreach ( self::allowed_ext() as $ext ) {
			$out[] = '.' . $ext;
		}

		return implode( ',', $out );
	}

	/**
	 * تشخیص گروه از روی پسوند و نوع.
	 *
	 * پسوند و MIME هر دو بررسی می‌شوند؛ تکیه بر یکی از آن‌ها به‌تنهایی راه
	 * فرار دارد (پسوند را می‌شود جعل کرد، MIME را مرورگر می‌فرستد).
	 *
	 * @param string $ext  پسوند بدون نقطه.
	 * @param string $mime نوع تشخیص‌داده‌شده.
	 * @return string نام گروه یا رشته‌ی خالی.
	 */
	public static function kind_of( $ext, $mime ) {
		$ext  = strtolower( (string) $ext );
		$mime = strtolower( (string) $mime );

		foreach ( self::kinds() as $name => $kind ) {
			if ( in_array( $ext, $kind['ext'], true ) && in_array( $mime, $kind['mime'], true ) ) {
				return $name;
			}
		}

		return '';
	}

	/* ---------------------------------------------------------------------
	 * محل نگهداری
	 * ------------------------------------------------------------------ */

	/**
	 * مسیر و نشانی پوشه‌ی فایل‌ها.
	 *
	 * @return array{dir:string,url:string}
	 */
	public static function base() {
		$uploads = wp_upload_dir();

		return array(
			'dir' => trailingslashit( $uploads['basedir'] ) . self::DIR,
			'url' => trailingslashit( $uploads['baseurl'] ) . self::DIR,
		);
	}

	/**
	 * ساخت پوشه و بستن اجرای اسکریپت داخل آن.
	 *
	 * @return string مسیر پوشه، یا رشته‌ی خالی اگر ساخته نشد.
	 */
	public static function ensure_dir() {
		$base = self::base();
		$dir  = $base['dir'];

		if ( ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		// جلوی فهرست شدن و اجرا شدن محتوای پوشه گرفته می‌شود.
		$guard = trailingslashit( $dir ) . 'index.php';

		if ( ! file_exists( $guard ) ) {
			file_put_contents( $guard, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		$htaccess = trailingslashit( $dir ) . '.htaccess';

		if ( ! file_exists( $htaccess ) ) {
			$rules  = "Options -Indexes\n";
			$rules .= "<FilesMatch \"\\.(php|phtml|php[0-9]|phar|cgi|pl|py|sh|htaccess)$\">\n";
			$rules .= "\tRequire all denied\n";
			$rules .= "\t<IfModule !mod_authz_core.c>\n\t\tDeny from all\n\t</IfModule>\n";
			$rules .= "</FilesMatch>\n";
			$rules .= "php_flag engine off\n";

			file_put_contents( $htaccess, $rules ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		return $dir;
	}

	/**
	 * نشانی عمومی یک فایل ذخیره‌شده.
	 *
	 * @param string $relative مسیر نسبی.
	 * @return string
	 */
	public static function url( $relative ) {
		$relative = self::clean_relative( $relative );

		if ( '' === $relative ) {
			return '';
		}

		$base = self::base();

		return trailingslashit( $base['url'] ) . $relative;
	}

	/**
	 * مسیر فیزیکی یک فایل ذخیره‌شده.
	 *
	 * @param string $relative مسیر نسبی.
	 * @return string
	 */
	public static function path( $relative ) {
		$relative = self::clean_relative( $relative );

		if ( '' === $relative ) {
			return '';
		}

		$base = self::base();

		return trailingslashit( $base['dir'] ) . $relative;
	}

	/**
	 * پاک کردن مسیر نسبی از هر چیزی که بتواند از پوشه بیرون بزند.
	 *
	 * @param string $relative مسیر.
	 * @return string
	 */
	protected static function clean_relative( $relative ) {
		$relative = str_replace( '\\', '/', (string) $relative );
		$relative = ltrim( $relative, '/' );

		// «..» یعنی تلاش برای بیرون رفتن از پوشه؛ کل مسیر دور انداخته می‌شود.
		if ( '' === $relative || false !== strpos( $relative, '..' ) ) {
			return '';
		}

		return preg_replace( '#[^A-Za-z0-9/._-]#', '', $relative );
	}

	/* ---------------------------------------------------------------------
	 * دریافت فایل
	 * ------------------------------------------------------------------ */

	/**
	 * بیشترین حجم مجاز هر فایل، بر حسب بایت.
	 *
	 * سقف سرور هم رعایت می‌شود؛ گرفتن عددی بزرگ‌تر از آن فقط پیام خطای
	 * گنگ تولید می‌کند.
	 *
	 * @return int
	 */
	public static function max_bytes() {
		$mb  = max( 1, (int) WCMA_Settings::get( 'lc_file_max_mb', 8 ) );
		$ours = $mb * self::MB;

		$server = wp_max_upload_size();

		return $server > 0 ? min( $ours, (int) $server ) : $ours;
	}

	/**
	 * آیا ارسال فایل روشن است؟
	 *
	 * @return bool
	 */
	public static function enabled() {
		return WCMA_Settings::is( 'lc_files_enabled' );
	}

	/**
	 * آیا ضبط صدا روشن است؟
	 *
	 * @return bool
	 */
	public static function voice_enabled() {
		return self::enabled() && WCMA_Settings::is( 'lc_voice_enabled' );
	}

	/**
	 * ذخیره‌ی یک فایل آپلودشده.
	 *
	 * @param array $file یک عضو از $_FILES.
	 * @return array|WP_Error
	 */
	/**
	 * بررسی اینکه این فایل اصلاً پذیرفتنی است یا نه.
	 *
	 * جدا از store() نوشته شده تا همین بخش — که تنها سد امنیتی است — بتواند
	 * مستقل و کامل آزمون شود، بی‌آنکه به بارگذاری واقعی نیاز باشد.
	 *
	 * @param array $file یک عضو از $_FILES.
	 * @return array|WP_Error {ext, mime, kind, size, name}
	 */
	public static function validate( $file ) {
		if ( ! self::enabled() ) {
			return new WP_Error( 'wcma_files_off', 'ارسال فایل در گفتگو خاموش است.' );
		}

		if ( ! is_array( $file ) || empty( $file['tmp_name'] ) ) {
			return new WP_Error( 'wcma_no_file', 'فایلی دریافت نشد.' );
		}

		if ( ! empty( $file['error'] ) ) {
			return new WP_Error( 'wcma_upload_error', self::upload_error( (int) $file['error'] ) );
		}

		$size = (int) ( $file['size'] ?? 0 );
		$max  = self::max_bytes();

		if ( $size <= 0 ) {
			return new WP_Error( 'wcma_empty_file', 'فایل خالی است.' );
		}

		if ( $size > $max ) {
			return new WP_Error(
				'wcma_too_big',
				sprintf( 'حجم فایل بیشتر از %s مگابایت است.', WCMA_Date::number( round( $max / self::MB, 1 ) ) )
			);
		}

		$name = (string) ( $file['name'] ?? 'file' );
		$ext  = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );

		/*
		 * نوع واقعی از روی محتوای فایل خوانده می‌شود، نه از روی چیزی که
		 * مرورگر ادعا کرده است؛ وگرنه تغییر دادن هدر کافی بود.
		 */
		$checked = wp_check_filetype_and_ext( $file['tmp_name'], $name );
		$mime    = (string) ( $checked['type'] ?? '' );
		$kind    = self::kind_of( $ext, $mime );

		if ( '' === $kind ) {
			return new WP_Error(
				'wcma_bad_type',
				'این نوع فایل پذیرفته نمی‌شود. مجاز: ' . implode( '، ', self::allowed_ext() )
			);
		}

		if ( 'audio' === $kind && ! self::voice_enabled() ) {
			return new WP_Error( 'wcma_voice_off', 'ارسال پیام صوتی خاموش است.' );
		}

		return array(
			'ext'  => $ext,
			'mime' => $mime,
			'kind' => $kind,
			'size' => $size,
			'name' => mb_substr( sanitize_file_name( $name ), 0, self::MAX_NAME ),
		);
	}

	public static function store( $file, $ms = 0 ) {
		$checked = self::validate( $file );

		if ( is_wp_error( $checked ) ) {
			return $checked;
		}

		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'wcma_no_file', 'فایلی دریافت نشد.' );
		}

		$ext  = $checked['ext'];
		$kind = $checked['kind'];
		$mime = $checked['mime'];
		$size = $checked['size'];

		$dir = self::ensure_dir();

		if ( ! $dir ) {
			return new WP_Error( 'wcma_no_dir', 'پوشه‌ی فایل‌ها ساخته نشد.' );
		}

		// پوشه‌بندی ماهانه، تا پاک‌سازی و پشتیبان‌گیری ساده بماند.
		$folder = gmdate( 'Y/m' );
		$target = trailingslashit( $dir ) . $folder;

		if ( ! wp_mkdir_p( $target ) ) {
			return new WP_Error( 'wcma_no_dir', 'پوشه‌ی ماه ساخته نشد.' );
		}

		// نام تازه‌ی تصادفی؛ نام اصلی فقط برای نمایش نگه داشته می‌شود.
		$stored   = wp_generate_password( 20, false, false ) . '.' . $ext;
		$relative = $folder . '/' . $stored;

		if ( ! @move_uploaded_file( $file['tmp_name'], trailingslashit( $target ) . $stored ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new WP_Error( 'wcma_move_failed', 'فایل ذخیره نشد.' );
		}

		@chmod( trailingslashit( $target ) . $stored, 0644 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		return array(
			'file' => $relative,
			'name' => $checked['name'],
			'kind' => $kind,
			'mime' => $mime,
			'size' => $size,
			// مدت را مرورگر هنگام ضبط می‌شمارد؛ خواندنش از خود فایل webm
			// نامطمئن است و اغلب بی‌نهایت برمی‌گرداند.
			'ms'   => self::clean_ms( $ms ),
			'url'  => self::url( $relative ),
		);
	}

	/**
	 * مدت ضبط‌شده، پس از پاک‌سازی.
	 *
	 * سقف دو ساعت گذاشته شده تا عدد بی‌معنی از سمت مرورگر ذخیره نشود.
	 *
	 * @param mixed $ms ورودی.
	 * @return int
	 */
	public static function clean_ms( $ms ) {
		$ms = (int) $ms;

		if ( $ms < 0 ) {
			return 0;
		}

		return min( $ms, 2 * 60 * 60 * 1000 );
	}

	/**
	 * پیام فارسی برای خطاهای آپلود PHP.
	 *
	 * @param int $code کد.
	 * @return string
	 */
	protected static function upload_error( $code ) {
		$map = array(
			UPLOAD_ERR_INI_SIZE   => 'حجم فایل از سقف سرور بیشتر است.',
			UPLOAD_ERR_FORM_SIZE  => 'حجم فایل از سقف فرم بیشتر است.',
			UPLOAD_ERR_PARTIAL    => 'فایل کامل نرسید؛ دوباره تلاش کنید.',
			UPLOAD_ERR_NO_FILE    => 'فایلی انتخاب نشده است.',
			UPLOAD_ERR_NO_TMP_DIR => 'پوشه‌ی موقت سرور در دسترس نیست.',
			UPLOAD_ERR_CANT_WRITE => 'سرور نتوانست فایل را بنویسد.',
			UPLOAD_ERR_EXTENSION  => 'یک افزونه‌ی PHP جلوی آپلود را گرفت.',
		);

		return $map[ $code ] ?? 'آپلود ناموفق بود.';
	}

	/**
	 * شکل پیوست برای فرستادن به مرورگر.
	 *
	 * @param array $row سطر پیام.
	 * @return array|null
	 */
	public static function shape( array $row ) {
		$file = (string) ( $row['att_file'] ?? '' );

		if ( '' === $file ) {
			return null;
		}

		$ms   = (int) ( $row['att_ms'] ?? 0 );
		$kind = (string) ( $row['att_kind'] ?? '' );
		$name = (string) ( $row['att_name'] ?? '' );
		$body = trim( (string) ( $row['body'] ?? '' ) );

		/*
		 * متن پیام برای فایلِ بدون توضیح، همان نام فایل (یا برچسب ویس) است.
		 * نوشتنش زیر حباب چیزی اضافه نمی‌کرد و فقط ارتفاع پیام را دو برابر
		 * می‌کرد، پس فقط توضیح واقعی کاربر برگردانده می‌شود.
		 */
		$auto = ( '' === $body ) || ( $body === $name ) || ( 'audio' === $kind && $body === self::VOICE_LABEL );

		return array(
			'url'   => self::url( $file ),
			'name'  => $name,
			'kind'  => $kind,
			// فقط توضیحی که خودِ فرستنده نوشته، نه برچسب خودکار.
			'caption' => $auto ? '' : $body,
			'mime'  => (string) ( $row['att_mime'] ?? '' ),
			'size'  => (int) ( $row['att_size'] ?? 0 ),
			'human' => self::human_size( (int) ( $row['att_size'] ?? 0 ) ),
			'ms'    => $ms,
			'clock' => self::clock( $ms ),
		);
	}

	/**
	 * مدت ضبط به شکل دقیقه:ثانیه٫دهم.
	 *
	 * دهمِ ثانیه نگه داشته می‌شود چون ویس‌های کوتاه بدون آن همه «۰:۰۰» دیده
	 * می‌شوند.
	 *
	 * @param int $ms میلی‌ثانیه.
	 * @return string
	 */
	public static function clock( $ms ) {
		$ms = max( 0, (int) $ms );

		if ( ! $ms ) {
			return '';
		}

		$total   = (int) floor( $ms / 1000 );
		$minutes = (int) floor( $total / 60 );
		$seconds = $total % 60;
		$tenths  = (int) floor( ( $ms % 1000 ) / 100 );

		return WCMA_Date::digits( sprintf( '%d:%02d٫%d', $minutes, $seconds, $tenths ) );
	}

	/**
	 * حجم خوانا با ارقام فارسی.
	 *
	 * @param int $bytes بایت.
	 * @return string
	 */
	public static function human_size( $bytes ) {
		$bytes = max( 0, (int) $bytes );

		if ( $bytes < self::KB ) {
			return WCMA_Date::number( $bytes ) . ' بایت';
		}

		if ( $bytes < self::MB ) {
			return WCMA_Date::number( round( $bytes / self::KB ) ) . ' کیلوبایت';
		}

		return WCMA_Date::number( round( $bytes / self::MB, 1 ) ) . ' مگابایت';
	}

	/* ---------------------------------------------------------------------
	 * پاک‌سازی
	 * ------------------------------------------------------------------ */

	/**
	 * مجموع حجم و شمار فایل‌های ذخیره‌شده.
	 *
	 * @return array{count:int,bytes:int}
	 */
	public static function usage() {
		$base = self::base();

		return self::scan( $base['dir'] );
	}

	/**
	 * پیمایش بازگشتی یک پوشه.
	 *
	 * @param string $dir پوشه.
	 * @return array{count:int,bytes:int}
	 */
	protected static function scan( $dir ) {
		$out = array( 'count' => 0, 'bytes' => 0 );

		if ( ! is_dir( $dir ) ) {
			return $out;
		}

		$items = @scandir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		foreach ( (array) $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$path = trailingslashit( $dir ) . $item;

			if ( is_dir( $path ) ) {
				$sub = self::scan( $path );

				$out['count'] += $sub['count'];
				$out['bytes'] += $sub['bytes'];
				continue;
			}

			// نگهبان‌های پوشه جزو فایل‌های کاربر نیستند.
			if ( in_array( $item, array( 'index.php', '.htaccess' ), true ) ) {
				continue;
			}

			$out['count']++;
			$out['bytes'] += (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}

		return $out;
	}

	/**
	 * حذف فایل‌های کهنه‌تر از بازه‌ی تعیین‌شده.
	 *
	 * @param int|null $days بازه، یا null برای خواندن از تنظیمات.
	 * @return int شمار فایل‌های حذف‌شده.
	 */
	public static function cleanup( $days = null ) {
		if ( null === $days ) {
			if ( ! WCMA_Settings::is( 'lc_files_prune' ) ) {
				return 0;
			}

			$days = (int) WCMA_Settings::get( 'lc_files_keep_days', 90 );
		}

		$days = (int) $days;

		// صفر یا منفی یعنی «هرگز پاک نکن»؛ نباید به حذف همه‌چیز تبدیل شود.
		if ( $days < 1 ) {
			return 0;
		}

		$base   = self::base();
		$cutoff = time() - ( $days * self::DAY );

		return self::prune( $base['dir'], $cutoff );
	}

	/**
	 * حذف همه‌ی فایل‌ها، صرف‌نظر از تاریخ.
	 *
	 * @return int
	 */
	public static function purge_all() {
		$base = self::base();

		return self::prune( $base['dir'], time() + self::DAY );
	}

	/**
	 * حذف فایل‌های قدیمی‌تر از یک زمان.
	 *
	 * @param string $dir    پوشه.
	 * @param int    $cutoff مرز زمانی.
	 * @return int
	 */
	protected static function prune( $dir, $cutoff ) {
		if ( ! is_dir( $dir ) ) {
			return 0;
		}

		$removed = 0;
		$items   = @scandir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		foreach ( (array) $items as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$path = trailingslashit( $dir ) . $item;

			if ( is_dir( $path ) ) {
				$removed += self::prune( $path, $cutoff );

				// پوشه‌ی ماهِ خالی‌شده هم برداشته می‌شود.
				$rest = @scandir( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

				if ( is_array( $rest ) && count( $rest ) <= 2 ) {
					@rmdir( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				}

				continue;
			}

			if ( in_array( $item, array( 'index.php', '.htaccess' ), true ) ) {
				continue;
			}

			if ( (int) @filemtime( $path ) >= $cutoff ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				continue;
			}

			if ( @unlink( $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$removed++;
			}
		}

		if ( $removed ) {
			self::forget( $removed );
		}

		return $removed;
	}

	/**
	 * پاک کردن ارجاع پیام‌ها به فایل‌هایی که دیگر روی دیسک نیستند.
	 *
	 * بدون این کار، حباب پیام یک لینک شکسته نشان می‌داد.
	 *
	 * @param int $hint شمار حذف‌شده‌ها، فقط برای لاگ.
	 */
	protected static function forget( $hint = 0 ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chat_messages' ) ) {
			return;
		}

		$table = WCMA_Chatbot::messages_table();

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			"SELECT id, att_file FROM {$table} WHERE att_file <> '' LIMIT 2000", // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$path = self::path( $row['att_file'] );

			if ( $path && file_exists( $path ) ) {
				continue;
			}

			$wpdb->update( // phpcs:ignore WordPress.DB
				$table,
				array( 'att_file' => '', 'att_kind' => 'gone' ),
				array( 'id' => (int) $row['id'] )
			);
		}
	}
}
