<?php
/**
 * ارسال ایمیل با SMTP، بدون نیاز به افزونه‌ی جداگانه.
 *
 * وردپرس به‌طور پیش‌فرض ایمیل را با تابع mail() سرور می‌فرستد و روی بیشتر
 * هاست‌ها یا اصلاً نمی‌رسد یا مستقیم به پوشه‌ی هرزنامه می‌رود. اینجا همان
 * PHPMailerی که خود وردپرس دارد به سرور SMTP شما وصل می‌شود.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_SMTP
 */
class WCMA_SMTP {

	/**
	 * آخرین خطای ارسال، برای نمایش در آزمون.
	 *
	 * @var string
	 */
	protected static $last_error = '';

	/**
	 * خط‌های گفتگو با سرور SMTP، وقتی اشکال‌زدایی روشن است.
	 *
	 * @var array
	 */
	protected static $debug = array();

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'phpmailer_init', array( __CLASS__, 'configure' ) );
		add_action( 'wp_mail_failed', array( __CLASS__, 'remember_error' ) );

		if ( self::is_on() && self::force_from() ) {
			// دیرتر از افزونه‌های دیگر می‌نشیند تا هویت فرستنده یکدست بماند.
			add_filter( 'wp_mail_from', array( __CLASS__, 'from_email' ), 99 );
			add_filter( 'wp_mail_from_name', array( __CLASS__, 'from_name' ), 99 );
		}
	}

	/**
	 * آیا SMTP روشن و کامل است؟
	 *
	 * تنظیم نیمه‌کاره بدتر از خاموش است: ایمیل‌ها بی‌صدا شکست می‌خورند. پس
	 * تا وقتی میزبان وارد نشده، اصلاً دخالتی نمی‌کنیم.
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'smtp_enabled' ) && '' !== trim( (string) WCMA_Settings::get( 'smtp_host', '' ) );
	}

	/**
	 * آیا هویت فرستنده باید اجباری شود؟
	 *
	 * @return bool
	 */
	protected static function force_from() {
		return WCMA_Settings::is( 'smtp_force_from' ) && is_email( self::from_email() );
	}

	/**
	 * روش‌های رمزگذاری.
	 *
	 * @return array
	 */
	public static function encryptions() {
		return array(
			'tls'  => 'TLS (معمولاً درگاه ۵۸۷)',
			'ssl'  => 'SSL (معمولاً درگاه ۴۶۵)',
			'none' => 'بدون رمزگذاری (معمولاً درگاه ۲۵)',
		);
	}

	/**
	 * درگاه پیشنهادی هر روش، برای راهنمایی در پیشخوان.
	 *
	 * @param string $secure روش.
	 * @return int
	 */
	public static function suggested_port( $secure ) {
		$map = array( 'tls' => 587, 'ssl' => 465, 'none' => 25 );

		return $map[ $secure ] ?? 587;
	}

	/**
	 * نشانی فرستنده.
	 *
	 * @return string
	 */
	public static function from_email() {
		$email = trim( (string) WCMA_Settings::get( 'smtp_from_email', '' ) );

		if ( ! $email ) {
			// اگر جدا تعیین نشده، از هویت ایمیلِ خود افزونه استفاده می‌شود.
			$email = trim( (string) WCMA_Settings::get( 'from_email', '' ) );
		}

		return is_email( $email ) ? $email : '';
	}

	/**
	 * نام فرستنده.
	 *
	 * @return string
	 */
	public static function from_name() {
		$name = trim( (string) WCMA_Settings::get( 'smtp_from_name', '' ) );

		if ( ! $name ) {
			$name = trim( (string) WCMA_Settings::get( 'from_name', '' ) );
		}

		return $name ? $name : (string) get_bloginfo( 'name' );
	}

	/**
	 * پیکربندی PHPMailer پیش از هر ارسال.
	 *
	 * @param PHPMailer\PHPMailer\PHPMailer|object $mailer شیء ارسال.
	 */
	public static function configure( $mailer ) {
		if ( ! self::is_on() || ! is_object( $mailer ) ) {
			return;
		}

		$secure = (string) WCMA_Settings::get( 'smtp_secure', 'tls' );
		$secure = isset( self::encryptions()[ $secure ] ) ? $secure : 'tls';

		if ( method_exists( $mailer, 'isSMTP' ) ) {
			$mailer->isSMTP();
		} else {
			$mailer->IsSMTP();
		}

		$mailer->Host    = trim( (string) WCMA_Settings::get( 'smtp_host', '' ) );
		$mailer->Port    = max( 1, (int) WCMA_Settings::get( 'smtp_port', 587 ) );
		$mailer->SMTPAuth = WCMA_Settings::is( 'smtp_auth' );

		if ( 'none' === $secure ) {
			// رشته‌ی خالی یعنی PHPMailer اصلاً STARTTLS را امتحان نکند.
			$mailer->SMTPSecure = '';
			$mailer->SMTPAutoTLS = false;
		} else {
			$mailer->SMTPSecure = $secure;
		}

		if ( $mailer->SMTPAuth ) {
			$mailer->Username = (string) WCMA_Settings::get( 'smtp_user', '' );
			$mailer->Password = (string) WCMA_Settings::get( 'smtp_pass', '' );
		}

		/*
		 * وردپرس ممکن است صفحه‌ها معطل بماند اگر میزبان جواب ندهد؛ سقف
		 * پیش‌فرض PHPMailer پنج دقیقه است.
		 */
		$mailer->Timeout = 20;

		if ( method_exists( $mailer, 'setSMTPXclientAttribute' ) || property_exists( $mailer, 'SMTPKeepAlive' ) ) {
			$mailer->SMTPKeepAlive = false;
		}

		if ( self::force_from() ) {
			$from = self::from_email();

			$mailer->setFrom( $from, self::from_name(), false );

			/*
			 * setFrom فقط From را عوض می‌کند و Sender را — که همان MAIL FROM
			 * پاکت است — دست‌نخورده می‌گذارد؛ وردپرس پیش از ما آن را پر کرده
			 * است. بیشتر سرورها نامه‌ای را که پاکتش با حساب واردشده نمی‌خواند
			 * رد می‌کنند یا به هرزنامه می‌فرستند، پس صریح نوشته می‌شود.
			 */
			$mailer->Sender = $from;
		}

		if ( WCMA_Settings::is( 'smtp_debug' ) ) {
			$mailer->SMTPDebug   = 2;
			$mailer->Debugoutput = array( __CLASS__, 'log_debug' );
		}

		/**
		 * دست بردن در تنظیم نهایی SMTP.
		 *
		 * @param object $mailer شیء PHPMailer.
		 */
		do_action( 'wcma_smtp_configured', $mailer );
	}

	/**
	 * گرفتن خروجی اشکال‌زدایی SMTP.
	 *
	 * گفتگوی خام با سرور تنها جایی است که دلیل واقعی رد شدن ایمیل را می‌گوید
	 * («۵۳۵ رمز اشتباه»، «۵۵۰ فرستنده مجاز نیست» و مانند آن)، پس نگه داشته
	 * می‌شود تا در نتیجه‌ی آزمون دیده شود.
	 *
	 * @param string $line  خط.
	 * @param int    $level سطح.
	 */
	public static function log_debug( $line, $level = 0 ) {
		unset( $level );

		$line = trim( (string) $line );

		if ( '' === $line ) {
			return;
		}

		// فقط چند خط آخر لازم است؛ بیشترش حافظه می‌گیرد و چیزی اضافه نمی‌کند.
		self::$debug[] = mb_substr( $line, 0, 300 );
		self::$debug   = array_slice( self::$debug, -40 );

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'WCMA SMTP: ' . $line ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
		}
	}

	/**
	 * خط‌های اشکال‌زدایی آخرین ارسال.
	 *
	 * @return array
	 */
	public static function debug_lines() {
		return self::$debug;
	}

	/**
	 * نگه‌داشتن خطای آخرین ارسال.
	 *
	 * @param WP_Error $error خطا.
	 */
	public static function remember_error( $error ) {
		if ( is_wp_error( $error ) ) {
			self::$last_error = $error->get_error_message();
		}
	}

	/**
	 * خطای آخرین ارسال.
	 *
	 * @return string
	 */
	public static function last_error() {
		return self::$last_error;
	}

	/**
	 * فرستادن یک ایمیل آزمایشی.
	 *
	 * @param string $to گیرنده.
	 * @return array{success:bool,message:string}
	 */
	public static function send_test( $to ) {
		$to = sanitize_email( (string) $to );

		if ( ! is_email( $to ) ) {
			return array( 'success' => false, 'message' => 'نشانی ایمیل معتبر نیست.' );
		}

		if ( ! self::is_on() ) {
			return array(
				'success' => false,
				'message' => 'SMTP خاموش است یا نشانی سرور وارد نشده؛ ایمیل با روش پیش‌فرض سرور فرستاده می‌شود.',
			);
		}

		self::$last_error = '';
		self::$debug      = array();

		$subject = 'آزمایش ارسال ایمیل — ' . get_bloginfo( 'name' );
		$body    = sprintf(
			"این یک ایمیل آزمایشی از افزونه‌ی اتوماسیون بازاریابی کلاسیکا است.\n\nسرور: %s\nدرگاه: %s\nرمزگذاری: %s\nزمان: %s",
			WCMA_Settings::get( 'smtp_host', '' ),
			WCMA_Settings::get( 'smtp_port', '' ),
			WCMA_Settings::get( 'smtp_secure', '' ),
			WCMA_Date::format( null, 'datetime' )
		);

		$sent = wp_mail( $to, $subject, $body );

		if ( $sent ) {
			return array( 'success' => true, 'message' => 'ایمیل آزمایشی فرستاده شد. صندوق ورودی و پوشه‌ی هرزنامه را ببینید.' );
		}

		$error = self::last_error();

		return array(
			'success' => false,
			'message' => $error ? 'ارسال نشد: ' . $error : 'ارسال نشد. نشانی سرور، درگاه، نام کاربری و رمز را بررسی کنید.',
			'debug'   => self::debug_lines(),
		);
	}

	/**
	 * وضعیت خلاصه برای نمایش در پیشخوان.
	 *
	 * @return array{state:string,label:string,detail:string}
	 */
	public static function status() {
		if ( ! WCMA_Settings::is( 'smtp_enabled' ) ) {
			return array(
				'state'  => 'off',
				'label'  => 'خاموش',
				'detail' => 'ایمیل‌ها با تابع mail() خود سرور فرستاده می‌شوند؛ روی بیشتر هاست‌ها به هرزنامه می‌روند.',
			);
		}

		if ( '' === trim( (string) WCMA_Settings::get( 'smtp_host', '' ) ) ) {
			return array(
				'state'  => 'warn',
				'label'  => 'ناقص',
				'detail' => 'روشن است ولی نشانی سرور SMTP وارد نشده، پس هنوز اثری ندارد.',
			);
		}

		if ( WCMA_Settings::is( 'smtp_auth' ) && '' === trim( (string) WCMA_Settings::get( 'smtp_user', '' ) ) ) {
			return array(
				'state'  => 'warn',
				'label'  => 'ناقص',
				'detail' => 'ورود با نام کاربری روشن است ولی نام کاربری وارد نشده.',
			);
		}

		return array(
			'state'  => 'on',
			'label'  => 'فعال',
			'detail' => sprintf(
				'%s روی درگاه %s با %s',
				WCMA_Settings::get( 'smtp_host', '' ),
				WCMA_Date::number( (int) WCMA_Settings::get( 'smtp_port', 587 ) ),
				strtoupper( (string) WCMA_Settings::get( 'smtp_secure', 'tls' ) )
			),
		);
	}
}
