<?php
/**
 * لید مگنت: فرم جذب سرنخ روی سایت و راه‌اندازی سریع مسیر ربات تلگرام.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Lead_Magnet
 */
class WCMA_Lead_Magnet {

	const SOURCE   = 'lead_magnet';
	const NONCE    = 'wcma_lead';
	const RATE_KEY = 'wcma_lead_rate_';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_shortcode( 'wcma_lead_form', array( __CLASS__, 'shortcode' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * آیا فرم روشن است؟
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return WCMA_Settings::is( 'lm_enabled' );
	}

	/**
	 * پاداشی که به سرنخ داده می‌شود.
	 *
	 * @return array
	 */
	public static function rewards() {
		return array(
			'coupon' => 'کد تخفیف (خودکار ساخته می‌شود)',
			'file'   => 'فایل دانلودی',
			'text'   => 'فقط یک پیام',
		);
	}

	/**
	 * ثبت مسیر REST.
	 */
	public static function register_routes() {
		register_rest_route(
			'wcma/v1',
			'/lead',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_submit' ),
				// فرم برای بازدیدکننده‌ی مهمان است؛ محافظت با نانس، تله و محدودیت نرخ انجام می‌شود.
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * بارگذاری استایل فقط وقتی شورت‌کد در صفحه هست.
	 */
	public static function enqueue() {
		if ( ! self::is_enabled() ) {
			return;
		}

		wp_enqueue_style( 'wcma-font', WCMA_URL . 'assets/css/font.css', array(), WCMA_Plugin::asset_version( 'assets/css/font.css' ) );
		wp_enqueue_style( 'wcma-lead', WCMA_URL . 'assets/css/lead.css', array( 'wcma-font' ), WCMA_Plugin::asset_version( 'assets/css/lead.css' ) );
		wp_enqueue_script( 'wcma-lead', WCMA_URL . 'assets/js/lead.js', array(), WCMA_Plugin::asset_version( 'assets/js/lead.js' ), true );

		wp_localize_script(
			'wcma-lead',
			'wcmaLead',
			array(
				'url'   => esc_url_raw( rest_url( 'wcma/v1/lead' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	/**
	 * شورت‌کد فرم.
	 *
	 * @param array $atts ویژگی‌ها.
	 * @return string
	 */
	public static function shortcode( $atts = array() ) {
		if ( ! self::is_enabled() ) {
			return '';
		}

		$atts = shortcode_atts(
			array(
				'title'    => WCMA_Settings::get( 'lm_title', '' ),
				'subtitle' => WCMA_Settings::get( 'lm_subtitle', '' ),
				'button'   => WCMA_Settings::get( 'lm_button', 'دریافت رایگان' ),
			),
			(array) $atts,
			'wcma_lead_form'
		);

		$ask_name  = WCMA_Settings::is( 'lm_ask_name' );
		$ask_email = WCMA_Settings::is( 'lm_ask_email' );
		$id        = 'wcma-lead-' . wp_rand( 1000, 9999 );

		ob_start();
		?>
		<div class="wcma-lead" id="<?php echo esc_attr( $id ); ?>">
			<form class="wcma-lead__form" novalidate>
				<?php if ( $atts['title'] ) : ?>
					<h3 class="wcma-lead__title"><?php echo esc_html( $atts['title'] ); ?></h3>
				<?php endif; ?>

				<?php if ( $atts['subtitle'] ) : ?>
					<p class="wcma-lead__subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
				<?php endif; ?>

				<?php if ( $ask_name ) : ?>
					<input type="text" class="wcma-lead__field" name="name" placeholder="نام شما" autocomplete="given-name" />
				<?php endif; ?>

				<input
					type="tel"
					class="wcma-lead__field"
					name="phone"
					placeholder="شماره موبایل"
					inputmode="numeric"
					autocomplete="tel"
					required
				/>

				<?php if ( $ask_email ) : ?>
					<input type="email" class="wcma-lead__field" name="email" placeholder="ایمیل (اختیاری)" autocomplete="email" />
				<?php endif; ?>

				<?php /* تله‌ی ربات‌ها: انسان این را نمی‌بیند و پر نمی‌کند. */ ?>
				<input type="text" name="website" class="wcma-lead__trap" tabindex="-1" autocomplete="off" aria-hidden="true" />

				<button type="submit" class="wcma-lead__submit"><?php echo esc_html( $atts['button'] ); ?></button>

				<?php if ( WCMA_Settings::get( 'lm_consent', '' ) ) : ?>
					<p class="wcma-lead__consent"><?php echo esc_html( WCMA_Settings::get( 'lm_consent', '' ) ); ?></p>
				<?php endif; ?>

				<div class="wcma-lead__note" role="status"></div>
			</form>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * دریافت فرم.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_submit( $request ) {
		if ( ! self::is_enabled() ) {
			return self::fail( 'این فرم فعال نیست.' );
		}

		$body = $request->get_json_params();
		$body = is_array( $body ) ? $body : $request->get_params();

		// تله پر شده یعنی ربات؛ بی‌سروصدا «موفق» می‌گوییم تا دوباره تلاش نکند.
		if ( ! empty( $body['website'] ) ) {
			return new WP_REST_Response( array( 'ok' => true, 'message' => self::success_text() ), 200 );
		}

		if ( ! self::allow_rate() ) {
			return self::fail( 'درخواست‌های زیادی فرستاده شده. کمی صبر کنید.' );
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( (string) ( $body['phone'] ?? '' ) );
		$email = sanitize_email( (string) ( $body['email'] ?? '' ) );
		$name  = sanitize_text_field( (string) ( $body['name'] ?? '' ) );

		if ( ! $phone && ! $email ) {
			return self::fail( 'شماره موبایل معتبر وارد کنید.' );
		}

		if ( ! $phone ) {
			return self::fail( 'شماره موبایل درست نیست. مثال: ۰۹۱۲۱۲۳۴۵۶۷' );
		}

		$contact_id = WCMA_CRM::upsert(
			array(
				'phone'      => $phone,
				'email'      => $email,
				'first_name' => $name,
				'source'     => 'lead_form',
				'tags'       => WCMA_Settings::get( 'lm_tag', 'لید مگنت' ),
			)
		);

		if ( ! $contact_id ) {
			return self::fail( 'ثبت نشد؛ دوباره تلاش کنید.' );
		}

		$page = esc_url_raw( (string) ( $body['page'] ?? '' ) );

		WCMA_CRM::add_note(
			$contact_id,
			'از فرم لید مگنت ثبت شد' . ( $page ? ' — صفحه: ' . $page : '' ),
			'note'
		);

		$reward = self::deliver( $phone, $email, $name, $contact_id );

		return new WP_REST_Response(
			array(
				'ok'      => true,
				'message' => self::success_text( $reward['coupon'] ),
				'link'    => $reward['link'],
			),
			200
		);
	}

	/**
	 * ساخت و فرستادن پاداش.
	 *
	 * @param string $phone      شماره.
	 * @param string $email      ایمیل.
	 * @param string $name       نام.
	 * @param int    $contact_id پرونده.
	 * @return array{coupon:string,link:string}
	 */
	protected static function deliver( $phone, $email, $name, $contact_id ) {
		$type   = WCMA_Settings::get( 'lm_reward', 'coupon' );
		$coupon = '';
		$link   = '';

		if ( 'coupon' === $type && class_exists( 'WCMA_Coupons' ) ) {
			$coupon = (string) WCMA_Coupons::create(
				array(
					'type'      => WCMA_Settings::get( 'lm_coupon_type', 'percent' ),
					'amount'    => (float) WCMA_Settings::get( 'lm_coupon_amount', 10 ),
					'days'      => (int) WCMA_Settings::get( 'lm_coupon_days', 7 ),
					'min_spend' => (float) WCMA_Settings::get( 'lm_coupon_min', 0 ),
					'email'     => $email,
					'prefix'    => 'LEAD',
					'workflow'  => 'لید مگنت',
				)
			);
		}

		if ( 'file' === $type ) {
			$link = esc_url_raw( (string) WCMA_Settings::get( 'lm_file', '' ) );
		}

		$context = array(
			'vars' => array(
				'{first_name}'  => $name ? $name : 'دوست عزیز',
				'{coupon_code}' => $coupon,
				'{file_link}'   => $link,
			),
		);

		$text = WCMA_Placeholders::replace( (string) WCMA_Settings::get( 'lm_sms_text', '' ), $context );
		$html = WCMA_Placeholders::replace( (string) WCMA_Settings::get( 'lm_email_text', '' ), $context );

		if ( trim( $text ) || trim( $html ) ) {
			WCMA_Sender::send(
				array(
					'channel'     => WCMA_Settings::get( 'lm_channel', 'sms' ),
					'phone'       => $phone,
					'email'       => $email,
					'subject'     => WCMA_Settings::get( 'lm_subject', 'هدیه‌ی شما' ),
					'text'        => $text,
					'html'        => $html ? $html : wpautop( $text ),
					'workflow'    => 'lead_magnet',
					'step'        => 'welcome',
					'object_type' => 'contact',
					'object_id'   => (int) $contact_id,
					'coupon_code' => $coupon,
					// این پیام پاسخِ درخواست خود کاربر است، نه تبلیغ گروهی.
					'skip_optout' => true,
				)
			);
		}

		return array( 'coupon' => $coupon, 'link' => $link );
	}

	/**
	 * متن موفقیت.
	 *
	 * @param string $coupon کد تخفیف.
	 * @return string
	 */
	protected static function success_text( $coupon = '' ) {
		$text = (string) WCMA_Settings::get( 'lm_success', 'ثبت شد! هدیه‌ی شما فرستاده شد.' );

		return WCMA_Placeholders::replace( $text, array( 'vars' => array( '{coupon_code}' => $coupon ) ) );
	}

	/**
	 * محدودیت نرخ بر پایه‌ی IP.
	 *
	 * @return bool
	 */
	protected static function allow_rate() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		if ( '' === $ip ) {
			return true;
		}

		$key   = self::RATE_KEY . md5( $ip );
		$count = (int) get_transient( $key );

		if ( $count >= 5 ) {
			return false;
		}

		set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );

		return true;
	}

	/**
	 * پاسخ ناموفق.
	 *
	 * @param string $message پیام.
	 * @return WP_REST_Response
	 */
	protected static function fail( $message ) {
		return new WP_REST_Response( array( 'ok' => false, 'message' => $message ), 200 );
	}

	/**
	 * شمار سرنخ‌های جذب‌شده.
	 *
	 * @return int
	 */
	public static function count() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			return 0;
		}

		$table = $wpdb->prefix . 'wcma_contacts';
		$tag   = (string) WCMA_Settings::get( 'lm_tag', 'لید مگنت' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE tags LIKE %s", '%' . $wpdb->esc_like( $tag ) . '%' ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * راه‌اندازی سریع مسیر ربات تلگرام.
	 *
	 * دنباله‌ی هفت‌روزه، دکمه‌ی شماره و کد تخفیف روز آخر را یک‌جا تنظیم می‌کند.
	 *
	 * @param string $topic موضوع، برای متن پیام‌ها.
	 * @return array
	 */
	public static function setup_telegram( $topic = '' ) {
		$topic = trim( sanitize_text_field( $topic ) );
		$topic = $topic ? $topic : 'کسب‌وکار شما';

		if ( ! WCMA_Settings::get( 'telegram_bot_token' ) ) {
			return array( 'success' => false, 'message' => 'اول توکن ربات تلگرام را در «کانال‌های ارتباطی» وارد کنید.' );
		}

		$existing = WCMA_Settings::get( 'tg_sequence', array() );

		// تنظیمات موجود را پاک نمی‌کنیم؛ کاربر باید خودش تصمیم بگیرد.
		if ( is_array( $existing ) && count( $existing ) > 0 ) {
			return array( 'success' => false, 'message' => 'دنباله‌ی روزانه از قبل تعریف شده است. برای جلوگیری از پاک شدن کارتان، چیزی تغییر نکرد.' );
		}

		$days = array();

		for ( $day = 1; $day <= 7; $day++ ) {
			$days[] = array(
				'day'    => $day,
				'active' => 'yes',
				'mode'   => 'offset',
				'time'   => '10:00',
				'type'   => 'text',
				'text'   => 7 === $day
					? sprintf( "{first_name} عزیز، این هم هدیه‌ی روز آخر 🎁\n\nکد تخفیف شما: {coupon_code}\n\nممنون که هفت روز همراه ما بودید.", $topic )
					: sprintf( "روز {day} از ۷ — نکته‌ی امروز درباره‌ی %s:\n\n[متن نکته را اینجا بنویسید]", $topic ),
			);
		}

		WCMA_Settings::update(
			array(
				'tg_bot_enabled'   => 'yes',
				'tg_bot_channel'   => 'telegram',
				'tg_ask_phone'     => 'yes',
				'tg_welcome_text'  => sprintf(
					"سلام! خوش آمدید 👋\n\nقرار است ۷ روز، هر روز یک نکته‌ی رایگان درباره‌ی %s برایتان بفرستیم و روز آخر یک هدیه.\n\nبرای شروع، شماره‌تان را با دکمه‌ی زیر بفرستید.",
					$topic
				),
				'tg_phone_thanks'  => 'ممنون! از فردا هر روز ساعت ۱۰ صبح یک نکته برایتان می‌فرستیم.',
				'tg_seq_enabled'   => 'yes',
				'tg_seq_first_now' => 'yes',
				'tg_seq_time'      => '10:00',
				'tg_sequence'      => WCMA_Admin_Fields::sanitize_value( 'tg_sequence', $days ),
			)
		);

		return array(
			'success' => true,
			'message' => 'دنباله‌ی ۷ روزه ساخته شد. حالا در برگه‌ی «ربات تلگرام» متن هر روز را بنویسید.',
		);
	}
}
