<?php
/**
 * درگاه «پرداخت از کیف پول».
 *
 * این فایل فقط وقتی بار می‌شود که ووکامرس درگاه‌ها را می‌سازد؛ پیش از آن
 * کلاس WC_Payment_Gateway وجود ندارد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Wallet_Gateway
 */
class WCMA_Wallet_Gateway extends WC_Payment_Gateway {

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->id                 = 'wcma_wallet';
		$this->method_title       = 'کیف پول';
		$this->method_description = 'مشتری می‌تواند سفارش را از موجودی کیف پولش پرداخت کند.';
		$this->has_fields         = false;
		$this->title              = (string) WCMA_Settings::get( 'wallet_gateway_title', 'پرداخت از کیف پول' );
		$this->description        = '';

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * آیا این روش پرداخت باید نشان داده شود؟
	 *
	 * @return bool
	 */
	public function is_available() {
		if ( ! WCMA_Wallet::is_on() || ! is_user_logged_in() ) {
			return false;
		}

		// سفارشِ شارژ کیف پول را نمی‌شود از خود کیف پول پرداخت کرد.
		if ( $this->is_topup_checkout() ) {
			return false;
		}

		return WCMA_Wallet::balance( get_current_user_id() ) > 0;
	}

	/**
	 * توضیح زیر نام درگاه: مانده و کسری.
	 *
	 * @return string
	 */
	public function get_description() {
		if ( ! is_user_logged_in() ) {
			return '';
		}

		$balance = WCMA_Wallet::balance( get_current_user_id() );
		$total   = $this->cart_total();
		$text    = sprintf( 'موجودی کیف پول شما: %s', WCMA_Date::price( $balance ) );

		if ( $total > 0 && $balance < $total ) {
			$text .= sprintf( ' — برای این سفارش %s کم دارید.', WCMA_Date::price( $total - $balance ) );
		}

		return $text;
	}

	/**
	 * پرداخت سفارش از کیف پول.
	 *
	 * @param int $order_id سفارش.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			wc_add_notice( 'سفارش پیدا نشد.', 'error' );

			return array( 'result' => 'failure' );
		}

		$user   = (int) $order->get_customer_id();
		$amount = (float) $order->get_total();

		if ( ! $user ) {
			wc_add_notice( 'برای پرداخت از کیف پول باید وارد حساب خود شوید.', 'error' );

			return array( 'result' => 'failure' );
		}

		$done = WCMA_Wallet::debit(
			$user,
			$amount,
			'order',
			array(
				'object_id' => $order->get_id(),
				'note'      => sprintf( 'پرداخت سفارش #%s', $order->get_order_number() ),
			)
		);

		if ( empty( $done['success'] ) ) {
			wc_add_notice( (string) $done['message'], 'error' );

			return array( 'result' => 'failure' );
		}

		$order->update_meta_data( WCMA_Wallet::PAID_META, $amount );
		$order->payment_complete();
		$order->add_order_note( sprintf( 'از کیف پول پرداخت شد: %s', WCMA_Date::price( $amount ) ) );

		if ( function_exists( 'WC' ) && WC()->cart ) {
			WC()->cart->empty_cart();
		}

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * بازگرداندن پول به کیف پول هنگام استرداد.
	 *
	 * @param int    $order_id سفارش.
	 * @param float  $amount   مبلغ.
	 * @param string $reason   دلیل.
	 * @return bool
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order = wc_get_order( $order_id );

		if ( ! $order || ! $order->get_customer_id() ) {
			return false;
		}

		$amount = null === $amount ? (float) $order->get_total() : (float) $amount;

		if ( $amount <= 0 ) {
			return false;
		}

		$done = WCMA_Wallet::credit(
			(int) $order->get_customer_id(),
			$amount,
			'refund',
			array(
				'object_id' => $order->get_id(),
				'note'      => $reason ? $reason : sprintf( 'بازگشت وجه سفارش #%s', $order->get_order_number() ),
			)
		);

		return ! empty( $done['success'] );
	}

	/**
	 * آیا سبد جاری، شارژ کیف پول است؟
	 *
	 * @return bool
	 */
	protected function is_topup_checkout() {
		global $wp;

		if ( empty( $wp->query_vars['order-pay'] ) ) {
			return false;
		}

		return WCMA_Wallet::is_topup( (int) $wp->query_vars['order-pay'] );
	}

	/**
	 * مبلغ سبد یا سفارشِ در حال پرداخت.
	 *
	 * @return float
	 */
	protected function cart_total() {
		global $wp;

		if ( ! empty( $wp->query_vars['order-pay'] ) ) {
			$order = wc_get_order( (int) $wp->query_vars['order-pay'] );

			return $order ? (float) $order->get_total() : 0.0;
		}

		return ( function_exists( 'WC' ) && WC()->cart ) ? (float) WC()->cart->get_total( 'edit' ) : 0.0;
	}
}
