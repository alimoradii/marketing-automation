<?php
/**
 * حساب‌های کنسول اپراتور: ساخت، ورود، توکن و تاریخچه‌ی اقدام‌ها.
 *
 * این حساب‌ها از کاربران وردپرس جدا هستند؛ مدیر می‌تواند برای هر همکار یک
 * حساب با رمز دلخواه بسازد بدون اینکه به او دسترسی پیشخوان بدهد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_App_Users
 */
class WCMA_App_Users {

	const TOKEN_DAYS  = 30;
	const MAX_TRIES   = 8;
	const TRY_WINDOW  = 900;
	const TRY_PREFIX  = 'wcma_app_try_';

	/**
	 * نقش‌های موجود.
	 *
	 * @return array
	 */
	public static function roles() {
		return array(
			'viewer'  => 'مشاهده‌گر (فقط خواندن)',
			'agent'   => 'اپراتور (پاسخ به گفتگو و ثبت یادداشت)',
			'manager' => 'مدیر (همه‌چیز، از جمله تاریخچه‌ی همکاران)',
		);
	}

	/**
	 * دسترسی‌هایی که هر نقش دارد.
	 *
	 * تعریف نقش تا وقتی جایی بررسی نشود، فقط یک برچسب است. این نقشه تنها
	 * مرجع تصمیم‌گیری است: هم مسیرهای REST از آن می‌پرسند، هم پنل موبایل
	 * دکمه‌های غیرمجاز را با آن پنهان می‌کند، هم پیشخوان همین را نشان می‌دهد.
	 *
	 * @return array نقش => فهرست دسترسی.
	 */
	public static function role_caps() {
		return array(
			'viewer'  => array( 'chat_read', 'contact_read' ),
			'agent'   => array( 'chat_read', 'chat_reply', 'contact_read', 'note_add' ),
			'manager' => array( 'chat_read', 'chat_reply', 'chat_mode', 'contact_read', 'note_add', 'team_history' ),
		);
	}

	/**
	 * توضیح فارسی هر دسترسی، برای نمایش در پیشخوان و پنل.
	 *
	 * @return array
	 */
	public static function cap_labels() {
		return array(
			'chat_read'    => 'دیدن گفتگوها',
			'chat_reply'   => 'پاسخ دادن به مشتری',
			'chat_mode'    => 'سپردن گفتگو به ربات یا گرفتن آن',
			'contact_read' => 'دیدن پرونده‌ی مشتریان',
			'note_add'     => 'ثبت یادداشت در پرونده',
			'team_history' => 'دیدن تاریخچه‌ی اقدام‌های همکاران',
		);
	}

	/**
	 * دسترسی‌های یک نقش.
	 *
	 * نقش ناشناس کمترین دسترسی را می‌گیرد، نه بیشترین؛ اگر روزی مقدار خرابی
	 * در ستون نقش بنشیند نباید به دسترسی کامل تبدیل شود.
	 *
	 * @param string $role نقش.
	 * @return array
	 */
	public static function caps( $role ) {
		$map = self::role_caps();

		return $map[ (string) $role ] ?? $map['viewer'];
	}

	/**
	 * آیا این نقش اجازه‌ی این کار را دارد؟
	 *
	 * @param string $role نقش.
	 * @param string $cap  دسترسی.
	 * @return bool
	 */
	public static function role_can( $role, $cap ) {
		return in_array( (string) $cap, self::caps( $role ), true );
	}

	/**
	 * کارهایی که در تاریخچه ثبت می‌شوند.
	 *
	 * @return array
	 */
	public static function actions() {
		return array(
			'login'       => 'ورود به کنسول',
			'logout'      => 'خروج',
			'login_fail'  => 'ورود ناموفق',
			'chat_open'   => 'باز کردن گفتگو',
			'chat_reply'  => 'پاسخ به مشتری',
			'chat_mode'   => 'تغییر حالت گفتگو',
			'chat_file'   => 'ارسال فایل در گفتگو',
			'contact_view' => 'دیدن پرونده‌ی مشتری',
			'note_add'    => 'ثبت یادداشت',
		);
	}

	/**
	 * نام جدول.
	 *
	 * @param string $which users یا tokens یا log.
	 * @return string
	 */
	public static function table( $which = 'users' ) {
		global $wpdb;

		return $wpdb->prefix . 'wcma_app_' . $which;
	}

	/* ---------------------------------------------------------------------
	 * حساب‌ها
	 * ------------------------------------------------------------------ */

	/**
	 * فهرست حساب‌ها.
	 *
	 * @return array
	 */
	public static function all() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return array();
		}

		$table = self::table();

		return (array) $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id ASC", ARRAY_A ); // phpcs:ignore WordPress.DB
	}

	/**
	 * یک حساب با شناسه.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return null;
		}

		$table = self::table();

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $row ? $row : null;
	}

	/**
	 * یک حساب با نام کاربری.
	 *
	 * @param string $username نام کاربری.
	 * @return array|null
	 */
	public static function by_username( $username ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return null;
		}

		$table = self::table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE username = %s", self::clean_username( $username ) ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * نام کاربری تمیز.
	 *
	 * @param string $username ورودی.
	 * @return string
	 */
	public static function clean_username( $username ) {
		$username = strtolower( trim( (string) $username ) );

		return (string) preg_replace( '/[^a-z0-9_.-]/', '', $username );
	}

	/**
	 * ساخت یا ویرایش حساب.
	 *
	 * @param array $data داده.
	 * @return array{success:bool,message:string,id:int}
	 */
	public static function save( array $data ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return self::fail( 'جدول حساب‌ها ساخته نشده است. از «تنظیمات عمومی» جدول‌ها را ترمیم کنید.' );
		}

		$id       = (int) ( $data['id'] ?? 0 );
		$username = self::clean_username( $data['username'] ?? '' );
		$name     = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		$role     = isset( self::roles()[ $data['role'] ?? '' ] ) ? $data['role'] : 'agent';
		$pass     = (string) ( $data['password'] ?? '' );

		if ( strlen( $username ) < 3 ) {
			return self::fail( 'نام کاربری دست‌کم سه نویسه‌ی انگلیسی باشد.' );
		}

		$existing = self::by_username( $username );

		if ( $existing && (int) $existing['id'] !== $id ) {
			return self::fail( 'این نام کاربری قبلاً گرفته شده است.' );
		}

		// رمز فقط هنگام ساخت اجباری است؛ در ویرایش، خالی یعنی «تغییر نده».
		if ( ! $id && strlen( $pass ) < 8 ) {
			return self::fail( 'رمز دست‌کم هشت نویسه باشد.' );
		}

		if ( $pass && strlen( $pass ) < 8 ) {
			return self::fail( 'رمز دست‌کم هشت نویسه باشد.' );
		}

		$row = array(
			'username'   => $username,
			'name'       => $name ? $name : $username,
			'role'       => $role,
			'active'     => empty( $data['active'] ) ? 0 : 1,
			'wp_user_id' => (int) ( $data['wp_user_id'] ?? 0 ),
		);

		if ( $pass ) {
			// همان الگوریتم خود وردپرس؛ رمز هرگز خام ذخیره نمی‌شود.
			$row['pass_hash'] = wp_hash_password( $pass );
		}

		if ( $id ) {
			$wpdb->update( self::table(), $row, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB

			return array( 'success' => true, 'message' => 'حساب به‌روز شد.', 'id' => $id );
		}

		$row['created_at'] = current_time( 'mysql' );

		$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB

		return array( 'success' => true, 'message' => 'حساب ساخته شد.', 'id' => (int) $wpdb->insert_id );
	}

	/**
	 * حذف حساب و همه‌ی توکن‌هایش.
	 *
	 * @param int $id شناسه.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;

		$id = (int) $id;

		if ( ! $id || ! WCMA_Install::table_exists( 'wcma_app_users' ) ) {
			return false;
		}

		$wpdb->delete( self::table( 'tokens' ), array( 'user_id' => $id ) ); // phpcs:ignore WordPress.DB
		$wpdb->delete( self::table(), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB

		return true;
	}

	/* ---------------------------------------------------------------------
	 * ورود و توکن
	 * ------------------------------------------------------------------ */

	/**
	 * ورود با نام کاربری و رمز.
	 *
	 * @param string $username نام کاربری.
	 * @param string $password رمز.
	 * @param string $device   نام دستگاه.
	 * @return array{success:bool,message:string,token:string,user:array}
	 */
	public static function login( $username, $password, $device = '' ) {
		$username = self::clean_username( $username );

		if ( ! self::allow_try( $username ) ) {
			return self::fail( 'تلاش‌های ناموفق زیاد بوده. چند دقیقه صبر کنید.' );
		}

		$user = self::by_username( $username );

		/*
		 * پیام خطا برای «کاربر نبود» و «رمز غلط» یکی است، تا کسی نتواند با
		 * آزمون‌وخطا بفهمد کدام نام کاربری واقعی است.
		 */
		if ( ! $user || ! wp_check_password( $password, $user['pass_hash'] ) ) {
			self::count_try( $username );
			self::log( $user ? (int) $user['id'] : 0, $username, 'login_fail', '', 0, 'نام کاربری یا رمز نادرست' );

			return self::fail( 'نام کاربری یا رمز درست نیست.' );
		}

		if ( empty( $user['active'] ) ) {
			return self::fail( 'این حساب غیرفعال شده است.' );
		}

		self::clear_try( $username );

		$token = self::issue_token( (int) $user['id'], $device );

		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB
			self::table(),
			array( 'last_login_at' => current_time( 'mysql' ), 'last_ip' => self::ip() ),
			array( 'id' => (int) $user['id'] )
		);

		self::log( (int) $user['id'], $user['name'], 'login', '', 0, $device );

		return array(
			'success' => true,
			'message' => '',
			'token'   => $token,
			'user'    => array(
				'id'   => (int) $user['id'],
				'name' => $user['name'],
				'role' => $user['role'],
			),
		);
	}

	/**
	 * ساخت توکن تازه.
	 *
	 * فقط درهم‌سازی توکن ذخیره می‌شود؛ اگر دیتابیس لو برود، توکن‌ها قابل
	 * استفاده نیستند.
	 *
	 * @param int    $user_id حساب.
	 * @param string $device  دستگاه.
	 * @return string توکن خام، که فقط همین یک‌بار دیده می‌شود.
	 */
	public static function issue_token( $user_id, $device = '' ) {
		global $wpdb;

		$token = bin2hex( random_bytes( 32 ) );

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table( 'tokens' ),
			array(
				'user_id'    => (int) $user_id,
				'token_hash' => hash( 'sha256', $token ),
				'device'     => sanitize_text_field( mb_substr( (string) $device, 0, 180 ) ),
				'created_at' => current_time( 'mysql' ),
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + ( self::TOKEN_DAYS * DAY_IN_SECONDS ) ),
			)
		);

		return $token;
	}

	/**
	 * یافتن حساب از روی توکن.
	 *
	 * @param string $token توکن خام.
	 * @return array|null
	 */
	public static function user_by_token( $token ) {
		global $wpdb;

		$token = trim( (string) $token );

		if ( '' === $token || ! WCMA_Install::table_exists( 'wcma_app_tokens' ) ) {
			return null;
		}

		$tokens = self::table( 'tokens' );
		$users  = self::table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT u.*, t.id AS token_id FROM {$tokens} t
				 INNER JOIN {$users} u ON u.id = t.user_id
				 WHERE t.token_hash = %s AND t.expires_at > %s AND u.active = 1",
				hash( 'sha256', $token ),
				current_time( 'mysql' )
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return null;
		}

		$wpdb->update( $tokens, array( 'last_used_at' => current_time( 'mysql' ) ), array( 'id' => (int) $row['token_id'] ) ); // phpcs:ignore WordPress.DB

		return $row;
	}

	/**
	 * باطل کردن یک توکن.
	 *
	 * @param string $token توکن خام.
	 */
	public static function revoke_token( $token ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_tokens' ) ) {
			return;
		}

		$wpdb->delete( self::table( 'tokens' ), array( 'token_hash' => hash( 'sha256', (string) $token ) ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * باطل کردن همه‌ی دستگاه‌های یک حساب.
	 *
	 * @param int $user_id حساب.
	 * @return int شمار توکن‌های باطل‌شده.
	 */
	public static function revoke_all( $user_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_tokens' ) ) {
			return 0;
		}

		return (int) $wpdb->delete( self::table( 'tokens' ), array( 'user_id' => (int) $user_id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * شمار دستگاه‌های فعال یک حساب.
	 *
	 * @param int $user_id حساب.
	 * @return int
	 */
	public static function device_count( $user_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_tokens' ) ) {
			return 0;
		}

		$tokens = self::table( 'tokens' );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$tokens} WHERE user_id = %d AND expires_at > %s", (int) $user_id, current_time( 'mysql' ) ) // phpcs:ignore WordPress.DB
		);
	}

	/* ---------------------------------------------------------------------
	 * جلوگیری از حدس رمز
	 * ------------------------------------------------------------------ */

	/**
	 * آیا اجازه‌ی تلاش تازه هست؟
	 *
	 * @param string $username نام کاربری.
	 * @return bool
	 */
	protected static function allow_try( $username ) {
		return (int) get_transient( self::TRY_PREFIX . md5( $username . '|' . self::ip() ) ) < self::MAX_TRIES;
	}

	/**
	 * ثبت یک تلاش ناموفق.
	 *
	 * @param string $username نام کاربری.
	 */
	protected static function count_try( $username ) {
		$key = self::TRY_PREFIX . md5( $username . '|' . self::ip() );

		set_transient( $key, (int) get_transient( $key ) + 1, self::TRY_WINDOW );
	}

	/**
	 * پاک کردن شمارنده پس از ورود موفق.
	 *
	 * @param string $username نام کاربری.
	 */
	protected static function clear_try( $username ) {
		delete_transient( self::TRY_PREFIX . md5( $username . '|' . self::ip() ) );
	}

	/* ---------------------------------------------------------------------
	 * تاریخچه
	 * ------------------------------------------------------------------ */

	/**
	 * ثبت یک اقدام.
	 *
	 * @param int    $user_id     حساب.
	 * @param string $actor       نام نمایشی.
	 * @param string $action      کار.
	 * @param string $object_type نوع هدف.
	 * @param int    $object_id   شناسه‌ی هدف.
	 * @param string $detail      توضیح.
	 */
	public static function log( $user_id, $actor, $action, $object_type = '', $object_id = 0, $detail = '' ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_log' ) ) {
			return;
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table( 'log' ),
			array(
				'user_id'     => (int) $user_id,
				'actor'       => sanitize_text_field( mb_substr( (string) $actor, 0, 180 ) ),
				'action'      => sanitize_key( $action ),
				'object_type' => sanitize_key( $object_type ),
				'object_id'   => (int) $object_id,
				'detail'      => sanitize_text_field( mb_substr( (string) $detail, 0, 500 ) ),
				'ip'          => self::ip(),
				'created_at'  => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * تاریخچه‌ی اقدام‌ها.
	 *
	 * @param array $args فیلترها.
	 * @return array
	 */
	public static function history( array $args = array() ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_app_log' ) ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$args = wp_parse_args( $args, array( 'user_id' => 0, 'action' => '', 'per_page' => 100, 'page' => 1 ) );

		$table  = self::table( 'log' );
		$where  = array( '1=1' );
		$params = array();

		if ( $args['user_id'] ) {
			$where[]  = 'user_id = %d';
			$params[] = (int) $args['user_id'];
		}

		if ( $args['action'] ) {
			$where[]  = 'action = %s';
			$params[] = sanitize_key( $args['action'] );
		}

		$clause = implode( ' AND ', $where );
		$total  = $params
			? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$clause}", $params ) ) // phpcs:ignore WordPress.DB
			: (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB

		$per_page = max( 10, min( 500, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );

		$params[] = $per_page;
		$params[] = ( $page - 1 ) * $per_page;

		$items = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE {$clause} ORDER BY id DESC LIMIT %d OFFSET %d", $params ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return array(
			'items' => (array) $items,
			'total' => $total,
			'page'  => $page,
			'pages' => (int) ceil( $total / $per_page ),
		);
	}

	/* ---------------------------------------------------------------------
	 * کمکی
	 * ------------------------------------------------------------------ */

	/**
	 * نشانی IP درخواست.
	 *
	 * @return string
	 */
	public static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		return mb_substr( $ip, 0, 45 );
	}

	/**
	 * خروجی ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function fail( $message ) {
		return array( 'success' => false, 'message' => $message, 'token' => '', 'user' => array(), 'id' => 0 );
	}
}
