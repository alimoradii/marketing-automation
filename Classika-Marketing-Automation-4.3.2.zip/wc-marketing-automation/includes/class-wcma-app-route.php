<?php
/**
 * سرو کردن وب‌اپ روی نشانی دلخواه.
 *
 * تعریف «نشانی دلخواه» به‌تنهایی کافی نیست؛ وردپرس باید واقعاً چیزی در آن
 * مسیر برگرداند، وگرنه صفحه‌ی ۴۰۴ می‌آید. این کلاس یک قاعده‌ی بازنویسی
 * می‌سازد و سه فایل اپ را از همان مسیر سرو می‌کند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_App_Route
 */
class WCMA_App_Route {

	const VAR       = 'wcma_app';
	const FLAG      = 'wcma_app_flush';
	const SLUG_SEEN = 'wcma_app_slug_seen';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rules' ) );
		add_filter( 'query_vars', array( __CLASS__, 'add_var' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ) );
	}

	/**
	 * مسیر انتخاب‌شده، تمیزشده.
	 *
	 * فقط مسیر نسبی پذیرفته می‌شود، نه نشانی کامل؛ چون افزونه فقط روی همین
	 * دامنه می‌تواند چیزی سرو کند.
	 *
	 * @return string
	 */
	public static function slug() {
		$slug = (string) WCMA_Settings::get( 'app_slug', '' );

		// اگر کاربر نشانی کامل نوشته باشد، فقط بخش مسیر برداشته می‌شود.
		if ( false !== stripos( $slug, '://' ) ) {
			$path = wp_parse_url( $slug, PHP_URL_PATH );
			$slug = is_string( $path ) ? $path : '';
		}

		$slug = trim( (string) $slug, "/ \t\n\r" );
		$slug = (string) preg_replace( '#[^A-Za-z0-9/_-]#', '', $slug );

		return $slug;
	}

	/**
	 * نشانی نهایی وب‌اپ.
	 *
	 * @return string
	 */
	public static function url() {
		$slug = self::slug();

		return $slug ? home_url( '/' . $slug . '/' ) : WCMA_URL . 'app/index.html';
	}

	/**
	 * ثبت قاعده‌های بازنویسی.
	 */
	public static function add_rules() {
		$slug = self::slug();

		if ( '' === $slug ) {
			self::maybe_flush( '' );

			return;
		}

		$quoted = preg_quote( $slug, '#' );

		add_rewrite_rule( '^' . $quoted . '/?$', 'index.php?' . self::VAR . '=page', 'top' );
		add_rewrite_rule( '^' . $quoted . '/sw\.js$', 'index.php?' . self::VAR . '=sw', 'top' );
		add_rewrite_rule( '^' . $quoted . '/manifest\.json$', 'index.php?' . self::VAR . '=manifest', 'top' );

		self::maybe_flush( $slug );
	}

	/**
	 * اگر مسیر عوض شده، قاعده‌ها یک‌بار تازه می‌شوند.
	 *
	 * flush در هر بار بارگذاری هزینه‌بر است، پس فقط وقتی لازم است انجام می‌شود.
	 *
	 * @param string $slug مسیر جاری.
	 */
	protected static function maybe_flush( $slug ) {
		if ( get_option( self::SLUG_SEEN ) === $slug ) {
			return;
		}

		update_option( self::SLUG_SEEN, $slug, false );
		flush_rewrite_rules( false );
	}

	/**
	 * افزودن متغیر پرس‌وجو.
	 *
	 * @param array $vars متغیرها.
	 * @return array
	 */
	public static function add_var( $vars ) {
		$vars[] = self::VAR;

		return $vars;
	}

	/**
	 * سرو کردن فایل درخواستی.
	 */
	public static function maybe_serve() {
		$what = get_query_var( self::VAR );

		if ( ! $what ) {
			return;
		}

		nocache_headers();

		switch ( $what ) {
			case 'sw':
				header( 'Content-Type: application/javascript; charset=utf-8' );
				// دامنه‌ی کنترل سرویس‌ورکر باید همان مسیر اپ باشد.
				header( 'Service-Worker-Allowed: /' . self::slug() . '/' );
				echo self::read( 'sw.js' ); // phpcs:ignore WordPress.Security.EscapeOutput
				exit;

			case 'manifest':
				header( 'Content-Type: application/manifest+json; charset=utf-8' );
				echo self::read( 'manifest.json' ); // phpcs:ignore WordPress.Security.EscapeOutput
				exit;

			default:
				header( 'Content-Type: text/html; charset=utf-8' );
				echo self::read( 'index.html' ); // phpcs:ignore WordPress.Security.EscapeOutput
				exit;
		}
	}

	/**
	 * خواندن فایل اپ با نشانی‌های مطلق.
	 *
	 * فایل‌ها با مسیر نسبی نوشته شده‌اند و از مسیر دلخواه کار نمی‌کنند، پس
	 * هنگام سرو کردن به نشانی مطلق تبدیل می‌شوند.
	 *
	 * @param string $file نام فایل.
	 * @return string
	 */
	protected static function read( $file ) {
		$path = WCMA_PATH . 'app/' . $file;

		if ( ! file_exists( $path ) ) {
			return '';
		}

		$body = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$base = WCMA_URL . 'app/';
		$app  = trailingslashit( self::url() );

		/*
		 * نشانی دارایی‌ها نسخه‌دار می‌شود تا با هر به‌روزرسانی افزونه، مرورگر
		 * و سرویس‌ورکر نسخه‌ی تازه را بگیرند نه نسخه‌ی کش‌شده را.
		 */
		$ver = '?v=' . rawurlencode( WCMA_VERSION );

		// دارایی‌ها از پوشه‌ی افزونه می‌آیند...
		$body = str_replace(
			array( '"../assets/', "'../assets/", '"./app.css"', '"./app.js"', "'./app.css'", "'./app.js'" ),
			array( '"' . WCMA_URL . 'assets/', "'" . WCMA_URL . 'assets/', '"' . $base . 'app.css' . $ver . '"', '"' . $base . 'app.js' . $ver . '"', "'" . $base . 'app.css' . $ver . "'", "'" . $base . 'app.js' . $ver . "'" ),
			$body
		);

		// ...ولی مانیفست و سرویس‌ورکر باید از خودِ مسیر اپ بیایند تا دامنه درست بماند.
		$body = str_replace(
			array( '"./manifest.json"', "'./sw.js'", '"./index.html"', '"./"' ),
			array( '"' . $app . 'manifest.json"', "'" . $app . 'sw.js' . $ver . "'", '"' . $app . '"', '"' . $app . '"' ),
			$body
		);

		/*
		 * آیکون‌ها در مانیفست نسبی‌اند و از مسیر دلخواه به فایل نبودنی می‌رسند؛
		 * نشانی مطلقشان از پوشه‌ی افزونه گرفته می‌شود.
		 */
		if ( 'manifest.json' === $file ) {
			$body = str_replace( '"icon-', '"' . $base . 'icon-', $body );
			$body = str_replace( '"' . $app . 'index.html"', '"' . $app . '"', $body );
		}

		/*
		 * نشانی REST از خود وردپرس گرفته می‌شود؛ حدس‌زدن آن از روی مسیر مرورگر
		 * روی نصب‌های زیرپوشه‌ای یا با پوشه‌ی محتوای تغییرنام‌داده می‌شکند.
		 */
		if ( 'index.html' === $file ) {
			$rest = untrailingslashit( rest_url( 'wcma/v1' ) );
			$tag  = '<script>window.wcmaRest=' . wp_json_encode( $rest ) . ';</script>' . "\n";
			$body = str_replace( '</head>', "\t" . $tag . '</head>', $body );
		}

		// سرویس‌ورکر پوسته را با نشانی مطلق کش می‌کند تا از هر مسیری درست بماند.
		if ( 'sw.js' === $file ) {
			$body = str_replace(
				array( "'./index.html'", "'./app.css'", "'./app.js'", "'./manifest.json'", "'../assets/" ),
				array( "'" . $app . "index.html'", "'" . $base . "app.css'", "'" . $base . "app.js'", "'" . $app . "manifest.json'", "'" . WCMA_URL . 'assets/' ),
				$body
			);
		}

		return $body;
	}
}
