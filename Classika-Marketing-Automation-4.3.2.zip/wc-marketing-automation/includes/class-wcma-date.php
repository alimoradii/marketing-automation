<?php
/**
 * تاریخ و عدد فارسی: تبدیل میلادی به شمسی و قالب‌بندی یکپارچه.
 *
 * همه‌ی بخش‌های افزونه از این کلاس استفاده می‌کنند تا تغییر یک تنظیم، همه‌جا اعمال شود.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Date
 */
class WCMA_Date {

	/**
	 * نام ماه‌های شمسی.
	 *
	 * @var array
	 */
	protected static $months = array(
		1  => 'فروردین',
		2  => 'اردیبهشت',
		3  => 'خرداد',
		4  => 'تیر',
		5  => 'مرداد',
		6  => 'شهریور',
		7  => 'مهر',
		8  => 'آبان',
		9  => 'آذر',
		10 => 'دی',
		11 => 'بهمن',
		12 => 'اسفند',
	);

	/**
	 * نام روزهای هفته، از شنبه.
	 *
	 * @var array
	 */
	protected static $weekdays = array( 'شنبه', 'یک‌شنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه' );

	/**
	 * آیا تقویم شمسی فعال است؟
	 *
	 * @return bool
	 */
	public static function is_jalali() {
		return 'gregorian' !== WCMA_Settings::get( 'date_calendar', 'jalali' );
	}

	/**
	 * آیا ارقام باید فارسی نمایش داده شوند؟
	 *
	 * @return bool
	 */
	public static function use_persian_digits() {
		return 'en' !== WCMA_Settings::get( 'date_digits', 'fa' );
	}

	/**
	 * تبدیل ارقام لاتین به فارسی.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	public static function to_persian_digits( $text ) {
		$text = (string) $text;

		if ( '' === $text ) {
			return '';
		}

		$latin   = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$persian = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );

		// متن ساده و بدون نشانه‌گذاری، مسیر کوتاه.
		if ( false === strpos( $text, '<' ) && false === strpos( $text, '&' ) ) {
			return str_replace( $latin, $persian, $text );
		}

		/*
		 * در متن HTML نباید داخل تگ‌ها و موجودیت‌ها دست برد؛ وگرنه چیزی مثل
		 * &#x62A; به &#x۶۲A; تبدیل می‌شد و مرورگر به‌جای «تومان» خودِ کد را نشان می‌داد.
		 */
		$parts = preg_split( '/(<[^>]*>|&#?[0-9A-Za-z]+;)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE );

		if ( ! $parts ) {
			return $text;
		}

		$out = '';

		foreach ( $parts as $index => $part ) {
			// بخش‌های فرد، همان تگ‌ها و موجودیت‌های جداشده‌اند.
			$out .= ( $index % 2 ) ? $part : str_replace( $latin, $persian, $part );
		}

		return $out;
	}

	/**
	 * قالب‌بندی مبلغ با ارقام فارسی، بدون خراب کردن نشانه‌گذاری ووکامرس.
	 *
	 * @param float $amount مبلغ.
	 * @return string
	 */
	public static function price( $amount ) {
		if ( ! function_exists( 'wc_price' ) ) {
			return self::number( $amount );
		}

		return self::digits( wc_price( (float) $amount ) );
	}

	/**
	 * تبدیل ارقام فارسی و عربی به لاتین.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	public static function to_latin_digits( $text ) {
		$text = str_replace( array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ), range( 0, 9 ), (string) $text );

		return str_replace( array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' ), range( 0, 9 ), $text );
	}

	/**
	 * اعمال تنظیم ارقام روی یک رشته.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	public static function digits( $text ) {
		return self::use_persian_digits() ? self::to_persian_digits( $text ) : (string) $text;
	}

	/**
	 * قالب‌بندی عدد با جداکننده و ارقام دلخواه.
	 *
	 * @param float $number  عدد.
	 * @param int   $decimals تعداد اعشار.
	 * @return string
	 */
	public static function number( $number, $decimals = 0 ) {
		if ( self::use_persian_digits() ) {
			// جداکننده‌ی هزارگان فارسی (U+066C) تا عدد با ارقام فارسی هم‌خوان باشد.
			return self::to_persian_digits( number_format( (float) $number, (int) $decimals, '٫', '٬' ) );
		}

		return number_format( (float) $number, (int) $decimals );
	}

	/**
	 * مبلغ به‌شکل متن ساده: بدون تگ، بدون موجودیت HTML و با ارقام فارسی.
	 *
	 * برای پیامک و پیام‌رسان‌ها لازم است؛ وگرنه چیزی مثل &#x62A; در متن پیام می‌ماند.
	 *
	 * @param string $html خروجی قیمت ووکامرس.
	 * @return string
	 */
	public static function plain_price( $html ) {
		$text = wp_strip_all_tags( (string) $html );
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );

		// فاصله‌ی باریک و بدون‌شکستِ ووکامرس در پیامک به فاصله‌ی معمولی تبدیل می‌شود.
		$text = str_replace( array( "\xC2\xA0", "\xE2\x80\xAF" ), ' ', $text );

		return self::digits( trim( preg_replace( '/\s+/u', ' ', $text ) ) );
	}

	/**
	 * مبلغ عددی به‌شکل متن ساده — برای جایی که HTML قیمت به‌درد نمی‌خورد.
	 *
	 * price() خروجی ووکامرس را می‌دهد که تگ و «&nbsp;» دارد؛ اگر آن را
	 * جایی بگذاریم که دوباره esc_html می‌شود، کاربر خودِ «&nbsp;» را می‌بیند.
	 *
	 * @param float $amount مبلغ.
	 * @return string
	 */
	public static function price_text( $amount ) {
		return self::plain_price( self::price( $amount ) );
	}

	/**
	 * تبدیل تاریخ میلادی به شمسی.
	 *
	 * @param int $gy سال.
	 * @param int $gm ماه.
	 * @param int $gd روز.
	 * @return array{0:int,1:int,2:int}
	 */
	public static function gregorian_to_jalali( $gy, $gm, $gd ) {
		$g_days_in_month = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );

		$gy2 = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;

		$days = 355666
			+ ( 365 * $gy )
			+ (int) ( ( $gy2 + 3 ) / 4 )
			- (int) ( ( $gy2 + 99 ) / 100 )
			+ (int) ( ( $gy2 + 399 ) / 400 )
			+ $gd
			+ $g_days_in_month[ $gm - 1 ];

		$jy = -1595 + ( 33 * (int) ( $days / 12053 ) );

		$days %= 12053;
		$jy   += 4 * (int) ( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$jy  += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		if ( $days < 186 ) {
			$jm = 1 + (int) ( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) ( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}

		return array( $jy, $jm, $jd );
	}

	/**
	 * تبدیل تاریخ شمسی به میلادی.
	 *
	 * @param int $jy سال شمسی.
	 * @param int $jm ماه شمسی.
	 * @param int $jd روز شمسی.
	 * @return array{0:int,1:int,2:int}
	 */
	public static function jalali_to_gregorian( $jy, $jm, $jd ) {
		$jy = (int) $jy + 1595;
		$jm = (int) $jm;
		$jd = (int) $jd;

		$days = -355668
			+ ( 365 * $jy )
			+ ( (int) ( $jy / 33 ) * 8 )
			+ (int) ( ( ( $jy % 33 ) + 3 ) / 4 )
			+ $jd
			+ ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );

		$gy = 400 * (int) ( $days / 146097 );

		$days %= 146097;

		if ( $days > 36524 ) {
			--$days;
			$gy   += 100 * (int) ( $days / 36524 );
			$days %= 36524;

			if ( $days >= 365 ) {
				++$days;
			}
		}

		$gy   += 4 * (int) ( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$gy  += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		$gd     = $days + 1;
		$is_leap = ( 0 === $gy % 4 && 0 !== $gy % 100 ) || 0 === $gy % 400;
		$lengths = array( 0, 31, $is_leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );

		for ( $gm = 0; $gm < 13 && $gd > $lengths[ $gm ]; $gm++ ) {
			$gd -= $lengths[ $gm ];
		}

		return array( $gy, $gm, $gd );
	}

	/**
	 * شمار روزهای یک ماه شمسی.
	 *
	 * @param int $jy سال.
	 * @param int $jm ماه.
	 * @return int
	 */
	public static function jalali_month_days( $jy, $jm ) {
		$jm = (int) $jm;

		if ( $jm <= 6 ) {
			return 31;
		}

		if ( $jm <= 11 ) {
			return 30;
		}

		// اسفند: ۳۰ روز در سال کبیسه، وگرنه ۲۹ روز.
		list( $gy, $gm, $gd ) = self::jalali_to_gregorian( $jy, 12, 30 );
		list( $back )         = self::gregorian_to_jalali( $gy, $gm, $gd );

		return (int) $back === (int) $jy ? 30 : 29;
	}

	/**
	 * تبدیل تاریخ واردشده توسط کاربر به قالب میلادی استاندارد.
	 *
	 * ورودی می‌تواند شمسی یا میلادی، با ارقام فارسی یا لاتین و با جداکننده‌ی / یا - باشد.
	 * سال‌های کوچک‌تر از ۱۷۰۰ شمسی در نظر گرفته می‌شوند.
	 *
	 * @param string $value ورودی.
	 * @param string $type  date یا datetime.
	 * @return string قالب Y-m-d یا Y-m-d H:i و در صورت نامعتبر بودن، رشته‌ی خالی.
	 */
	public static function parse( $value, $type = 'date' ) {
		$value = trim( self::to_latin_digits( (string) $value ) );

		if ( '' === $value ) {
			return '';
		}

		// جداکننده‌ی تاریخ و ساعت می‌تواند T یا فاصله باشد.
		$value = str_replace( array( 'T', '،' ), array( ' ', ' ' ), $value );
		$time  = '';

		if ( preg_match( '/(\d{1,2}):(\d{2})/', $value, $t ) ) {
			$time  = sprintf( '%02d:%02d', min( 23, (int) $t[1] ), min( 59, (int) $t[2] ) );
			$value = str_replace( $t[0], '', $value );
		}

		if ( ! preg_match( '/(\d{4})\s*[\/\-.]\s*(\d{1,2})\s*[\/\-.]\s*(\d{1,2})/', $value, $m ) ) {
			return '';
		}

		$y = (int) $m[1];
		$mo = (int) $m[2];
		$d = (int) $m[3];

		if ( $mo < 1 || $mo > 12 || $d < 1 || $d > 31 ) {
			return '';
		}

		if ( $y < 1700 ) {
			// ۳۱ مهر یا ۳۰ اسفندِ سال غیرکبیسه وجود ندارد و نباید بی‌صدا به ماه بعد سر بخورد.
			if ( $d > self::jalali_month_days( $y, $mo ) ) {
				return '';
			}

			list( $y, $mo, $d ) = self::jalali_to_gregorian( $y, $mo, $d );
		}

		if ( ! checkdate( $mo, $d, $y ) ) {
			return '';
		}

		$date = sprintf( '%04d-%02d-%02d', $y, $mo, $d );

		if ( 'datetime' === $type ) {
			return $date . ' ' . ( $time ? $time : '00:00' );
		}

		return $date;
	}

	/**
	 * نمایش یک تاریخ میلادی در قالب ورودی‌های افزونه (شمسی یا میلادی، بسته به تنظیمات).
	 *
	 * @param string $value تاریخ به قالب Y-m-d یا Y-m-d H:i.
	 * @param string $type  date یا datetime.
	 * @return string
	 */
	public static function for_input( $value, $type = 'date' ) {
		$value = self::parse( $value, $type );

		if ( '' === $value ) {
			return '';
		}

		list( $date, $time ) = array_pad( explode( ' ', $value ), 2, '' );
		list( $y, $mo, $d )  = array_map( 'intval', explode( '-', $date ) );

		if ( self::is_jalali() ) {
			list( $y, $mo, $d ) = self::gregorian_to_jalali( $y, $mo, $d );
		}

		$out = sprintf( '%04d/%02d/%02d', $y, $mo, $d );

		if ( 'datetime' === $type && $time ) {
			$out .= ' ' . $time;
		}

		return self::digits( $out );
	}

	/**
	 * داده‌های موردنیاز تقویم شمسی در سمت مرورگر.
	 *
	 * @return array
	 */
	public static function picker_config() {
		return array(
			'jalali'          => self::is_jalali(),
			'digits'          => self::use_persian_digits() ? 'fa' : 'en',
			'months'          => array_values( self::$months ),
			'gregorianMonths' => array( 'ژانویه', 'فوریه', 'مارس', 'آوریل', 'مه', 'ژوئن', 'ژوئیه', 'اوت', 'سپتامبر', 'اکتبر', 'نوامبر', 'دسامبر' ),
			'days'            => array( 'ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج' ),
			'weekdays'        => self::$weekdays,
			'today'           => 'امروز',
			'clear'           => 'پاک کردن',
			'close'           => 'بستن',
			'now'             => gmdate( 'Y-m-d', time() + (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ),
		);
	}

	/**
	 * خروجی HTML یک تاریخ، به‌شکلی که با تغییر تنظیمات بدون بارگذاری دوباره‌ی صفحه به‌روز شود.
	 *
	 * مقدار خام میلادی در data نگه داشته می‌شود تا مرورگر بتواند دوباره آن را قالب‌بندی کند.
	 *
	 * @param string $mysql رشته‌ی تاریخ جدول‌ها (به وقت محلی).
	 * @param string $type  نوع خروجی.
	 * @param string $empty خروجی در صورت خالی بودن.
	 * @return string
	 */
	public static function html( $mysql, $type = 'datetime', $empty = '—' ) {
		$text = self::mysql( $mysql, $type, $empty );

		if ( ! $mysql || '0000-00-00' === substr( (string) $mysql, 0, 10 ) ) {
			return esc_html( $empty );
		}

		return sprintf(
			'<time data-wcma-date="%s" data-wcma-format="%s">%s</time>',
			esc_attr( gmdate( 'Y-m-d H:i', strtotime( (string) $mysql ) ) ),
			esc_attr( $type ),
			esc_html( $text )
		);
	}

	/**
	 * خروجی HTML یک عدد، برای به‌روزرسانی زنده‌ی ارقام.
	 *
	 * @param float $number   عدد.
	 * @param int   $decimals اعشار.
	 * @return string
	 */
	public static function number_html( $number, $decimals = 0 ) {
		return sprintf(
			'<span data-wcma-number="%s" data-wcma-decimals="%d">%s</span>',
			esc_attr( (string) $number ),
			(int) $decimals,
			esc_html( self::number( $number, $decimals ) )
		);
	}

	/**
	 * نام روز هفته برای یک زمان.
	 *
	 * هفته‌ی ایرانی از شنبه آغاز می‌شود، در حالی که date('w') یکشنبه را صفر می‌گیرد.
	 *
	 * @param int $timestamp زمان.
	 * @return string
	 */
	public static function weekday( $timestamp ) {
		$w = (int) gmdate( 'w', $timestamp );

		// یکشنبه(۰) → ۱، ... ، شنبه(۶) → ۰
		$index = ( $w + 1 ) % 7;

		return self::$weekdays[ $index ];
	}

	/**
	 * قالب‌بندی یک زمان بر اساس تنظیمات افزونه.
	 *
	 * @param int|string $when زمان (timestamp یا رشته‌ی قابل تجزیه).
	 * @param string     $type نوع خروجی.
	 * @return string
	 */
	public static function format( $when = null, $type = 'date' ) {
		$timestamp = self::normalize( $when );

		if ( ! $timestamp ) {
			return '';
		}

		// زمان محلی سایت.
		$local = $timestamp + ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );

		if ( ! self::is_jalali() ) {
			$formats = array(
				'date'      => 'Y/m/d',
				'date_long' => 'j F Y',
				'date_full' => 'l j F Y',
				'datetime'  => 'Y/m/d H:i',
				'time'      => 'H:i',
				'day'       => 'l',
			);

			return self::digits( date_i18n( $formats[ $type ] ?? $formats['date'], $timestamp ) );
		}

		list( $jy, $jm, $jd ) = self::gregorian_to_jalali(
			(int) gmdate( 'Y', $local ),
			(int) gmdate( 'n', $local ),
			(int) gmdate( 'j', $local )
		);

		$time = gmdate( 'H:i', $local );
		$day  = self::weekday( $local );

		switch ( $type ) {
			case 'date_long':
				$out = sprintf( '%d %s %d', $jd, self::$months[ $jm ], $jy );
				break;
			// روز هفته همراه تاریخ، بدون ساعت؛ برای جداکننده‌ی روز در گفتگو.
			case 'date_full':
				$out = sprintf( '%s %d %s %d', $day, $jd, self::$months[ $jm ], $jy );
				break;
			case 'datetime':
				$out = sprintf( '%04d/%02d/%02d ساعت %s', $jy, $jm, $jd, $time );
				break;
			case 'datetime_long':
				$out = sprintf( '%s %d %s %d، ساعت %s', $day, $jd, self::$months[ $jm ], $jy, $time );
				break;
			case 'time':
				$out = $time;
				break;
			case 'day':
				$out = $day;
				break;
			case 'month':
				$out = self::$months[ $jm ];
				break;
			case 'date':
			default:
				$out = sprintf( '%04d/%02d/%02d', $jy, $jm, $jd );
				break;
		}

		return self::digits( $out );
	}

	/**
	 * قالب‌بندی یک رشته‌ی تاریخ دیتابیس (زمان محلی سایت).
	 *
	 * @param string $mysql رشته.
	 * @param string $type  نوع.
	 * @return string
	 */
	public static function mysql( $mysql, $type = 'datetime', $empty = '—' ) {
		if ( ! $mysql || '0000-00-00' === substr( (string) $mysql, 0, 10 ) ) {
			return $empty;
		}

		// رشته‌های جدول‌های افزونه به وقت محلی‌اند، پس اختلاف را خنثی می‌کنیم.
		$timestamp = strtotime( $mysql ) - ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );

		return self::format( $timestamp, $type );
	}

	/**
	 * تبدیل ورودی‌های گوناگون به timestamp مطلق.
	 *
	 * @param mixed $when ورودی.
	 * @return int
	 */
	protected static function normalize( $when ) {
		if ( null === $when ) {
			return time();
		}

		if ( is_numeric( $when ) ) {
			return (int) $when;
		}

		if ( $when instanceof WC_DateTime || $when instanceof DateTime ) {
			return $when->getTimestamp();
		}

		$parsed = strtotime( (string) $when );

		return $parsed ? $parsed : 0;
	}
}
