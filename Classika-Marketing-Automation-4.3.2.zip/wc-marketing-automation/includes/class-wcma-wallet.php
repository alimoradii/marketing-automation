<?php
/**
 * کیف پول مشتری.
 *
 * مانده در متای کاربر نگه داشته می‌شود تا خواندنش سریع باشد، ولی حقیقتِ
 * ماجرا دفتر تراکنش‌هاست: هر تغییری یک ردیف می‌سازد و مانده‌ی پس از خودش را
 * هم ثبت می‌کند، پس همیشه می‌شود سر درآورد پول از کجا آمد و کجا رفت.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Wallet
 */
class WCMA_Wallet {

	/**
	 * کلید متای مانده.
	 */
	const META = 'wcma_wallet_balance';

	/**
	 * متای سفارشِ شارژ.
	 */
	const ORDER_META = '_wcma_topup';

	/**
	 * متای سفارشی که از کیف پول پرداخت شده.
	 */
	const PAID_META = '_wcma_wallet_paid';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'maybe_credit' ) );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'maybe_credit' ) );
		add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'register_gateway' ) );
	}

	/**
	 * آیا کیف پول روشن است؟
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'wallet_enabled' ) && WCMA_Install::table_exists( 'wcma_wallet' );
	}

	/**
	 * نام جدول دفتر.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_wallet';
	}

	/**
	 * مانده‌ی کیف پول.
	 *
	 * @param int $user_id کاربر.
	 * @return float
	 */
	public static function balance( $user_id ) {
		return round( (float) get_user_meta( (int) $user_id, self::META, true ), 2 );
	}

	/**
	 * افزودن به کیف پول.
	 *
	 * @param int    $user_id کاربر.
	 * @param float  $amount  مبلغ (مثبت).
	 * @param string $source  منبع.
	 * @param array  $args    جزئیات.
	 * @return array{success:bool,message:string,balance:float}
	 */
	public static function credit( $user_id, $amount, $source = 'manual', array $args = array() ) {
		return self::move( $user_id, abs( (float) $amount ), 'credit', $source, $args );
	}

	/**
	 * برداشت از کیف پول.
	 *
	 * @param int    $user_id کاربر.
	 * @param float  $amount  مبلغ (مثبت).
	 * @param string $source  منبع.
	 * @param array  $args    جزئیات.
	 * @return array{success:bool,message:string,balance:float}
	 */
	public static function debit( $user_id, $amount, $source = 'manual', array $args = array() ) {
		return self::move( $user_id, -abs( (float) $amount ), 'debit', $source, $args );
	}

	/**
	 * نوشتن یک تراکنش.
	 *
	 * @param int    $user_id کاربر.
	 * @param float  $delta   تغییر (مثبت یا منفی).
	 * @param string $kind    credit یا debit.
	 * @param string $source  منبع.
	 * @param array  $args    جزئیات.
	 * @return array
	 */
	protected static function move( $user_id, $delta, $kind, $source, array $args ) {
		global $wpdb;

		$user_id = (int) $user_id;
		$delta   = round( (float) $delta, 2 );

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			return self::fail( 'کاربر پیدا نشد.' );
		}

		if ( 0.0 === $delta ) {
			return self::fail( 'مبلغ صفر است.' );
		}

		if ( ! WCMA_Install::table_exists( 'wcma_wallet' ) ) {
			return self::fail( 'جدول کیف پول ساخته نشده است.' );
		}

		$before = self::balance( $user_id );
		$after  = round( $before + $delta, 2 );

		// اجازه‌ی منفی شدن نداریم؛ وگرنه کیف پول تبدیل به وام می‌شود.
		if ( $after < 0 ) {
			return self::fail( 'موجودی کیف پول کافی نیست.' );
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'user_id'    => $user_id,
				'amount'     => $delta,
				'balance'    => $after,
				'kind'       => 'debit' === $kind ? 'debit' : 'credit',
				'source'     => sanitize_key( $source ),
				'object_id'  => (int) ( $args['object_id'] ?? 0 ),
				'note'       => mb_substr( sanitize_text_field( (string) ( $args['note'] ?? '' ) ), 0, 250 ),
				'actor'      => mb_substr( sanitize_text_field( (string) ( $args['actor'] ?? '' ) ), 0, 190 ),
				'created_at' => current_time( 'mysql' ),
			)
		);

		update_user_meta( $user_id, self::META, $after );

		/**
		 * پس از هر تغییر کیف پول.
		 *
		 * @param int    $user_id کاربر.
		 * @param float  $delta   تغییر.
		 * @param float  $after   مانده‌ی تازه.
		 * @param string $source  منبع.
		 */
		do_action( 'wcma_wallet_changed', $user_id, $delta, $after, $source );

		return array( 'success' => true, 'message' => 'انجام شد.', 'balance' => $after );
	}

	/**
	 * تراکنش‌های یک کاربر.
	 *
	 * @param int   $user_id کاربر.
	 * @param array $args    صفحه‌بندی.
	 * @return array{items:array,total:int,pages:int,page:int}
	 */
	public static function history( $user_id, array $args = array() ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_wallet' ) ) {
			return array( 'items' => array(), 'total' => 0, 'pages' => 0, 'page' => 1 );
		}

		$args     = wp_parse_args( $args, array( 'per_page' => 20, 'page' => 1 ) );
		$table    = self::table();
		$user_id  = (int) $user_id;
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );

		$total = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d", $user_id ) // phpcs:ignore WordPress.DB
		);

		$items = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB
				$user_id,
				$per_page,
				( $page - 1 ) * $per_page
			),
			ARRAY_A
		);

		return array(
			'items' => $items ? $items : array(),
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
			'page'  => $page,
		);
	}

	/**
	 * برچسب منبع هر تراکنش.
	 *
	 * @param string $source منبع.
	 * @return string
	 */
	public static function source_label( $source ) {
		$map = array(
			'topup'  => 'شارژ کیف پول',
			'order'  => 'پرداخت سفارش',
			'refund' => 'بازگشت وجه',
			'manual' => 'تغییر دستی مدیر',
			'gift'   => 'هدیه',
		);

		return $map[ $source ] ?? $source;
	}

	/* ------------------------------------------------------------------ */
	/* شارژ از راه ووکامرس                                                 */
	/* ------------------------------------------------------------------ */

	/**
	 * کمترین و بیشترین مبلغ شارژ.
	 *
	 * @return array{min:float,max:float}
	 */
	public static function limits() {
		return array(
			'min' => max( 0, (float) WCMA_Settings::get( 'wallet_min', 10000 ) ),
			'max' => max( 0, (float) WCMA_Settings::get( 'wallet_max', 50000000 ) ),
		);
	}

	/**
	 * ساخت سفارش شارژ و برگرداندن نشانی پرداخت.
	 *
	 * از خودِ ووکامرس استفاده می‌شود تا هر درگاهی که فروشگاه دارد، بدون
	 * یک خط کد اضافه، برای شارژ هم کار کند.
	 *
	 * @param int   $user_id کاربر.
	 * @param float $amount  مبلغ.
	 * @return array{success:bool,message:string,url:string}
	 */
	public static function start_topup( $user_id, $amount ) {
		$user_id = (int) $user_id;
		$amount  = round( (float) $amount, 2 );
		$limits  = self::limits();

		if ( ! self::is_on() ) {
			return self::fail( 'کیف پول فعال نیست.' );
		}

		/*
		 * مبلغ پیش از هر چیز سنجیده می‌شود: هم ارزان‌تر است و هم پیام درست را
		 * به کاربر می‌دهد. اگر ووکامرس اول بررسی می‌شد، مبلغ نامعتبر پیام
		 * بی‌ربطِ «ووکامرس در دسترس نیست» می‌گرفت.
		 */
		if ( $amount < $limits['min'] ) {
			return self::fail( sprintf( 'کمترین مبلغ شارژ %s است.', WCMA_Date::price_text( $limits['min'] ) ) );
		}

		if ( $limits['max'] > 0 && $amount > $limits['max'] ) {
			return self::fail( sprintf( 'بیشترین مبلغ شارژ %s است.', WCMA_Date::price_text( $limits['max'] ) ) );
		}

		if ( ! function_exists( 'wc_create_order' ) ) {
			return self::fail( 'ووکامرس در دسترس نیست.' );
		}

		$order = wc_create_order( array( 'customer_id' => $user_id ) );

		if ( is_wp_error( $order ) ) {
			return self::fail( 'ساخت سفارش شارژ انجام نشد.' );
		}

		/*
		 * به‌جای ساختن محصولِ واقعی در فروشگاه، مبلغ به‌صورت «هزینه» روی
		 * سفارش می‌نشیند؛ این‌طور چیزی در کاتالوگ و انبار اضافه نمی‌شود.
		 */
		$fee = new WC_Order_Item_Fee();
		$fee->set_name( 'شارژ کیف پول' );
		$fee->set_amount( (string) $amount );
		$fee->set_total( (string) $amount );
		$fee->set_tax_status( 'none' );

		$order->add_item( $fee );
		$order->update_meta_data( self::ORDER_META, $amount );
		$order->calculate_totals( false );
		$order->save();

		return array(
			'success' => true,
			'message' => 'سفارش شارژ ساخته شد.',
			'url'     => $order->get_checkout_payment_url(),
			'order'   => $order->get_id(),
		);
	}

	/**
	 * واریز پس از پرداخت سفارش شارژ.
	 *
	 * @param int $order_id سفارش.
	 */
	public static function maybe_credit( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;

		if ( ! $order ) {
			return;
		}

		$amount = (float) $order->get_meta( self::ORDER_META );
		$user   = (int) $order->get_customer_id();

		if ( $amount <= 0 || ! $user ) {
			return;
		}

		/*
		 * سفارش می‌تواند چند بار به این وضعیت‌ها برسد (مثلاً processing و
		 * بعد completed)؛ بدون این نشان، هر بار دوباره واریز می‌شد.
		 */
		if ( $order->get_meta( '_wcma_topup_done' ) ) {
			return;
		}

		$order->update_meta_data( '_wcma_topup_done', 1 );
		$order->save();

		self::credit(
			$user,
			$amount,
			'topup',
			array(
				'object_id' => $order->get_id(),
				'note'      => sprintf( 'شارژ با سفارش #%s', $order->get_order_number() ),
			)
		);
	}

	/**
	 * آیا این سفارش، سفارش شارژ است؟
	 *
	 * @param WC_Order|int $order سفارش.
	 * @return bool
	 */
	public static function is_topup( $order ) {
		$order = is_numeric( $order ) && function_exists( 'wc_get_order' ) ? wc_get_order( $order ) : $order;

		return $order && (float) $order->get_meta( self::ORDER_META ) > 0;
	}

	/**
	 * افزودن درگاه «پرداخت از کیف پول».
	 *
	 * @param array $gateways درگاه‌ها.
	 * @return array
	 */
	public static function register_gateway( $gateways ) {
		if ( ! self::is_on() || ! WCMA_Settings::is( 'wallet_gateway' ) || ! class_exists( 'WC_Payment_Gateway' ) ) {
			return $gateways;
		}

		require_once WCMA_PATH . 'includes/class-wcma-wallet-gateway.php';

		$gateways[] = 'WCMA_Wallet_Gateway';

		return $gateways;
	}

	/**
	 * پاسخ ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function fail( $message ) {
		return array( 'success' => false, 'message' => $message, 'balance' => 0.0, 'url' => '' );
	}
}
