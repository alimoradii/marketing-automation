<?php
/**
 * مدیریت اشتراک و لغو اشتراک مشتریان.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Subscribers
 */
class WCMA_Subscribers {

	const OPTED_OUT_OPTION = 'wcma_opted_out';

	/**
	 * راه‌اندازی هوک‌ها.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'handle_unsubscribe_request' ) );
		add_action( 'woocommerce_review_order_before_submit', array( __CLASS__, 'render_optin_checkbox' ) );
		add_action( 'woocommerce_checkout_update_order_meta', array( __CLASS__, 'save_optin' ) );
	}

	/**
	 * ساخت لینک لغو اشتراک.
	 *
	 * @param string $email ایمیل.
	 * @return string
	 */
	public static function unsubscribe_url( $email ) {
		if ( ! is_email( $email ) ) {
			return home_url();
		}

		return add_query_arg(
			array(
				'wcma_unsubscribe' => rawurlencode( $email ),
				'wcma_token'       => self::token( $email ),
			),
			home_url( '/' )
		);
	}

	/**
	 * توکن امضای لینک لغو اشتراک.
	 *
	 * @param string $email ایمیل.
	 * @return string
	 */
	public static function token( $email ) {
		return substr( wp_hash( 'wcma_unsub_' . strtolower( $email ) ), 0, 20 );
	}

	/**
	 * پردازش درخواست لغو اشتراک.
	 */
	public static function handle_unsubscribe_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['wcma_unsubscribe'] ) || empty( $_GET['wcma_token'] ) ) {
			return;
		}

		$email = sanitize_email( wp_unslash( $_GET['wcma_unsubscribe'] ) );
		$token = sanitize_text_field( wp_unslash( $_GET['wcma_token'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( ! is_email( $email ) || ! hash_equals( self::token( $email ), $token ) ) {
			wp_die( 'لینک لغو اشتراک معتبر نیست.', 'لغو اشتراک', array( 'response' => 400 ) );
		}

		self::opt_out( $email );

		wp_die(
			'<p style="font-family:tahoma,sans-serif;direction:rtl">اشتراک ایمیل <strong>' . esc_html( $email ) . '</strong> با موفقیت لغو شد. دیگر پیام تبلیغاتی برای شما ارسال نخواهد شد.</p><p style="direction:rtl"><a href="' . esc_url( home_url() ) . '">بازگشت به فروشگاه</a></p>',
			'لغو اشتراک',
			array( 'response' => 200 )
		);
	}

	/**
	 * لغو اشتراک یک ایمیل.
	 *
	 * @param string $email ایمیل.
	 */
	public static function opt_out( $email ) {
		$email = strtolower( sanitize_email( $email ) );
		$list  = get_option( self::OPTED_OUT_OPTION, array() );
		if ( ! is_array( $list ) ) {
			$list = array();
		}

		$list[ md5( $email ) ] = $email;
		update_option( self::OPTED_OUT_OPTION, $list, false );

		$user = get_user_by( 'email', $email );
		if ( $user ) {
			update_user_meta( $user->ID, 'wcma_opted_out', 'yes' );
		}
	}

	/**
	 * بازگرداندن اشتراک.
	 *
	 * @param string $email ایمیل.
	 */
	public static function opt_in( $email ) {
		$email = strtolower( sanitize_email( $email ) );
		$list  = get_option( self::OPTED_OUT_OPTION, array() );
		if ( is_array( $list ) ) {
			unset( $list[ md5( $email ) ] );
			update_option( self::OPTED_OUT_OPTION, $list, false );
		}

		$user = get_user_by( 'email', $email );
		if ( $user ) {
			delete_user_meta( $user->ID, 'wcma_opted_out' );
		}
	}

	/**
	 * بررسی لغو اشتراک بودن.
	 *
	 * @param string $email ایمیل.
	 * @return bool
	 */
	public static function is_opted_out( $email ) {
		if ( ! $email ) {
			return false;
		}

		$list = get_option( self::OPTED_OUT_OPTION, array() );
		return is_array( $list ) && isset( $list[ md5( strtolower( $email ) ) ] );
	}

	/**
	 * نمایش تیک عضویت در خبرنامه در صفحه پرداخت.
	 */
	public static function render_optin_checkbox() {
		if ( ! WCMA_Settings::is( 'unsubscribe_enabled' ) ) {
			return;
		}

		woocommerce_form_field(
			'wcma_marketing_optin',
			array(
				'type'    => 'checkbox',
				'class'   => array( 'form-row wcma-optin' ),
				'label'   => 'مایلم از تخفیف‌ها و پیشنهادهای ویژه باخبر شوم.',
				'default' => 1,
			),
			1
		);
	}

	/**
	 * ذخیره‌ی وضعیت عضویت هنگام ثبت سفارش.
	 *
	 * @param int $order_id شناسه‌ی سفارش.
	 */
	public static function save_optin( $order_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$optin = ! empty( $_POST['wcma_marketing_optin'] );
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$order->update_meta_data( '_wcma_marketing_optin', $optin ? 'yes' : 'no' );
		$order->save();

		$email = $order->get_billing_email();
		if ( $email ) {
			if ( $optin ) {
				self::opt_in( $email );
			} else {
				self::opt_out( $email );
			}
		}
	}
}
