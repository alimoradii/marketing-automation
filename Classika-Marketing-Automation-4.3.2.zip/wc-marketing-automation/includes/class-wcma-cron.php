<?php
/**
 * زمان‌بندی و اجرای وظایف دوره‌ای.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Cron
 */
class WCMA_Cron {

	/**
	 * راه‌اندازی هوک‌ها.
	 */
	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'add_schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval
		add_action( 'wcma_worker_event', array( __CLASS__, 'run_worker' ) );
		add_action( 'wcma_daily_event', array( __CLASS__, 'run_daily' ) );
	}

	/**
	 * افزودن بازه‌ی ۵ دقیقه‌ای.
	 *
	 * @param array $schedules بازه‌ها.
	 * @return array
	 */
	public static function add_schedules( $schedules ) {
		$schedules['wcma_five_minutes'] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => 'هر ۵ دقیقه (اتوماسیون بازاریابی)',
		);

		return $schedules;
	}

	/**
	 * اجرای کارگر اصلی: اسکن و پردازش صف.
	 */
	public static function run_worker() {
		if ( ! WCMA_Settings::is( 'enabled' ) ) {
			return;
		}

		/**
		 * اسکن ورک‌فلوهایی که باید مرتب بررسی شوند.
		 */
		do_action( 'wcma_scheduled_scan' );

		WCMA_Queue::process();

		/**
		 * کارهای پس از پردازش صف.
		 */
		do_action( 'wcma_worker_tick' );

		update_option( 'wcma_last_run', current_time( 'mysql' ), false );
	}

	/**
	 * اجرای وظایف روزانه.
	 */
	public static function run_daily() {
		if ( ! WCMA_Settings::is( 'enabled' ) ) {
			return;
		}

		/**
		 * ورک‌فلوهای روزانه (خرید مجدد، تولد و ...).
		 */
		do_action( 'wcma_daily_scan' );

		WCMA_Logger::purge_old();
		WCMA_Queue::purge_old();
		WCMA_Carts::purge_old();
		WCMA_Coupons::cleanup_expired();
	}

	/**
	 * اجرای دستی کارگر (از پیشخوان).
	 *
	 * @return array
	 */
	public static function run_now() {
		do_action( 'wcma_scheduled_scan' );

		// این یک اقدام صریح مدیر است، پس ساعات استراحت را دور می‌زند؛ در غیر این صورت
		// دکمه در همان بازه‌ای که مدیر بیشتر به آن نیاز دارد بی‌اثر می‌بود.
		$processed = WCMA_Queue::process( true );
		do_action( 'wcma_worker_tick' );

		update_option( 'wcma_last_run', current_time( 'mysql' ), false );

		return array(
			'success' => true,
			'message' => sprintf( 'اجرا انجام شد. %s پیام از صف پردازش شد.', number_format_i18n( $processed ) ),
		);
	}
}
