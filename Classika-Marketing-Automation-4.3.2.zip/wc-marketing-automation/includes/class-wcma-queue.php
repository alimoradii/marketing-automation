<?php
/**
 * صف زمان‌بندی‌شده‌ی ارسال پیام‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Queue
 */
class WCMA_Queue {

	const MAX_ATTEMPTS = 3;

	/**
	 * نام جدول صف.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcma_queue';
	}

	/**
	 * افزودن کار به صف.
	 *
	 * @param array $args پارامترها.
	 * @return int
	 */
	public static function add( array $args ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'workflow'     => '',
				'step'         => '',
				'channel'      => 'email',
				'object_type'  => 'order',
				'object_id'    => 0,
				'user_id'      => 0,
				'recipient'    => '',
				'payload'      => array(),
				'scheduled_at' => current_time( 'mysql' ),
			)
		);

		// جلوگیری از تکرار.
		if ( self::exists( $args['workflow'], $args['step'], $args['object_type'], $args['object_id'] ) ) {
			return 0;
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'workflow'     => $args['workflow'],
				'step'         => $args['step'],
				'channel'      => $args['channel'],
				'object_type'  => $args['object_type'],
				'object_id'    => (int) $args['object_id'],
				'user_id'      => (int) $args['user_id'],
				'recipient'    => $args['recipient'],
				'payload'      => wp_json_encode( $args['payload'] ),
				'status'       => 'pending',
				'scheduled_at' => $args['scheduled_at'],
				'created_at'   => current_time( 'mysql' ),
			)
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * بررسی وجود کار مشابه در صف.
	 *
	 * @param string $workflow    ورک‌فلو.
	 * @param string $step        مرحله.
	 * @param string $object_type نوع شیء.
	 * @param int    $object_id   شناسه.
	 * @return bool
	 */
	public static function exists( $workflow, $step, $object_type, $object_id ) {
		global $wpdb;

		$table = self::table();
		$count = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE workflow = %s AND step = %s AND object_type = %s AND object_id = %d AND status IN ('pending','processing')", // phpcs:ignore WordPress.DB
				$workflow,
				$step,
				$object_type,
				$object_id
			)
		);

		return $count > 0;
	}

	/**
	 * دریافت کارهای آماده‌ی اجرا.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public static function due( $limit = 25, array $only_workflows = array() ) {
		global $wpdb;

		$table = self::table();

		if ( $only_workflows ) {
			$placeholders = implode( ',', array_fill( 0, count( $only_workflows ), '%s' ) );
			$params       = array_merge( array( current_time( 'mysql' ) ), array_values( $only_workflows ), array( (int) $limit ) );

			return $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE status = 'pending' AND scheduled_at <= %s AND workflow IN ({$placeholders}) ORDER BY scheduled_at ASC LIMIT %d", // phpcs:ignore WordPress.DB
					$params
				),
				ARRAY_A
			);
		}

		return $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status = 'pending' AND scheduled_at <= %s ORDER BY scheduled_at ASC LIMIT %d", // phpcs:ignore WordPress.DB
				current_time( 'mysql' ),
				(int) $limit
			),
			ARRAY_A
		);
	}

	/**
	 * به‌روزرسانی وضعیت یک کار.
	 *
	 * @param int    $id     شناسه.
	 * @param string $status وضعیت.
	 */
	public static function set_status( $id, $status ) {
		global $wpdb;
		$wpdb->update( self::table(), array( 'status' => $status ), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * افزایش شمارنده‌ی تلاش.
	 *
	 * @param int $id شناسه.
	 */
	public static function bump_attempt( $id ) {
		global $wpdb;

		$table = self::table();
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "UPDATE {$table} SET attempts = attempts + 1 WHERE id = %d", (int) $id ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * حذف کارهای مربوط به یک شیء (مثلاً وقتی سبد بازیابی شد).
	 *
	 * @param string $object_type نوع شیء.
	 * @param int    $object_id   شناسه.
	 * @param string $workflow    ورک‌فلو (اختیاری).
	 */
	public static function cancel_for_object( $object_type, $object_id, $workflow = '' ) {
		global $wpdb;

		$table = self::table();

		if ( $workflow ) {
			$wpdb->query( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"UPDATE {$table} SET status = 'cancelled' WHERE object_type = %s AND object_id = %d AND workflow = %s AND status = 'pending'", // phpcs:ignore WordPress.DB
					$object_type,
					$object_id,
					$workflow
				)
			);
			return;
		}

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET status = 'cancelled' WHERE object_type = %s AND object_id = %d AND status = 'pending'", // phpcs:ignore WordPress.DB
				$object_type,
				$object_id
			)
		);
	}

	/**
	 * پردازش صف.
	 *
	 * @return int تعداد پردازش‌شده.
	 */
	public static function process( $force = false ) {
		if ( ! WCMA_Settings::is( 'enabled' ) ) {
			return 0;
		}

		$batch = (int) WCMA_Settings::get( 'batch_size', 25 );
		$only  = array();

		if ( ! $force && self::in_quiet_hours() ) {
			/**
			 * ورک‌فلوهایی که از ساعات استراحت معاف‌اند.
			 *
			 * برخی پیام‌ها حساس به زمان‌اند (مثلاً خبر موجود شدن کالا) و نگه داشتن
			 * آن‌ها تا صبح، فایده‌شان را از بین می‌برد.
			 *
			 * @param array $exempt فهرست شناسه‌ی ورک‌فلوها.
			 */
			$only = (array) apply_filters( 'wcma_quiet_hours_exempt_workflows', array() );

			if ( ! $only ) {
				return 0;
			}
		}

		$jobs      = self::due( max( 1, $batch ), $only );
		$processed = 0;

		foreach ( (array) $jobs as $job ) {
			self::set_status( $job['id'], 'processing' );
			self::bump_attempt( $job['id'] );

			$result = self::run_job( $job );

			if ( $result ) {
				self::set_status( $job['id'], 'done' );
			} elseif ( (int) $job['attempts'] + 1 >= self::MAX_ATTEMPTS ) {
				self::set_status( $job['id'], 'failed' );
			} else {
				self::set_status( $job['id'], 'pending' );
			}

			$processed++;
		}

		return $processed;
	}

	/**
	 * اجرای یک کار صف.
	 *
	 * @param array $job رکورد کار.
	 * @return bool
	 */
	protected static function run_job( array $job ) {
		$payload = json_decode( (string) $job['payload'], true );
		if ( ! is_array( $payload ) ) {
			$payload = array();
		}

		/**
		 * اجازه‌ی پردازش سفارشی کارهای صف.
		 *
		 * @param bool|null $handled آیا پردازش شد.
		 * @param array     $job     کار.
		 * @param array     $payload داده‌ها.
		 */
		$handled = apply_filters( 'wcma_process_queue_job', null, $job, $payload );
		if ( null !== $handled ) {
			return (bool) $handled;
		}

		$workflow = WCMA_Plugin::instance()->get_workflow( $job['workflow'] );
		if ( $workflow && method_exists( $workflow, 'run_queued' ) ) {
			return (bool) $workflow->run_queued( $job, $payload );
		}

		return false;
	}

	/**
	 * توضیح خوانا از وضعیت ساعات استراحت، برای نمایش در پیشخوان.
	 *
	 * @return array{active:bool,start:string,end:string,text:string}
	 */
	public static function quiet_hours_status() {
		$enabled = WCMA_Settings::is( 'quiet_hours_enabled' );
		$start   = (string) WCMA_Settings::get( 'quiet_hours_start', '23:00' );
		$end     = (string) WCMA_Settings::get( 'quiet_hours_end', '08:00' );
		$active  = $enabled && self::in_quiet_hours();

		if ( ! $enabled ) {
			$text = 'ساعات استراحت خاموش است؛ پیام‌ها در هر ساعتی ارسال می‌شوند.';
		} elseif ( $active ) {
			$text = sprintf(
				'هم‌اکنون در ساعات استراحت هستیم (%s تا %s). پیام‌ها نگه داشته می‌شوند تا ساعت %s.',
				$start,
				$end,
				$end
			);
		} else {
			$text = sprintf( 'اکنون خارج از ساعات استراحت (%s تا %s) هستیم.', $start, $end );
		}

		return array(
			'active' => $active,
			'start'  => $start,
			'end'    => $end,
			'text'   => $text,
		);
	}

	/**
	 * آیا اکنون در بازه‌ی سکوت شبانه هستیم؟
	 *
	 * @return bool
	 */
	public static function in_quiet_hours() {
		if ( ! WCMA_Settings::is( 'quiet_hours_enabled' ) ) {
			return false;
		}

		$start = WCMA_Settings::get( 'quiet_hours_start', '23:00' );
		$end   = WCMA_Settings::get( 'quiet_hours_end', '08:00' );

		$now_min   = (int) current_time( 'H' ) * 60 + (int) current_time( 'i' );
		$start_min = self::time_to_minutes( $start );
		$end_min   = self::time_to_minutes( $end );

		if ( $start_min === $end_min ) {
			return false;
		}

		if ( $start_min < $end_min ) {
			return $now_min >= $start_min && $now_min < $end_min;
		}

		// بازه‌ای که از نیمه‌شب عبور می‌کند.
		return $now_min >= $start_min || $now_min < $end_min;
	}

	/**
	 * تبدیل HH:MM به دقیقه.
	 *
	 * @param string $time زمان.
	 * @return int
	 */
	protected static function time_to_minutes( $time ) {
		$parts = explode( ':', (string) $time );
		return ( (int) ( $parts[0] ?? 0 ) ) * 60 + ( (int) ( $parts[1] ?? 0 ) );
	}

	/**
	 * ساخت مقدار ستون scheduled_at از یک زمان مطلق (UTC).
	 *
	 * ستون scheduled_at با زمان محلی سایت (مانند current_time('mysql')) مقایسه می‌شود،
	 * بنابراین اختلاف ساعت سایت به زمان UTC اضافه می‌شود.
	 *
	 * @param int $utc_timestamp زمان مطلق.
	 * @param int $delay         تأخیر به ثانیه.
	 * @return string
	 */
	public static function schedule_from_utc( $utc_timestamp, $delay = 0 ) {
		$offset = (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;

		return gmdate( 'Y-m-d H:i:s', (int) $utc_timestamp + (int) $delay + (int) $offset );
	}

	/**
	 * ساخت مقدار ستون scheduled_at از یک رشته‌ی زمان محلی.
	 *
	 * رشته‌ی ورودی از قبل به وقت محلی سایت است، پس نباید دوباره جابه‌جا شود.
	 *
	 * @param string $mysql_local رشته‌ی زمان محلی.
	 * @param int    $delay       تأخیر به ثانیه.
	 * @return string
	 */
	public static function schedule_from_local( $mysql_local, $delay = 0 ) {
		$base = strtotime( (string) $mysql_local );

		if ( ! $base ) {
			$base = strtotime( current_time( 'mysql' ) );
		}

		return gmdate( 'Y-m-d H:i:s', $base + (int) $delay );
	}

	/**
	 * تبدیل مقدار تأخیر به ثانیه.
	 *
	 * @param int    $delay مقدار.
	 * @param string $unit  واحد (minute/hour/day).
	 * @return int
	 */
	public static function delay_to_seconds( $delay, $unit ) {
		$delay = max( 0, (int) $delay );

		switch ( $unit ) {
			case 'minute':
				return $delay * MINUTE_IN_SECONDS;
			case 'hour':
				return $delay * HOUR_IN_SECONDS;
			case 'day':
			default:
				return $delay * DAY_IN_SECONDS;
		}
	}

	/**
	 * آمار صف.
	 *
	 * @return array
	 */
	public static function stats() {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_results( "SELECT status, COUNT(*) AS total FROM {$table} GROUP BY status", ARRAY_A ); // phpcs:ignore WordPress.DB

		$stats = array(
			'pending' => 0,
			'done'    => 0,
			'failed'  => 0,
		);

		foreach ( (array) $rows as $row ) {
			$stats[ $row['status'] ] = (int) $row['total'];
		}

		return $stats;
	}

	/**
	 * حذف کارهای قدیمی تمام‌شده.
	 */
	public static function purge_old() {
		global $wpdb;

		$table = self::table();
		$wpdb->query( "DELETE FROM {$table} WHERE status IN ('done','cancelled','failed') AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)" ); // phpcs:ignore WordPress.DB
	}
}
