<?php
/**
 * سلامت سیستم: بررسی محیط اجرا، جدول‌ها، زمان‌بند و صف.
 *
 * پس از هر به‌روزرسانی وردپرس، ووکامرس یا PHP، این فهرست با یک نگاه
 * می‌گوید چیزی به هم ریخته یا نه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Health
 */
class WCMA_Health {

	const OK   = 'ok';
	const WARN = 'warn';
	const BAD  = 'bad';

	/**
	 * کمینه‌ی نسخه‌هایی که افزونه با آن‌ها آزموده شده است.
	 *
	 * از هدر خود فایل افزونه خوانده می‌شود تا با هر انتشار هماهنگ بماند.
	 *
	 * @param string $key کلید هدر.
	 * @return string
	 */
	public static function header( $key ) {
		static $headers = null;

		if ( null === $headers ) {
			$headers = get_file_data(
				WCMA_FILE,
				array(
					'php' => 'Requires PHP',
					'wp'  => 'Requires at least',
					'wc'  => 'WC requires at least',
					'wct' => 'WC tested up to',
				)
			);

			/*
			 * اگر هدر به هر دلیلی خوانده نشود (فایل جابه‌جا شده، دسترسی خواندن
			 * نیست)، مقدار خالی باعث می‌شد همه‌ی بررسی‌های نسخه بی‌صدا سبز
			 * شوند. مقدار پشتیبان جلوی این سکوت را می‌گیرد.
			 */
			$fallback = array(
				'php' => '7.4',
				'wp'  => '5.8',
				'wc'  => '6.0',
				'wct' => '',
			);

			foreach ( $fallback as $name => $value ) {
				if ( empty( $headers[ $name ] ) ) {
					$headers[ $name ] = $value;
				}
			}
		}

		return isset( $headers[ $key ] ) ? (string) $headers[ $key ] : '';
	}

	/**
	 * همه‌ی بررسی‌ها.
	 *
	 * @return array فهرستی از گروه‌ها، هر گروه با عنوان و ردیف‌ها.
	 */
	public static function groups() {
		return array(
			array(
				'title' => 'محیط اجرا',
				'icon'  => 'admin-tools',
				'rows'  => self::environment(),
			),
			array(
				'title' => 'داده‌های افزونه',
				'icon'  => 'database',
				'rows'  => self::storage(),
			),
			array(
				'title' => 'زمان‌بند و صف',
				'icon'  => 'clock',
				'rows'  => self::scheduler(),
			),
		);
	}

	/**
	 * بررسی‌های محیط: PHP، وردپرس، ووکامرس و افزونه‌های PHP.
	 *
	 * @return array
	 */
	protected static function environment() {
		$rows = array();

		$php_min = self::header( 'php' );
		$rows[]  = self::compare(
			'نسخه‌ی PHP',
			PHP_VERSION,
			$php_min,
			sprintf( 'این افزونه از PHP %s به بالا را می‌خواهد.', $php_min )
		);

		$rows[] = self::compare(
			'نسخه‌ی وردپرس',
			get_bloginfo( 'version' ),
			self::header( 'wp' ),
			sprintf( 'وردپرس را به %s یا بالاتر برسانید.', self::header( 'wp' ) )
		);

		if ( defined( 'WC_VERSION' ) ) {
			$row = self::compare(
				'نسخه‌ی ووکامرس',
				WC_VERSION,
				self::header( 'wc' ),
				sprintf( 'ووکامرس را به %s یا بالاتر برسانید.', self::header( 'wc' ) )
			);

			// بالاتر از نسخه‌ی آزموده‌شده، خطا نیست ولی باید حواسمان باشد.
			$tested = self::header( 'wct' );

			if ( self::OK === $row['status'] && $tested && version_compare( WC_VERSION, $tested, '>' ) ) {
				$row['status'] = self::WARN;
				$row['hint']   = sprintf(
					'این افزونه تا ووکامرس %s آزموده شده است. احتمال مشکل کم است، ولی پس از این به‌روزرسانی یک‌بار «اجرای فوری زمان‌بند» را بزنید.',
					$tested
				);
			}

			$rows[] = $row;
		} else {
			$rows[] = self::row( 'نسخه‌ی ووکامرس', 'نصب نیست', self::BAD, 'بدون ووکامرس هیچ ورک‌فلویی کار نمی‌کند.' );
		}

		// افزونه‌های PHP که افزونه واقعاً به آن‌ها تکیه دارد.
		$needed = array(
			'curl'     => 'برای تماس با پنل پیامک، تلگرام و سرویس‌های هوش مصنوعی',
			'json'     => 'برای خواندن پاسخ سرویس‌ها',
			'mbstring' => 'برای شمردن درست حروف فارسی',
		);

		$missing = array();

		foreach ( $needed as $ext => $why ) {
			if ( ! extension_loaded( $ext ) ) {
				$missing[] = $ext . ' (' . $why . ')';
			}
		}

		$rows[] = $missing
			? self::row( 'افزونه‌های PHP', 'نداشته: ' . implode( '، ', $missing ), self::BAD, 'از میزبان بخواهید این افزونه‌ها را فعال کند.' )
			: self::row( 'افزونه‌های PHP', 'همه موجودند (curl، json، mbstring)', self::OK );

		$rows[] = self::row(
			'پروتکل سایت',
			is_ssl() ? 'HTTPS' : 'HTTP',
			is_ssl() ? self::OK : self::WARN,
			is_ssl() ? '' : 'وب‌هوک ربات و گفتگوی آنلاین روی HTTP کار نمی‌کنند.'
		);

		/*
		 * WP_MEMORY_LIMIT معمولاً هست، ولی همه‌جا نه (اجرای زودهنگام، WP-CLI،
		 * پیکربندی‌های خاص). تکیه‌ی بی‌محافظ روی آن، کل برگه‌ی تنظیمات را
		 * با خطای مرگبار پایین می‌آورد.
		 */
		$limit = defined( 'WP_MEMORY_LIMIT' ) ? (string) WP_MEMORY_LIMIT : (string) ini_get( 'memory_limit' );
		$memory = self::bytes( $limit );
		$low    = $memory > 0 && $memory < ( 128 * 1024 * 1024 );

		$rows[] = self::row(
			'حافظه‌ی وردپرس',
			'' !== $limit ? WCMA_Date::digits( $limit ) : 'نامشخص',
			$low ? self::WARN : self::OK,
			$low ? 'کمتر از ۱۲۸ مگابایت برای گزارش‌های بزرگ کم می‌آید.' : ''
		);

		return $rows;
	}

	/**
	 * بررسی جدول‌ها و پشتیبان.
	 *
	 * @return array
	 */
	protected static function storage() {
		$rows    = array();
		$missing = WCMA_Install::missing_tables();
		$total   = count( WCMA_Install::tables() );

		$rows[] = $missing
			? self::row(
				'جدول‌های افزونه',
				sprintf( '%s جدول از %s ساخته نشده است', WCMA_Date::number( count( $missing ) ), WCMA_Date::number( $total ) ),
				self::BAD,
				'دکمه‌ی «ترمیم جدول‌ها» در همین برگه را بزنید.'
			)
			: self::row( 'جدول‌های افزونه', sprintf( 'هر %s جدول سالم است', WCMA_Date::number( $total ) ), self::OK );

		$db_version = get_option( 'wcma_db_version' );

		$rows[] = self::row(
			'نسخه‌ی ساختار دیتابیس',
			WCMA_Date::digits( (string) ( $db_version ? $db_version : '—' ) ),
			$db_version === WCMA_Install::DB_VERSION ? self::OK : self::WARN,
			$db_version === WCMA_Install::DB_VERSION ? '' : 'ساختار با نسخه‌ی افزونه یکی نیست؛ صفحه را دوباره بارگذاری کنید تا خودکار اصلاح شود.'
		);

		$backup = WCMA_Install::backup_info();

		$rows[] = self::row(
			'پشتیبان تنظیمات',
			! empty( $backup['time'] ) ? 'آخرین ذخیره: ' . WCMA_Date::mysql( $backup['time'] ) : 'هنوز گرفته نشده',
			! empty( $backup['time'] ) ? self::OK : self::WARN,
			! empty( $backup['time'] ) ? '' : 'با اولین ذخیره‌ی تنظیمات خودکار ساخته می‌شود.'
		);

		return $rows;
	}

	/**
	 * بررسی زمان‌بند و صف ارسال.
	 *
	 * @return array
	 */
	protected static function scheduler() {
		global $wpdb;

		$rows = array();

		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			$rows[] = self::row(
				'زمان‌بند وردپرس',
				'با DISABLE_WP_CRON خاموش شده است',
				self::WARN,
				'اگر کرون واقعی سرور تنظیم شده، مشکلی نیست؛ وگرنه هیچ پیامی خودکار نمی‌رود.'
			);
		} else {
			$rows[] = self::row( 'زمان‌بند وردپرس', 'روشن است', self::OK );
		}

		$next = wp_next_scheduled( 'wcma_worker_event' );

		$rows[] = self::row(
			'اجرای بعدی کارگر',
			$next ? WCMA_Date::mysql( gmdate( 'Y-m-d H:i:s', $next + ( (float) get_option( 'gmt_offset' ) * 3600 ) ) ) : 'زمان‌بندی نشده',
			$next ? self::OK : self::BAD,
			$next ? '' : 'افزونه را یک‌بار غیرفعال و دوباره فعال کنید تا زمان‌بندی ساخته شود.'
		);

		$last = get_option( 'wcma_last_run' );

		$rows[] = self::row(
			'آخرین اجرا',
			$last ? WCMA_Date::mysql( $last ) : 'تا حالا اجرا نشده',
			self::last_run_status( $last ),
			self::last_run_status( $last ) === self::OK ? '' : 'بیش از یک ساعت است که زمان‌بند اجرا نشده؛ «اجرای فوری زمان‌بند» را بزنید.'
		);

		if ( WCMA_Install::table_exists( 'wcma_queue' ) ) {
			$queue = $wpdb->prefix . 'wcma_queue';

			$pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$queue} WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB
			$failed  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$queue} WHERE status = 'failed'" ); // phpcs:ignore WordPress.DB

			$rows[] = self::row(
				'صف ارسال',
				sprintf( '%s در انتظار، %s ناموفق', WCMA_Date::number( $pending ), WCMA_Date::number( $failed ) ),
				$failed > 0 ? self::WARN : self::OK,
				$failed > 0 ? 'دلیل شکست‌ها را در برگه‌ی گزارش‌ها ببینید.' : ''
			);
		}

		return $rows;
	}

	/**
	 * وضعیت آخرین اجرا.
	 *
	 * @param string $last زمان.
	 * @return string
	 */
	protected static function last_run_status( $last ) {
		if ( ! $last ) {
			return self::WARN;
		}

		$stamp = strtotime( $last );
		$now   = strtotime( current_time( 'mysql' ) );

		// کارگر هر ۵ دقیقه است؛ یک ساعت سکوت یعنی کرون کار نمی‌کند.
		return ( $now - $stamp ) > 3600 ? self::WARN : self::OK;
	}

	/**
	 * مقایسه‌ی نسخه.
	 *
	 * @param string $label   عنوان.
	 * @param string $current نسخه‌ی فعلی.
	 * @param string $min     کمینه.
	 * @param string $hint    راهنما.
	 * @return array
	 */
	protected static function compare( $label, $current, $min, $hint ) {
		$current = trim( (string) $current );

		// مقداری که شکل نسخه ندارد یعنی چیزی سرِ جایش نیست، نه اینکه سالم است.
		if ( ! preg_match( '/^\d+(\.\d+)*/', $current ) ) {
			return self::row( $label, 'خوانده نشد', self::WARN, 'نسخه قابل تشخیص نبود؛ اگر بقیه‌ی موارد سالم‌اند نگران نباشید.' );
		}

		$ok = ! $min || version_compare( $current, $min, '>=' );

		return self::row( $label, WCMA_Date::digits( $current ), $ok ? self::OK : self::BAD, $ok ? '' : $hint );
	}

	/**
	 * یک ردیف بررسی.
	 *
	 * @param string $label  عنوان.
	 * @param string $value  مقدار.
	 * @param string $status وضعیت.
	 * @param string $hint   راهنما.
	 * @return array
	 */
	protected static function row( $label, $value, $status = self::OK, $hint = '' ) {
		return array(
			'label'  => $label,
			'value'  => $value,
			'status' => $status,
			'hint'   => $hint,
		);
	}

	/**
	 * تبدیل رشته‌ی حافظه به بایت.
	 *
	 * @param string $value مقدار مثل 128M.
	 * @return int
	 */
	protected static function bytes( $value ) {
		$value = trim( (string) $value );

		if ( ! preg_match( '/^(\d+)\s*([KMG])?/i', $value, $m ) ) {
			return 0;
		}

		$size = (int) $m[1];
		$unit = isset( $m[2] ) ? strtoupper( $m[2] ) : '';

		// ضریب‌ها دستی نوشته شده‌اند تا به ثابت‌های وردپرس گره نخورند.
		switch ( $unit ) {
			case 'G':
				return $size * 1024 * 1024 * 1024;
			case 'M':
				return $size * 1024 * 1024;
			case 'K':
				return $size * 1024;
		}

		return $size;
	}

	/**
	 * خلاصه‌ی وضعیت کلی.
	 *
	 * @return array{status:string,bad:int,warn:int}
	 */
	public static function summary() {
		$bad  = 0;
		$warn = 0;

		foreach ( self::groups() as $group ) {
			foreach ( $group['rows'] as $row ) {
				if ( self::BAD === $row['status'] ) {
					$bad++;
				} elseif ( self::WARN === $row['status'] ) {
					$warn++;
				}
			}
		}

		$status = self::OK;

		if ( $bad ) {
			$status = self::BAD;
		} elseif ( $warn ) {
			$status = self::WARN;
		}

		return array( 'status' => $status, 'bad' => $bad, 'warn' => $warn );
	}
}
