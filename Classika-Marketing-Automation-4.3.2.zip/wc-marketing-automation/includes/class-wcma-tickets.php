<?php
/**
 * تیکت پشتیبانی.
 *
 * مشتری از پنل کاربری تیکت باز می‌کند و پشتیبانی از پیشخوان پاسخ می‌دهد.
 * پیوستِ تیکت‌ها در همان پوشه‌ی امنِ گفتگو می‌نشیند، نه در رسانه‌ی وردپرس.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Tickets
 */
class WCMA_Tickets {

	/**
	 * سقف تیکت باز برای هر کاربر.
	 *
	 * بدون سقف، یک نفر می‌تواند صندوق پشتیبانی را پر کند.
	 */
	const MAX_OPEN = 10;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_ticket_replied', array( __CLASS__, 'notify' ), 10, 2 );
	}

	/**
	 * آیا تیکتینگ روشن است؟
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'tickets_enabled' ) && WCMA_Install::table_exists( 'wcma_tickets' );
	}

	/**
	 * نام جدول.
	 *
	 * @param string $which tickets یا replies.
	 * @return string
	 */
	public static function table( $which = 'tickets' ) {
		global $wpdb;

		return $wpdb->prefix . ( 'replies' === $which ? 'wcma_ticket_replies' : 'wcma_tickets' );
	}

	/**
	 * بخش‌های پشتیبانی.
	 *
	 * @return array
	 */
	public static function departments() {
		$raw  = (string) WCMA_Settings::get( 'ticket_departments', '' );
		$rows = preg_split( '/[\r\n،,]+/u', $raw );
		$out  = array();

		foreach ( (array) $rows as $row ) {
			$row = trim( (string) $row );

			if ( '' === $row ) {
				continue;
			}

			/*
			 * کلید باید از همان صافیِ sanitize_key رد شود که هنگام ثبت تیکت
			 * روی مقدارِ فرم اجرا می‌شود. sanitize_title روی نام فارسی چیزی
			 * مثل «%d9%81%d8%b1…» می‌دهد و sanitize_key درصدها را می‌اندازد؛
			 * بدون این هم‌سان‌سازی، هیچ بخشی پیدا نمی‌شد و همه‌ی تیکت‌ها
			 * بی‌صدا در بخشِ اول می‌نشستند.
			 */
			$key = sanitize_key( sanitize_title( $row ) );

			// نامی که چیزی جز نشانه ندارد، یا با نامِ پیشین یکی شده است.
			if ( '' === $key || isset( $out[ $key ] ) ) {
				$key = 'd' . substr( md5( $row ), 0, 10 );
			}

			$out[ $key ] = $row;
		}

		return $out ? $out : array(
			'support' => 'پشتیبانی فنی',
			'sales'   => 'فروش',
			'finance' => 'مالی',
		);
	}

	/**
	 * درجه‌های اهمیت.
	 *
	 * @return array
	 */
	public static function priorities() {
		return array(
			'low'    => 'کم',
			'normal' => 'عادی',
			'high'   => 'زیاد',
		);
	}

	/**
	 * وضعیت‌ها.
	 *
	 * @return array
	 */
	public static function statuses() {
		return array(
			'open'     => 'در انتظار پاسخ',
			'answered' => 'پاسخ داده شده',
			'closed'   => 'بسته',
		);
	}

	/**
	 * ساخت تیکت تازه.
	 *
	 * @param int   $user_id کاربر.
	 * @param array $data    داده.
	 * @return array{success:bool,message:string,id:int}
	 */
	public static function open( $user_id, array $data ) {
		global $wpdb;

		$user_id = (int) $user_id;
		$subject = trim( sanitize_text_field( (string) ( $data['subject'] ?? '' ) ) );
		$body    = trim( wp_kses_post( (string) ( $data['body'] ?? '' ) ) );

		if ( ! self::is_on() ) {
			return self::fail( 'بخش تیکت فعال نیست.' );
		}

		if ( ! $user_id ) {
			return self::fail( 'برای ثبت تیکت باید وارد حساب خود شوید.' );
		}

		if ( '' === $subject || '' === $body ) {
			return self::fail( 'موضوع و متن تیکت را کامل کنید.' );
		}

		if ( self::open_count( $user_id ) >= self::MAX_OPEN ) {
			return self::fail( 'شما چند تیکت باز دارید. لطفاً در همان‌ها پیگیری کنید.' );
		}

		$departments = self::departments();
		$department  = sanitize_key( (string) ( $data['department'] ?? '' ) );
		$department  = isset( $departments[ $department ] ) ? $department : (string) key( $departments );

		$priorities = self::priorities();
		$priority   = sanitize_key( (string) ( $data['priority'] ?? '' ) );
		$priority   = isset( $priorities[ $priority ] ) ? $priority : 'normal';

		$now = current_time( 'mysql' );

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'user_id'       => $user_id,
				'contact_id'    => self::contact_of( $user_id ),
				'subject'       => mb_substr( $subject, 0, 190 ),
				'department'    => $department,
				'priority'      => $priority,
				'status'        => 'open',
				'order_id'      => (int) ( $data['order_id'] ?? 0 ),
				'replies'       => 0,
				'unread_staff'  => 1,
				'unread_user'   => 0,
				'last_reply_at' => $now,
				'created_at'    => $now,
			)
		);

		$ticket_id = (int) $wpdb->insert_id;

		if ( ! $ticket_id ) {
			return self::fail( 'تیکت ثبت نشد.' );
		}

		self::reply(
			$ticket_id,
			array(
				'body'   => $body,
				'author' => 'user',
				'file'   => $data['file'] ?? array(),
			),
			$user_id
		);

		return array( 'success' => true, 'message' => 'تیکت شما ثبت شد.', 'id' => $ticket_id );
	}

	/**
	 * افزودن پاسخ به یک تیکت.
	 *
	 * @param int   $ticket_id تیکت.
	 * @param array $data      داده.
	 * @param int   $actor_id  نویسنده.
	 * @return array{success:bool,message:string,id:int}
	 */
	public static function reply( $ticket_id, array $data, $actor_id = 0 ) {
		global $wpdb;

		$ticket_id = (int) $ticket_id;
		$ticket    = self::get( $ticket_id );
		$body      = trim( wp_kses_post( (string) ( $data['body'] ?? '' ) ) );
		$file      = is_array( $data['file'] ?? null ) ? $data['file'] : array();
		$staff     = 'staff' === ( $data['author'] ?? 'user' );

		if ( ! $ticket ) {
			return self::fail( 'تیکت پیدا نشد.' );
		}

		if ( '' === $body && empty( $file['url'] ) ) {
			return self::fail( 'متن پاسخ خالی است.' );
		}

		if ( 'closed' === $ticket['status'] && ! $staff ) {
			return self::fail( 'این تیکت بسته شده است. برای موضوع تازه، تیکت جدید بزنید.' );
		}

		$now = current_time( 'mysql' );

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table( 'replies' ),
			array(
				'ticket_id'   => $ticket_id,
				'author'      => $staff ? 'staff' : 'user',
				'author_id'   => (int) $actor_id,
				'author_name' => mb_substr( self::author_name( $staff, $actor_id, $data ), 0, 190 ),
				'body'        => $body,
				'att_url'     => (string) ( $file['url'] ?? '' ),
				'att_name'    => (string) ( $file['name'] ?? '' ),
				'att_kind'    => (string) ( $file['kind'] ?? '' ),
				'att_mime'    => (string) ( $file['mime'] ?? '' ),
				'att_size'    => (int) ( $file['size'] ?? 0 ),
				'created_at'  => $now,
			)
		);

		$reply_id = (int) $wpdb->insert_id;

		$wpdb->update( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'replies'       => (int) $ticket['replies'] + 1,
				'status'        => $staff ? 'answered' : 'open',
				// هر طرف که نوشت، طرف مقابل «نخوانده» می‌شود.
				'unread_staff'  => $staff ? 0 : 1,
				'unread_user'   => $staff ? 1 : 0,
				'last_reply_at' => $now,
			),
			array( 'id' => $ticket_id )
		);

		/**
		 * پس از هر پاسخ در تیکت.
		 *
		 * @param int  $ticket_id تیکت.
		 * @param bool $staff     پاسخ از سوی پشتیبانی بود؟
		 */
		do_action( 'wcma_ticket_replied', $ticket_id, $staff );

		return array( 'success' => true, 'message' => 'پاسخ ثبت شد.', 'id' => $reply_id );
	}

	/**
	 * بستن یا باز کردن تیکت.
	 *
	 * @param int    $ticket_id تیکت.
	 * @param string $status    وضعیت.
	 * @return bool
	 */
	public static function set_status( $ticket_id, $status ) {
		global $wpdb;

		$status = isset( self::statuses()[ $status ] ) ? $status : 'open';

		$done = $wpdb->update( // phpcs:ignore WordPress.DB
			self::table(),
			array( 'status' => $status ),
			array( 'id' => (int) $ticket_id ),
			array( '%s' ),
			array( '%d' )
		);

		return false !== $done;
	}

	/**
	 * یک تیکت.
	 *
	 * @param int $ticket_id تیکت.
	 * @return array|null
	 */
	public static function get( $ticket_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_tickets' ) ) {
			return null;
		}

		$table = self::table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $ticket_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * پیام‌های یک تیکت.
	 *
	 * @param int $ticket_id تیکت.
	 * @return array
	 */
	public static function replies( $ticket_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_ticket_replies' ) ) {
			return array();
		}

		$table = self::table( 'replies' );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_id = %d ORDER BY id ASC", (int) $ticket_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $rows ? $rows : array();
	}

	/**
	 * فهرست تیکت‌ها.
	 *
	 * @param array $args فیلترها.
	 * @return array{items:array,total:int,pages:int,page:int}
	 */
	public static function query( array $args = array() ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_tickets' ) ) {
			return array( 'items' => array(), 'total' => 0, 'pages' => 0, 'page' => 1 );
		}

		$args = wp_parse_args(
			$args,
			array(
				'user_id'    => 0,
				'status'     => '',
				'department' => '',
				'search'     => '',
				'per_page'   => 20,
				'page'       => 1,
			)
		);

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $args['user_id'] ) {
			$where[]  = 'user_id = %d';
			$params[] = (int) $args['user_id'];
		}

		if ( $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = sanitize_key( $args['status'] );
		}

		if ( $args['department'] ) {
			$where[]  = 'department = %s';
			$params[] = sanitize_key( $args['department'] );
		}

		if ( $args['search'] ) {
			$where[]  = 'subject LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}

		$clause   = implode( ' AND ', $where );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );

		$total = $params
			? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$clause}", $params ) ) // phpcs:ignore WordPress.DB
			: (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB

		$params[] = $per_page;
		$params[] = ( $page - 1 ) * $per_page;

		$items = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE {$clause} ORDER BY last_reply_at DESC, id DESC LIMIT %d OFFSET %d", $params ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return array(
			'items' => $items ? $items : array(),
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
			'page'  => $page,
		);
	}

	/**
	 * شمار تیکت‌های بازِ یک کاربر.
	 *
	 * @param int $user_id کاربر.
	 * @return int
	 */
	public static function open_count( $user_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_tickets' ) ) {
			return 0;
		}

		$table = self::table();

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND status <> 'closed'", (int) $user_id ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * شمار تیکت‌های نخوانده‌ی پشتیبانی.
	 *
	 * @return int
	 */
	public static function waiting() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_tickets' ) ) {
			return 0;
		}

		$table = self::table();

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE unread_staff = 1 AND status <> 'closed'" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * خوانده‌شدن تیکت توسط یک طرف.
	 *
	 * @param int  $ticket_id تیکت.
	 * @param bool $staff     پشتیبانی؟
	 */
	public static function mark_read( $ticket_id, $staff = true ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB
			self::table(),
			$staff ? array( 'unread_staff' => 0 ) : array( 'unread_user' => 0 ),
			array( 'id' => (int) $ticket_id ),
			array( '%d' ),
			array( '%d' )
		);
	}

	/**
	 * خبر دادن پاسخ تازه.
	 *
	 * @param int  $ticket_id تیکت.
	 * @param bool $staff     پاسخ از پشتیبانی؟
	 */
	public static function notify( $ticket_id, $staff ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket ) {
			return;
		}

		// پاسخ مشتری برای پشتیبانی، و پاسخ پشتیبانی برای مشتری خبر می‌شود.
		if ( $staff ) {
			if ( ! WCMA_Settings::is( 'ticket_notify_user' ) ) {
				return;
			}

			$phone = WCMA_Accounts::phone( (int) $ticket['user_id'] );

			if ( ! $phone ) {
				return;
			}

			$text = sprintf(
				"پاسخ تازه‌ای برای تیکت شما ثبت شد.\nموضوع: %s\n%s",
				$ticket['subject'],
				WCMA_Panel::url( 'tickets', array( 'ticket' => (int) $ticket_id ) )
			);

			WCMA_SMS_Gateways::send( $phone, $text );

			return;
		}

		if ( ! WCMA_Settings::is( 'ticket_notify_staff' ) ) {
			return;
		}

		$to = trim( (string) WCMA_Settings::get( 'ticket_staff_email', '' ) );
		$to = $to ? $to : (string) get_option( 'admin_email' );

		if ( is_email( $to ) ) {
			wp_mail(
				$to,
				sprintf( 'تیکت تازه: %s', $ticket['subject'] ),
				sprintf(
					"مشتری تیکتی ثبت کرد.\n\nموضوع: %s\nبخش: %s\n\n%s",
					$ticket['subject'],
					self::departments()[ $ticket['department'] ] ?? $ticket['department'],
					admin_url( 'admin.php?page=wcma&tab=tickets&ticket=' . (int) $ticket_id )
				)
			);
		}
	}

	/**
	 * پرونده‌ی مشتریِ یک کاربر.
	 *
	 * @param int $user_id کاربر.
	 * @return int
	 */
	protected static function contact_of( $user_id ) {
		if ( ! class_exists( 'WCMA_CRM' ) ) {
			return 0;
		}

		$user = get_userdata( (int) $user_id );

		if ( ! $user ) {
			return 0;
		}

		$contact = WCMA_CRM::find( (string) $user->user_email, WCMA_Accounts::phone( $user_id ) );

		return $contact ? (int) $contact['id'] : 0;
	}

	/**
	 * نام نویسنده‌ی پاسخ.
	 *
	 * @param bool  $staff    پشتیبانی؟
	 * @param int   $actor_id شناسه.
	 * @param array $data     داده.
	 * @return string
	 */
	protected static function author_name( $staff, $actor_id, array $data ) {
		$given = trim( (string) ( $data['author_name'] ?? '' ) );

		if ( '' !== $given ) {
			return $given;
		}

		if ( $staff ) {
			$user = $actor_id ? get_userdata( (int) $actor_id ) : null;

			return $user ? (string) $user->display_name : 'پشتیبانی';
		}

		return WCMA_Accounts::display_name( (int) $actor_id );
	}

	/**
	 * پاسخ ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function fail( $message ) {
		return array( 'success' => false, 'message' => $message, 'id' => 0 );
	}
}
