<?php
/**
 * پنل کاربری مشتری.
 *
 * روی مسیر دلخواهی از همان دامنه سرو می‌شود — نه برگه‌ی وردپرس و نه قالب
 * فروشگاه — تا هرچه در آن هست مال خود افزونه باشد و با هر پوسته‌ای یکسان
 * دیده شود.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Panel
 */
class WCMA_Panel {

	/**
	 * متغیر پرس‌وجوی مسیر.
	 */
	const VAR = 'wcma_panel';

	/**
	 * مسیر دیده‌شده، برای تازه‌سازی قاعده‌ها.
	 */
	const SLUG_SEEN = 'wcma_panel_slug_seen';

	/**
	 * صفحه‌های پنل.
	 *
	 * @return array
	 */
	public static function pages() {
		$pages = array(
			'home'    => array( 'title' => 'خانه', 'icon' => 'home' ),
			'orders'  => array( 'title' => 'سفارش‌ها', 'icon' => 'bag' ),
			'wallet'  => array( 'title' => 'کیف پول', 'icon' => 'wallet' ),
			'tickets' => array( 'title' => 'تیکت‌ها', 'icon' => 'ticket' ),
			'profile' => array( 'title' => 'اطلاعات من', 'icon' => 'user' ),
		);

		if ( ! WCMA_Wallet::is_on() ) {
			unset( $pages['wallet'] );
		}

		if ( ! WCMA_Tickets::is_on() ) {
			unset( $pages['tickets'] );
		}

		return $pages;
	}

	/**
	 * دموهای ظاهری.
	 *
	 * @return array
	 */
	public static function demos() {
		return array(
			'sidebar' => 'دموی یک — ستون کناری (کلاسیک)',
			'top'     => 'دموی دو — نوار بالا (مینیمال)',
			'cards'   => 'دموی سه — کاشی‌های رنگی (مدرن)',
		);
	}

	/**
	 * دموی انتخاب‌شده.
	 *
	 * @return string
	 */
	public static function demo() {
		$demo = (string) WCMA_Settings::get( 'panel_demo', 'sidebar' );

		return isset( self::demos()[ $demo ] ) ? $demo : 'sidebar';
	}

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_rules' ) );
		add_filter( 'query_vars', array( __CLASS__, 'add_var' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ) );
		add_action( 'admin_post_wcma_panel', array( __CLASS__, 'handle_post' ) );
		add_action( 'admin_post_nopriv_wcma_panel', array( __CLASS__, 'handle_post' ) );
	}

	/**
	 * آیا پنل روشن است؟
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'panel_enabled' );
	}

	/**
	 * مسیر پنل.
	 *
	 * @return string
	 */
	public static function slug() {
		$slug = (string) WCMA_Settings::get( 'panel_slug', 'my-panel' );

		if ( false !== stripos( $slug, '://' ) ) {
			$path = wp_parse_url( $slug, PHP_URL_PATH );
			$slug = is_string( $path ) ? $path : '';
		}

		$slug = trim( (string) $slug, "/ \t\n\r" );
		$slug = (string) preg_replace( '#[^A-Za-z0-9/_-]#', '', $slug );

		return $slug ? $slug : 'my-panel';
	}

	/**
	 * نشانی یک صفحه‌ی پنل.
	 *
	 * @param string $page  صفحه.
	 * @param array  $extra پارامترهای اضافه.
	 * @return string
	 */
	public static function url( $page = '', array $extra = array() ) {
		$url = home_url( '/' . self::slug() . '/' );

		if ( $page && 'home' !== $page ) {
			$url .= $page . '/';
		}

		return $extra ? add_query_arg( $extra, $url ) : $url;
	}

	/**
	 * ثبت قاعده‌های بازنویسی.
	 */
	public static function add_rules() {
		if ( ! self::is_on() ) {
			self::maybe_flush( '' );

			return;
		}

		$slug   = self::slug();
		$quoted = preg_quote( $slug, '#' );

		add_rewrite_rule( '^' . $quoted . '/?$', 'index.php?' . self::VAR . '=home', 'top' );
		add_rewrite_rule( '^' . $quoted . '/([a-z-]+)/?$', 'index.php?' . self::VAR . '=$matches[1]', 'top' );

		self::maybe_flush( $slug );
	}

	/**
	 * تازه‌سازی قاعده‌ها، فقط وقتی مسیر عوض شده.
	 *
	 * @param string $slug مسیر.
	 */
	protected static function maybe_flush( $slug ) {
		if ( get_option( self::SLUG_SEEN ) === $slug ) {
			return;
		}

		update_option( self::SLUG_SEEN, $slug, false );
		flush_rewrite_rules( false );
	}

	/**
	 * افزودن متغیر پرس‌وجو.
	 *
	 * @param array $vars متغیرها.
	 * @return array
	 */
	public static function add_var( $vars ) {
		$vars[] = self::VAR;

		return $vars;
	}

	/**
	 * سرو کردن پنل.
	 */
	public static function maybe_serve() {
		$page = get_query_var( self::VAR );

		if ( ! $page || ! self::is_on() ) {
			return;
		}

		$pages = self::pages();
		$page  = isset( $pages[ $page ] ) ? $page : 'home';

		nocache_headers();

		// بدون ورود، فقط صفحه‌ی ورود دیده می‌شود.
		if ( ! is_user_logged_in() ) {
			self::render( 'login', array() );
			exit;
		}

		self::render( $page, $pages );
		exit;
	}

	/**
	 * چاپ صفحه.
	 *
	 * @param string $page  صفحه.
	 * @param array  $pages فهرست صفحه‌ها.
	 */
	protected static function render( $page, array $pages ) {
		$user    = wp_get_current_user();
		$demo    = self::demo();
		$notice  = self::take_notice();
		$view    = WCMA_PATH . 'includes/panel/page-' . $page . '.php';
		$shell   = WCMA_PATH . 'includes/panel/shell.php';
		$context = compact( 'page', 'pages', 'user', 'demo', 'notice', 'view' );

		if ( ! file_exists( $view ) ) {
			$context['view'] = WCMA_PATH . 'includes/panel/page-home.php';
		}

		include $shell;
	}

	/**
	 * نقش‌هایی که می‌شود به کاربر تازه داد.
	 *
	 * @return array
	 */
	public static function roles() {
		$out = array( '' => 'مشتری (پیش‌فرض ووکامرس)' );

		if ( ! function_exists( 'wp_roles' ) ) {
			return $out;
		}

		foreach ( wp_roles()->get_names() as $key => $label ) {
			/*
			 * نقش‌های مدیریتی عمداً در این فهرست نمی‌آیند: کسی که با یک کد
			 * پیامکی ثبت‌نام می‌کند نباید بتواند به پیشخوان برسد.
			 */
			if ( in_array( $key, array( 'administrator', 'editor', 'shop_manager' ), true ) ) {
				continue;
			}

			$out[ $key ] = function_exists( 'translate_user_role' ) ? translate_user_role( $label ) : $label;
		}

		return $out;
	}

	/**
	 * آیکون‌های خطیِ پنل.
	 *
	 * از دشیکون استفاده نمی‌شود: آن فایل فقط در پیشخوان بار می‌شود و کشیدنش
	 * به جلوی سایت، برای پنج آیکون، صفحه را بی‌دلیل سنگین می‌کند.
	 *
	 * @param string $name نام آیکون.
	 */
	public static function icon( $name ) {
		$paths = array(
			'home'   => 'M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
			'bag'    => 'M6 7h12l1 13H5zM9 7V5a3 3 0 0 1 6 0v2',
			'wallet' => 'M3 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM16 12h3M3 9h16',
			'ticket' => 'M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4z',
			'user'   => 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
		);

		$d = $paths[ $name ] ?? $paths['home'];

		printf(
			'<svg class="wp-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="%s"/></svg>',
			esc_attr( $d )
		);
	}

	/**
	 * برداشتن پیام یک‌بارمصرف.
	 *
	 * @return array{type:string,text:string}|null
	 */
	public static function take_notice() {
		$key    = self::notice_key();
		$notice = get_transient( $key );

		if ( $notice ) {
			delete_transient( $key );
		}

		return is_array( $notice ) ? $notice : null;
	}

	/**
	 * گذاشتن پیام برای بارگذاری بعدی.
	 *
	 * @param string $type success یا error.
	 * @param string $text متن.
	 */
	public static function notice( $type, $text ) {
		set_transient( self::notice_key(), array( 'type' => $type, 'text' => $text ), 60 );
	}

	/**
	 * کلید پیام، جدا برای هر کاربر.
	 *
	 * @return string
	 */
	protected static function notice_key() {
		return 'wcma_panel_note_' . get_current_user_id();
	}

	/**
	 * گرفتن فرم‌های پنل.
	 *
	 * فرم‌ها به admin-post می‌روند و به همان صفحه برمی‌گردند؛ این‌طور دوباره
	 * فرستادن فرم با تازه‌سازی صفحه رخ نمی‌دهد.
	 */
	public static function handle_post() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( self::url() );
			exit;
		}

		check_admin_referer( 'wcma_panel' );

		$user_id = get_current_user_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$what = isset( $_POST['wcma_do'] ) ? sanitize_key( wp_unslash( $_POST['wcma_do'] ) ) : '';
		$back = self::url();

		switch ( $what ) {
			case 'profile':
				$back = self::url( 'profile' );
				self::save_profile( $user_id );
				break;

			case 'topup':
				$back = self::url( 'wallet' );
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$amount = isset( $_POST['amount'] ) ? WCMA_Date::to_latin_digits( sanitize_text_field( wp_unslash( $_POST['amount'] ) ) ) : '';
				$start  = WCMA_Wallet::start_topup( $user_id, (float) preg_replace( '/[^0-9.]/', '', $amount ) );

				if ( ! empty( $start['success'] ) ) {
					wp_safe_redirect( $start['url'] );
					exit;
				}

				self::notice( 'error', (string) $start['message'] );
				break;

			case 'ticket_open':
				$back = self::url( 'tickets' );
				self::open_ticket( $user_id );
				break;

			case 'ticket_reply':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$ticket_id = isset( $_POST['ticket'] ) ? (int) $_POST['ticket'] : 0;
				$back      = self::url( 'tickets', array( 'ticket' => $ticket_id ) );
				self::reply_ticket( $user_id, $ticket_id );
				break;
		}

		wp_safe_redirect( $back );
		exit;
	}

	/**
	 * ذخیره‌ی اطلاعات کاربر.
	 *
	 * @param int $user_id کاربر.
	 */
	protected static function save_profile( $user_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$first = trim( sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ) );
		$last  = trim( sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ) );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $first ) {
			self::notice( 'error', 'نام نمی‌تواند خالی باشد.' );

			return;
		}

		if ( $email && ! is_email( $email ) ) {
			self::notice( 'error', 'ایمیل معتبر نیست.' );

			return;
		}

		// ایمیل تکراری، ورود آن کاربر را خراب می‌کند.
		if ( $email ) {
			$owner = email_exists( $email );

			if ( $owner && (int) $owner !== (int) $user_id ) {
				self::notice( 'error', 'این ایمیل برای حساب دیگری ثبت شده است.' );

				return;
			}
		}

		$data = array(
			'ID'           => $user_id,
			'first_name'   => $first,
			'last_name'    => $last,
			'display_name' => trim( $first . ' ' . $last ),
		);

		if ( $email ) {
			$data['user_email'] = $email;
		}

		wp_update_user( $data );
		update_user_meta( $user_id, 'billing_first_name', $first );
		update_user_meta( $user_id, 'billing_last_name', $last );

		if ( class_exists( 'WCMA_CRM' ) ) {
			WCMA_CRM::upsert(
				array(
					'user_id'    => $user_id,
					'phone'      => WCMA_Accounts::phone( $user_id ),
					'email'      => $email,
					'first_name' => $first,
					'last_name'  => $last,
				)
			);
		}

		self::notice( 'success', 'اطلاعات شما ذخیره شد.' );
	}

	/**
	 * ثبت تیکت تازه از پنل.
	 *
	 * @param int $user_id کاربر.
	 */
	protected static function open_ticket( $user_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$data = array(
			'subject'    => wp_unslash( $_POST['subject'] ?? '' ),
			'body'       => wp_unslash( $_POST['body'] ?? '' ),
			'department' => wp_unslash( $_POST['department'] ?? '' ),
			'priority'   => wp_unslash( $_POST['priority'] ?? '' ),
			'order_id'   => (int) ( $_POST['order_id'] ?? 0 ),
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$data['file'] = self::take_upload();
		$done         = WCMA_Tickets::open( $user_id, $data );

		self::notice( empty( $done['success'] ) ? 'error' : 'success', (string) $done['message'] );
	}

	/**
	 * پاسخ مشتری در تیکت.
	 *
	 * @param int $user_id   کاربر.
	 * @param int $ticket_id تیکت.
	 */
	protected static function reply_ticket( $user_id, $ticket_id ) {
		$ticket = WCMA_Tickets::get( $ticket_id );

		// تیکت کسِ دیگری به هیچ‌وجه نباید باز یا پاسخ داده شود.
		if ( ! $ticket || (int) $ticket['user_id'] !== (int) $user_id ) {
			self::notice( 'error', 'این تیکت پیدا نشد.' );

			return;
		}

		$done = WCMA_Tickets::reply(
			$ticket_id,
			array(
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				'body'   => wp_unslash( $_POST['body'] ?? '' ),
				'author' => 'user',
				'file'   => self::take_upload(),
			),
			$user_id
		);

		self::notice( empty( $done['success'] ) ? 'error' : 'success', (string) $done['message'] );
	}

	/**
	 * گرفتن پیوستِ فرم، اگر بود.
	 *
	 * @return array
	 */
	protected static function take_upload() {
		if ( empty( $_FILES['attachment']['name'] ) || ! class_exists( 'WCMA_Chat_Files' ) ) {
			return array();
		}

		if ( ! WCMA_Chat_Files::enabled() ) {
			return array();
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$stored = WCMA_Chat_Files::store( $_FILES['attachment'] );

		// store یا آرایه‌ی فایل می‌دهد یا WP_Error؛ خطا را بی‌صدا رد می‌کنیم
		// تا متن تیکت به‌خاطر یک پیوستِ نامعتبر از دست نرود.
		return is_wp_error( $stored ) ? array() : (array) $stored;
	}
}
