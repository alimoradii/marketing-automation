<?php
/**
 * تولید کدهای تخفیف پویا و اختصاصی.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Coupons
 */
class WCMA_Coupons {

	/**
	 * ساخت یک کد تخفیف اختصاصی.
	 *
	 * @param array $args پارامترها.
	 * @return array|false آرایه‌ی code/label/expiry یا false.
	 */
	public static function create( array $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'type'          => 'percent',
				'amount'        => 10,
				'days'          => 7,
				'email'         => '',
				'min_spend'     => 0,
				'usage_limit'   => 1,
				'prefix'        => 'MA',
				'products'      => array(),
				'workflow'      => '',
				'free_shipping' => false,
			)
		);

		$amount = (float) $args['amount'];
		if ( $amount <= 0 ) {
			return false;
		}

		$code   = self::generate_code( $args['prefix'] );
		$expiry = '';

		$coupon = new WC_Coupon();
		$coupon->set_code( $code );
		$coupon->set_discount_type( 'percent' === $args['type'] ? 'percent' : 'fixed_cart' );
		$coupon->set_amount( $amount );
		$coupon->set_individual_use( true );
		$coupon->set_usage_limit( max( 1, (int) $args['usage_limit'] ) );
		$coupon->set_free_shipping( (bool) $args['free_shipping'] );
		$coupon->set_description( 'ساخته‌شده به‌صورت خودکار توسط افزونه اتوماسیون بازاریابی' . ( $args['workflow'] ? ' - ' . $args['workflow'] : '' ) );

		if ( (float) $args['min_spend'] > 0 ) {
			$coupon->set_minimum_amount( (float) $args['min_spend'] );
		}

		if ( is_email( $args['email'] ) ) {
			$coupon->set_email_restrictions( array( $args['email'] ) );
			$coupon->set_usage_limit_per_user( 1 );
		}

		if ( ! empty( $args['products'] ) ) {
			$coupon->set_product_ids( array_map( 'intval', (array) $args['products'] ) );
		}

		$days = (int) $args['days'];
		if ( $days > 0 ) {
			// ووکامرس تاریخ انقضا را به‌صورت UTC تفسیر می‌کند.
			$timestamp = time() + ( $days * DAY_IN_SECONDS );
			$coupon->set_date_expires( $timestamp );
			$expiry = WCMA_Date::format( $timestamp, 'date' );
		}

		$coupon_id = $coupon->save();
		if ( ! $coupon_id ) {
			return false;
		}

		update_post_meta( $coupon_id, '_wcma_generated', 'yes' );
		update_post_meta( $coupon_id, '_wcma_workflow', $args['workflow'] );

		return array(
			'id'     => $coupon_id,
			'code'   => $code,
			'label'  => self::amount_label( $args['type'], $amount ),
			'expiry' => $expiry,
		);
	}

	/**
	 * ساخت کد یکتا.
	 *
	 * @param string $prefix پیشوند.
	 * @return string
	 */
	protected static function generate_code( $prefix = 'MA' ) {
		$prefix = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $prefix ) );
		$prefix = $prefix ? $prefix : 'MA';

		do {
			$code   = $prefix . strtoupper( wp_generate_password( 6, false, false ) );
			$exists = wc_get_coupon_id_by_code( $code );
		} while ( $exists );

		return $code;
	}

	/**
	 * برچسب خوانا برای مقدار تخفیف.
	 *
	 * @param string $type   نوع.
	 * @param float  $amount مقدار.
	 * @return string
	 */
	public static function amount_label( $type, $amount ) {
		if ( 'percent' === $type ) {
			return sprintf( '%s درصد', number_format_i18n( $amount ) );
		}
		return trim( wp_strip_all_tags( wc_price( $amount ) ) );
	}

	/**
	 * حذف کدهای تخفیف منقضی‌شده‌ی ساخته‌شده توسط افزونه.
	 *
	 * @return int تعداد حذف‌شده.
	 */
	public static function cleanup_expired() {
		$query = new WP_Query(
			array(
				'post_type'      => 'shop_coupon',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'fields'         => 'ids',
				// phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_query'     => array(
					array(
						'key'   => '_wcma_generated',
						'value' => 'yes',
					),
					array(
						'key'     => 'date_expires',
						'value'   => time() - ( 30 * DAY_IN_SECONDS ),
						'compare' => '<',
						'type'    => 'NUMERIC',
					),
				),
			)
		);

		$deleted = 0;
		foreach ( $query->posts as $coupon_id ) {
			wp_delete_post( $coupon_id, true );
			$deleted++;
		}

		return $deleted;
	}
}
