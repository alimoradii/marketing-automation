<?php
/**
 * ورود گروهی مخاطبان از فایل اکسل (xlsx) یا CSV به پرونده‌ی مشتریان.
 *
 * هر ردیف یک شماره‌ی موبایل و نام و نام خانوادگی دارد. مخاطب واردشده در
 * پرونده‌ی مشتریان می‌نشیند و هر وقت با همان شماره ربات را باز کند و شماره‌اش
 * را بدهد، ربات او را به نام می‌شناسد.
 *
 * فایل xlsx بدون هیچ کتابخانه‌ی بیرونی خوانده می‌شود: یک بسته‌ی zip است با
 * چند فایل XML، و ZipArchive و DOMDocument روی بیشتر میزبان‌ها هست.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Contacts_Import
 */
class WCMA_Contacts_Import {

	/**
	 * سقف حجم فایل بارگذاری‌شده.
	 */
	const MAX_BYTES = 5242880;

	/**
	 * سقف حجم XML ِ برگه‌ی اکسل پس از باز شدن؛ جلوی فایل‌های بمب‌مانند را می‌گیرد.
	 */
	const MAX_XML_BYTES = 62914560;

	/**
	 * سقف ردیف‌های یک فایل.
	 */
	const MAX_ROWS = 20000;

	/**
	 * برچسب پیش‌فرض مخاطبان واردشده.
	 */
	const DEFAULT_TAG = 'ورود از اکسل';

	/**
	 * فضای نام رابطه‌ها در قالب معمولی و Strict اکسل.
	 *
	 * @var array
	 */
	protected static $rel_ns = array(
		'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
		'http://purl.oclc.org/ooxml/officeDocument/relationships',
	);

	/* ------------------------------------------------------------------ */
	/* خواندن فایل                                                         */
	/* ------------------------------------------------------------------ */

	/**
	 * خواندن ردیف‌های یک فایل.
	 *
	 * @param string $path مسیر فایل روی دیسک.
	 * @param string $name نام اصلی فایل (برای پسوند).
	 * @return array{success:bool,message?:string,rows?:array,truncated?:bool}
	 */
	public static function read( $path, $name ) {
		$ext = strtolower( (string) pathinfo( (string) $name, PATHINFO_EXTENSION ) );

		if ( ! is_readable( $path ) ) {
			return self::error( 'فایل خوانده نشد.' );
		}

		if ( filesize( $path ) > self::MAX_BYTES ) {
			return self::error( sprintf( 'حجم فایل بیش از %s مگابایت است. فایل را به چند بخش تقسیم کنید.', WCMA_Date::number( self::MAX_BYTES / 1048576 ) ) );
		}

		if ( 'xls' === $ext ) {
			return self::error( 'فایل‌های قدیمی xls پشتیبانی نمی‌شوند. در اکسل «Save As» را بزنید و قالب «Excel Workbook (.xlsx)» یا «CSV UTF-8» را انتخاب کنید.' );
		}

		// پسوند گاهی اشتباه است؛ امضای zip یعنی فایل اکسلِ واقعی.
		$head = (string) file_get_contents( $path, false, null, 0, 4 ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( 'xlsx' === $ext || "PK\x03\x04" === $head ) {
			return self::read_xlsx( $path );
		}

		if ( in_array( $ext, array( 'csv', 'txt', 'tsv' ), true ) ) {
			return self::read_csv( $path );
		}

		return self::error( 'فقط فایل اکسل (xlsx) یا CSV پذیرفته می‌شود.' );
	}

	/**
	 * خواندن نخستین برگه‌ی یک فایل xlsx.
	 *
	 * @param string $path مسیر.
	 * @return array
	 */
	protected static function read_xlsx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) || ! class_exists( 'DOMDocument' ) ) {
			return self::error( 'برای خواندن فایل اکسل، افزونه‌ی Zip یا DOM روی سرور PHP فعال نیست. فایل را در اکسل با قالب «CSV UTF-8» ذخیره و همان را بارگذاری کنید.' );
		}

		$zip = new ZipArchive();

		if ( true !== $zip->open( $path ) ) {
			return self::error( 'فایل اکسل باز نشد؛ شاید آسیب دیده یا رمزدار است.' );
		}

		$sheet = self::first_sheet( $zip );
		$doc   = $sheet ? self::zip_xml( $zip, $sheet ) : null;

		if ( ! $doc ) {
			$zip->close();

			return self::error( 'برگه‌ای در فایل اکسل پیدا نشد یا قابل خواندن نبود.' );
		}

		$strings   = self::shared_strings( $zip );
		$rows      = array();
		$numbers   = array();
		$truncated = false;

		$zip->close();

		foreach ( $doc->getElementsByTagNameNS( '*', 'row' ) as $row ) {
			$cells = array();
			$next  = 0;

			foreach ( $row->childNodes as $cell ) {
				if ( XML_ELEMENT_NODE !== $cell->nodeType || 'c' !== $cell->localName ) {
					continue;
				}

				$ref = (string) $cell->getAttribute( 'r' );
				$col = '' !== $ref ? self::column_index( $ref ) : $next;

				$next           = $col + 1;
				$cells[ $col ] = trim( self::cell_value( $cell, $strings ) );
			}

			if ( ! $cells ) {
				continue;
			}

			$line = array_fill( 0, max( array_keys( $cells ) ) + 1, '' );

			foreach ( $cells as $col => $value ) {
				$line[ $col ] = $value;
			}

			$rows[] = $line;

			// شماره‌ی ردیف خودِ اکسل، تا گزارش خطا با ردیف‌های خالیِ جاافتاده جابه‌جا نشود.
			$numbers[] = (int) $row->getAttribute( 'r' ) ? (int) $row->getAttribute( 'r' ) : count( $rows );

			if ( count( $rows ) > self::MAX_ROWS ) {
				$truncated = true;
				array_pop( $rows );
				array_pop( $numbers );
				break;
			}
		}

		return array(
			'success'   => true,
			'rows'      => $rows,
			'numbers'   => $numbers,
			'truncated' => $truncated,
		);
	}

	/**
	 * مقدار متنی یک خانه.
	 *
	 * @param DOMElement $cell    خانه.
	 * @param array      $strings رشته‌های مشترک.
	 * @return string
	 */
	protected static function cell_value( $cell, array $strings ) {
		$type = (string) $cell->getAttribute( 't' );

		if ( 'inlineStr' === $type ) {
			return self::text_of( $cell );
		}

		$value = '';

		foreach ( $cell->childNodes as $child ) {
			if ( XML_ELEMENT_NODE === $child->nodeType && 'v' === $child->localName ) {
				$value = (string) $child->textContent;
				break;
			}
		}

		if ( 's' === $type ) {
			return (string) ( $strings[ (int) $value ] ?? '' );
		}

		return $value;
	}

	/**
	 * متن یک رشته‌ی اکسل (ساده یا چندتکه)، بدون آوانگاری‌های rPh.
	 *
	 * @param DOMElement $node گره.
	 * @return string
	 */
	protected static function text_of( $node ) {
		$text = '';

		foreach ( $node->getElementsByTagNameNS( '*', 't' ) as $t ) {
			if ( $t->parentNode && 'rPh' === $t->parentNode->localName ) {
				continue;
			}

			$text .= $t->textContent;
		}

		return $text;
	}

	/**
	 * رشته‌های مشترک فایل اکسل.
	 *
	 * @param ZipArchive $zip بسته.
	 * @return array
	 */
	protected static function shared_strings( $zip ) {
		$doc = self::zip_xml( $zip, 'xl/sharedStrings.xml' );

		if ( ! $doc ) {
			return array();
		}

		$out = array();

		foreach ( $doc->getElementsByTagNameNS( '*', 'si' ) as $si ) {
			$out[] = self::text_of( $si );
		}

		return $out;
	}

	/**
	 * مسیر نخستین برگه، از روی فهرست برگه‌های کارپوشه.
	 *
	 * @param ZipArchive $zip بسته.
	 * @return string
	 */
	protected static function first_sheet( $zip ) {
		$book = self::zip_xml( $zip, 'xl/workbook.xml' );
		$rels = self::zip_xml( $zip, 'xl/_rels/workbook.xml.rels' );

		if ( $book && $rels ) {
			$rid = '';

			foreach ( $book->getElementsByTagNameNS( '*', 'sheet' ) as $sheet ) {
				foreach ( self::$rel_ns as $ns ) {
					$rid = (string) $sheet->getAttributeNS( $ns, 'id' );

					if ( '' !== $rid ) {
						break;
					}
				}

				break;
			}

			foreach ( $rels->getElementsByTagNameNS( '*', 'Relationship' ) as $rel ) {
				if ( '' === $rid || $rel->getAttribute( 'Id' ) !== $rid ) {
					continue;
				}

				$target = ltrim( (string) $rel->getAttribute( 'Target' ), '/' );

				// نشانی نسبی از پوشه‌ی xl است، نشانیِ مطلق از ریشه‌ی بسته.
				$path = 0 === strpos( $target, 'xl/' ) ? $target : 'xl/' . $target;

				if ( false !== $zip->locateName( $path ) ) {
					return $path;
				}
			}
		}

		if ( false !== $zip->locateName( 'xl/worksheets/sheet1.xml' ) ) {
			return 'xl/worksheets/sheet1.xml';
		}

		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = (string) $zip->getNameIndex( $i );

			if ( preg_match( '#^xl/worksheets/[^/]+\.xml$#', $name ) ) {
				return $name;
			}
		}

		return '';
	}

	/**
	 * خواندن امن یک فایل XML از درون بسته.
	 *
	 * @param ZipArchive $zip  بسته.
	 * @param string     $name نام فایل درون بسته.
	 * @return DOMDocument|null
	 */
	protected static function zip_xml( $zip, $name ) {
		$stat = $zip->statName( $name );

		if ( ! $stat || (int) $stat['size'] > self::MAX_XML_BYTES ) {
			return null;
		}

		$xml = $zip->getFromName( $name );

		// فایل‌های اکسل DOCTYPE ندارند؛ وجودش یعنی فایل دست‌کاری‌شده (حمله‌ی موجودیت XML).
		if ( ! is_string( $xml ) || '' === $xml || false !== stripos( $xml, '<!DOCTYPE' ) ) {
			return null;
		}

		$doc      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$loaded   = $doc->loadXML( $xml, LIBXML_NONET | LIBXML_COMPACT | ( defined( 'LIBXML_PARSEHUGE' ) ? LIBXML_PARSEHUGE : 0 ) );

		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		return $loaded ? $doc : null;
	}

	/**
	 * شماره‌ی ستون (از صفر) از روی نشانی خانه، مثلاً AB12 ⇐ ۲۷.
	 *
	 * @param string $ref نشانی.
	 * @return int
	 */
	protected static function column_index( $ref ) {
		$letters = strtoupper( (string) preg_replace( '/[^A-Za-z]/', '', $ref ) );
		$index   = 0;

		for ( $i = 0, $len = strlen( $letters ); $i < $len; $i++ ) {
			$index = $index * 26 + ( ord( $letters[ $i ] ) - 64 );
		}

		return max( 0, $index - 1 );
	}

	/**
	 * خواندن فایل CSV (و متن جداشده با تب).
	 *
	 * اکسل فارسی CSV را گاهی با کدگذاری ویندوز (Windows-1256) و گاهی UTF-16
	 * ذخیره می‌کند؛ هر دو به UTF-8 برگردانده می‌شوند تا نام‌ها به‌هم نریزند.
	 *
	 * @param string $path مسیر.
	 * @return array
	 */
	protected static function read_csv( $path ) {
		$raw = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( "\xFF\xFE" === substr( $raw, 0, 2 ) ) {
			$raw = (string) mb_convert_encoding( substr( $raw, 2 ), 'UTF-8', 'UTF-16LE' );
		} elseif ( "\xFE\xFF" === substr( $raw, 0, 2 ) ) {
			$raw = (string) mb_convert_encoding( substr( $raw, 2 ), 'UTF-8', 'UTF-16BE' );
		} elseif ( "\xEF\xBB\xBF" === substr( $raw, 0, 3 ) ) {
			$raw = substr( $raw, 3 );
		}

		if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			$converted = function_exists( 'iconv' ) ? @iconv( 'CP1256', 'UTF-8//IGNORE', $raw ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors

			if ( ! is_string( $converted ) || '' === $converted ) {
				return self::error( 'کدگذاری فایل CSV شناخته نشد. در اکسل هنگام ذخیره، قالب «CSV UTF-8» را انتخاب کنید.' );
			}

			$raw = $converted;
		}

		$raw = str_replace( array( "\r\n", "\r" ), "\n", $raw );

		// جداکننده از روی نخستین ردیفِ پر حدس زده می‌شود.
		$first = '';

		foreach ( explode( "\n", $raw ) as $line ) {
			if ( '' !== trim( $line ) ) {
				$first = $line;
				break;
			}
		}

		$delimiter = ',';
		$best      = 0;

		foreach ( array( ',', ';', "\t", '|' ) as $candidate ) {
			$count = substr_count( $first, $candidate );

			if ( $count > $best ) {
				$best      = $count;
				$delimiter = $candidate;
			}
		}

		$stream = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		fwrite( $stream, $raw ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		rewind( $stream );

		$rows      = array();
		$numbers   = array();
		$truncated = false;
		$line      = 1;
		$pos       = 0;

		while ( false !== ( $cells = fgetcsv( $stream, 0, $delimiter, '"', '' ) ) ) {
			// شماره‌ی خطِ واقعی؛ خط خالی و خانه‌ی چندخطی آن را جابه‌جا نمی‌کنند.
			$start = $line;
			$now   = (int) ftell( $stream );
			$line += substr_count( $raw, "\n", $pos, max( 0, $now - $pos ) );
			$pos   = $now;

			if ( array( null ) === $cells ) {
				continue;
			}

			$rows[]    = array_map(
				static function ( $cell ) {
					return trim( (string) $cell );
				},
				$cells
			);
			$numbers[] = $start;

			if ( count( $rows ) > self::MAX_ROWS ) {
				$truncated = true;
				array_pop( $rows );
				array_pop( $numbers );
				break;
			}
		}

		fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		return array(
			'success'   => true,
			'rows'      => $rows,
			'numbers'   => $numbers,
			'truncated' => $truncated,
		);
	}

	/* ------------------------------------------------------------------ */
	/* تشخیص ستون‌ها                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * شکل یکدستِ عنوان یک ستون برای مقایسه.
	 *
	 * @param string $label عنوان.
	 * @return string
	 */
	protected static function header_key( $label ) {
		$label = str_replace( array( 'ي', 'ك', 'ة' ), array( 'ی', 'ک', 'ه' ), (string) $label );
		$label = function_exists( 'mb_strtolower' ) ? mb_strtolower( $label ) : strtolower( $label );

		// فاصله، نیم‌فاصله، خط تیره، زیرخط و نشانه‌ها کنار می‌روند.
		return (string) preg_replace( '/[^\p{L}\p{N}]+/u', '', $label );
	}

	/**
	 * نقش یک عنوان ستون: phone، first، last، full یا خالی.
	 *
	 * @param string $label عنوان.
	 * @return string
	 */
	protected static function header_role( $label ) {
		$key = self::header_key( $label );

		if ( '' === $key ) {
			return '';
		}

		$raw = trim( str_replace( array( 'ي', 'ك' ), array( 'ی', 'ک' ), (string) $label ) );

		// «نام و نام خانوادگی»، «اسم و فامیل»، «نام/نام خانوادگی»، «نام - نام خانوادگی» و مانند آن.
		if ( preg_match( '/^(نام|اسم)و.*(فامیل|خانوادگی)/u', $key )
			|| preg_match( '/^(نام|اسم)\s*[\/\\\-–،,+&|]\s*.*(فامیل|خانوادگی)/u', $raw )
			|| in_array( $key, array( 'نامکامل', 'fullname', 'nameandsurname', 'namefamily', 'name' ), true ) ) {
			return 'full';
		}

		if ( false !== mb_strpos( $key, 'خانوادگی' ) || false !== mb_strpos( $key, 'فامیل' )
			|| in_array( $key, array( 'lastname', 'surname', 'family', 'familyname', 'lname', 'last' ), true ) ) {
			return 'last';
		}

		// «موبایل» و «همراه» صریح‌اند؛ «تلفن» و «شماره» می‌توانند تلفن ثابت یا ردیف باشند.
		foreach ( array( 'موبایل', 'همراه', 'mobile', 'cell' ) as $needle ) {
			if ( false !== mb_strpos( $key, $needle ) ) {
				return 'mobile';
			}
		}

		foreach ( array( 'تلفن', 'شماره', 'تماس', 'phone', 'number' ) as $needle ) {
			if ( false !== mb_strpos( $key, $needle ) ) {
				return 'phone';
			}
		}

		// «tel» فقط خودش؛ وگرنه «Telegram ID» هم ستون شماره حساب می‌شد.
		if ( preg_match( '/^(tel|tell|telephone|telno)$/', $key ) ) {
			return 'phone';
		}

		if ( in_array( $key, array( 'نام', 'نامکوچک', 'اسم', 'firstname', 'first', 'fname', 'givenname' ), true ) ) {
			return 'first';
		}

		return '';
	}

	/**
	 * شماره‌ی موبایل یکدست از مقدار یک خانه.
	 *
	 * اکسل شماره را عدد می‌داند: صفر اولش می‌افتد و گاهی به‌شکل 9.12E+09 در
	 * CSV می‌آید؛ هر دو حالت درست برگردانده می‌شوند.
	 *
	 * @param string $value مقدار.
	 * @return string
	 */
	public static function clean_phone( $value ) {
		$value = trim( WCMA_Date::to_latin_digits( (string) $value ) );

		if ( preg_match( '/^(\d+)(?:\.(\d*))?e\+?(\d+)$/i', $value, $m ) ) {
			$fraction = (string) ( $m[2] ?? '' );
			$exponent = (int) $m[3];

			/*
			 * CSVِ اکسل عدد بلند را گِرد و علمی می‌نویسد (989121234567 ⇐ 9.89121E+11).
			 * چنین مقداری رقم‌های واقعی را ندارد و تبدیلش شماره‌ای ساختگی می‌سازد؛
			 * پس فقط وقتی پذیرفته می‌شود که همه‌ی رقم‌ها در آن مانده باشند.
			 */
			if ( strlen( $fraction ) < $exponent ) {
				return '';
			}

			$value = $m[1] . substr( $fraction, 0, $exponent );
		} elseif ( preg_match( '/^(\d+)\.0+$/', $value, $m ) ) {
			$value = $m[1];
		}

		return WCMA_SMS_Gateways::normalize_phone( $value );
	}

	/**
	 * آیا این خانه، خودش یک شماره است (و نه عنوانی که شماره‌ی نمونه دارد)؟
	 *
	 * @param string $cell خانه.
	 * @return bool
	 */
	protected static function is_phone_cell( $cell ) {
		$latin = trim( WCMA_Date::to_latin_digits( (string) $cell ) );

		return '' !== $latin
			&& (bool) preg_match( '/^(\+?[\d\s\-().]+|\d+(\.\d*)?e\+?\d+)$/i', $latin )
			&& '' !== self::clean_phone( $latin );
	}

	/**
	 * آیا این مقدار عددی است که اکسل گِرد و علمی کرده (و رقم‌هایش از دست رفته)؟
	 *
	 * @param string $value مقدار.
	 * @return bool
	 */
	protected static function rounded( $value ) {
		return (bool) preg_match( '/^\d+(\.\d*)?e\+?\d+$/i', trim( WCMA_Date::to_latin_digits( (string) $value ) ) );
	}

	/**
	 * نامِ پاک و یکدست: بدون برچسب HTML، با «ی» و «ک» فارسی.
	 *
	 * فایل‌های CSV ویندوزی، ی و ک عربی دارند و جستجوی نام را خراب می‌کردند.
	 *
	 * @param string $name نام.
	 * @return string
	 */
	protected static function clean_name( $name ) {
		$name = str_replace( array( 'ي', 'ك', 'ى' ), array( 'ی', 'ک', 'ی' ), (string) $name );
		$name = (string) preg_replace( '/\s+/u', ' ', sanitize_text_field( $name ) );

		return mb_substr( trim( $name ), 0, 120 );
	}

	/**
	 * پیدا کردن ستون‌ها، با عنوان یا (در نبود عنوان) از روی محتوا.
	 *
	 * @param array $rows ردیف‌ها.
	 * @return array{header:int,phone:int,first:int,last:int,full:int} -۱ یعنی نیست.
	 */
	public static function detect( array $rows ) {
		$map    = array( 'header' => -1, 'phone' => -1, 'first' => -1, 'last' => -1, 'full' => -1 );
		$phones = array();
		$best   = 0;

		/*
		 * ردیف عنوان: از چند ردیف اول، آنکه بیشترین عنوانِ شناخته‌شده را دارد و
		 * شماره ندارد. عنوانِ بالای جدول («شماره تماس مشتریان») یک نقش بیشتر
		 * ندارد و جای ردیف عنوانِ واقعی را نمی‌گیرد.
		 */
		foreach ( array_slice( $rows, 0, 5, true ) as $index => $row ) {
			$roles  = array();
			$found  = array();
			$data   = false;

			foreach ( $row as $col => $cell ) {
				// «موبایل (مثال: 0912…)» عنوان است؛ فقط خانه‌ی یکسره عددی، داده حساب می‌شود.
				if ( self::is_phone_cell( $cell ) ) {
					$data = true;
					break;
				}

				$role = self::header_role( $cell );

				if ( 'mobile' === $role || 'phone' === $role ) {
					$found[ $col ] = $role;
					$role          = 'phone';
				}

				if ( '' !== $role && ! isset( $roles[ $role ] ) ) {
					$roles[ $role ] = $col;
				}
			}

			if ( ! $data && count( $roles ) > $best ) {
				$best          = count( $roles );
				$map['header'] = (int) $index;
				$phones        = $found;

				foreach ( array( 'first', 'last', 'full' ) as $role ) {
					$map[ $role ] = isset( $roles[ $role ] ) ? (int) $roles[ $role ] : -1;
				}
			}
		}

		$data = array_slice( $rows, $map['header'] + 1, 200 );

		// چند خانه در هر ستون شماره‌ی موبایل معتبر دارد، و چند خانه اصلاً پر است.
		$scores = array();
		$filled = array();

		foreach ( $data as $row ) {
			foreach ( $row as $col => $cell ) {
				if ( '' !== $cell ) {
					$filled[ $col ] = ( $filled[ $col ] ?? 0 ) + 1;
				}

				if ( self::clean_phone( $cell ) ) {
					$scores[ $col ] = ( $scores[ $col ] ?? 0 ) + 1;
				}
			}
		}

		/*
		 * از ستون‌هایی که عنوان شماره دارند، آنکه شماره‌ی معتبر بیشتری دارد؛ در
		 * برابری، «موبایل» بر «تلفن» و «شماره» مقدم است. «تلفن | موبایل» دیگر
		 * تلفن ثابت را برنمی‌دارد و ستون ردیف («شماره») جای موبایل را نمی‌گیرد.
		 */
		$pick  = -1;
		$score = -1;

		foreach ( $phones as $col => $role ) {
			$value = ( $scores[ $col ] ?? 0 ) * 2 + ( 'mobile' === $role ? 1 : 0 );

			if ( $value > $score ) {
				$score = $value;
				$pick  = (int) $col;
			}
		}

		/*
		 * ستونی که عنوانش شناخته نشد ولی پر از شماره است، فقط جای ستونِ عنوان‌دارِ
		 * خالی را می‌گیرد. ستون «موبایل» که پر است ولی شماره‌ی معتبری ندارد (مثلاً
		 * اکسل گِردش کرده) می‌ماند تا خطایش گزارش شود؛ وگرنه ستونی مثل کد پستی جای
		 * موبایل وارد می‌شد.
		 */
		if ( $scores && ( $pick < 0 || empty( $filled[ $pick ] ) ) ) {
			arsort( $scores );
			$pick = (int) key( $scores );
		}

		$map['phone'] = $pick;

		foreach ( array( 'first', 'last', 'full' ) as $role ) {
			if ( $map[ $role ] === $map['phone'] ) {
				$map[ $role ] = -1;
			}
		}

		// «نام» تنها، وقتی ستون نام خانوادگی نیست، نام کامل است.
		if ( $map['first'] >= 0 && $map['last'] < 0 && $map['full'] < 0 ) {
			$map['full']  = $map['first'];
			$map['first'] = -1;
		}

		// و برعکس: «Name» کنار «Last name» همان نام کوچک است.
		if ( $map['full'] >= 0 && $map['last'] >= 0 && $map['first'] < 0 ) {
			$map['first'] = $map['full'];
			$map['full']  = -1;
		}

		// ستون نامی که تنهاست، نام کامل است؛ هر عنوانی که داشته باشد.
		if ( $map['last'] >= 0 && $map['first'] < 0 && $map['full'] < 0 ) {
			$map['full'] = $map['last'];
			$map['last'] = -1;
		}

		// فایل بی‌عنوان: ستون‌های متنیِ کنار شماره، به ترتیب نام و نام خانوادگی‌اند.
		if ( $map['header'] < 0 && $map['phone'] >= 0 ) {
			$text = array();

			foreach ( $data as $row ) {
				foreach ( $row as $col => $cell ) {
					if ( $col !== $map['phone'] && '' !== $cell && ! preg_match( '/^[\d\s.+\-()]+$/u', WCMA_Date::to_latin_digits( $cell ) ) ) {
						$text[ $col ] = true;
					}
				}
			}

			ksort( $text );
			$cols = array_keys( $text );

			if ( 1 === count( $cols ) ) {
				$map['full'] = $cols[0];
			} elseif ( count( $cols ) > 1 ) {
				$map['first'] = $cols[0];
				$map['last']  = $cols[1];
			}
		}

		return $map;
	}

	/* ------------------------------------------------------------------ */
	/* ورود                                                                */
	/* ------------------------------------------------------------------ */

	/**
	 * ورود یک فایل، از خواندن تا گزارش.
	 *
	 * @param string $path مسیر فایل.
	 * @param string $name نام اصلی فایل.
	 * @param array  $args tag و overwrite.
	 * @return array گزارش.
	 */
	public static function import_file( $path, $name, array $args = array() ) {
		$read = self::read( $path, $name );

		if ( empty( $read['success'] ) ) {
			return $read;
		}

		$args['numbers']     = $read['numbers'] ?? array();
		$report              = self::import( $read['rows'], $args );
		$report['truncated'] = ! empty( $read['truncated'] );
		$report['file']      = sanitize_file_name( (string) $name );

		if ( $report['truncated'] ) {
			$report['message'] .= sprintf( ' فقط %s ردیف نخست خوانده شد؛ بقیه را در فایل جداگانه وارد کنید.', WCMA_Date::number( self::MAX_ROWS ) );
		}

		return $report;
	}

	/**
	 * ورود ردیف‌ها به پرونده‌ی مشتریان.
	 *
	 * @param array $rows ردیف‌ها.
	 * @param array $args tag (برچسب)، overwrite (جایگزینی نام موجود) و numbers (شماره‌ی واقعی ردیف‌ها).
	 * @return array گزارش.
	 */
	public static function import( array $rows, array $args = array() ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			return self::error( 'جدول پرونده‌ی مشتریان ساخته نشده است. در تب «تست ارسال»، «ترمیم جدول‌ها» را بزنید.' );
		}

		if ( ! $rows ) {
			return self::error( 'فایل خالی است یا ردیفی در آن پیدا نشد.' );
		}

		$map = self::detect( $rows );

		if ( $map['phone'] < 0 ) {
			return self::error( 'ستون شماره‌ی موبایل پیدا نشد. ستونی با عنوان «موبایل» بگذارید یا از فایل نمونه استفاده کنید.' );
		}

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}

		$numbers   = isset( $args['numbers'] ) && is_array( $args['numbers'] ) ? $args['numbers'] : array();
		$tag       = trim( sanitize_text_field( (string) ( $args['tag'] ?? self::DEFAULT_TAG ) ) );
		$overwrite = ! empty( $args['overwrite'] );
		$report    = array(
			'success'   => true,
			'rows'      => 0,
			'created'   => 0,
			'updated'   => 0,
			'invalid'   => 0,
			'duplicate' => 0,
			'in_bot'    => 0,
			'samples'   => array(),
			'columns'   => $map,
		);

		$seen = array();

		foreach ( $rows as $index => $row ) {
			if ( $index <= $map['header'] ) {
				continue;
			}

			$raw_phone = (string) ( $row[ $map['phone'] ] ?? '' );
			$first     = $map['first'] >= 0 ? (string) ( $row[ $map['first'] ] ?? '' ) : '';
			$last      = $map['last'] >= 0 ? (string) ( $row[ $map['last'] ] ?? '' ) : '';

			if ( $map['full'] >= 0 && '' === $first ) {
				$first = (string) ( $row[ $map['full'] ] ?? '' );
			}

			$first = self::clean_name( $first );
			$last  = self::clean_name( $last );

			// ردیف یکسره خالی، ردیف نیست.
			if ( '' === trim( implode( '', $row ) ) ) {
				continue;
			}

			$report['rows']++;

			$phone = self::clean_phone( $raw_phone );

			if ( '' === $phone ) {
				$report['invalid']++;

				if ( self::rounded( $raw_phone ) ) {
					$report['rounded'] = ( $report['rounded'] ?? 0 ) + 1;
				}

				if ( count( $report['samples'] ) < 10 ) {
					$report['samples'][] = array(
						'row'   => $numbers[ $index ] ?? $index + 1,
						'phone' => $raw_phone,
						'name'  => trim( $first . ' ' . $last ),
					);
				}

				continue;
			}

			if ( isset( $seen[ $phone ] ) ) {
				$report['duplicate']++;
				continue;
			}

			$seen[ $phone ] = true;
			$existing       = WCMA_CRM::find( '', $phone );
			$data           = array( 'phone' => $phone );

			if ( '' !== $tag ) {
				$tags   = $existing ? WCMA_CRM::tag_list( $existing['tags'] ) : array();
				$tags[] = $tag;

				$data['tags'] = $tags;
			}

			/*
			 * نام موجود جایگزین می‌شود اگر مدیر خواسته باشد، اگر پرونده نامی
			 * ندارد، یا اگر نامش فقط نام تلگرامی است (پرونده را خود ربات ساخته).
			 * نام و نام خانوادگی با هم عوض می‌شوند تا «نام تلگرامی + نام خانوادگیِ
			 * اکسل» درهم نشوند.
			 */
			$replace = false;

			if ( ! $existing ) {
				$data['first_name'] = $first;
				$data['last_name']  = $last;
				$data['source']     = 'import';

				$report['created']++;
			} else {
				$current = trim( $existing['first_name'] . ' ' . $existing['last_name'] );
				$replace = '' !== $first && ( $overwrite || '' === $current || self::telegram_named( $existing ) );

				// وگرنه فقط نام خانوادگیِ خالیِ همان شخص پر می‌شود.
				$same = '' === $first || self::clean_name( $existing['first_name'] ) === $first;

				if ( ! $replace && $same && '' !== $last && '' === trim( (string) $existing['last_name'] ) ) {
					$data['last_name'] = $last;
				}

				$report['updated']++;
			}

			$contact_id = WCMA_CRM::upsert( $data );

			// upsert مقدار خالی را نمی‌نویسد؛ نام خانوادگیِ قبلی باید واقعاً پاک شود.
			if ( $replace && $contact_id ) {
				$wpdb->update( WCMA_CRM::table(), array( 'first_name' => $first, 'last_name' => $last ), array( 'id' => (int) $contact_id ) ); // phpcs:ignore WordPress.DB
			}
		}

		$report['in_bot'] = self::link_subscribers( array_keys( $seen ) );

		$report['message'] = sprintf(
			'%s ردیف خوانده شد: %s مخاطب تازه، %s به‌روزرسانی، %s شماره‌ی نامعتبر، %s تکراری در فایل. %s نفر از همین حالا در ربات هستند و شناخته شدند.',
			WCMA_Date::number( $report['rows'] ),
			WCMA_Date::number( $report['created'] ),
			WCMA_Date::number( $report['updated'] ),
			WCMA_Date::number( $report['invalid'] ),
			WCMA_Date::number( $report['duplicate'] ),
			WCMA_Date::number( $report['in_bot'] )
		);

		if ( ! empty( $report['rounded'] ) ) {
			$report['message'] .= sprintf(
				' %s شماره را اکسل گِرد کرده و به‌شکل علمی (مثل 9.12E+09) ذخیره بود و رقم‌هایش از دست رفته است؛ در اکسل ستون موبایل را «Text» کنید و شماره‌ها را دوباره وارد کنید، یا از فایل xlsx استفاده کنید.',
				WCMA_Date::number( $report['rounded'] )
			);
		}

		/**
		 * پس از ورود گروهی مخاطبان.
		 *
		 * @param array $report گزارش.
		 */
		do_action( 'wcma_contacts_imported', $report );

		return $report;
	}

	/**
	 * آیا نامِ این پرونده همان نامِ تلگرامیِ صاحبش است (و نه نامی که کسی وارد کرده)؟
	 *
	 * منبعِ پرونده بعد از ساخته شدن عوض نمی‌شود و برای این کار قابل اعتماد نیست:
	 * پرونده‌ای که ربات ساخته ممکن است بعداً با سفارش یا دستِ مدیر نام درست
	 * گرفته باشد، و پرونده‌ی واردشده‌ی بی‌نام ممکن است نام تلگرامی گرفته باشد.
	 *
	 * @param array $contact پرونده.
	 * @return bool
	 */
	protected static function telegram_named( array $contact ) {
		global $wpdb;

		$first = trim( (string) $contact['first_name'] );
		$full  = trim( $first . ' ' . (string) $contact['last_name'] );

		if ( '' === $first || ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return false;
		}

		$subs  = $wpdb->prefix . 'wcma_bot_subs';
		$names = $wpdb->get_col( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT name FROM {$subs} WHERE contact_id = %d OR ( phone <> '' AND phone = %s )", (int) $contact['id'], (string) $contact['phone'] ) // phpcs:ignore WordPress.DB
		);

		foreach ( (array) $names as $name ) {
			$name = trim( (string) $name );

			// نام کامل باید یکی باشد؛ نام کوچکِ یکسان، نام خانوادگیِ واقعی را پاک می‌کرد.
			if ( '' !== $name && $name === $full ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * وصل کردن مشترکانی که از قبل شماره داده‌اند به پرونده‌ی تازه‌شان.
	 *
	 * @param array $phones شماره‌های واردشده.
	 * @return int شمار مشترکانی که با این شماره‌ها در ربات‌اند.
	 */
	protected static function link_subscribers( array $phones ) {
		global $wpdb;

		if ( ! $phones || ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return 0;
		}

		$subs     = $wpdb->prefix . 'wcma_bot_subs';
		$contacts = WCMA_CRM::table();
		$found    = 0;

		foreach ( array_chunk( $phones, 500 ) as $chunk ) {
			$in = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );

			$wpdb->query( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					// فقط شماره‌ی تأییدشده؛ شماره‌ای که کسی با کارتِ دیگری ثبت کرده، نامِ صاحبش را نمی‌گیرد.
					"UPDATE {$subs} s JOIN {$contacts} c ON c.phone = s.phone SET s.contact_id = c.id WHERE s.phone_verified = 1 AND s.phone IN ({$in})", // phpcs:ignore WordPress.DB
					$chunk
				)
			);

			$found += (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT COUNT(*) FROM {$subs} WHERE phone_verified = 1 AND phone IN ({$in})", $chunk ) // phpcs:ignore WordPress.DB
			);
		}

		return $found;
	}

	/* ------------------------------------------------------------------ */
	/* فایل نمونه                                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * فایل نمونه‌ی اکسل (یا CSV، اگر Zip روی سرور نباشد).
	 *
	 * ستون موبایل از پیش «متن» است تا اکسل صفر اول شماره‌ها را نیندازد.
	 *
	 * @return array{name:string,mime:string,body:string}
	 */
	public static function template() {
		$rows = array(
			array( 'نام', 'نام خانوادگی', 'موبایل' ),
			array( 'علی', 'مرادی', '09121234567' ),
			array( 'سارا', 'احمدی', '09351234567' ),
		);

		if ( class_exists( 'ZipArchive' ) ) {
			$body = self::build_xlsx( $rows );

			if ( '' !== $body ) {
				return array(
					'name' => 'contacts-template.xlsx',
					'mime' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
					'body' => $body,
				);
			}
		}

		$csv = "\xEF\xBB\xBF";

		foreach ( $rows as $row ) {
			$csv .= implode( ',', $row ) . "\n";
		}

		return array(
			'name' => 'contacts-template.csv',
			'mime' => 'text/csv; charset=utf-8',
			'body' => $csv,
		);
	}

	/**
	 * ساختن یک فایل xlsx ساده با یک برگه‌ی راست‌به‌چپ.
	 *
	 * @param array $rows ردیف‌ها؛ ردیف نخست عنوان است.
	 * @return string محتوای دودویی فایل، یا خالی اگر ساخته نشد.
	 */
	protected static function build_xlsx( array $rows ) {
		$main = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
		$rel  = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
		$pkg  = 'http://schemas.openxmlformats.org/package/2006/relationships';
		$head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";

		$data = '';

		foreach ( $rows as $r => $row ) {
			$data .= '<row r="' . ( $r + 1 ) . '">';

			foreach ( array_values( $row ) as $c => $value ) {
				$ref   = chr( 65 + $c ) . ( $r + 1 );
				$style = 0 === $r ? 1 : ( 2 === $c ? 2 : 0 );
				$data .= '<c r="' . $ref . '" t="inlineStr" s="' . $style . '"><is><t>' . htmlspecialchars( (string) $value, ENT_XML1 ) . '</t></is></c>';
			}

			$data .= '</row>';
		}

		$parts = array(
			'[Content_Types].xml'        => $head . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
				. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
				. '<Default Extension="xml" ContentType="application/xml"/>'
				. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
				. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
				. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
				. '</Types>',
			'_rels/.rels'                => $head . '<Relationships xmlns="' . $pkg . '">'
				. '<Relationship Id="rId1" Type="' . $rel . '/officeDocument" Target="xl/workbook.xml"/>'
				. '</Relationships>',
			'xl/workbook.xml'            => $head . '<workbook xmlns="' . $main . '" xmlns:r="' . $rel . '">'
				. '<sheets><sheet name="مخاطبان" sheetId="1" r:id="rId1"/></sheets>'
				. '</workbook>',
			'xl/_rels/workbook.xml.rels' => $head . '<Relationships xmlns="' . $pkg . '">'
				. '<Relationship Id="rId1" Type="' . $rel . '/worksheet" Target="worksheets/sheet1.xml"/>'
				. '<Relationship Id="rId2" Type="' . $rel . '/styles" Target="styles.xml"/>'
				. '</Relationships>',
			'xl/styles.xml'              => $head . '<styleSheet xmlns="' . $main . '">'
				. '<fonts count="2"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><name val="Tahoma"/></font></fonts>'
				. '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
				. '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
				. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
				. '<cellXfs count="3">'
				. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
				. '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
				. '<xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
				. '</cellXfs>'
				. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
				. '</styleSheet>',
			'xl/worksheets/sheet1.xml'   => $head . '<worksheet xmlns="' . $main . '">'
				. '<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>'
				. '<cols><col min="1" max="2" width="22" customWidth="1"/><col min="3" max="3" width="18" style="2" customWidth="1"/></cols>'
				. '<sheetData>' . $data . '</sheetData>'
				. '</worksheet>',
		);

		$tmp = wp_tempnam( 'wcma-template' );
		$zip = new ZipArchive();

		if ( ! $tmp || true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return '';
		}

		foreach ( $parts as $name => $xml ) {
			$zip->addFromString( $name, $xml );
		}

		$zip->close();

		$body = (string) file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		wp_delete_file( $tmp );

		return $body;
	}

	/**
	 * آمار مخاطبان برای کارت ورود.
	 *
	 * @return array{phones:int,imported:int,in_bot:int}
	 */
	public static function stats() {
		global $wpdb;

		$out = array( 'phones' => 0, 'imported' => 0, 'in_bot' => 0 );

		if ( WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			$contacts = WCMA_CRM::table();

			$out['phones']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$contacts} WHERE phone <> ''" ); // phpcs:ignore WordPress.DB
			$out['imported'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$contacts} WHERE source = 'import'" ); // phpcs:ignore WordPress.DB
		}

		if ( WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			$subs = $wpdb->prefix . 'wcma_bot_subs';

			$out['in_bot'] = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT contact_id) FROM {$subs} WHERE contact_id > 0" ); // phpcs:ignore WordPress.DB
		}

		return $out;
	}

	/**
	 * کدام‌یک از این پرونده‌ها در ربات‌اند؟
	 *
	 * @param array $ids شناسه‌ی پرونده‌ها.
	 * @return array شناسه ⇐ true.
	 */
	public static function in_bot( array $ids ) {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( ! $ids || ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return array();
		}

		$subs  = $wpdb->prefix . 'wcma_bot_subs';
		$in    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$found = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT contact_id FROM {$subs} WHERE contact_id IN ({$in})", $ids ) ); // phpcs:ignore WordPress.DB

		return array_fill_keys( array_map( 'intval', (array) $found ), true );
	}

	/**
	 * آخرین گزارش ورودِ کاربر جاری (یک‌بار نمایش داده می‌شود).
	 *
	 * @param array|null $report اگر داده شود، ذخیره می‌شود.
	 * @return array|null
	 */
	public static function last_report( $report = null ) {
		$key = 'wcma_import_report_' . get_current_user_id();

		if ( null !== $report ) {
			set_transient( $key, $report, HOUR_IN_SECONDS );

			return $report;
		}

		$saved = get_transient( $key );

		if ( $saved ) {
			delete_transient( $key );
		}

		return is_array( $saved ) ? $saved : null;
	}

	/**
	 * خروجی ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function error( $message ) {
		return array(
			'success' => false,
			'message' => (string) $message,
		);
	}
}
