<?php
/**
 * موتور جایگزینی شورت‌کدها (متغیرهای پویا) در متن پیام‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Placeholders
 */
class WCMA_Placeholders {

	/**
	 * فهرست متغیرهای پشتیبانی‌شده به همراه توضیح.
	 *
	 * @return array
	 */
	public static function available() {
		$groups = self::groups();
		$flat   = array();

		foreach ( $groups as $group ) {
			foreach ( $group['items'] as $tag => $meta ) {
				$flat[ $tag ] = $meta['label'];
			}
		}

		return $flat;
	}

	/**
	 * متغیرها به‌همراه عنوان، توضیح کارکرد و نمونه‌ی خروجی، دسته‌بندی‌شده.
	 *
	 * @return array
	 */
	public static function groups() {
		$groups = array(
			'customer' => array(
				'title' => 'مشتری',
				'items' => array(
					'{first_name}'     => array(
						'label'  => 'نام کوچک',
						'desc'   => 'نام کوچک مشتری از اطلاعات صورتحساب. اگر خالی باشد «مشتری» جایگزین می‌شود.',
						'sample' => 'علی',
					),
					'{last_name}'      => array(
						'label'  => 'نام خانوادگی',
						'desc'   => 'نام خانوادگی مشتری.',
						'sample' => 'مرادی',
					),
					'{full_name}'      => array(
						'label'  => 'نام کامل',
						'desc'   => 'نام و نام خانوادگی با هم؛ در نبود هر دو «مشتری گرامی».',
						'sample' => 'علی مرادی',
					),
					'{email}'          => array(
						'label'  => 'ایمیل',
						'desc'   => 'نشانی ایمیل مشتری.',
						'sample' => 'ali@example.com',
					),
					'{phone}'          => array(
						'label'  => 'شماره موبایل',
						'desc'   => 'شماره موبایل مشتری از اطلاعات صورتحساب.',
						'sample' => '۰۹۱۲۱۲۳۴۵۶۷',
					),
					'{customer_orders}' => array(
						'label'  => 'تعداد کل سفارش‌ها',
						'desc'   => 'شمار سفارش‌های تکمیل‌شده‌ی این مشتری تا امروز. برای پیام‌های قدرشناسانه مفید است.',
						'sample' => '۷',
					),
					'{customer_total}' => array(
						'label'  => 'مجموع خرید مشتری',
						'desc'   => 'مبلغ کل خریدهای مشتری از فروشگاه.',
						'sample' => '۱۲,۵۰۰,۰۰۰ تومان',
					),
				),
			),
			'order'    => array(
				'title' => 'سفارش',
				'items' => array(
					'{order_number}'   => array(
						'label'  => 'شماره سفارش',
						'desc'   => 'شماره‌ای که مشتری در فاکتور و پیگیری می‌بیند.',
						'sample' => '۱۰۲۴',
					),
					'{order_total}'    => array(
						'label'  => 'مبلغ کل سفارش',
						'desc'   => 'مبلغ نهایی سفارش با واحد پول فروشگاه.',
						'sample' => '۲۵۰,۰۰۰ تومان',
					),
					'{order_status}'   => array(
						'label'  => 'وضعیت سفارش',
						'desc'   => 'نام فارسی وضعیت فعلی سفارش.',
						'sample' => 'در حال پردازش',
					),
					'{order_date}'     => array(
						'label'  => 'تاریخ سفارش',
						'desc'   => 'تاریخ ثبت سفارش به تقویم و ارقام تنظیم‌شده.',
						'sample' => '۱۴۰۵/۰۶/۱۸',
					),
					'{order_time}'     => array(
						'label'  => 'ساعت سفارش',
						'desc'   => 'ساعت ثبت سفارش.',
						'sample' => '۰۷:۱۴',
					),
					'{order_day}'      => array(
						'label'  => 'روز هفته‌ی سفارش',
						'desc'   => 'نام روز هفته‌ای که سفارش ثبت شده است.',
						'sample' => 'چهارشنبه',
					),
					'{order_items}'    => array(
						'label'  => 'فهرست اقلام سفارش',
						'desc'   => 'جدول محصولات سفارش. مناسب ایمیل؛ در پیامک به متن ساده تبدیل می‌شود.',
						'sample' => 'جدول محصولات',
					),
					'{order_count}'    => array(
						'label'  => 'تعداد اقلام سفارش',
						'desc'   => 'شمار کل کالاهای داخل این سفارش.',
						'sample' => '۳',
					),
					'{order_link}'     => array(
						'label'  => 'لینک مشاهده سفارش',
						'desc'   => 'نشانی صفحه‌ی جزئیات سفارش در حساب کاربری مشتری.',
						'sample' => 'https://…/view-order/1024',
					),
					'{payment_link}'   => array(
						'label'  => 'لینک پرداخت',
						'desc'   => 'نشانی پرداخت سفارش پرداخت‌نشده. کلید بازیابی سفارش‌های ناتمام.',
						'sample' => 'https://…/order-pay/1024',
					),
					'{payment_method}' => array(
						'label'  => 'روش پرداخت',
						'desc'   => 'نام درگاه یا روش پرداختی که مشتری انتخاب کرده است.',
						'sample' => 'پرداخت اینترنتی',
					),
					'{shipping_method}' => array(
						'label'  => 'روش ارسال',
						'desc'   => 'روش ارسال انتخاب‌شده در سفارش.',
						'sample' => 'پست پیشتاز',
					),
					'{order_address}'  => array(
						'label'  => 'آدرس تحویل',
						'desc'   => 'نشانی کامل تحویل سفارش.',
						'sample' => 'تهران، خیابان …',
					),
					'{order_city}'     => array(
						'label'  => 'شهر',
						'desc'   => 'شهر ثبت‌شده در آدرس صورتحساب.',
						'sample' => 'تهران',
					),
				),
			),
			'product'  => array(
				'title' => 'محصول',
				'items' => array(
					'{product_name}'   => array(
						'label'  => 'نام محصول',
						'desc'   => 'نام محصول مرتبط با پیام (مثلاً محصول ناموجود یا محصول سبد).',
						'sample' => 'پازل ۵۰۰ قطعه',
					),
					'{product_link}'   => array(
						'label'  => 'لینک محصول',
						'desc'   => 'نشانی صفحه‌ی محصول.',
						'sample' => 'https://…/product/…',
					),
					'{product_price}'  => array(
						'label'  => 'قیمت محصول',
						'desc'   => 'قیمت فعلی محصول با واحد پول.',
						'sample' => '۲۵۰,۰۰۰ تومان',
					),
					'{product_sku}'    => array(
						'label'  => 'کد محصول (SKU)',
						'desc'   => 'کد انبارداری محصول.',
						'sample' => 'PZL-500',
					),
					'{stock_qty}'      => array(
						'label'  => 'تعداد موجودی',
						'desc'   => 'موجودی فعلی محصول؛ اگر مدیریت موجودی خاموش باشد خالی می‌ماند.',
						'sample' => '۷',
					),
				),
			),
			'cart'     => array(
				'title' => 'سبد خرید',
				'items' => array(
					'{cart_items}'     => array(
						'label'  => 'فهرست اقلام سبد',
						'desc'   => 'جدول محصولات باقی‌مانده در سبد خرید.',
						'sample' => 'جدول محصولات',
					),
					'{cart_total}'     => array(
						'label'  => 'مبلغ سبد خرید',
						'desc'   => 'مبلغ کل سبد رها شده.',
						'sample' => '۴۸۰,۰۰۰ تومان',
					),
					'{cart_count}'     => array(
						'label'  => 'تعداد اقلام سبد',
						'desc'   => 'شمار کالاهای داخل سبد.',
						'sample' => '۲',
					),
					'{recovery_link}'  => array(
						'label'  => 'لینک بازیابی سبد',
						'desc'   => 'با کلیک روی آن، سبد مشتری دقیقاً بازسازی می‌شود. مهم‌ترین متغیر این ورک‌فلو.',
						'sample' => 'https://…/cart?wcma_recover=…',
					),
				),
			),
			'coupon'   => array(
				'title' => 'کد تخفیف',
				'items' => array(
					'{coupon_code}'    => array(
						'label'  => 'کد تخفیف',
						'desc'   => 'کد یکتایی که برای همین مشتری ساخته می‌شود. اگر ورک‌فلو کد نسازد خالی می‌ماند.',
						'sample' => 'VIPA1B2C3',
					),
					'{coupon_amount}'  => array(
						'label'  => 'مقدار تخفیف',
						'desc'   => 'مقدار تخفیف به‌صورت خوانا (درصد یا مبلغ).',
						'sample' => '۱۰ درصد',
					),
					'{coupon_expiry}'  => array(
						'label'  => 'تاریخ انقضای کد',
						'desc'   => 'آخرین روز اعتبار کد تخفیف. برای ایجاد حس فوریت مفید است.',
						'sample' => '۱۴۰۵/۰۶/۲۵',
					),
				),
			),
			'vip'      => array(
				'title' => 'باشگاه مشتریان',
				'items' => array(
					'{vip_tier}'           => array(
						'label'  => 'سطح مشتری',
						'desc'   => 'نام سطح فعلی مشتری در باشگاه.',
						'sample' => 'طلایی',
					),
					'{vip_perk}'           => array(
						'label'  => 'مزایای سطح',
						'desc'   => 'متن مزایایی که برای سطح فعلی تعریف کرده‌اید.',
						'sample' => 'ارسال رایگان',
					),
					'{vip_total}'          => array(
						'label'  => 'مجموع خرید در بازه',
						'desc'   => 'مبلغ خرید مشتری در بازه‌ی محاسبه‌ی باشگاه.',
						'sample' => '۲۵,۰۰۰,۰۰۰ تومان',
					),
					'{vip_orders}'         => array(
						'label'  => 'تعداد سفارش در بازه',
						'desc'   => 'شمار سفارش‌های مشتری در بازه‌ی محاسبه‌ی باشگاه.',
						'sample' => '۱۲',
					),
					'{vip_next_tier}'      => array(
						'label'  => 'سطح بعدی',
						'desc'   => 'نام سطح بالاتر؛ اگر مشتری در بالاترین سطح باشد خالی می‌ماند.',
						'sample' => 'طلایی',
					),
					'{vip_next_remaining}' => array(
						'label'  => 'فاصله تا سطح بعدی',
						'desc'   => 'چقدر خرید یا چند سفارش تا ارتقا مانده است. انگیزه‌ی خرید بعدی.',
						'sample' => '۵,۰۰۰,۰۰۰ تومان',
					),
				),
			),
			'shop'     => array(
				'title' => 'فروشگاه و زمان',
				'items' => array(
					'{site_title}'     => array(
						'label'  => 'نام فروشگاه',
						'desc'   => 'عنوان سایت از تنظیمات وردپرس.',
						'sample' => 'فروشگاه من',
					),
					'{site_url}'       => array(
						'label'  => 'آدرس فروشگاه',
						'desc'   => 'نشانی صفحه‌ی اصلی فروشگاه.',
						'sample' => 'https://example.com',
					),
					'{shop_phone}'     => array(
						'label'  => 'تلفن فروشگاه',
						'desc'   => 'شماره‌ی تماس فروشگاه از تنظیمات افزونه.',
						'sample' => '۰۲۱-۱۲۳۴۵۶۷۸',
					),
					'{today}'          => array(
						'label'  => 'تاریخ امروز',
						'desc'   => 'تاریخ امروز به تقویم و ارقام تنظیم‌شده.',
						'sample' => '۱۴۰۵/۰۶/۱۸',
					),
					'{today_long}'     => array(
						'label'  => 'تاریخ امروز (بلند)',
						'desc'   => 'تاریخ با نام ماه، مناسب متن‌های رسمی.',
						'sample' => '۱۸ شهریور ۱۴۰۵',
					),
					'{weekday}'        => array(
						'label'  => 'روز هفته',
						'desc'   => 'نام روز جاری هفته.',
						'sample' => 'چهارشنبه',
					),
					'{time}'           => array(
						'label'  => 'ساعت کنونی',
						'desc'   => 'ساعت لحظه‌ی ارسال پیام.',
						'sample' => '۰۷:۱۴',
					),
					'{unsubscribe}'    => array(
						'label'  => 'لینک لغو اشتراک',
						'desc'   => 'لینک امضاشده‌ی لغو دریافت پیام‌های تبلیغاتی. در ایمیل‌ها توصیه می‌شود.',
						'sample' => 'https://…?wcma_unsubscribe=…',
					),
					'{cancel_link}'    => array(
						'label'  => 'لینک لغو اطلاع‌رسانی موجودی',
						'desc'   => 'فقط در ورک‌فلو هشدار موجودی معنا دارد.',
						'sample' => 'https://…?wcma_stock_cancel=…',
					),
					'{telegram_connect}' => array(
						'label'  => 'لینک اتصال به ربات تلگرام',
						'desc'   => 'لینک اختصاصی هر مشتری برای اتصال حسابش به ربات تلگرام.',
						'sample' => 'https://t.me/bot?start=…',
					),
					'{bale_connect}'   => array(
						'label'  => 'لینک اتصال به ربات بله',
						'desc'   => 'مانند تلگرام، برای پیام‌رسان بله.',
						'sample' => 'https://ble.ir/bot?start=…',
					),
					'{rubika_connect}' => array(
						'label'  => 'لینک اتصال به ربات روبیکا',
						'desc'   => 'مانند تلگرام، برای پیام‌رسان روبیکا.',
						'sample' => 'https://rubika.ir/bot?start=…',
					),
				),
			),
			'bot'      => array(
				'title' => 'ربات تلگرام',
				'items' => array(
					'{day}'              => array(
						'label'  => 'شماره‌ی روز دنباله',
						'desc'   => 'چندمین پیام دنباله است؛ همان شماره‌ای که در تنظیمات روز نوشته‌اید.',
						'sample' => '۳',
					),
					'{day_of_journey}'   => array(
						'label'  => 'روز چندم از شروع',
						'desc'   => 'از روزی که کاربر ربات را استارت کرده، امروز روز چندم است. روز استارت، روز ۱ حساب می‌شود.',
						'sample' => '۵',
					),
					'{days_since_start}' => array(
						'label'  => 'چند روز از شروع گذشته',
						'desc'   => 'تعداد روزهای سپری‌شده از استارت. روز استارت، صفر است.',
						'sample' => '۴',
					),
					'{start_date}'       => array(
						'label'  => 'تاریخ شروع (شمسی)',
						'desc'   => 'تاریخ شمسی روزی که کاربر ربات را استارت کرد.',
						'sample' => '۱۴۰۴/۰۶/۱۸',
					),
					'{start_date_long}'  => array(
						'label'  => 'تاریخ شروع با نام ماه',
						'desc'   => 'همان تاریخ شروع، با نام ماه شمسی.',
						'sample' => '۱۸ شهریور ۱۴۰۴',
					),
					'{start_weekday}'    => array(
						'label'  => 'روز هفته‌ی شروع',
						'desc'   => 'نام روز هفته‌ای که کاربر ربات را استارت کرد.',
						'sample' => 'سه‌شنبه',
					),
					'{phone_date}'       => array(
						'label'  => 'تاریخ دادن شماره (شمسی)',
						'desc'   => 'تاریخ شمسی روزی که کاربر شماره‌ی موبایلش را فرستاد. اگر نفرستاده باشد خالی می‌ماند.',
						'sample' => '۱۴۰۴/۰۶/۱۹',
					),
					'{phone_date_long}'  => array(
						'label'  => 'تاریخ دادن شماره با نام ماه',
						'desc'   => 'همان تاریخ، با نام ماه شمسی.',
						'sample' => '۱۹ شهریور ۱۴۰۴',
					),
					'{days_since_phone}' => array(
						'label'  => 'چند روز از دادن شماره گذشته',
						'desc'   => 'تعداد روزهای سپری‌شده از لحظه‌ای که شماره را به اشتراک گذاشت.',
						'sample' => '۳',
					),
					'{total_days}'       => array(
						'label'  => 'شمار کل روزهای دنباله',
						'desc'   => 'بلندترین روزی که برایش محتوا تعریف کرده‌اید.',
						'sample' => '۷',
					),
					'{remaining_days}'   => array(
						'label'  => 'روزهای باقی‌مانده',
						'desc'   => 'چند روز دیگر از دنباله مانده است.',
						'sample' => '۴',
					),
					'{username}'         => array(
						'label'  => 'نام کاربری تلگرام',
						'desc'   => 'نام کاربری کاربر در تلگرام، با @. اگر نداشته باشد خالی می‌ماند.',
						'sample' => '@ali',
					),
					'{sent_count}'       => array(
						'label'  => 'شمار پیام‌های گرفته‌شده',
						'desc'   => 'تا حالا چند پیام از دنباله برای این کاربر رفته است.',
						'sample' => '۲',
					),
				),
			),
		);

		/**
		 * فیلتر گروه‌های متغیرها.
		 *
		 * @param array $groups گروه‌ها.
		 */
		return apply_filters( 'wcma_placeholder_groups', $groups );
	}

	/**
	 * اطلاعات کامل یک متغیر.
	 *
	 * @param string $tag برچسب.
	 * @return array|null
	 */
	public static function info( $tag ) {
		// چه با آکولاد نوشته شود چه بدون آن، یک متغیر است.
		$tag = '{' . trim( (string) $tag, '{} ' ) . '}';

		foreach ( self::groups() as $group ) {
			if ( isset( $group['items'][ $tag ] ) ) {
				return $group['items'][ $tag ];
			}
		}

		return null;
	}

	/**
	 * جایگزینی متغیرها در یک متن.
	 *
	 * @param string $text متن ورودی.
	 * @param array  $data داده‌های زمینه (order, product, cart, coupon, user).
	 * @return string
	 */
	public static function replace( $text, array $data = array() ) {
		if ( '' === trim( (string) $text ) ) {
			return '';
		}

		$vars = self::build_vars( $data );

		/**
		 * فیلتر متغیرهای قابل جایگزینی.
		 *
		 * @param array $vars متغیرها.
		 * @param array $data زمینه.
		 */
		$vars = apply_filters( 'wcma_placeholder_values', $vars, $data );

		// مقادیر آماده‌ای که فراخواننده مستقیم داده است، بر بقیه اولویت دارند.
		if ( ! empty( $data['vars'] ) && is_array( $data['vars'] ) ) {
			foreach ( $data['vars'] as $tag => $value ) {
				if ( '' !== (string) $value ) {
					$vars[ '{' . trim( (string) $tag, '{}' ) . '}' ] = (string) $value;
				}
			}
		}

		return strtr( $text, $vars );
	}

	/**
	 * ساخت آرایه‌ی متغیر => مقدار از روی زمینه.
	 *
	 * @param array $data زمینه.
	 * @return array
	 */
	protected static function build_vars( array $data ) {
		// مقدار پیش‌فرض همه‌ی متغیرها خالی است تا هیچ برچسبی جایگزین‌نشده باقی نماند.
		$vars = array();

		foreach ( array_keys( self::available() ) as $tag ) {
			$vars[ $tag ] = '';
		}

		$vars['{site_title}'] = get_bloginfo( 'name' );
		$vars['{site_url}']   = home_url();
		$vars['{shop_phone}'] = (string) WCMA_Settings::get( 'shop_phone', '' );
		$vars['{today}']      = WCMA_Date::format( null, 'date' );
		$vars['{today_long}'] = WCMA_Date::format( null, 'date_long' );
		$vars['{weekday}']    = WCMA_Date::format( null, 'day' );
		$vars['{time}']       = WCMA_Date::format( null, 'time' );

		// --- کاربر ---
		if ( ! empty( $data['user_id'] ) ) {
			$user = get_userdata( (int) $data['user_id'] );

			if ( $user ) {
				$first = get_user_meta( $user->ID, 'billing_first_name', true );
				$last  = get_user_meta( $user->ID, 'billing_last_name', true );

				$vars['{first_name}'] = $first ? $first : $user->first_name;
				$vars['{last_name}']  = $last ? $last : $user->last_name;
				$vars['{email}']      = $user->user_email;
				$vars['{phone}']      = WCMA_Date::digits( (string) get_user_meta( $user->ID, 'billing_phone', true ) );
			}
		}

		// --- سفارش ---
		if ( ! empty( $data['order'] ) && $data['order'] instanceof WC_Order ) {
			$order = $data['order'];

			$vars['{first_name}']     = $order->get_billing_first_name() ? $order->get_billing_first_name() : $vars['{first_name}'];
			$vars['{last_name}']      = $order->get_billing_last_name() ? $order->get_billing_last_name() : $vars['{last_name}'];
			$vars['{email}']          = $order->get_billing_email() ? $order->get_billing_email() : $vars['{email}'];
			$vars['{phone}']          = $order->get_billing_phone() ? WCMA_Date::digits( $order->get_billing_phone() ) : $vars['{phone}'];
			$vars['{order_number}']   = WCMA_Date::digits( $order->get_order_number() );
			$vars['{order_total}']    = WCMA_Date::digits( self::strip_price( $order->get_formatted_order_total() ) );
			$vars['{order_status}']   = wc_get_order_status_name( $order->get_status() );
			$vars['{order_link}']     = $order->get_view_order_url();
			$vars['{payment_link}']   = $order->get_checkout_payment_url();
			$vars['{order_items}']    = self::format_order_items( $order );
			$vars['{payment_method}'] = $order->get_payment_method_title();
			$vars['{order_city}']     = $order->get_billing_city();
			$vars['{order_address}']  = trim( wp_strip_all_tags( $order->get_formatted_billing_address() ) );
			$vars['{order_count}']    = WCMA_Date::digits( (string) $order->get_item_count() );

			if ( method_exists( $order, 'get_shipping_method' ) ) {
				$vars['{shipping_method}'] = $order->get_shipping_method();
			}

			$date = $order->get_date_created();

			if ( $date ) {
				$vars['{order_date}'] = WCMA_Date::format( $date->getTimestamp(), 'date' );
				$vars['{order_time}'] = WCMA_Date::format( $date->getTimestamp(), 'time' );
				$vars['{order_day}']  = WCMA_Date::format( $date->getTimestamp(), 'day' );
			}
		}

		// --- محصول ---
		if ( ! empty( $data['product'] ) ) {
			$product = is_numeric( $data['product'] ) ? wc_get_product( $data['product'] ) : $data['product'];

			if ( $product instanceof WC_Product ) {
				$vars['{product_name}']  = $product->get_name();
				$vars['{product_link}']  = get_permalink( $product->get_id() );
				$vars['{product_price}'] = WCMA_Date::digits( trim( wp_strip_all_tags( $product->get_price_html() ) ) );
				$vars['{product_sku}']   = $product->get_sku();

				if ( $product->managing_stock() ) {
					$qty = $product->get_stock_quantity();

					if ( null !== $qty ) {
						$vars['{stock_qty}'] = WCMA_Date::number( $qty );
					}
				}
			}
		}

		// --- سبد خرید رها شده ---
		if ( ! empty( $data['cart'] ) && is_array( $data['cart'] ) ) {
			$cart = $data['cart'];

			if ( ! empty( $cart['first_name'] ) ) {
				$vars['{first_name}'] = $cart['first_name'];
			}
			if ( ! empty( $cart['email'] ) ) {
				$vars['{email}'] = $cart['email'];
			}
			if ( ! empty( $cart['phone'] ) ) {
				$vars['{phone}'] = WCMA_Date::digits( $cart['phone'] );
			}

			$vars['{cart_total}']    = WCMA_Date::digits( self::strip_price( wc_price( (float) ( $cart['cart_total'] ?? 0 ) ) ) );
			$vars['{cart_count}']    = WCMA_Date::number( (int) ( $cart['item_count'] ?? 0 ) );
			$vars['{cart_items}']    = self::format_cart_items( $cart );
			$vars['{recovery_link}'] = WCMA_Carts::recovery_url( $cart );

			$contents = maybe_unserialize( $cart['cart_contents'] ?? '' );

			if ( is_array( $contents ) && $contents ) {
				$first = reset( $contents );

				if ( ! empty( $first['product_id'] ) ) {
					$product = wc_get_product( $first['product_id'] );

					if ( $product ) {
						$vars['{product_name}']  = $product->get_name();
						$vars['{product_link}']  = get_permalink( $product->get_id() );
						$vars['{product_price}'] = WCMA_Date::digits( trim( wp_strip_all_tags( $product->get_price_html() ) ) );
					}
				}
			}
		}

		// --- کد تخفیف ---
		if ( ! empty( $data['coupon'] ) && is_array( $data['coupon'] ) ) {
			$vars['{coupon_code}']   = $data['coupon']['code'] ?? '';
			$vars['{coupon_amount}'] = WCMA_Date::digits( $data['coupon']['label'] ?? '' );
			$vars['{coupon_expiry}'] = $data['coupon']['expiry'] ?? '';
		}

		// --- مقادیر صریح ---
		if ( ! empty( $data['vars'] ) && is_array( $data['vars'] ) ) {
			foreach ( $data['vars'] as $key => $value ) {
				$vars[ '{' . trim( $key, '{}' ) . '}' ] = $value;
			}
		}

		$email = $vars['{email}'];

		// --- آمار مشتری و لینک‌های اختصاصی ---
		$link_user = (int) ( $data['user_id'] ?? 0 );

		if ( ! $link_user && $email ) {
			$found     = get_user_by( 'email', $email );
			$link_user = $found ? $found->ID : 0;
		}

		if ( $link_user && function_exists( 'wc_get_customer_order_count' ) ) {
			$vars['{customer_orders}'] = WCMA_Date::number( (int) wc_get_customer_order_count( $link_user ) );

			if ( function_exists( 'wc_get_customer_total_spent' ) ) {
				$vars['{customer_total}'] = WCMA_Date::digits( self::strip_price( wc_price( (float) wc_get_customer_total_spent( $link_user ) ) ) );
			}
		}

		if ( $link_user && class_exists( 'WCMA_Bot_Link' ) ) {
			foreach ( array_keys( WCMA_Bot_Link::linkable() ) as $messenger ) {
				$vars[ '{' . $messenger . '_connect}' ] = WCMA_Bot_Link::connect_url( $messenger, $link_user );
			}
		}

		if ( $email ) {
			$vars['{unsubscribe}'] = WCMA_Subscribers::unsubscribe_url( $email );
		}

		$vars['{full_name}'] = trim( $vars['{first_name}'] . ' ' . $vars['{last_name}'] );

		if ( '' === $vars['{full_name}'] ) {
			$vars['{full_name}'] = 'مشتری گرامی';
		}

		if ( '' === $vars['{first_name}'] ) {
			$vars['{first_name}'] = 'مشتری';
		}

		return $vars;
	}

	/**
	 * تبدیل خروجی wc_price به متن ساده.
	 *
	 * @param string $html خروجی HTML قیمت.
	 * @return string
	 */
	protected static function strip_price( $html ) {
		return trim( html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES, 'UTF-8' ) );
	}

	/**
	 * قالب‌بندی اقلام سفارش به صورت جدول HTML.
	 *
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	public static function format_order_items( $order ) {
		$rows = '';

		foreach ( $order->get_items() as $item ) {
			$rows .= sprintf(
				'<tr><td style="padding:8px;border-bottom:1px solid #eee">%s</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:center">%d</td><td style="padding:8px;border-bottom:1px solid #eee">%s</td></tr>',
				esc_html( $item->get_name() ),
				(int) $item->get_quantity(),
				wp_kses_post( wc_price( $item->get_total() ) )
			);
		}

		if ( '' === $rows ) {
			return '';
		}

		return '<table style="width:100%;border-collapse:collapse;text-align:right" dir="rtl"><thead><tr><th style="padding:8px;text-align:right">محصول</th><th style="padding:8px">تعداد</th><th style="padding:8px;text-align:right">قیمت</th></tr></thead><tbody>' . $rows . '</tbody></table>';
	}

	/**
	 * قالب‌بندی اقلام سبد خرید رها شده.
	 *
	 * @param array $cart رکورد سبد.
	 * @return string
	 */
	public static function format_cart_items( array $cart ) {
		$contents = maybe_unserialize( $cart['cart_contents'] ?? '' );
		if ( ! is_array( $contents ) || ! $contents ) {
			return '';
		}

		$rows = '';
		foreach ( $contents as $line ) {
			$product_id = ! empty( $line['variation_id'] ) ? $line['variation_id'] : ( $line['product_id'] ?? 0 );
			$product    = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$image = $product->get_image_id() ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );

			$rows .= sprintf(
				'<tr><td style="padding:8px;border-bottom:1px solid #eee;width:64px"><img src="%s" width="56" height="56" alt="" style="border-radius:8px" /></td><td style="padding:8px;border-bottom:1px solid #eee"><a href="%s" style="color:#111;text-decoration:none">%s</a></td><td style="padding:8px;border-bottom:1px solid #eee;text-align:center">%d</td><td style="padding:8px;border-bottom:1px solid #eee">%s</td></tr>',
				esc_url( $image ),
				esc_url( get_permalink( $product->get_id() ) ),
				esc_html( $product->get_name() ),
				(int) ( $line['quantity'] ?? 1 ),
				wp_kses_post( wc_price( (float) ( $line['line_total'] ?? $product->get_price() ) ) )
			);
		}

		if ( '' === $rows ) {
			return '';
		}

		return '<table style="width:100%;border-collapse:collapse;text-align:right" dir="rtl"><tbody>' . $rows . '</tbody></table>';
	}

	/**
	 * تبدیل متن HTML به متن ساده مناسب پیامک.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	public static function to_plain( $text ) {
		$text = (string) $text;

		// محتوای اسکریپت و استایل باید کامل حذف شود، نه فقط تگ آن؛ در غیر این صورت
		// کدهای CSS/JS وارد متن پیامک می‌شوند و هزینه و خرابی به بار می‌آورند.
		$text = preg_replace( '#<(script|style|head)\b[^>]*>.*?</\1>#is', '', $text );

		// تگ‌های بلوکی به خط جدید تبدیل می‌شوند تا متن به‌هم نچسبد.
		$text = preg_replace( '#<br\s*/?>#i', "\n", $text );
		$text = preg_replace( '#</(p|div|tr|li|h[1-6]|table|ul|ol)>#i', "\n", $text );
		$text = preg_replace( '#</td>\s*#i', ' ', $text );

		$text = wp_strip_all_tags( $text );
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );

		// فاصله‌های اضافی ناشی از قالب HTML.
		$text = preg_replace( '/[ \t]{2,}/', ' ', $text );
		$text = preg_replace( "/[ \t]*\n[ \t]*/", "\n", $text );
		$text = preg_replace( "/\n{3,}/", "\n\n", $text );

		return trim( $text );
	}
}
