<?php
/**
 * تب گزارش‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended
$filters = array(
	'workflow' => isset( $_GET['f_workflow'] ) ? sanitize_key( wp_unslash( $_GET['f_workflow'] ) ) : '',
	'channel'  => isset( $_GET['f_channel'] ) ? sanitize_key( wp_unslash( $_GET['f_channel'] ) ) : '',
	'status'   => isset( $_GET['f_status'] ) ? sanitize_key( wp_unslash( $_GET['f_status'] ) ) : '',
	'search'   => isset( $_GET['f_search'] ) ? sanitize_text_field( wp_unslash( $_GET['f_search'] ) ) : '',
	'from'     => isset( $_GET['f_from'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_GET['f_from'] ) ) ) : '',
	'to'       => isset( $_GET['f_to'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_GET['f_to'] ) ) ) : '',
	'page'     => isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1,
	'per_page' => WCMA_Admin::per_page( 'f_per' ),
);
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$result = WCMA_Logger::query( $filters );
$stats  = WCMA_Logger::stats( 30 );
$pages  = (int) ceil( $result['total'] / $filters['per_page'] );

$workflow_labels = array(
	'abandoned_cart'  => 'سبد رها شده',
	'review_reminder' => 'یادآوری ثبت نظر',
	'review_reward'   => 'پاداش ثبت نظر',
	'winback'         => 'خرید مجدد',
	'stock_alert'     => 'هشدار موجودی',
	'vip_club'        => 'باشگاه مشتریان',
	'birthday'        => 'تبریک تولد',
	'order_status'    => 'وضعیت سفارش',
	'campaign'        => 'کمپین',
	'test'            => 'تست',
);

$channel_labels = WCMA_Sender::channels();
?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat wcma-stat--blue">
		<span class="wcma-stat__icon dashicons dashicons-yes-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['sent'] ) ); ?></span>
			<span class="wcma-stat__label">ارسال موفق (۳۰ روز)</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--red">
		<span class="wcma-stat__icon dashicons dashicons-warning"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['failed'] ) ); ?></span>
			<span class="wcma-stat__label">ارسال ناموفق</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-cart"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['conversions'] ) ); ?></span>
			<span class="wcma-stat__label">تبدیل به خرید</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-money-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo wp_kses_post( WCMA_Date::price( $stats['revenue'] ) ); ?></span>
			<span class="wcma-stat__label">درآمد منتسب</span>
		</div>
	</div>
</div>

<?php WCMA_Admin_Fields::card_start( 'عملکرد به تفکیک ورک‌فلو (۳۰ روز اخیر)', '', 'chart-bar' ); ?>
	<?php if ( ! empty( $stats['by_workflow'] ) ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>ورک‌فلو</th>
						<th>ارسال موفق</th>
						<th>ناموفق</th>
						<th>تبدیل</th>
						<th>نرخ تبدیل</th>
						<th>درآمد</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $stats['by_workflow'] as $wf => $data ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $workflow_labels[ $wf ] ?? $wf ); ?></strong></td>
							<td><?php echo esc_html( number_format_i18n( $data['sent'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $data['failed'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $data['conversions'] ) ); ?></td>
							<td><?php echo esc_html( $data['sent'] > 0 ? number_format_i18n( round( ( $data['conversions'] / $data['sent'] ) * 100, 1 ), 1 ) . '٪' : '—' ); ?></td>
							<td><?php echo wp_kses_post( WCMA_Date::price( $data['revenue'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-empty">داده‌ای برای نمایش وجود ندارد.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'گزارش ارسال‌ها', '', 'list-view' ); ?>

	<form method="get" class="wcma-filters is-instant">
		<input type="hidden" name="page" value="wcma" />
		<input type="hidden" name="tab" value="reports" />

		<input type="search" name="f_search" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="جستجوی گیرنده یا موضوع" />

		<select name="f_workflow">
			<option value="">همه‌ی ورک‌فلوها</option>
			<?php foreach ( $workflow_labels as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $filters['workflow'], $key ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>

		<select name="f_channel">
			<option value="">همه‌ی کانال‌ها</option>
			<?php foreach ( $channel_labels as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $filters['channel'], $key ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>

		<select name="f_status">
			<option value="">همه‌ی وضعیت‌ها</option>
			<option value="sent" <?php selected( $filters['status'], 'sent' ); ?>>موفق</option>
			<option value="failed" <?php selected( $filters['status'], 'failed' ); ?>>ناموفق</option>
		</select>

		<input type="date" data-wcma-jalali name="f_from" value="<?php echo esc_attr( $filters['from'] ); ?>" title="از تاریخ" />
		<input type="date" data-wcma-jalali name="f_to" value="<?php echo esc_attr( $filters['to'] ); ?>" title="تا تاریخ" />

		<?php
		/*
		 * دکمه‌ی فیلتر برداشته شده و هر تغییری بی‌درنگ اعمال می‌شود؛ این دکمه
		 * فقط برای صفحه‌کلید و مرورگرِ بدون جاوااسکریپت می‌ماند و دیده نمی‌شود.
		 */
		?>
		<button type="submit" class="screen-reader-text">اعمال فیلتر</button>
		<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'reports' ) ); ?>" class="wcma-btn wcma-btn--ghost">پاک کردن</a>
	</form>

	<?php
	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 'f_per',
			'current' => $filters['per_page'],
			'total'   => (int) $result['total'],
		)
	);
	?>

	<?php if ( $result['items'] ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>تاریخ</th>
						<th>ورک‌فلو</th>
						<th>کانال</th>
						<th>گیرنده</th>
						<th>موضوع / متن</th>
						<th>کد تخفیف</th>
						<th>وضعیت</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $result['items'] as $row ) : ?>
						<tr>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $row['created_at'] ); ?></td>
							<td>
								<?php echo esc_html( $workflow_labels[ $row['workflow'] ] ?? $row['workflow'] ); ?>
								<?php if ( $row['step'] ) : ?>
									<br /><small class="wcma-muted"><?php echo esc_html( $row['step'] ); ?></small>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( $channel_labels[ $row['channel'] ] ?? $row['channel'] ); ?></td>
							<td class="wcma-ltr"><?php echo esc_html( $row['recipient'] ); ?></td>
							<td class="wcma-truncate" title="<?php echo esc_attr( wp_strip_all_tags( $row['message'] ) ); ?>">
								<?php echo esc_html( $row['subject'] ? $row['subject'] : mb_substr( wp_strip_all_tags( (string) $row['message'] ), 0, 60 ) ); ?>
							</td>
							<td class="wcma-ltr"><?php echo esc_html( $row['coupon_code'] ? $row['coupon_code'] : '—' ); ?></td>
							<td>
								<?php if ( 'failed' === $row['status'] ) : ?>
									<span class="wcma-badge wcma-badge--red" title="<?php echo esc_attr( $row['error_message'] ); ?>">ناموفق</span>
								<?php elseif ( $row['converted'] ) : ?>
									<span class="wcma-badge wcma-badge--green">منجر به خرید</span>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--blue">ارسال شد</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'paged',
				'current' => (int) $filters['page'],
				'pages'   => $pages,
			)
		);
		?>
	<?php else : ?>
		<p class="wcma-empty">گزارشی با این فیلترها پیدا نشد.</p>
	<?php endif; ?>

	<div class="wcma-actions wcma-actions--split">
		<div class="wcma-export">
			<?php
			$wcma_report_args = array(
				'wcma_report' => 'print',
				'f_from'      => $filters['from'],
				'f_to'        => $filters['to'],
				'_wpnonce'    => wp_create_nonce( 'wcma_report_print' ),
			);
			?>

			<a
				href="<?php echo esc_url( add_query_arg( $wcma_report_args, WCMA_Admin::tab_url( 'reports' ) ) ); ?>"
				class="wcma-btn wcma-btn--primary"
				target="_blank"
				rel="noopener"
			>
				<span class="dashicons dashicons-visibility"></span>
				مشاهده‌ی گزارش
			</a>

			<a
				href="<?php echo esc_url( add_query_arg( array_merge( $wcma_report_args, array( 'auto' => 1 ) ), WCMA_Admin::tab_url( 'reports' ) ) ); ?>"
				class="wcma-btn wcma-btn--secondary"
				target="_blank"
				rel="noopener"
			>
				<span class="dashicons dashicons-media-document"></span>
				دریافت PDF
			</a>

			<form method="post">
				<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
				<input type="hidden" name="wcma_action" value="export_logs" />
				<input type="hidden" name="f_workflow" value="<?php echo esc_attr( $filters['workflow'] ); ?>" />
				<input type="hidden" name="f_channel" value="<?php echo esc_attr( $filters['channel'] ); ?>" />
				<input type="hidden" name="f_status" value="<?php echo esc_attr( $filters['status'] ); ?>" />
				<input type="hidden" name="f_search" value="<?php echo esc_attr( $filters['search'] ); ?>" />
				<input type="hidden" name="f_from" value="<?php echo esc_attr( $filters['from'] ); ?>" />
				<input type="hidden" name="f_to" value="<?php echo esc_attr( $filters['to'] ); ?>" />
				<button type="submit" class="wcma-btn wcma-btn--secondary">
					<span class="dashicons dashicons-media-spreadsheet"></span>
					خروجی CSV (اکسل)
				</button>
			</form>

			<span class="wcma-field__desc">
				«دریافت PDF» گزارش را باز می‌کند و بی‌درنگ پنجره‌ی چاپ می‌آید؛ در آن پنجره مقصد را
				روی <strong>Save as PDF</strong> (یا «ذخیره به‌شکل PDF») بگذارید تا فایل روی
				رایانه‌تان ذخیره شود. هر سه خروجی از همین فیلترهای بالا پیروی می‌کنند.
			</span>
		</div>

		<form method="post">
			<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
			<input type="hidden" name="wcma_action" value="clear_logs" />
			<button type="submit" class="wcma-btn wcma-btn--danger" data-confirm="همه‌ی گزارش‌ها حذف شوند؟ این کار برگشت‌پذیر نیست.">
				<span class="dashicons dashicons-trash"></span>
				پاک کردن همه‌ی گزارش‌ها
			</button>
		</form>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>
