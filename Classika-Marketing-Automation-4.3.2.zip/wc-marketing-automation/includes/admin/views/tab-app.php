<?php
/**
 * برگه‌ی دسترسی اپلیکیشن: نشانی وب‌اپ، حساب‌های کنسول و تاریخچه‌ی اقدام‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_slug    = WCMA_App_Route::slug();
$wcma_app_url = WCMA_App_Route::url();
$wcma_users   = WCMA_App_Users::all();
$wcma_https   = is_ssl();
$wcma_ready   = WCMA_Install::table_exists( 'wcma_app_users' );
$wcma_base    = WCMA_Admin::tab_url( 'app' );
$wcma_edit    = isset( $_GET['account'] ) ? (int) $_GET['account'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wcma_row     = $wcma_edit ? WCMA_App_Users::get( $wcma_edit ) : null;
$wcma_seeing  = isset( $_GET['history'] ) ? (int) $_GET['history'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>

<?php WCMA_Admin_Fields::card_start( 'کنسول اپراتور', 'گفتگوها و پرونده‌ی مشتریان را از موبایل مدیریت کنید، بیرون از پیشخوان وردپرس.', 'smartphone', 'وب‌اپ روی همین دامنه اجرا می‌شود و روی صفحه‌ی گوشی نصب می‌شود؛ نیازی به فروشگاه اپ نیست.', 'app-console' ); ?>

	<?php if ( ! $wcma_https ) : ?>
		<div class="wcma-notice wcma-notice--error">
			<span class="dashicons dashicons-warning"></span>
			<span>سایت روی HTTPS نیست. نصب وب‌اپ و ذخیره‌ی امن رمز، هر دو به HTTPS نیاز دارند.</span>
		</div>
	<?php endif; ?>

	<?php if ( ! $wcma_ready ) : ?>
		<div class="wcma-notice wcma-notice--error">
			<span class="dashicons dashicons-warning"></span>
			<span>جدول حساب‌ها ساخته نشده است. در «تنظیمات عمومی» دکمه‌ی ترمیم جدول‌ها را بزنید.</span>
		</div>
	<?php endif; ?>

	<div class="wcma-app-link">
		<span class="dashicons dashicons-external"></span>
		<div>
			<strong>نشانی وب‌اپ</strong>
			<input type="text" readonly dir="ltr" value="<?php echo esc_attr( $wcma_app_url ); ?>" onfocus="this.select()" class="wcma-ltr-input" />
			<p class="wcma-field__desc">
				این نشانی را در مرورگر گوشی باز کنید و از منوی مرورگر «افزودن به صفحه‌ی اصلی» را بزنید.
			</p>
		</div>
		<a href="<?php echo esc_url( $wcma_app_url ); ?>" target="_blank" rel="noopener" class="wcma-btn wcma-btn--primary">
			<span class="dashicons dashicons-visibility"></span>
			باز کردن
		</a>
	</div>

	<?php if ( $wcma_slug && get_page_by_path( $wcma_slug ) ) : ?>
		<div class="wcma-notice wcma-notice--error">
			<span class="dashicons dashicons-warning"></span>
			<span>برگه‌ای با همین مسیر در سایت هست و وب‌اپ روی آن را می‌پوشاند. مسیر دیگری بگذارید.</span>
		</div>
	<?php endif; ?>

	<form method="post" class="wcma-form">
		<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
		<input type="hidden" name="wcma_action" value="save_settings" />

		<?php
		WCMA_Admin_Fields::text(
			'app_slug',
			'مسیر دلخواه روی همین دامنه',
			array(
				'placeholder' => 'app',
				'description' => sprintf(
					'فقط مسیر را بنویسید، نه نشانی کامل. مثلاً با نوشتن <code>app</code> نشانی می‌شود <code dir="ltr">%s</code>. خالی بگذارید تا نشانی پیش‌فرض بالا بماند.',
					esc_html( home_url( '/app/' ) )
				),
				'help'        => 'افزونه واقعاً همان مسیر را سرو می‌کند؛ نیازی به ساخت برگه یا کپی فایل نیست. اگر مسیر با برگه‌ای از سایت یکی باشد، برگه پوشانده می‌شود.',
			)
		);
		?>

		<?php WCMA_Admin_Fields::submit(); ?>
	</form>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'حساب‌های کنسول', 'برای هر همکار یک حساب با رمز دلخواه بسازید؛ نیازی به دادن دسترسی پیشخوان وردپرس نیست.', 'admin-users', 'این حساب‌ها از کاربران وردپرس جدا هستند و فقط به کنسول اپراتور دسترسی دارند.' ); ?>

	<form method="post" class="wcma-account-form">
		<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
		<input type="hidden" name="wcma_action" value="app_user_save" />
		<input type="hidden" name="account_id" value="<?php echo esc_attr( $wcma_edit ); ?>" />

		<h3 class="wcma-subtitle"><?php echo $wcma_row ? 'ویرایش حساب' : 'حساب تازه'; ?></h3>

		<div class="wcma-account-grid">
			<label class="wcma-field__label">
				نام نمایشی
				<input type="text" name="account_name" value="<?php echo esc_attr( $wcma_row['name'] ?? '' ); ?>" placeholder="مثلاً سارا نوری" />
			</label>

			<label class="wcma-field__label">
				نام کاربری
				<input type="text" name="account_username" dir="ltr" value="<?php echo esc_attr( $wcma_row['username'] ?? '' ); ?>" placeholder="sara" required />
			</label>

			<label class="wcma-field__label">
				رمز
				<?php WCMA_Admin_Fields::help( 'دست‌کم هشت نویسه. رمز درهم‌سازی می‌شود و دیگر قابل دیدن نیست؛ اگر فراموش شد، رمز تازه بگذارید.' ); ?>
				<input type="text" name="account_password" dir="ltr" autocomplete="new-password" placeholder="<?php echo $wcma_row ? 'خالی یعنی تغییر نکند' : 'رمز دلخواه'; ?>" />
			</label>

			<label class="wcma-field__label">
				نقش
				<?php WCMA_Admin_Fields::help( 'نقش تعیین می‌کند حساب در پنل چه چیزی را می‌بیند و چه کاری می‌تواند بکند. جدول زیر دقیقاً همان چیزی است که سرور هم بررسی می‌کند.' ); ?>
				<select name="account_role">
					<?php foreach ( WCMA_App_Users::roles() as $wcma_key => $wcma_label ) : ?>
						<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( $wcma_row['role'] ?? 'agent', $wcma_key ); ?>><?php echo esc_html( $wcma_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
		</div>

		<div class="wcma-table-wrap">
			<table class="wcma-table wcma-caps-table">
				<thead>
					<tr>
						<th>دسترسی</th>
						<?php foreach ( WCMA_App_Users::roles() as $wcma_rkey => $wcma_rlabel ) : ?>
							<th><?php echo esc_html( strtok( $wcma_rlabel, ' (' ) ); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( WCMA_App_Users::cap_labels() as $wcma_cap => $wcma_cap_label ) : ?>
						<tr>
							<td><?php echo esc_html( $wcma_cap_label ); ?></td>
							<?php foreach ( array_keys( WCMA_App_Users::roles() ) as $wcma_rkey ) : ?>
								<td class="wcma-caps-cell">
									<?php if ( WCMA_App_Users::role_can( $wcma_rkey, $wcma_cap ) ) : ?>
										<span class="dashicons dashicons-yes-alt" style="color:#16a34a" title="دارد"></span>
										<span class="screen-reader-text">دارد</span>
									<?php else : ?>
										<span class="dashicons dashicons-minus" style="color:#cbd5e1" title="ندارد"></span>
										<span class="screen-reader-text">ندارد</span>
									<?php endif; ?>
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<label class="wcma-account-active">
			<input type="checkbox" name="account_active" value="1" <?php checked( $wcma_row ? (int) $wcma_row['active'] : 1, 1 ); ?> />
			حساب فعال باشد
		</label>

		<div class="wcma-actions">
			<button type="submit" class="wcma-btn wcma-btn--primary">
				<span class="dashicons dashicons-yes"></span>
				<?php echo $wcma_row ? 'ذخیره‌ی تغییرات' : 'ساخت حساب'; ?>
			</button>

			<?php if ( $wcma_row ) : ?>
				<a href="<?php echo esc_url( $wcma_base ); ?>" class="wcma-btn wcma-btn--ghost">انصراف</a>
			<?php endif; ?>
		</div>
	</form>

	<?php if ( $wcma_users ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>نام</th>
						<th>نام کاربری</th>
						<th>نقش</th>
						<th>وضعیت</th>
						<th>ربات</th>
						<th>دستگاه‌ها</th>
						<th>آخرین ورود</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_users as $wcma_user ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $wcma_user['name'] ); ?></strong></td>
							<td dir="ltr" class="wcma-ltr"><?php echo esc_html( $wcma_user['username'] ); ?></td>
							<td>
								<?php echo esc_html( strtok( (string) ( WCMA_App_Users::roles()[ $wcma_user['role'] ] ?? $wcma_user['role'] ), ' (' ) ); ?>
								<br />
								<small class="wcma-muted">
									<?php
									$wcma_caps = array();

									foreach ( WCMA_App_Users::caps( $wcma_user['role'] ) as $wcma_cap ) {
										$wcma_caps[] = WCMA_App_Users::cap_labels()[ $wcma_cap ] ?? $wcma_cap;
									}

									echo esc_html( implode( '، ', $wcma_caps ) );
									?>
								</small>
							</td>
							<td>
								<?php if ( $wcma_user['active'] ) : ?>
									<span class="wcma-badge" style="background:#dcfce7;color:#14532d">فعال</span>
								<?php else : ?>
									<span class="wcma-badge" style="background:#fee2e2;color:#7f1d1d">غیرفعال</span>
								<?php endif; ?>
							</td>
							<td class="wcma-staffbot" data-user="<?php echo esc_attr( (int) $wcma_user['id'] ); ?>">
								<?php if ( ! empty( $wcma_user['tg_chat_id'] ) ) : ?>
									<span class="wcma-badge" style="background:#dcfce7;color:#14532d">
										<?php echo esc_html( WCMA_Bot_Staff::label( WCMA_Bot_Staff::channel_of( $wcma_user ) ) ); ?>
									</span>
									<button type="button" class="wcma-btn wcma-btn--ghost wcma-staff-unlink" data-user="<?php echo esc_attr( (int) $wcma_user['id'] ); ?>" data-confirm="اتصال این حساب به ربات باز شود؟">قطع</button>
								<?php else : ?>
									<button type="button" class="wcma-btn wcma-btn--ghost wcma-staff-code" data-user="<?php echo esc_attr( (int) $wcma_user['id'] ); ?>">کد اتصال</button>
								<?php endif; ?>
								<div class="wcma-staffbot__out" hidden></div>
							</td>
							<td><?php echo esc_html( WCMA_Date::number( WCMA_App_Users::device_count( (int) $wcma_user['id'] ) ) ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_user['last_login_at'] ?? '', 'datetime' ); ?></td>
							<td class="wcma-nowrap">
								<a href="<?php echo esc_url( add_query_arg( 'account', (int) $wcma_user['id'], $wcma_base ) ); ?>" class="wcma-btn wcma-btn--ghost">ویرایش</a>
								<a href="<?php echo esc_url( add_query_arg( 'history', (int) $wcma_user['id'], $wcma_base ) ); ?>" class="wcma-btn wcma-btn--ghost">تاریخچه</a>

								<form method="post" class="wcma-inline-form">
									<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
									<input type="hidden" name="wcma_action" value="app_user_revoke" />
									<input type="hidden" name="account_id" value="<?php echo esc_attr( (int) $wcma_user['id'] ); ?>" />
									<button type="submit" class="wcma-btn wcma-btn--ghost" data-confirm="همه‌ی دستگاه‌های این حساب از کنسول خارج می‌شوند. ادامه؟">خروج دستگاه‌ها</button>
								</form>

								<form method="post" class="wcma-inline-form">
									<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
									<input type="hidden" name="wcma_action" value="app_user_delete" />
									<input type="hidden" name="account_id" value="<?php echo esc_attr( (int) $wcma_user['id'] ); ?>" />
									<button type="submit" class="wcma-btn wcma-btn--ghost" data-confirm="این حساب کامل حذف شود؟">حذف</button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-field__desc">هنوز حسابی ساخته نشده است. با فرم بالا اولین حساب را بسازید.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php
WCMA_Admin_Fields::card_start(
	'کنسول کارکنان در ربات',
	'همکاران حساب کنسولشان را به ربات تلگرام وصل می‌کنند و از همان‌جا سرنخ ثبت می‌کنند، کارهای امروزشان را می‌بینند و یادآوری می‌گیرند.',
	'admin-comments',
	'هر حساب یک کد یک‌بارمصرف می‌گیرد؛ با زدن آن در ربات، آن چت به همان حساب گره می‌خورد. کد ۲۴ ساعت اعتبار دارد.',
	'staff-bot'
);
?>
	<?php
	/*
	 * این کلید باید داخل فرم باشد و دکمه‌ی ذخیره داشته باشد؛ وگرنه با
	 * تازه‌سازی صفحه به حالت قبل برمی‌گردد، چون چیزی به سرور نرفته است.
	 */
	?>
	<form method="post" class="wcma-form">
		<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
		<input type="hidden" name="wcma_action" value="save_settings" />

		<?php
		WCMA_Admin_Fields::toggle(
			'staff_bot',
			'کنسول کارکنان روشن باشد',
			'تا وقتی خاموش است، ربات پیام همکاران را مثل پیام مشتری‌ها پاسخ می‌دهد.'
		);
		?>

		<?php WCMA_Admin_Fields::submit(); ?>
	</form>

	<?php $wcma_bots = WCMA_Bot_Staff::channels(); ?>

	<?php if ( ! $wcma_bots ) : ?>
		<p class="wcma-field__desc">
			هنوز هیچ رباتی آماده نیست. در برگه‌ی «کانال‌های ارتباطی» توکن دست‌کم یکی از
			تلگرام، بله یا روبیکا را وارد و همان کانال را روشن کنید.
		</p>
	<?php else : ?>
		<p class="wcma-field__desc">
			کنسول روی این ربات‌ها کار می‌کند:
			<strong><?php echo esc_html( implode( '، ', $wcma_bots ) ); ?></strong>.
			کد اتصال به حساب گره می‌خورد، نه به یک ربات؛ همکار می‌تواند آن را در هرکدام بزند.
		</p>
	<?php endif; ?>

	<h3 class="wcma-subtitle">همکار در ربات چه می‌بیند؟</h3>

	<ul class="wcma-list">
		<li><b>➕ ثبت سرنخ تازه</b> — نام، موبایل، یادداشت و تاریخ پیگیری را گام‌به‌گام می‌پرسد و پرونده را در CRM می‌سازد.</li>
		<li><b>📋 کارهای امروز</b> — پیگیری‌های سررسیدشده‌ی خودش، با <span dir="ltr">/done ۱۲</span> برای بستن هرکدام.</li>
		<li><b>👤 حساب من</b> — نام، نقش و شمار کارهای باز.</li>
		<li>یادآوری پیگیری‌ها سر وقتشان به همین‌جا می‌رسد.</li>
	</ul>

	<p class="wcma-field__desc">
		برای کسانی که تایپ را ترجیح می‌دهند:
		<code dir="ltr">/lead نام خانوادگی | ۰۹۱۲۳۴۵۶۷۸۹ | یادداشت | فردا</code>
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php
$wcma_hist = WCMA_App_Users::history(
	array(
		'user_id'  => $wcma_seeing,
		'per_page' => WCMA_Admin::per_page( 'h_per' ),
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		'page'     => isset( $_GET['hpage'] ) ? max( 1, (int) $_GET['hpage'] ) : 1,
	)
);
$wcma_who  = $wcma_seeing ? WCMA_App_Users::get( $wcma_seeing ) : null;
?>

<?php WCMA_Admin_Fields::card_start( 'تاریخچه‌ی اقدام‌ها' . ( $wcma_who ? ' — ' . $wcma_who['name'] : '' ), 'هر کاری که از کنسول انجام شده، با زمان و جزئیات.', 'backup', 'ورود و خروج، باز کردن گفتگو، پاسخ به مشتری، دیدن پرونده و ثبت یادداشت همگی ثبت می‌شوند.' ); ?>

	<?php if ( $wcma_users ) : ?>
		<div class="wcma-who-filter">
			<span class="wcma-who-filter__label">
				<span class="dashicons dashicons-filter"></span>
				گردش کار چه کسی؟
			</span>

			<a
				href="<?php echo esc_url( $wcma_base ); ?>"
				class="wcma-who <?php echo $wcma_seeing ? '' : 'is-active'; ?>"
			>همه‌ی همکاران</a>

			<?php foreach ( $wcma_users as $wcma_user ) : ?>
				<a
					href="<?php echo esc_url( add_query_arg( 'history', (int) $wcma_user['id'], $wcma_base ) ); ?>"
					class="wcma-who <?php echo $wcma_seeing === (int) $wcma_user['id'] ? 'is-active' : ''; ?>"
				>
					<span class="dashicons dashicons-admin-users"></span>
					<?php echo esc_html( $wcma_user['name'] ); ?>
				</a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php
	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 'h_per',
			'current' => WCMA_Admin::per_page( 'h_per' ),
			'total'   => (int) $wcma_hist['total'],
		)
	);
	?>

	<?php if ( $wcma_hist['items'] ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>زمان</th>
						<th>چه کسی</th>
						<th>چه کاری</th>
						<th>جزئیات</th>
						<th>IP</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_hist['items'] as $wcma_event ) : ?>
						<tr>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_event['created_at'], 'datetime' ); ?></td>
							<td><strong><?php echo esc_html( $wcma_event['actor'] ); ?></strong></td>
							<td>
								<?php $wcma_bad = 'login_fail' === $wcma_event['action']; ?>
								<span class="wcma-badge" style="background:<?php echo $wcma_bad ? '#fee2e2' : '#e0e7ff'; ?>;color:<?php echo $wcma_bad ? '#7f1d1d' : '#3730a3'; ?>">
									<?php echo esc_html( WCMA_App_Users::actions()[ $wcma_event['action'] ] ?? $wcma_event['action'] ); ?>
								</span>
							</td>
							<td><?php echo esc_html( $wcma_event['detail'] ); ?></td>
							<td dir="ltr" class="wcma-ltr"><?php echo esc_html( $wcma_event['ip'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'hpage',
				'current' => (int) ( $wcma_hist['page'] ?? 1 ),
				'pages'   => (int) ( $wcma_hist['pages'] ?? 1 ),
			)
		);
		?>

		<p class="wcma-field__desc">
			<?php echo esc_html( WCMA_Date::number( $wcma_hist['total'] ) ); ?> رویداد ثبت شده است.
		</p>
	<?php else : ?>
		<p class="wcma-field__desc">هنوز اقدامی ثبت نشده است.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'برای توسعه‌دهنده', 'اگر خواستید کلاینت دیگری بنویسید یا به ابزارهایی مثل n8n وصل کنید.', 'editor-code' ); ?>
	<p class="wcma-field__desc">
		اول <code dir="ltr">POST /agent/login</code> با نام کاربری و رمز؛ توکن برمی‌گردد.
		بعد در همه‌ی درخواست‌ها: <code dir="ltr">Authorization: Bearer &lt;token&gt;</code>
	</p>

	<div class="wcma-table-wrap">
		<table class="wcma-table">
			<thead>
				<tr><th>متد</th><th>مسیر</th><th>کار</th></tr>
			</thead>
			<tbody>
				<?php
				$wcma_routes = array(
					array( 'POST', '/agent/login', 'ورود و گرفتن توکن' ),
					array( 'POST', '/agent/logout', 'باطل کردن توکن همین دستگاه' ),
					array( 'GET', '/agent/me', 'اطلاعات اپراتور و شمار خوانده‌نشده‌ها' ),
					array( 'GET', '/agent/chats', 'صندوق گفتگو' ),
					array( 'GET', '/agent/chats/{id}', 'پیام‌های یک گفتگو' ),
					array( 'POST', '/agent/chats/{id}/reply', 'پاسخ اپراتور' ),
					array( 'POST', '/agent/chats/{id}/mode', 'ربات یا اپراتور' ),
					array( 'GET', '/agent/contacts', 'فهرست و جستجوی مشتریان' ),
					array( 'GET', '/agent/contacts/{id}', 'پرونده و گردش کار' ),
					array( 'POST', '/agent/contacts/{id}/note', 'ثبت یادداشت' ),
					array( 'GET', '/agent/history', 'تاریخچه‌ی اقدام‌ها (فقط مدیر)' ),
				);
				?>
				<?php foreach ( $wcma_routes as $wcma_route ) : ?>
					<tr>
						<td><span class="wcma-badge wcma-badge--soft"><?php echo esc_html( $wcma_route[0] ); ?></span></td>
						<td><code dir="ltr"><?php echo esc_html( $wcma_route[1] ); ?></code></td>
						<td><?php echo esc_html( $wcma_route[2] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<p class="wcma-field__desc">
		پایه‌ی همه‌ی مسیرها: <code dir="ltr"><?php echo esc_html( rest_url( 'wcma/v1' ) ); ?></code>
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>
