<?php
/**
 * تب سفارش‌های اخیر با امکان ارسال دستی پیام.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- فیلتر خواندنی است.
$wcma_from = isset( $_GET['o_from'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_GET['o_from'] ) ) ) : '';
$wcma_to   = isset( $_GET['o_to'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_GET['o_to'] ) ) ) : '';
// phpcs:enable WordPress.Security.NonceVerification.Recommended

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wcma_opage = isset( $_GET['opage'] ) ? max( 1, (int) $_GET['opage'] ) : 1;
$wcma_oper  = WCMA_Admin::per_page( 'o_per' );

$wcma_args = array(
	'limit'   => $wcma_oper,
	'paged'   => $wcma_opage,
	'orderby' => 'date',
	'order'   => 'DESC',
	// برای شمار کل صفحه‌ها، نه فقط ردیف‌های همین صفحه.
	'paginate' => true,
);

/*
 * ووکامرس بازه را با یک رشته‌ی «از...تا» می‌گیرد. مرز پایین را ابتدای روز
 * و مرز بالا را پایان روز می‌گیریم تا سفارش‌های خودِ آن روز هم بیایند.
 */
if ( $wcma_from || $wcma_to ) {
	$wcma_args['date_created'] = sprintf(
		'%s...%s',
		$wcma_from ? $wcma_from . ' 00:00:00' : '1970-01-01 00:00:00',
		$wcma_to ? $wcma_to . ' 23:59:59' : gmdate( 'Y-m-d 23:59:59', current_time( 'timestamp' ) )
	);

}

/*
 * با paginate، ووکامرس یک شیء برمی‌گرداند که هم ردیف‌ها را دارد و هم شمار
 * کل صفحه‌ها؛ بدون آن راهی نبود که بدانیم صفحه‌ی بعدی وجود دارد یا نه.
 */
$wcma_page  = wc_get_orders( $wcma_args );
$orders     = is_object( $wcma_page ) ? (array) $wcma_page->orders : (array) $wcma_page;
$wcma_opgs  = is_object( $wcma_page ) ? (int) $wcma_page->max_num_pages : 1;
$wcma_ototal = is_object( $wcma_page ) ? (int) $wcma_page->total : count( $orders );
?>

<?php WCMA_Admin_Fields::card_start( 'سفارش‌های اخیر', 'وضعیت پیام‌های ارسال‌شده برای هر سفارش و امکان ارسال دستی.', 'list-view' ); ?>

	<form method="get" class="wcma-filters is-instant">
		<input type="hidden" name="page" value="wcma" />
		<input type="hidden" name="tab" value="orders" />

		<input type="date" data-wcma-jalali name="o_from" value="<?php echo esc_attr( $wcma_from ); ?>" title="از تاریخ" />
		<input type="date" data-wcma-jalali name="o_to" value="<?php echo esc_attr( $wcma_to ); ?>" title="تا تاریخ" />

		<button type="submit" class="screen-reader-text">اعمال فیلتر</button>

		<?php if ( $wcma_from || $wcma_to ) : ?>
			<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'orders' ) ); ?>" class="wcma-btn wcma-btn--ghost">پاک کردن</a>
		<?php endif; ?>
	</form>
	<?php
	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 'o_per',
			'current' => $wcma_oper,
			'total'   => $wcma_ototal,
		)
	);
	?>

	<?php if ( $orders ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>سفارش</th>
						<th>مشتری</th>
						<th>راه تماس</th>
						<th>مبلغ</th>
						<th>وضعیت</th>
						<th>پیام‌های ارسال‌شده</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php
					global $wpdb;
					$logs_table = WCMA_Logger::table();

					foreach ( $orders as $order ) :
						if ( ! $order instanceof WC_Order ) {
							continue;
						}

						$sent = $wpdb->get_results( // phpcs:ignore WordPress.DB
							$wpdb->prepare(
								"SELECT workflow, step, channel, status, created_at FROM {$logs_table} WHERE object_type = 'order' AND object_id = %d ORDER BY id DESC LIMIT 6", // phpcs:ignore WordPress.DB
								$order->get_id()
							),
							ARRAY_A
						);

						$recovered = 'yes' === $order->get_meta( '_wcma_recovered' );
						?>
						<tr>
							<td>
								<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>" target="_blank">#<?php echo esc_html( $order->get_order_number() ); ?></a>
								<?php if ( $recovered ) : ?>
									<span class="wcma-badge wcma-badge--green" title="این سفارش در پی پیام بازیابی ثبت شده است">بازیابی‌شده</span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ); ?></td>
							<td class="wcma-ltr">
								<?php echo esc_html( $order->get_billing_phone() ); ?>
								<br /><small><?php echo esc_html( $order->get_billing_email() ); ?></small>
							</td>
							<td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
							<td><span class="wcma-badge wcma-badge--gray"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span></td>
							<td>
								<?php if ( $sent ) : ?>
									<ul class="wcma-log-mini">
										<?php foreach ( $sent as $log ) : ?>
											<li class="<?php echo 'failed' === $log['status'] ? 'is-failed' : ''; ?>">
												<span class="dashicons dashicons-<?php echo 'sms' === $log['channel'] ? 'smartphone' : 'email-alt'; ?>"></span>
												<?php echo esc_html( $log['workflow'] . ' / ' . $log['step'] ); ?>
												<small><?php echo WCMA_Date::html( $log['created_at'] ); ?></small>
											</li>
										<?php endforeach; ?>
									</ul>
								<?php else : ?>
									<span class="wcma-muted">—</span>
								<?php endif; ?>
							</td>
							<td class="wcma-table__actions">
								<button type="button" class="wcma-btn wcma-btn--tiny wcma-order-action" data-order="<?php echo esc_attr( $order->get_id() ); ?>" data-op="remind">
									یادآوری پرداخت
								</button>
								<button type="button" class="wcma-btn wcma-btn--tiny wcma-order-action" data-order="<?php echo esc_attr( $order->get_id() ); ?>" data-op="review">
									درخواست ثبت نظر
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'opage',
				'current' => $wcma_opage,
				'pages'   => $wcma_opgs,
			)
		);
		?>
	<?php else : ?>
		<p class="wcma-empty">
			<?php echo ( $wcma_from || $wcma_to ) ? 'در این بازه‌ی تاریخ سفارشی ثبت نشده است.' : 'هنوز سفارشی ثبت نشده است.'; ?>
		</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
