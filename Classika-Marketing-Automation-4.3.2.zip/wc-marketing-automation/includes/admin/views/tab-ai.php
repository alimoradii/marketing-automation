<?php
/**
 * تب محتوای هوشمند (AI).
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$providers = WCMA_AI::providers();
$options   = array();

foreach ( $providers as $key => $data ) {
	$options[ $key ] = $data['label'];
}

$current   = isset( $providers[ WCMA_Settings::get( 'ai_provider', 'openai' ) ] ) ? WCMA_Settings::get( 'ai_provider', 'openai' ) : 'openai';
$suggested = WCMA_AI::models_for( $current );

// نقشه‌ی سرویس‌ها برای به‌روزرسانی زنده‌ی راهنما و مدل‌ها بدون نیاز به ذخیره.
$provider_map = array();

foreach ( $providers as $key => $data ) {
	$provider_map[ $key ] = array(
		'help'    => $data['help'],
		'models'  => $data['models'],
		'default' => $data['default'],
	);
}
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'اتصال به سرویس هوش مصنوعی', 'برای تولید خودکار متن پیام‌ها و کمپین‌ها.', 'lightbulb' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'ai_enabled', 'فعال بودن تولید محتوا با هوش مصنوعی' );

		WCMA_Admin_Fields::select(
			'ai_provider',
			'سرویس‌دهنده',
			$options,
			array( 'description' => '<span class="wcma-ai-help">' . esc_html( $providers[ $current ]['help'] ) . '</span>' )
		);

		WCMA_Admin_Fields::text(
			'ai_api_key',
			'کلید API',
			array(
				'type'        => 'password',
				'description' => 'کلید در دیتابیس سایت شما ذخیره می‌شود و فقط برای درخواست به سرویس انتخابی استفاده می‌گردد.',
			)
		);

		WCMA_Admin_Fields::text(
			'ai_model',
			'نام مدل',
			array(
				'placeholder'  => $providers[ $current ]['default'],
				'description'  => '<span class="wcma-ai-models"></span>',
			)
		);
		?>

		<div class="wcma-ai-base" data-only="openai_compatible">
			<?php
			WCMA_Admin_Fields::text(
				'ai_base_url',
				'آدرس پایه (فقط برای سرویس سازگار با OpenAI)',
				array(
					'placeholder' => 'https://api.example.com/v1',
					'description' => 'اگر از سرویس واسط داخلی استفاده می‌کنید، آدرس پایه‌ی آن را وارد کنید.',
				)
			);
			?>
		</div>

		<div class="wcma-ai-providers" data-providers="<?php echo esc_attr( wp_json_encode( $provider_map ) ); ?>"></div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'لحن و زمینه‌ی کسب‌وکار', 'هرچه اطلاعات دقیق‌تری بدهید، متن تولیدشده مناسب‌تر خواهد بود.', 'admin-comments' ); ?>
		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'ai_tone',
				'لحن نوشتار',
				array( 'placeholder' => 'صمیمی و حرفه‌ای' )
			);

			WCMA_Admin_Fields::select(
				'ai_language',
				'زبان خروجی',
				array(
					'fa' => 'فارسی',
					'en' => 'انگلیسی',
				)
			);

			WCMA_Admin_Fields::text(
				'ai_max_tokens',
				'حداکثر طول پاسخ',
				array(
					'type' => 'number',
					'min'  => 100,
					'max'  => 4000,
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::textarea(
			'ai_business_context',
			'معرفی کوتاه کسب‌وکار شما',
			array(
				'rows'        => 4,
				'placeholder' => 'مثال: فروشگاه اینترنتی چسب و مواد شیمیایی صنعتی با تمرکز بر مشتریان تولیدی و صنفی. ارسال سریع و مشاوره‌ی فنی رایگان.',
				'description' => 'این متن به‌عنوان زمینه به هوش مصنوعی داده می‌شود.',
			)
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php WCMA_Admin_Fields::card_start( 'آزمایشگاه تولید محتوا', 'یک متن نمونه بسازید و پس از ویرایش، در ورک‌فلوها یا کمپین‌ها استفاده کنید.', 'superhero' ); ?>
	<?php if ( ! WCMA_AI::is_ready() ) : ?>
		<div class="wcma-info wcma-info--warn">
			<span class="dashicons dashicons-warning"></span>
			<div>برای استفاده از این بخش، ابتدا سرویس هوش مصنوعی را فعال کرده و کلید API را ذخیره کنید.</div>
		</div>
	<?php endif; ?>

	<div class="wcma-row">
		<?php
		WCMA_Admin_Fields::select(
			'ai_lab_template',
			'نوع محتوا',
			WCMA_AI::templates(),
			array(
				'name'  => 'ai_lab_template',
				'value' => 'campaign_email',
			)
		);

		WCMA_Admin_Fields::select(
			'ai_lab_channel',
			'کانال مقصد',
			array(
				'email' => 'ایمیل (HTML)',
				'sms'   => 'پیامک (متن ساده و کوتاه)',
			),
			array(
				'name'  => 'ai_lab_channel',
				'value' => 'email',
			)
		);
		?>
	</div>

	<?php
	WCMA_Admin_Fields::textarea(
		'ai_lab_brief',
		'توضیح شما (اختیاری)',
		array(
			'rows'        => 3,
			'name'        => 'ai_lab_brief',
			'value'       => '',
			'placeholder' => 'مثال: مشتری سه محصول در سبد گذاشته و خرید را رها کرده. لحن دوستانه، اشاره به ارسال رایگان.',
		)
	);
	?>

	<div class="wcma-actions">
		<button type="button" class="wcma-btn wcma-btn--ai" id="wcma-ai-lab-generate" data-target="ai_lab_output">
			<span class="dashicons dashicons-superhero"></span>
			تولید محتوا
		</button>
	</div>

	<?php
	WCMA_Admin_Fields::textarea(
		'ai_lab_output',
		'متن تولیدشده',
		array(
			'rows'    => 10,
			'name'    => 'ai_lab_output',
			'value'   => '',
			'counter' => true,
		)
	);
	?>

	<div class="wcma-info">
		<span class="dashicons dashicons-info"></span>
		<div>متن تولیدشده را کپی کرده و در تب ورک‌فلو موردنظر یا در کمپین قرار دهید. پیش از ارسال انبوه، حتماً متن را بازخوانی کنید.</div>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>
