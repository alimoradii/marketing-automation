<?php
/**
 * تب تست ارسال پیامک و ایمیل.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
?>

<?php WCMA_Admin_Fields::card_start( 'تست ارسال', 'پیش از فعال کردن ورک‌فلوها، از صحت تنظیمات پیامک و ایمیل مطمئن شوید.', 'email-alt' ); ?>

	<div class="wcma-test">
		<div class="wcma-row">
			<?php
			$wcma_test_channels = array(
				'email' => 'ایمیل',
				'sms'   => 'پیامک',
			);

			foreach ( WCMA_Messengers::all() as $wcma_key => $wcma_msgr ) {
				$wcma_test_channels[ $wcma_key ] = $wcma_msgr['label'];
			}

			WCMA_Admin_Fields::select(
				'test_channel',
				'کانال ارسال',
				$wcma_test_channels,
				array(
					'name'  => 'test_channel',
					'value' => 'email',
				)
			);

			WCMA_Admin_Fields::text(
				'test_to',
				'گیرنده (ایمیل، شماره موبایل یا شناسه‌ی کانال/چت)',
				array(
					'name'  => 'test_to',
					'value' => $current_user->user_email,
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::text(
			'test_subject',
			'موضوع (فقط برای ایمیل)',
			array(
				'name'  => 'test_subject',
				'value' => 'پیام آزمایشی از ' . get_bloginfo( 'name' ),
			)
		);

		WCMA_Admin_Fields::placeholder_help( array() );

		WCMA_Admin_Fields::textarea(
			'test_message',
			'متن پیام',
			array(
				'rows'    => 6,
				'name'    => 'test_message',
				'value'   => '{first_name} عزیز، این یک پیام آزمایشی از {site_title} است. کد تخفیف نمونه: {coupon_code}',
				'counter' => true,
			)
		);
		?>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-send-test">
				<span class="dashicons dashicons-send"></span>
				ارسال پیام آزمایشی
			</button>
		</div>

		<div class="wcma-test__result" id="wcma-test-result"></div>
	</div>

	<div class="wcma-info">
		<span class="dashicons dashicons-info"></span>
		<div>
			<strong>نکته‌های عیب‌یابی</strong>
			<ul>
				<li>اگر ایمیل ارسال نشد، معمولاً مشکل از تنظیمات ارسال ایمیل سرور است؛ یک افزونه‌ی SMTP نصب و پیکربندی کنید.</li>
				<li>اگر پیامک ارسال نشد، اعتبار پنل، درست بودن کلید API و شماره‌ی خط فرستنده را بررسی کنید.</li>
				<li>برای واتساپ شماره‌ی موبایل گیرنده را وارد کنید؛ برای تلگرام، بله، ایتا و روبیکا شناسه‌ی کانال یا چت را.</li>
				<li>در واتساپ، پیام تبلیغاتی بدون «قالب تأییدشده» فقط تا ۲۴ ساعت پس از آخرین پیام مشتری تحویل داده می‌شود.</li>
				<li>نتیجه‌ی هر تست در تب «گزارش‌ها» با نام ورک‌فلو «تست» ثبت می‌شود و متن خطای دقیق سرویس‌دهنده در آن قابل مشاهده است.</li>
			</ul>
		</div>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'وضعیت زمان‌بند (Cron)', '', 'clock' ); ?>
	<?php
	$next_worker = wp_next_scheduled( 'wcma_worker_event' );
	$next_daily  = wp_next_scheduled( 'wcma_daily_event' );
	$queue       = WCMA_Queue::stats();
	?>
	<div class="wcma-minigrid">
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo esc_html( $next_worker ? WCMA_Date::format( $next_worker, 'datetime' ) : 'زمان‌بندی نشده' ); ?></span>
			<span class="wcma-mini__label">اجرای بعدی کارگر (هر ۵ دقیقه)</span>
		</div>
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo esc_html( $next_daily ? WCMA_Date::format( $next_daily, 'datetime' ) : 'زمان‌بندی نشده' ); ?></span>
			<span class="wcma-mini__label">اجرای بعدی وظایف روزانه</span>
		</div>
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo esc_html( number_format_i18n( $queue['pending'] ) ); ?></span>
			<span class="wcma-mini__label">پیام در صف</span>
		</div>
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo WCMA_Queue::in_quiet_hours() ? 'بله' : 'خیر'; ?></span>
			<span class="wcma-mini__label">اکنون در ساعات استراحت؟</span>
		</div>
	</div>

	<div class="wcma-info">
		<span class="dashicons dashicons-info"></span>
		<div>
			زمان‌بند وردپرس تنها با بازدید از سایت اجرا می‌شود. اگر سایت شما ترافیک کمی دارد، توصیه می‌شود کرون واقعی سرور را تنظیم کنید:
			<code dir="ltr">*/5 * * * * wget -q -O - <?php echo esc_html( site_url( 'wp-cron.php?doing_wp_cron' ) ); ?></code>
			و سپس در فایل <code>wp-config.php</code> مقدار <code dir="ltr">define('DISABLE_WP_CRON', true);</code> را قرار دهید.
		</div>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>
