<?php
/**
 * کارت عیب‌یابی ارسال هشدار موجودی.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

global $wpdb;

$wcma_logs_table  = WCMA_Logger::table();
$wcma_queue_table = WCMA_Queue::table();

$wcma_stuck = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
	$wpdb->prepare( "SELECT COUNT(*) FROM {$wcma_queue_table} WHERE workflow = %s AND status = 'pending'", 'stock_alert' ) // phpcs:ignore WordPress.DB
);

$wcma_recent_logs = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
	$wpdb->prepare( "SELECT * FROM {$wcma_logs_table} WHERE workflow = %s ORDER BY id DESC LIMIT 8", 'stock_alert' ), // phpcs:ignore WordPress.DB
	ARRAY_A
);

$wcma_missing   = WCMA_Install::missing_tables();
$wcma_quiet     = WCMA_Queue::quiet_hours_status();
$wcma_channel   = WCMA_Settings::get( 'st_channel', 'email' );
$wcma_sms_ready = WCMA_Settings::is( 'sms_enabled' ) && ( WCMA_Settings::get( 'sms_api_key' ) || WCMA_Settings::get( 'sms_username' ) );
$wcma_immediate = WCMA_Settings::is( 'st_send_immediately' );
$wcma_cron_ok   = (bool) wp_next_scheduled( 'wcma_worker_event' );
?>

<?php WCMA_Admin_Fields::card_start( 'عیب‌یابی ارسال', 'اگر پیامی دریافت نشد، این فهرست نشان می‌دهد مشکل کجاست.', 'sos' ); ?>

	<ul class="wcma-checklist">
		<?php
		$wcma_checks = array(
			array(
				'ok'   => ! in_array( 'wcma_stock_alerts', $wcma_missing, true ),
				'text' => in_array( 'wcma_stock_alerts', $wcma_missing, true )
					? 'جدول درخواست‌ها در دیتابیس ساخته نشده است — بدون آن هیچ ثبت‌نامی ذخیره نمی‌شود.'
					: 'جدول درخواست‌ها در دیتابیس موجود است.',
				'fix'  => 'دکمه‌ی «ساخت دوباره‌ی جدول‌ها» را بزنید.',
			),
			array(
				'ok'   => WCMA_Settings::is( 'enabled' ),
				'text' => 'کلید اصلی افزونه روشن است.',
				'fix'  => 'در تب «تنظیمات عمومی» افزونه را فعال کنید.',
			),
			array(
				'ok'   => WCMA_Settings::is( 'st_enabled' ),
				'text' => 'ورک‌فلو هشدار موجودی فعال است.',
				'fix'  => 'گزینه‌ی بالای همین صفحه را روشن کنید.',
			),
			array(
				'ok'   => WCMA_Settings::is( 'log_enabled' ),
				'text' => 'ثبت گزارش ارسال‌ها روشن است.',
				'fix'  => 'بدون آن، جدول پایین خالی می‌ماند و عیب‌یابی ممکن نیست.',
			),
			array(
				'ok'   => $wcma_immediate || $wcma_cron_ok,
				'text' => $wcma_immediate ? 'ارسال فوری روشن است (وابسته به کرون نیست).' : 'زمان‌بند وردپرس فعال است.',
				'fix'  => 'ارسال فوری را روشن کنید یا کرون واقعی سرور را تنظیم نمایید.',
			),
			array(
				// متن باید وضعیت واقعی را بگوید، نه همیشه جمله‌ی مثبت را.
				'ok'   => ! $wcma_quiet['active'] || WCMA_Settings::is( 'st_ignore_quiet_hours' ),
				'text' => $wcma_quiet['text']
					. ( $wcma_quiet['active'] && WCMA_Settings::is( 'st_ignore_quiet_hours' ) ? ' اما این ورک‌فلو از آن معاف شده است.' : '' ),
				'fix'  => 'یا گزینه‌ی «نادیده گرفتن ساعات استراحت» را در بالای همین صفحه روشن کنید، یا بازه را در تنظیمات عمومی تغییر دهید.',
			),
			array(
				'ok'   => in_array( $wcma_channel, array( 'email', 'both' ), true ) ? (bool) WCMA_Settings::get( 'from_email' ) : true,
				'text' => 'ایمیل فرستنده تنظیم شده است.',
				'fix'  => 'در تنظیمات عمومی ایمیل فرستنده را وارد کنید.',
			),
			array(
				'ok'   => in_array( $wcma_channel, array( 'sms', 'both' ), true ) ? $wcma_sms_ready : true,
				'text' => 'پنل پیامک پیکربندی شده است.',
				'fix'  => 'در تب «پیامک و پیام‌رسان‌ها» پنل را فعال و با دکمه‌ی تست بیازمایید.',
			),
			array(
				'ok'   => 0 === $wcma_stuck,
				'text' => 0 === $wcma_stuck
					? 'هیچ پیامی در صف معطل نمانده است.'
					: sprintf( '%s پیام در صف منتظر اجرای زمان‌بند است.', number_format_i18n( $wcma_stuck ) ),
				'fix'  => 'دکمه‌ی «اجرای فوری زمان‌بند» در بالای صفحه را بزنید؛ این دکمه ساعات استراحت را دور می‌زند و صف را همین حالا خالی می‌کند.',
			),
		);

		foreach ( $wcma_checks as $wcma_check ) :
			?>
			<li class="<?php echo $wcma_check['ok'] ? 'is-ok' : 'is-warn'; ?>">
				<span class="dashicons dashicons-<?php echo $wcma_check['ok'] ? 'yes-alt' : 'warning'; ?>"></span>
				<span>
					<?php echo esc_html( $wcma_check['text'] ); ?>
					<?php if ( ! $wcma_check['ok'] ) : ?>
						— <em><?php echo esc_html( $wcma_check['fix'] ); ?></em>
					<?php endif; ?>
				</span>
			</li>
		<?php endforeach; ?>
	</ul>

	<div class="wcma-actions">
		<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-repair-tables">
			<span class="dashicons dashicons-database"></span>
			ساخت دوباره‌ی جدول‌ها
		</button>
		<span id="wcma-repair-result"></span>
	</div>

	<h3 class="wcma-subtitle">شبیه‌سازی کامل مسیر</h3>

	<div class="wcma-simulate">
		<p class="wcma-field__desc">
			شناسه‌ی یک محصول <strong>موجود</strong> و یک ایمیل یا شماره وارد کنید. افزونه کل
			زنجیره را اجرا می‌کند و می‌گوید دقیقاً کدام مرحله شکست می‌خورد. پیام واقعی ارسال
			می‌شود، پس شماره یا ایمیل خودتان را بگذارید.
		</p>

		<div class="wcma-simulate__row">
			<select id="wcma-sim-picker" class="wc-product-search" data-placeholder="جستجوی محصول بر اساس نام..." data-action="woocommerce_json_search_products_and_variations" style="min-width:260px"></select>
			<input type="text" id="wcma-sim-contact" placeholder="ایمیل یا شماره موبایل شما" dir="ltr" />
			<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-sim-run">
				<span class="dashicons dashicons-controls-play"></span>
				اجرای شبیه‌سازی
			</button>
		</div>

		<div class="wcma-simulate__row">
			<input type="text" id="wcma-sim-product" placeholder="یا مستقیم بنویسید: شناسه، نام، کد محصول (SKU)، لینک یا نامک" dir="ltr" style="flex:1" />
		</div>

		<?php
		$wcma_samples = WCMA_Stock_Alerts::sample_products( 6 );

		if ( $wcma_samples ) :
			?>
			<p class="wcma-field__desc">
				<strong>محصولات اخیر شما:</strong>
				<?php
				$wcma_bits = array();

				foreach ( $wcma_samples as $wcma_sample ) {
					$wcma_bits[] = sprintf(
						'<button type="button" class="wcma-tag wcma-sim-pick" data-id="%d">%s — %d %s</button>',
						(int) $wcma_sample['id'],
						esc_html( $wcma_sample['name'] ),
						(int) $wcma_sample['id'],
						$wcma_sample['in_stock'] ? '✓' : '(ناموجود)'
					);
				}

				echo wp_kses_post( implode( ' ', $wcma_bits ) );
				?>
			</p>
		<?php endif; ?>

		<ul class="wcma-checklist" id="wcma-sim-result"></ul>
	</div>

	<h3 class="wcma-subtitle">آخرین تلاش‌های ارسال</h3>

	<?php if ( $wcma_recent_logs ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>تاریخ</th>
						<th>کانال</th>
						<th>گیرنده</th>
						<th>وضعیت</th>
						<th>پیام خطا</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_recent_logs as $wcma_log ) : ?>
						<tr>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_log['created_at'] ); ?></td>
							<td><?php echo esc_html( $wcma_log['channel'] ); ?></td>
							<td class="wcma-ltr"><?php echo esc_html( $wcma_log['recipient'] ); ?></td>
							<td>
								<?php if ( 'failed' === $wcma_log['status'] ) : ?>
									<span class="wcma-badge wcma-badge--red">ناموفق</span>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--green">ارسال شد</span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( $wcma_log['error_message'] ? $wcma_log['error_message'] : '—' ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-empty">
			هنوز هیچ تلاش ارسالی ثبت نشده است؛ یعنی یا محصولی موجود نشده، یا ثبت گزارش‌ها خاموش است.
		</p>
	<?php endif; ?>

	<div class="wcma-info">
		<span class="dashicons dashicons-info"></span>
		<div>
			<strong>آزمایش سریع:</strong> یک محصول را ناموجود کنید، در صفحه‌اش ثبت‌نام کنید،
			سپس موجودی را به عددی بزرگ‌تر از «حداقل موجودی» تغییر دهید و ذخیره کنید. با روشن
			بودن ارسال فوری، پیام باید بلافاصله برسد و در جدول بالا ثبت شود. اگر ردیفی با
			وضعیت «ناموفق» دیدید، متن خطا دقیقاً می‌گوید سرویس‌دهنده چه پاسخی داده است.
		</div>
	</div>

<?php WCMA_Admin_Fields::card_end(); ?>
