<?php
/**
 * تب ۲: یادآوری ثبت نظر.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$channels = WCMA_Sender::channels();
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'یادآوری ثبت نظر', 'چند روز پس از خرید، به‌صورت خودکار از مشتری بخواهید نظرش را ثبت کند.', 'format-status' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'rr_enabled', 'فعال بودن یادآوری ثبت نظر' );
		?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'rr_delay',
				'ارسال پس از',
				array(
					'type' => 'number',
					'min'  => 0,
				)
			);

			WCMA_Admin_Fields::select(
				'rr_unit',
				'واحد زمان',
				array(
					'minute' => 'دقیقه',
					'hour'   => 'ساعت',
					'day'    => 'روز',
				)
			);

			WCMA_Admin_Fields::select( 'rr_channel', 'کانال ارسال', $channels );
			?>
		</div>

		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::select(
				'rr_only_status',
				'مبنای شمارش زمان: رسیدن سفارش به وضعیت',
				WCMA_Admin_Fields::order_status_options(),
				array( 'description' => 'معمولاً «تکمیل شده» بهترین انتخاب است.' )
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::toggle(
			'rr_skip_reviewed',
			'اگر مشتری قبلاً نظر ثبت کرده، پیام ارسال نشود',
			'از ارسال یادآوری تکراری برای مشتریانی که نظر داده‌اند جلوگیری می‌کند.'
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'متن پیام', '', 'edit' ); ?>
		<?php
		WCMA_Admin_Fields::placeholder_help( array( 'product_name', 'product_link', 'product_price', 'order_number', 'order_date', 'order_items', 'unsubscribe' ) );

		WCMA_Admin_Fields::text( 'rr_subject', 'موضوع ایمیل' );

		WCMA_Admin_Fields::textarea(
			'rr_sms_text',
			'متن پیامک',
			array(
				'rows'    => 3,
				'counter' => true,
			)
		);

		WCMA_Admin_Fields::textarea(
			'rr_email_text',
			'متن ایمیل (HTML مجاز است)',
			array( 'rows' => 7 )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
