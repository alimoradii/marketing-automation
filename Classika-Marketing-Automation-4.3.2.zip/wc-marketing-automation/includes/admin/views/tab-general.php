<?php
/**
 * تب تنظیمات عمومی.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'وضعیت کلی افزونه', 'کلید اصلی اجرای همه‌ی ورک‌فلوها.', 'admin-generic' ); ?>
		<?php
		WCMA_Admin_Fields::toggle(
			'enabled',
			'فعال بودن کل افزونه',
			'با غیرفعال کردن این گزینه، هیچ ورک‌فلویی اجرا نمی‌شود و هیچ پیامی ارسال نخواهد شد.'
		);

		WCMA_Admin_Fields::toggle(
			'error_report_admin',
			'ارسال گزارش خطاها به ایمیل مدیر سایت',
			'در صورت بروز خطا در ارسال، یک ایمیل اطلاع‌رسانی برای مدیر ارسال می‌شود.'
		);

		WCMA_Admin_Fields::text(
			'error_report_email',
			'ایمیل دریافت گزارش خطا',
			array(
				'type'        => 'email',
				'placeholder' => get_option( 'admin_email' ),
			)
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'گزارش‌گیری و نگهداری داده', '', 'chart-bar' ); ?>
		<?php
		WCMA_Admin_Fields::toggle(
			'log_enabled',
			'ثبت گزارش ارسال‌ها در دیتابیس',
			'برای مشاهده در تب «گزارش‌ها». با غیرفعال کردن آن، آمار و نمودارها به‌روزرسانی نمی‌شوند.'
		);

		WCMA_Admin_Fields::text(
			'log_retention_days',
			'مدت نگهداری گزارش‌ها',
			array(
				'type'        => 'number',
				'min'         => 1,
				'suffix'      => 'روز',
				'description' => 'گزارش‌های قدیمی‌تر از این مدت به‌صورت خودکار حذف می‌شوند تا دیتابیس سبک بماند.',
			)
		);

		?>

		<?php
		/*
		 * «تعداد سفارش‌ها در تب سفارش‌های اخیر» از اینجا برداشته شد: حالا
		 * تعداد هر صفحه بالای خودِ فهرست انتخاب می‌شود و این تنظیم فقط یک
		 * کلیدِ بی‌اثر می‌ماند.
		 */
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'زمان‌بندی و سرعت ارسال', 'برای جلوگیری از مزاحمت برای مشتری و فشار به سرور.', 'clock' ); ?>
		<?php
		WCMA_Admin_Fields::toggle(
			'quiet_hours_enabled',
			'عدم ارسال پیام در ساعات استراحت',
			'پیام‌هایی که در این بازه به سررسید می‌رسند، تا پایان بازه در صف می‌مانند و بعد ارسال می‌شوند.'
		);
		?>

		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::text( 'quiet_hours_start', 'شروع ساعات استراحت', array( 'type' => 'time' ) );
			WCMA_Admin_Fields::text( 'quiet_hours_end', 'پایان ساعات استراحت', array( 'type' => 'time' ) );
			?>
		</div>

		<?php
		WCMA_Admin_Fields::text(
			'batch_size',
			'تعداد پیام در هر بار اجرای زمان‌بند',
			array(
				'type'        => 'number',
				'min'         => 1,
				'max'         => 500,
				'suffix'      => 'پیام',
				'description' => 'زمان‌بند هر ۵ دقیقه اجرا می‌شود. عدد بزرگ سرعت ارسال را بالا می‌برد اما بار سرور را بیشتر می‌کند.',
			)
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'ترتیب اولویت ارسال', 'هر ورک‌فلو کانال خودش را دارد؛ اگر آن کانال برای مشتری ممکن نبود، افزونه به ترتیب این فهرست جایگزین می‌کند.', 'sort', 'مثال: اگر ورک‌فلو روی پیامک باشد ولی مشتری شماره نداشته باشد، افزونه سراغ کانال بعدی این فهرست می‌رود.' ); ?>
		<?php
		$wcma_order    = WCMA_Sender::priority();
		$wcma_labels   = WCMA_Sender::channels();
		$wcma_position = 1;
		?>

		<div class="wcma-priority">
			<?php foreach ( $wcma_order as $wcma_channel ) : ?>
				<?php
				$wcma_ready = 'sms' === $wcma_channel || 'email' === $wcma_channel
					? true
					: WCMA_Messengers::is_ready( $wcma_channel );
				?>
				<?php
				$wcma_ch_icons = array(
					'sms'      => 'smartphone',
					'email'    => 'email-alt',
					'whatsapp' => 'whatsapp',
					'telegram' => 'admin-comments',
					'bale'     => 'format-chat',
					'eitaa'    => 'format-chat',
					'rubika'   => 'format-chat',
				);
				?>
				<div class="wcma-priority__row">
					<span class="wcma-priority__num"><?php echo esc_html( WCMA_Date::number( $wcma_position ) ); ?></span>

					<span class="wcma-priority__icon dashicons dashicons-<?php echo esc_attr( $wcma_ch_icons[ $wcma_channel ] ?? 'megaphone' ); ?>"></span>

					<span class="wcma-priority__name">
						<?php echo esc_html( $wcma_labels[ $wcma_channel ] ?? $wcma_channel ); ?>
						<?php if ( ! $wcma_ready ) : ?>
							<small>تنظیم نشده — نادیده گرفته می‌شود</small>
						<?php endif; ?>
					</span>

					<select name="wcma[channel_priority][<?php echo esc_attr( $wcma_channel ); ?>]" class="wcma-priority__select">
						<?php for ( $wcma_i = 1; $wcma_i <= count( $wcma_order ); $wcma_i++ ) : ?>
							<option value="<?php echo esc_attr( $wcma_i ); ?>" <?php selected( $wcma_position, $wcma_i ); ?>>
								<?php echo esc_html( WCMA_Date::number( $wcma_i ) ); ?>
							</option>
						<?php endfor; ?>
					</select>
				</div>
				<?php $wcma_position++; ?>
			<?php endforeach; ?>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				نمونه: اگر ترتیب «۱ پیامک، ۲ ایمیل، ۳ واتساپ» باشد و مشتری فقط ایمیل داشته
				باشد، پیام با ایمیل می‌رود. پیام‌رسان‌هایی مثل تلگرام فقط برای مشتری‌هایی
				به کار می‌روند که حسابشان را به ربات وصل کرده‌اند.
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'تاریخ و اعداد', 'این تنظیم روی همه‌ی بخش‌ها اعمال می‌شود: متن پیام‌ها، گزارش‌ها و جدول‌های پیشخوان.', 'calendar-alt' ); ?>
		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::select(
				'date_calendar',
				'تقویم',
				array(
					'jalali'    => 'شمسی (هجری خورشیدی)',
					'gregorian' => 'میلادی',
				)
			);

			WCMA_Admin_Fields::select(
				'date_digits',
				'ارقام',
				array(
					'fa' => 'فارسی (۰۱۲۳۴۵۶۷۸۹)',
					'en' => 'لاتین (0123456789)',
				)
			);
			?>
		</div>

		<div class="wcma-info wcma-date-live" data-live="1">
			<span class="dashicons dashicons-info"></span>
			<div>
				نمونه‌ی خروجی با تنظیم فعلی:
				<strong><?php echo WCMA_Date::html( gmdate( 'Y-m-d H:i:s', time() + (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ), 'datetime_long' ); ?></strong>
				<span class="wcma-date-live__state"></span>
				<br />
				<small>تغییر این دو گزینه بی‌درنگ و بدون زدن دکمه‌ی ذخیره اعمال و ثبت می‌شود؛
				همه‌ی تاریخ‌های همین صفحه هم فوراً به‌روز می‌شوند.</small>
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'اطلاعات فروشگاه و نگهداری داده', '', 'store' ); ?>
		<?php
		WCMA_Admin_Fields::text(
			'shop_phone',
			'تلفن تماس فروشگاه',
			array( 'description' => 'در متن پیام‌ها با متغیر <code dir="ltr">{shop_phone}</code> قابل استفاده است.' )
		);
		?>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				هویت فرستنده‌ی ایمیل و تنظیمات پیامک و پیام‌رسان‌ها به تب
				<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'sms' ) ); ?>">کانال‌های ارتباطی</a>
				منتقل شده است.
			</div>
		</div>

		<?php
		WCMA_Admin_Fields::toggle(
			'delete_data_on_uninstall',
			'حذف کامل داده‌ها هنگام پاک کردن افزونه',
			'به‌طور پیش‌فرض خاموش است. تا وقتی خاموش بماند، حتی اگر افزونه را پاک کنید، تنظیمات و گزارش‌ها و پرونده‌ی مشتریان سر جایشان می‌مانند و با نصب دوباره برمی‌گردند. روشن کردن آن برگشت‌پذیر نیست.'
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پرونده‌ی مشتریان (CRM)', 'رفتار خودکار پرونده‌ها؛ خود فهرست مشتریان در برگه‌ی «مدیریت ارتباط با مشتریان» است.', 'id-alt', 'پرونده‌ها خودکار از سفارش‌ها، فرم لید مگنت، ربات و گفتگو ساخته می‌شوند؛ اینجا فقط رفتارشان را تنظیم می‌کنید.', 'crm' ); ?>
<?php
		WCMA_Admin_Fields::toggle( 'crm_enabled', 'فعال بودن پرونده‌ی مشتریان', '', 'با خاموش کردن، پرونده‌ی تازه ساخته نمی‌شود ولی داده‌های موجود پاک نمی‌شوند.' );
		WCMA_Admin_Fields::toggle( 'crm_auto_sync', 'همگام‌سازی خودکار روزانه با سفارش‌ها', '', 'هر شب سفارش‌های تازه خوانده می‌شوند تا شمار خرید، مبلغ کل و مرحله‌ی هر مشتری به‌روز بماند.' );

		WCMA_Admin_Fields::text(
			'crm_churn_days',
			'پس از چند روز بی‌خریدی، مشتری «در خطر ریزش» شمرده شود؟',
			array(
				'type'   => 'number',
				'min'    => 30,
				'suffix' => 'روز',
			)
		);

		WCMA_Admin_Fields::toggle( 'crm_followup_reminder', 'یادآوری پیگیری‌های سررسیدشده با پیامک', '', 'اگر برای مشتری تاریخ پیگیری گذاشته باشید، در روز موعد به شماره‌ی زیر پیامک می‌رسد.' );

		WCMA_Admin_Fields::text(
			'crm_reminder_phone',
			'شماره‌ی دریافت یادآوری پیگیری',
			array( 'placeholder' => '09121234567' )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php
	WCMA_Admin_Fields::card_start(
		'یادآوری پیگیری‌ها',
		'هر یادداشت، تماس یا جلسه‌ای که در پرونده‌ی مشتری تاریخ بگیرد، سر وقتش به ثبت‌کننده‌اش یادآوری می‌شود.',
		'bell',
		'کارهای سررسیدشده در بالای برگه‌ی «پرونده‌ی مشتریان» هم فهرست می‌شوند. یادآوری با همان زمان‌بند افزونه می‌رود، پس دقتش به فاصله‌ی اجرای زمان‌بند بستگی دارد.',
		'followups'
	);
	?>
		<?php
		WCMA_Admin_Fields::toggle(
			'followup_reminders',
			'یادآوری‌ها فرستاده شوند',
			'با خاموش کردن این گزینه، کارها همچنان در «کارهای امروز» دیده می‌شوند ولی پیامی فرستاده نمی‌شود.'
		);

		WCMA_Admin_Fields::select(
			'followup_channel',
			'یادآوری از کدام راه برسد',
			WCMA_Followups::channels(),
			array(
				'description' => 'در حالت خودکار، اگر همکار حسابش را به ربات وصل کرده باشد پیام به ربات می‌رود؛ وگرنه پیامک و در نبودش ایمیل.',
			)
		);

		WCMA_Admin_Fields::text(
			'followup_hour',
			'ساعت یادآوریِ کارهای بدون ساعت',
			array(
				'type'        => 'time',
				'description' => 'وقتی فقط تاریخ ثبت شده و ساعتی تعیین نشده، یادآوری در این ساعت فرستاده می‌شود.',
			)
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php WCMA_Admin_Fields::card_start( 'پشتیبان تنظیمات', 'برای انتقال به سایت دیگر یا اطمینان بیشتر پیش از تغییرات بزرگ.', 'backup', 'فقط تنظیمات را نگه می‌دارد، نه داده‌ی مشتریان و گزارش‌ها. هنگام بازگرداندن، تنظیمات فعلی جایگزین می‌شوند.' ); ?>
	<?php $wcma_backup = WCMA_Install::backup_info(); ?>

	<div class="wcma-info">
		<span class="dashicons dashicons-shield"></span>
		<div>
			<strong>داده‌های شما با به‌روزرسانی یا حذف افزونه پاک نمی‌شوند.</strong>
			<br />
			به‌روزرسانی فقط فایل‌های افزونه را عوض می‌کند و جدول‌ها و تنظیمات دست‌نخورده می‌مانند؛
			ستون‌های تازه هم خودکار اضافه می‌شوند. هنگام حذف افزونه هم تا وقتی گزینه‌ی
			«حذف کامل داده‌ها» خاموش است، چیزی پاک نمی‌شود.
			<?php if ( $wcma_backup ) : ?>
				<br />
				یک نسخه‌ی پشتیبان از
				<strong><?php echo esc_html( WCMA_Date::number( $wcma_backup['count'] ) ); ?></strong>
				تنظیم در دیتابیس نگهداری می‌شود
				(آخرین به‌روزرسانی: <?php echo WCMA_Date::html( $wcma_backup['saved_at'] ); ?>)
				و اگر افزونه پاک و دوباره نصب شود، خودکار برمی‌گردد.
			<?php endif; ?>
		</div>
	</div>

	<div class="wcma-actions">
		<form method="post" style="display: inline;">
			<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
			<input type="hidden" name="wcma_action" value="export_settings" />
			<button type="submit" class="wcma-btn wcma-btn--secondary">
				<span class="dashicons dashicons-download"></span>
				گرفتن فایل پشتیبان
			</button>
		</form>
	</div>

	<form method="post" enctype="multipart/form-data" class="wcma-restore">
		<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
		<input type="hidden" name="wcma_action" value="import_settings" />

		<label class="wcma-field__label" for="wcma_settings_file">بازگرداندن از فایل پشتیبان</label>

		<div class="wcma-restore__row">
			<input type="file" id="wcma_settings_file" name="wcma_settings_file" accept="application/json,.json" />
			<button type="submit" class="wcma-btn wcma-btn--ghost" data-confirm="تنظیمات فعلی با محتوای فایل جایگزین می‌شود. ادامه می‌دهید؟">
				<span class="dashicons dashicons-upload"></span>
				بازگرداندن
			</button>
		</div>

		<p class="wcma-field__desc">
			فقط کلیدهای شناخته‌شده‌ی همین افزونه وارد می‌شوند و مثل فرم عادی پاک‌سازی می‌گردند؛
			پس فایل دستکاری‌شده نمی‌تواند چیز ناخواسته‌ای وارد کند.
		</p>
	</form>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php
// اگر کلاس به هر دلیلی بارگذاری نشده باشد، برگه نباید با خطای مرگبار بیفتد.
if ( ! class_exists( 'WCMA_Health' ) ) {
	return;
}

$wcma_health  = WCMA_Health::groups();
$wcma_summary = WCMA_Health::summary();

$wcma_badges = array(
	WCMA_Health::OK   => array( 'icon' => 'yes-alt', 'text' => 'همه چیز سالم است' ),
	WCMA_Health::WARN => array( 'icon' => 'warning', 'text' => 'چند مورد نیاز به توجه دارد' ),
	WCMA_Health::BAD  => array( 'icon' => 'dismiss', 'text' => 'موردی هست که باید درست شود' ),
);

$wcma_badge = $wcma_badges[ $wcma_summary['status'] ];
?>

<?php WCMA_Admin_Fields::card_start( 'سلامت سیستم', 'پس از هر به‌روزرسانی وردپرس، ووکامرس یا PHP، این فهرست را یک نگاه بیندازید.', 'shield-alt', 'همه‌ی بررسی‌ها محلی‌اند و هیچ اطلاعاتی جایی فرستاده نمی‌شود. ردیف قرمز یعنی کاری باید انجام شود، زرد یعنی حواستان باشد.' ); ?>

	<div class="wcma-health__summary is-<?php echo esc_attr( $wcma_summary['status'] ); ?>">
		<span class="dashicons dashicons-<?php echo esc_attr( $wcma_badge['icon'] ); ?>"></span>
		<div>
			<strong><?php echo esc_html( $wcma_badge['text'] ); ?></strong>
			<?php if ( $wcma_summary['bad'] || $wcma_summary['warn'] ) : ?>
				<span class="wcma-field__desc">
					<?php
					$wcma_parts = array();

					if ( $wcma_summary['bad'] ) {
						$wcma_parts[] = WCMA_Date::number( $wcma_summary['bad'] ) . ' ایراد';
					}

					if ( $wcma_summary['warn'] ) {
						$wcma_parts[] = WCMA_Date::number( $wcma_summary['warn'] ) . ' هشدار';
					}

					echo esc_html( implode( ' و ', $wcma_parts ) );
					?>
				</span>
			<?php endif; ?>
		</div>
		<a href="<?php echo esc_url( add_query_arg( 'wcma_refresh', time() ) ); ?>" class="wcma-btn wcma-btn--ghost">
			<span class="dashicons dashicons-update"></span>
			بررسی دوباره
		</a>
	</div>

	<?php foreach ( $wcma_health as $wcma_group ) : ?>
		<h3 class="wcma-subtitle">
			<span class="dashicons dashicons-<?php echo esc_attr( $wcma_group['icon'] ); ?>"></span>
			<?php echo esc_html( $wcma_group['title'] ); ?>
		</h3>

		<ul class="wcma-health__list">
			<?php foreach ( $wcma_group['rows'] as $wcma_row ) : ?>
				<li class="is-<?php echo esc_attr( $wcma_row['status'] ); ?>">
					<span class="wcma-health__label"><?php echo esc_html( $wcma_row['label'] ); ?></span>
					<span class="wcma-health__value"><?php echo esc_html( $wcma_row['value'] ); ?></span>
					<?php if ( ! empty( $wcma_row['hint'] ) ) : ?>
						<span class="wcma-health__hint"><?php echo esc_html( $wcma_row['hint'] ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endforeach; ?>

	<p class="wcma-field__desc">
		این بررسی‌ها فقط وضعیت همین سایت را می‌خوانند و هیچ اطلاعاتی جایی فرستاده نمی‌شود.
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>
