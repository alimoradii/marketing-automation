<?php
/**
 * گزارش رسمی مدیریت، آماده‌ی چاپ و ذخیره به‌شکل PDF.
 *
 * این فایل یک سند کامل و مستقل تولید می‌کند تا خروجی چاپ، تمیز و بدون منوهای وردپرس باشد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_from  = $wcma_report['from'];
$wcma_to    = $wcma_report['to'];
$wcma_total = $wcma_report['sent'] + $wcma_report['failed'];
$wcma_rate  = $wcma_total > 0 ? ( $wcma_report['sent'] / $wcma_total ) * 100 : 0;
$wcma_conv  = $wcma_report['sent'] > 0 ? ( $wcma_report['conversions'] / $wcma_report['sent'] ) * 100 : 0;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php echo esc_html( 'گزارش عملکرد اتوماسیون بازاریابی کلاسیکا — ' . get_bloginfo( 'name' ) ); ?></title>
	<link rel="stylesheet" href="<?php echo esc_url( WCMA_URL . 'assets/css/font.css?v=' . WCMA_VERSION ); ?>" />
	<style>
		* { box-sizing: border-box; margin: 0; padding: 0; }

		body {
			font-family: 'Vazirmatn WCMA', Vazirmatn, Tahoma, sans-serif;
			direction: rtl;
			background: #f1f5f9;
			color: #16202f;
			font-size: 13px;
			line-height: 2;
			padding: 26px 16px;
			-webkit-print-color-adjust: exact;
			print-color-adjust: exact;
		}

		.sheet {
			max-width: 900px;
			margin: 0 auto;
			background: #fff;
			border-radius: 14px;
			padding: 38px 42px 46px;
			box-shadow: 0 10px 40px rgba(15, 23, 42, .1);
		}

		.head { display: flex; align-items: flex-start; gap: 18px; border-bottom: 3px solid #2563eb; padding-bottom: 18px; margin-bottom: 22px; }
		.head__logo img { max-height: 56px; max-width: 150px; display: block; }
		.head__id { flex: 1; }
		.head__id h1 { font-size: 19px; font-weight: 700; line-height: 1.7; }
		.head__id .site { font-size: 14px; color: #2563eb; font-weight: 700; }
		.head__id .url { font-size: 11.5px; color: #64748b; direction: ltr; text-align: right; }
		.head__meta { text-align: left; font-size: 11.5px; color: #64748b; line-height: 2.1; }
		.head__meta strong { display: block; color: #16202f; font-size: 12.5px; }

		.period { background: #eff6ff; border-radius: 10px; padding: 12px 16px; margin-bottom: 22px; font-size: 13px; }
		.period strong { color: #1d4ed8; }

		.kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 26px; }

		.kpi { border: 1px solid #e2e8f0; border-radius: 11px; padding: 14px 16px; border-top: 3px solid #94a3b8; }
		.kpi--blue { border-top-color: #2563eb; }
		.kpi--green { border-top-color: #16a34a; }
		.kpi--amber { border-top-color: #d97706; }
		.kpi--purple { border-top-color: #7c3aed; }
		.kpi__value { font-size: 21px; font-weight: 700; line-height: 1.6; }
		.kpi__label { font-size: 11.5px; color: #64748b; }
		.kpi__note { font-size: 11px; color: #94a3b8; }

		h2 { font-size: 14.5px; font-weight: 700; margin: 26px 0 11px; padding-right: 11px; border-right: 4px solid #2563eb; }

		table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
		th, td { padding: 9px 11px; text-align: right; border-bottom: 1px solid #eef2f7; }
		thead th { background: #f8fafc; font-weight: 700; font-size: 12px; color: #475569; border-bottom: 2px solid #e2e8f0; }
		tbody tr:last-child td { border-bottom: 0; }
		tfoot td { font-weight: 700; background: #f8fafc; border-top: 2px solid #e2e8f0; }
		.num { font-variant-numeric: tabular-nums; }
		.muted { color: #94a3b8; }

		.bar { display: block; height: 6px; border-radius: 3px; background: #e2e8f0; overflow: hidden; margin-top: 4px; }
		.bar span { display: block; height: 100%; background: #2563eb; border-radius: 3px; }

		.empty { text-align: center; color: #94a3b8; padding: 26px; font-size: 13px; }

		.foot { margin-top: 30px; padding-top: 14px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8; display: flex; justify-content: space-between; gap: 12px; }

		.toolbar { max-width: 900px; margin: 0 auto 16px; display: flex; gap: 9px; justify-content: flex-end; }

		.toolbar button, .toolbar a {
			font-family: inherit;
			font-size: 13px;
			border: 1px solid #cbd5e1;
			background: #fff;
			color: #16202f;
			border-radius: 9px;
			padding: 9px 18px;
			cursor: pointer;
			text-decoration: none;
			display: inline-block;
		}

		.toolbar button { background: #2563eb; border-color: #2563eb; color: #fff; font-weight: 700; }

		.toolbar__hint { flex: 1; align-self: center; font-size: 11.5px; color: #64748b; text-align: right; }

		@media print {
			html, body { background: #fff !important; padding: 0; margin: 0; }
			.sheet { box-shadow: none; border-radius: 0; padding: 0; max-width: none; }
			.toolbar { display: none !important; }

			h2 { break-after: avoid; page-break-after: avoid; }
			table { break-inside: auto; }
			tr, .kpi { break-inside: avoid; page-break-inside: avoid; }
			thead { display: table-header-group; }
			tfoot { display: table-row-group; }
			.head, .period, .kpis { break-inside: avoid; page-break-inside: avoid; }

			/* رنگ‌ها و نوارها در چاپ هم دیده شوند. */
			.kpi, .period, thead th, tfoot td, .bar, .bar span {
				-webkit-print-color-adjust: exact;
				print-color-adjust: exact;
			}

			a { text-decoration: none; color: inherit; }
		}

		@page { size: A4; margin: 14mm 12mm; }
	</style>
</head>
<body>

<div class="toolbar">
	<button type="button" id="wcma-print">دریافت فایل PDF</button>
	<a href="<?php echo esc_url( $wcma_back ); ?>">بازگشت به گزارش‌ها</a>
	<span class="toolbar__hint">در پنجره‌ی چاپ، مقصد را روی «Save as PDF» بگذارید.</span>
</div>

<div class="sheet">
	<div class="head">
		<?php if ( $wcma_logo ) : ?>
			<div class="head__logo"><img src="<?php echo esc_url( $wcma_logo ); ?>" alt="" /></div>
		<?php endif; ?>

		<div class="head__id">
			<h1>گزارش عملکرد اتوماسیون بازاریابی</h1>
			<div class="site"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></div>
			<div class="url"><?php echo esc_html( home_url() ); ?></div>
		</div>

		<div class="head__meta">
			<strong>تاریخ تهیه</strong>
			<?php echo esc_html( WCMA_Date::format( null, 'date_long' ) ); ?>
			<br />
			ساعت <?php echo esc_html( WCMA_Date::format( null, 'time' ) ); ?>
		</div>
	</div>

	<div class="period">
		بازه‌ی گزارش:
		<strong>
			<?php if ( $wcma_from || $wcma_to ) : ?>
				<?php echo esc_html( $wcma_from ? WCMA_Date::mysql( $wcma_from . ' 00:00:00', 'date_long', '' ) : 'ابتدا' ); ?>
				تا
				<?php echo esc_html( $wcma_to ? WCMA_Date::mysql( $wcma_to . ' 00:00:00', 'date_long', '' ) : 'امروز' ); ?>
			<?php else : ?>
				تمام دوره‌ی فعالیت افزونه
			<?php endif; ?>
		</strong>
	</div>

	<div class="kpis">
		<div class="kpi kpi--blue">
			<div class="kpi__value"><?php echo esc_html( WCMA_Date::number( $wcma_report['sent'] ) ); ?></div>
			<div class="kpi__label">پیام ارسال‌شده</div>
			<div class="kpi__note">نرخ موفقیت <?php echo esc_html( WCMA_Date::number( $wcma_rate, 1 ) ); ?>٪</div>
		</div>
		<div class="kpi kpi--amber">
			<div class="kpi__value"><?php echo esc_html( WCMA_Date::number( $wcma_report['failed'] ) ); ?></div>
			<div class="kpi__label">ارسال ناموفق</div>
			<div class="kpi__note">از مجموع <?php echo esc_html( WCMA_Date::number( $wcma_total ) ); ?> تلاش</div>
		</div>
		<div class="kpi kpi--green">
			<div class="kpi__value"><?php echo esc_html( WCMA_Date::number( $wcma_report['conversions'] ) ); ?></div>
			<div class="kpi__label">خرید در پی پیام</div>
			<div class="kpi__note">نرخ تبدیل <?php echo esc_html( WCMA_Date::number( $wcma_conv, 1 ) ); ?>٪</div>
		</div>
		<div class="kpi kpi--purple">
			<div class="kpi__value"><?php echo wp_kses_post( WCMA_Date::price( $wcma_report['revenue'] ) ); ?></div>
			<div class="kpi__label">درآمد منتسب</div>
			<div class="kpi__note">مجموع سفارش‌های پیگیری‌شده</div>
		</div>
	</div>

	<h2>عملکرد به تفکیک ورک‌فلو</h2>

	<?php if ( $wcma_report['by_workflow'] ) : ?>
		<table>
			<thead>
				<tr>
					<th>ورک‌فلو</th>
					<th class="num">ارسال موفق</th>
					<th class="num">ناموفق</th>
					<th class="num">خرید</th>
					<th class="num">نرخ تبدیل</th>
					<th class="num">درآمد</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wcma_report['by_workflow'] as $wcma_key => $wcma_row ) : ?>
					<?php $wcma_wf_conv = $wcma_row['sent'] > 0 ? ( $wcma_row['conversions'] / $wcma_row['sent'] ) * 100 : 0; ?>
					<tr>
						<td><?php echo esc_html( $wcma_labels[ $wcma_key ] ?? $wcma_key ); ?></td>
						<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_row['sent'] ) ); ?></td>
						<td class="num <?php echo $wcma_row['failed'] ? '' : 'muted'; ?>"><?php echo esc_html( WCMA_Date::number( $wcma_row['failed'] ) ); ?></td>
						<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_row['conversions'] ) ); ?></td>
						<td class="num">
							<?php echo esc_html( WCMA_Date::number( $wcma_wf_conv, 1 ) ); ?>٪
							<span class="bar"><span style="width: <?php echo esc_attr( min( 100, $wcma_wf_conv ) ); ?>%"></span></span>
						</td>
						<td class="num"><?php echo wp_kses_post( WCMA_Date::price( $wcma_row['revenue'] ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<td>مجموع</td>
					<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_report['sent'] ) ); ?></td>
					<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_report['failed'] ) ); ?></td>
					<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_report['conversions'] ) ); ?></td>
					<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_conv, 1 ) ); ?>٪</td>
					<td class="num"><?php echo wp_kses_post( WCMA_Date::price( $wcma_report['revenue'] ) ); ?></td>
				</tr>
			</tfoot>
		</table>
	<?php else : ?>
		<p class="empty">در این بازه ارسالی ثبت نشده است.</p>
	<?php endif; ?>

	<h2>عملکرد به تفکیک کانال</h2>

	<?php if ( $wcma_report['by_channel'] ) : ?>
		<table>
			<thead>
				<tr>
					<th>کانال</th>
					<th class="num">ارسال موفق</th>
					<th class="num">ناموفق</th>
					<th class="num">سهم از کل</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $wcma_report['by_channel'] as $wcma_key => $wcma_row ) : ?>
					<?php
					$wcma_ch_total = $wcma_row['sent'] + $wcma_row['failed'];
					$wcma_share    = $wcma_total > 0 ? ( $wcma_ch_total / $wcma_total ) * 100 : 0;
					?>
					<tr>
						<td><?php echo esc_html( $wcma_channels[ $wcma_key ] ?? $wcma_key ); ?></td>
						<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_row['sent'] ) ); ?></td>
						<td class="num <?php echo $wcma_row['failed'] ? '' : 'muted'; ?>"><?php echo esc_html( WCMA_Date::number( $wcma_row['failed'] ) ); ?></td>
						<td class="num">
							<?php echo esc_html( WCMA_Date::number( $wcma_share, 1 ) ); ?>٪
							<span class="bar"><span style="width: <?php echo esc_attr( min( 100, $wcma_share ) ); ?>%"></span></span>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<p class="empty">داده‌ای برای تفکیک کانال نیست.</p>
	<?php endif; ?>

	<?php if ( $wcma_report['daily'] ) : ?>
		<h2>روند روزانه</h2>

		<table>
			<thead>
				<tr>
					<th>تاریخ</th>
					<th class="num">کل ارسال</th>
					<th class="num">ناموفق</th>
					<th class="num">خرید</th>
					<th class="num">درآمد</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( array_slice( $wcma_report['daily'], -31 ) as $wcma_day ) : ?>
					<tr>
						<td><?php echo esc_html( WCMA_Date::mysql( $wcma_day['day'] . ' 00:00:00', 'date', '—' ) ); ?></td>
						<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_day['total'] ) ); ?></td>
						<td class="num <?php echo (int) $wcma_day['failed'] ? '' : 'muted'; ?>"><?php echo esc_html( WCMA_Date::number( $wcma_day['failed'] ) ); ?></td>
						<td class="num"><?php echo esc_html( WCMA_Date::number( $wcma_day['conversions'] ?? 0 ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( WCMA_Date::price( (float) ( $wcma_day['revenue'] ?? 0 ) ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<div class="foot">
		<span>تهیه‌شده توسط افزونه‌ی اتوماسیون بازاریابی کلاسیکا — تیم دکتر علی مرادی · نسخه <?php echo esc_html( WCMA_Date::digits( WCMA_VERSION ) ); ?></span>
		<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
	</div>
</div>

<script>
	( function () {
		var button = document.getElementById( 'wcma-print' );

		if ( button ) {
			button.addEventListener( 'click', function () { window.print(); } );
		}

		<?php if ( $wcma_auto_print ) : ?>
		// صبر می‌کنیم فونت برسد، وگرنه پنجره‌ی چاپ متن را با فونت جایگزین می‌گیرد.
		function go() { window.setTimeout( function () { window.print(); }, 250 ); }

		if ( document.fonts && document.fonts.ready ) {
			document.fonts.ready.then( go );
		} else {
			window.addEventListener( 'load', go );
		}
		<?php endif; ?>
	}() );
</script>

</body>
</html>
