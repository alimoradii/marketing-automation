<?php
/**
 * تب کانال‌های ارتباطی: پیامک، ایمیل و پیام‌رسان‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$gateways = WCMA_SMS_Gateways::all();
$options  = array();

foreach ( $gateways as $key => $data ) {
	$options[ $key ] = $data['label'];
}
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'پنل پیامک', 'اطلاعات سرویس پیامکی خود را وارد کنید تا ورک‌فلوها بتوانند پیامک ارسال کنند.', 'smartphone', 'کلید API را از پنل خود سرویس‌دهنده بگیرید. پس از وارد کردن، با «تست اتصال» یک پیامک واقعی بفرستید تا مطمئن شوید کار می‌کند.', 'sms-panel' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'sms_enabled', 'فعال بودن ارسال پیامک' );

		WCMA_Admin_Fields::select(
			'sms_gateway',
			'سرویس‌دهنده‌ی پیامک',
			$options,
			array( 'description' => 'پس از انتخاب، فقط فیلدهای موردنیاز همان سرویس نمایش داده می‌شود.' )
		);
		?>

		<div class="wcma-gateway-fields" data-gateways='<?php echo esc_attr( wp_json_encode( wp_list_pluck( $gateways, 'fields' ) ) ); ?>'>
			<div data-field="sms_api_key">
				<?php WCMA_Admin_Fields::text( 'sms_api_key', 'کلید API', array( 'placeholder' => 'API Key' ) ); ?>
			</div>
			<div data-field="sms_username">
				<?php WCMA_Admin_Fields::text( 'sms_username', 'نام کاربری پنل' ); ?>
			</div>
			<div data-field="sms_password">
				<?php WCMA_Admin_Fields::text( 'sms_password', 'رمز عبور پنل', array( 'type' => 'password' ) ); ?>
			</div>
			<div data-field="sms_sender">
				<?php WCMA_Admin_Fields::text( 'sms_sender', 'شماره‌ی خط فرستنده', array( 'placeholder' => 'مثال: 10008663' ) ); ?>
			</div>
			<div data-field="sms_ippanel_api">
				<?php
				WCMA_Admin_Fields::select(
					'sms_ippanel_api',
					'نسل API آی‌پی‌پنل',
					array(
						'auto'   => 'خودکار (هر دو را امتحان کن)',
						'edge'   => 'نسل جدید — edge.ippanel.com',
						'legacy' => 'نسل قدیمی — api2.ippanel.com',
					),
					array( 'description' => 'کلیدهای base64 (که به <code dir="ltr">=</code> ختم می‌شوند) معمولاً نسل جدید هستند.' )
				);
				?>
			</div>
			<div data-field="sms_custom_url">
				<?php WCMA_Admin_Fields::text( 'sms_custom_url', 'آدرس درخواست (Endpoint)', array( 'placeholder' => 'https://example.com/api/send' ) ); ?>
			</div>
			<div data-field="sms_custom_method">
				<?php WCMA_Admin_Fields::select( 'sms_custom_method', 'متد درخواست', array( 'POST' => 'POST', 'GET' => 'GET' ) ); ?>
			</div>
			<div data-field="sms_custom_body">
				<?php
				WCMA_Admin_Fields::textarea(
					'sms_custom_body',
					'بدنه‌ی درخواست (JSON)',
					array(
						'rows'        => 4,
						'description' => 'می‌توانید از <code>{phone}</code>، <code>{message}</code> و <code>{sender}</code> استفاده کنید.',
					)
				);
				?>
			</div>
			<div data-field="sms_custom_headers">
				<?php
				WCMA_Admin_Fields::textarea(
					'sms_custom_headers',
					'هدرهای اضافی',
					array(
						'rows'        => 3,
						'placeholder' => "Authorization: Bearer xxxxx",
						'description' => 'هر هدر در یک خط، به شکل <code>نام: مقدار</code>.',
					)
				);
				?>
			</div>
		</div>

		<div class="wcma-conntest" data-channel="sms">
			<div class="wcma-conntest__head">
				<span class="dashicons dashicons-admin-plugins"></span>
				<div>
					<strong>تست اتصال پنل پیامک</strong>
					<p>یک پیامک واقعی به شماره‌ی زیر ارسال می‌شود. نیازی به ذخیره کردن نیست؛ همین مقادیر واردشده آزموده می‌شوند.</p>
				</div>
			</div>
			<div class="wcma-conntest__row">
				<input type="text" class="wcma-conntest__to" placeholder="شماره موبایل گیرنده، مثال: 09121234567" value="<?php echo esc_attr( WCMA_Settings::get( 'os_admin_phone' ) ); ?>" />
				<button type="button" class="wcma-btn wcma-btn--secondary wcma-conntest__btn">
					<span class="dashicons dashicons-send"></span>
					تست اتصال و ارسال پیامک
				</button>
			</div>
			<div class="wcma-conntest__result"></div>
		</div>

		<div class="wcma-info wcma-balance" id="wcma-sms-balance">
			<span class="dashicons dashicons-chart-pie"></span>
			<div class="wcma-balance__body">
				<strong>اعتبار پنل پیامک</strong>
				<div class="wcma-balance__value" data-empty="در حال استعلام...">در حال استعلام...</div>
				<span class="wcma-balance__meta"></span>
			</div>
			<button type="button" class="wcma-btn wcma-btn--ghost wcma-balance__refresh" title="استعلام دوباره">
				<span class="dashicons dashicons-update"></span>
			</button>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				<strong>راهنمای سرویس‌ها</strong>
				<ul>
					<?php foreach ( $gateways as $key => $data ) : ?>
						<li><strong><?php echo esc_html( $data['label'] ); ?>:</strong> <?php echo esc_html( $data['help'] ); ?></li>
					<?php endforeach; ?>
				</ul>
				<p>پس از ذخیره، از تب «تست ارسال» یک پیامک آزمایشی بفرستید تا از صحت تنظیمات مطمئن شوید.</p>
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php
	$wcma_smtp = WCMA_SMTP::status();

	WCMA_Admin_Fields::card_start(
		'سرور ارسال ایمیل (SMTP)',
		'ایمیل را به‌جای تابع mail() هاست، از سرور ایمیل خودتان بفرستید — بدون نیاز به نصب افزونه‌ی SMTP جداگانه.',
		'email-alt',
		'وردپرس به‌طور پیش‌فرض ایمیل را با mail() سرور می‌فرستد که روی بیشتر هاست‌های اشتراکی یا نمی‌رسد یا در پوشه‌ی هرزنامه می‌افتد. با SMTP، ایمیل از یک نشانی تأییدشده فرستاده می‌شود و شانس رسیدنش بسیار بیشتر است.',
		'smtp'
	);
	?>
		<div class="wcma-info wcma-info--<?php echo esc_attr( 'on' === $wcma_smtp['state'] ? 'ok' : ( 'warn' === $wcma_smtp['state'] ? 'warn' : '' ) ); ?>">
			<span class="dashicons dashicons-<?php echo esc_attr( 'on' === $wcma_smtp['state'] ? 'yes-alt' : 'info' ); ?>"></span>
			<div>
				وضعیت کنونی: <strong><?php echo esc_html( $wcma_smtp['label'] ); ?></strong>
				<br />
				<?php echo esc_html( $wcma_smtp['detail'] ); ?>
			</div>
		</div>

		<?php
		WCMA_Admin_Fields::toggle(
			'smtp_enabled',
			'ارسال ایمیل از طریق SMTP',
			'',
			'تا وقتی نشانی سرور را وارد نکنید، این گزینه اثری ندارد و ایمیل‌ها با روش پیش‌فرض سرور می‌روند.'
		);
		?>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::text(
				'smtp_host',
				'نشانی سرور SMTP',
				array(
					'placeholder' => 'mail.example.com',
					'description' => 'این نشانی را میزبان هاست یا سرویس ایمیل شما (مثلاً Gmail، Zoho، میل‌سرور شرکتی) می‌دهد.',
				)
			);

			WCMA_Admin_Fields::select( 'smtp_secure', 'روش رمزگذاری', WCMA_SMTP::encryptions() );
			?>
		</div>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::text(
				'smtp_port',
				'درگاه',
				array(
					'type'        => 'number',
					'min'         => 1,
					'max'         => 65535,
					'description' => 'اگر مطمئن نیستید: TLS → ۵۸۷، SSL → ۴۶۵، بدون رمزگذاری → ۲۵.',
				)
			);

			WCMA_Admin_Fields::toggle(
				'smtp_auth',
				'ورود با نام کاربری و رمز',
				'',
				'تقریباً همه‌ی سرویس‌ها این را لازم دارند. فقط برای سرورهای داخلی بدون احراز هویت خاموشش کنید.'
			);
			?>
		</div>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::text(
				'smtp_user',
				'نام کاربری',
				array( 'placeholder' => 'you@example.com' )
			);

			// رمز هرگز داخل صفحه چاپ نمی‌شود؛ خالی گذاشتنش یعنی «تغییر نکند».
			WCMA_Admin_Fields::text(
				'smtp_pass',
				'رمز',
				array(
					'type'        => 'password',
					'value'       => '',
					'placeholder' => WCMA_Settings::get( 'smtp_pass', '' ) ? 'ذخیره شده — خالی یعنی تغییر نکند' : 'رمز حساب ایمیل',
					'attrs'       => array( 'autocomplete' => 'new-password' ),
					'description' => 'اگر روی حساب ایمیلتان ورود دومرحله‌ای فعال است، به‌جای رمز اصلی باید «رمز اپلیکیشن» بسازید.',
				)
			);
			?>
		</div>

		<h3 class="wcma-subtitle">هویت فرستنده</h3>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::text(
				'smtp_from_email',
				'ایمیل فرستنده',
				array(
					'type'        => 'email',
					'placeholder' => 'no-reply@example.com',
					'description' => 'خالی بگذارید تا همان «ایمیل فرستنده»ی کارت پایین استفاده شود. بیشتر سرورها فقط نشانی‌ای را می‌پذیرند که به حساب SMTP تعلق دارد.',
				)
			);

			WCMA_Admin_Fields::text( 'smtp_from_name', 'نام فرستنده', array( 'placeholder' => get_bloginfo( 'name' ) ) );
			?>
		</div>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::toggle(
				'smtp_force_from',
				'هویت فرستنده روی همه‌ی ایمیل‌های سایت اعمال شود',
				'',
				'شامل ایمیل‌های ووکامرس و خود وردپرس هم می‌شود. اگر سرور شما فقط یک نشانی مجاز دارد، این را روشن بگذارید وگرنه بعضی ایمیل‌ها رد می‌شوند.'
			);

			WCMA_Admin_Fields::toggle(
				'smtp_debug',
				'ثبت گفتگوی خام با سرور برای عیب‌یابی',
				'',
				'فقط هنگام اشکال‌زدایی روشن کنید؛ متن پاسخ سرور در نتیجه‌ی آزمون نشان داده می‌شود.'
			);
			?>
		</div>

		<div class="wcma-conntest" id="wcma-smtp-test">
			<div class="wcma-conntest__head">
				<span class="dashicons dashicons-email-alt"></span>
				<div>
					<strong>آزمون ارسال با SMTP</strong>
					<p>بدون ذخیره کردن هم کار می‌کند؛ مقادیر همین فرم برای آزمون به کار می‌روند.</p>
				</div>
			</div>

			<div class="wcma-conntest__row">
				<input type="email" class="wcma-conntest__to" dir="ltr" placeholder="you@example.com" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" />
				<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-smtp-test-btn">
					<span class="dashicons dashicons-email-alt"></span>
					ارسال ایمیل آزمایشی
				</button>
			</div>

			<div class="wcma-conntest__result"></div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پنل ایمیل', 'ایمیل‌ها با همان سامانه‌ی ایمیل وردپرس ارسال می‌شوند؛ اینجا فقط هویت فرستنده و رفتار جایگزینی را تعیین می‌کنید.', 'email', '', 'email-panel' ); ?>
		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::text( 'from_name', 'نام فرستنده‌ی ایمیل' );
			WCMA_Admin_Fields::text( 'from_email', 'ایمیل فرستنده', array( 'type' => 'email' ) );
			?>
		</div>

		<?php
		WCMA_Admin_Fields::toggle(
			'sms_fallback_email',
			'در صورت ناموفق بودن پیامک، ایمیل هم ارسال شود',
			'اگر ارسال پیامک با خطا مواجه شود، همان پیام به‌صورت ایمیل برای مشتری فرستاده می‌شود.'
		);

		WCMA_Admin_Fields::toggle(
			'unsubscribe_enabled',
			'نمایش لینک لغو اشتراک و تیک عضویت در خبرنامه',
			'لینک لغو اشتراک در انتهای ایمیل‌ها درج می‌شود و در صفحه‌ی پرداخت، تیک دریافت پیشنهادها نمایش داده می‌شود.'
		);
		?>

		<div class="wcma-conntest" data-channel="email">
			<div class="wcma-conntest__head">
				<span class="dashicons dashicons-email-alt"></span>
				<div>
					<strong>تست ارسال ایمیل</strong>
					<p>یک ایمیل واقعی به نشانی زیر فرستاده می‌شود تا از درستی تنظیمات مطمئن شوید.</p>
				</div>
			</div>

			<div class="wcma-conntest__row">
				<input type="email" class="wcma-conntest__to" dir="ltr" placeholder="you@example.com" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" />
				<button type="button" class="wcma-btn wcma-btn--secondary wcma-conntest__btn">
					<span class="dashicons dashicons-email-alt"></span>
					تست اتصال و ارسال ایمیل
				</button>
			</div>

			<div class="wcma-conntest__result"></div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php foreach ( WCMA_Messengers::all() as $wcma_key => $wcma_msgr ) : ?>
		<?php
		WCMA_Admin_Fields::card_start(
			'کانال ' . $wcma_msgr['label'],
			$wcma_msgr['help'],
			$wcma_msgr['icon']
		);
		?>

			<?php WCMA_Admin_Fields::toggle( $wcma_msgr['enabled_key'], 'فعال بودن کانال ' . $wcma_msgr['label'] ); ?>

			<div class="wcma-row">
				<?php
				WCMA_Admin_Fields::text(
					$wcma_msgr['token_key'],
					$wcma_msgr['token_label'],
					array(
						'type'        => 'password',
						'placeholder' => $wcma_msgr['token_holder'],
					)
				);

				WCMA_Admin_Fields::text(
					$wcma_msgr['chat_key'],
					$wcma_msgr['chat_label'],
					array( 'placeholder' => $wcma_msgr['chat_holder'] )
				);
				?>
			</div>

			<?php if ( 'whatsapp' === $wcma_key ) : ?>
				<div class="wcma-row wcma-row--3">
					<?php
					WCMA_Admin_Fields::text(
						'whatsapp_template',
						'نام قالب تأییدشده (Template)',
						array(
							'placeholder' => 'مثال: marketing_fa',
							'description' => 'برای پیام تبلیغاتی الزامی است.',
						)
					);

					WCMA_Admin_Fields::text(
						'whatsapp_template_lang',
						'زبان قالب',
						array( 'placeholder' => 'fa' )
					);

					WCMA_Admin_Fields::text(
						'whatsapp_api_version',
						'نسخه‌ی API',
						array( 'placeholder' => 'v21.0' )
					);
					?>
				</div>

				<div class="wcma-info wcma-info--warn">
					<span class="dashicons dashicons-warning"></span>
					<div>
						<strong>نکته‌ی مهم درباره‌ی واتساپ</strong>
						<p>
							در واتساپ، پیامی که شما آغاز می‌کنید فقط در صورتی تحویل داده می‌شود که یک
							<strong>قالب تأییدشده توسط متا</strong> داشته باشد؛ مگر آنکه مشتری در ۲۴ ساعت
							گذشته به شما پیام داده باشد. اگر فیلد بالا را خالی بگذارید، پیام‌ها به‌صورت
							متن ساده ارسال می‌شوند و خارج از آن بازه‌ی ۲۴ ساعته رد خواهند شد.
						</p>
						<p>
							قالب را با یک متغیر <code dir="ltr">{{1}}</code> در بدنه بسازید؛ متن تولیدشده‌ی
							افزونه در همان متغیر قرار می‌گیرد.
						</p>
					</div>
				</div>
			<?php else : ?>
				<div class="wcma-info">
					<span class="dashicons dashicons-info"></span>
					<div>
						پیام‌های <?php echo esc_html( $wcma_msgr['label'] ); ?> به کانال/چت بالا ارسال می‌شوند.
						برای ارسال به یک مشتری خاص، شناسه‌ی چت او را در پروفایل کاربر
						(فیلد <code dir="ltr">wcma_<?php echo esc_html( $wcma_key ); ?>_chat_id</code>) ذخیره کنید.
						این کانال بیشتر برای اطلاع‌رسانی به کانال فروشگاه و کمپین‌های عمومی مناسب است.
					</div>
				</div>
			<?php endif; ?>

			<?php if ( WCMA_Bot_Link::is_linkable( $wcma_key ) ) : ?>
				<?php
				$wcma_connected = WCMA_Bot_Link::connected_count( $wcma_key );
				$wcma_hook      = WCMA_Bot_Link::webhook_url( $wcma_key );
				?>
				<div class="wcma-botlink">
					<div class="wcma-botlink__head">
						<span class="dashicons dashicons-admin-links"></span>
						<div>
							<strong>اتصال مستقیم به مشتریان</strong>
							<p>
								ربات‌ها اجازه ندارند اول شروع‌کننده‌ی گفتگو باشند، پس با شماره‌ی موبایل
								نمی‌توان به مشتری پیام داد. با تنظیم زیر، مشتری یک بار ربات را باز می‌کند
								و از آن پس پیام‌های او به‌جای کانال عمومی، مستقیم به خودش می‌رسد.
							</p>
						</div>
					</div>

					<?php
					WCMA_Admin_Fields::text(
						$wcma_key . '_bot_username',
						'نام کاربری ربات (بدون @)',
						array(
							'placeholder' => 'MyShopBot',
							'description' => 'برای ساخت لینک اتصال اختصاصی هر مشتری لازم است.',
						)
					);
					?>

					<div class="wcma-botlink__hook">
						<label class="wcma-field__label">نشانی وب‌هوک (Webhook)</label>
						<input type="text" readonly value="<?php echo esc_attr( $wcma_hook ); ?>" dir="ltr" onfocus="this.select()" />
						<p class="wcma-field__desc">
							این نشانی را در پنل ربات ثبت کنید، یا دکمه‌ی زیر را بزنید تا خودکار ثبت شود
							(نیازمند SSL فعال روی سایت).
						</p>
					</div>

					<div class="wcma-botlink__actions">
						<button type="button" class="wcma-btn wcma-btn--secondary wcma-register-hook" data-messenger="<?php echo esc_attr( $wcma_key ); ?>">
							<span class="dashicons dashicons-admin-links"></span>
							ثبت خودکار وب‌هوک
						</button>
						<span class="wcma-botlink__count">
							<strong><?php echo esc_html( number_format_i18n( $wcma_connected ) ); ?></strong>
							مشتری متصل
						</span>
					</div>
					<div class="wcma-botlink__result"></div>

					<div class="wcma-info">
						<span class="dashicons dashicons-info"></span>
						<div>
							پس از ثبت وب‌هوک، مشتری دو راه برای اتصال دارد: لینک اختصاصی
							(<code dir="ltr">{<?php echo esc_html( $wcma_key ); ?>_connect}</code> که می‌توانید در ایمیل و پیامک بگذارید)،
							یا باز کردن ربات و زدن دکمه‌ی «اشتراک‌گذاری شماره‌ی من» که خودکار او را
							به حساب ووکامرسش وصل می‌کند.
						</div>
					</div>
				</div>
			<?php endif; ?>

			<div class="wcma-conntest" data-channel="<?php echo esc_attr( $wcma_key ); ?>">
				<div class="wcma-conntest__head">
					<span class="dashicons dashicons-admin-plugins"></span>
					<div>
						<strong>تست اتصال <?php echo esc_html( $wcma_msgr['label'] ); ?></strong>
						<p>یک پیام آزمایشی واقعی ارسال می‌شود. نیازی به ذخیره کردن نیست؛ همین مقادیر واردشده آزموده می‌شوند.</p>
					</div>
				</div>
				<div class="wcma-conntest__row">
					<input
						type="text"
						class="wcma-conntest__to"
						data-fallback="<?php echo esc_attr( $wcma_msgr['chat_key'] ); ?>"
						placeholder="<?php echo 'whatsapp' === $wcma_key ? 'شماره موبایل گیرنده، مثال: 09121234567' : 'خالی بگذارید تا به همان مقصد بالا ارسال شود'; ?>"
					/>
					<button type="button" class="wcma-btn wcma-btn--secondary wcma-conntest__btn">
						<span class="dashicons dashicons-send"></span>
						تست اتصال <?php echo esc_html( $wcma_msgr['label'] ); ?>
					</button>
				</div>
				<div class="wcma-conntest__result"></div>
			</div>

		<?php WCMA_Admin_Fields::card_end(); ?>
	<?php endforeach; ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
