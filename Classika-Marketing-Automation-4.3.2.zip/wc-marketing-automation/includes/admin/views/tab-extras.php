<?php
/**
 * تب ۵: تبریک تولد و اطلاع‌رسانی وضعیت سفارش.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$channels    = WCMA_Sender::channels();
$status_map  = (array) WCMA_Settings::get( 'os_statuses', array() );
$all_statuses = WCMA_Admin_Fields::order_status_options();
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'تبریک تولد مشتری', 'در روز تولد مشتری یک پیام همراه با هدیه ارسال می‌شود.', 'buddicons-activity' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'bd_enabled', 'فعال بودن پیام تولد' );

		WCMA_Admin_Fields::toggle(
			'bd_field_enabled',
			'نمایش فیلد تاریخ تولد در حساب کاربری و صفحه‌ی پرداخت',
			'بدون این فیلد، تاریخ تولد مشتریان جمع‌آوری نمی‌شود.'
		);
		?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'bd_days_before',
				'ارسال چند روز قبل از تولد',
				array(
					'type'        => 'number',
					'min'         => 0,
					'max'         => 30,
					'suffix'      => 'روز',
					'description' => 'صفر یعنی دقیقاً روز تولد.',
				)
			);

			WCMA_Admin_Fields::select( 'bd_channel', 'کانال ارسال', $channels );

			WCMA_Admin_Fields::text(
				'bd_coupon_days',
				'اعتبار کد هدیه',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);
			?>
		</div>

		<?php WCMA_Admin_Fields::toggle( 'bd_coupon', 'همراه پیام تولد، کد تخفیف هدیه ارسال شود' ); ?>

		<div class="wcma-row wcma-coupon-fields">
			<?php
			WCMA_Admin_Fields::select(
				'bd_coupon_type',
				'نوع تخفیف',
				array(
					'percent' => 'درصدی',
					'fixed'   => 'مبلغ ثابت',
				)
			);

			WCMA_Admin_Fields::text(
				'bd_coupon_amount',
				'مقدار تخفیف',
				array(
					'type' => 'number',
					'min'  => 0,
					'step' => '0.01',
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::placeholder_help( array( 'coupon_code', 'coupon_amount', 'coupon_expiry' ) );

		WCMA_Admin_Fields::text( 'bd_subject', 'موضوع ایمیل' );

		WCMA_Admin_Fields::textarea(
			'bd_sms_text',
			'متن پیامک',
			array(
				'rows'    => 3,
				'counter' => true,
			)
		);

		WCMA_Admin_Fields::textarea( 'bd_email_text', 'متن ایمیل', array( 'rows' => 6 ) );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'اطلاع‌رسانی وضعیت سفارش', 'با هر تغییر وضعیت سفارش، به مشتری اطلاع داده می‌شود.', 'update-alt' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'os_enabled', 'فعال بودن اطلاع‌رسانی وضعیت سفارش' );

		WCMA_Admin_Fields::select( 'os_channel', 'کانال ارسال', $channels );

		WCMA_Admin_Fields::placeholder_help( array( 'order_number', 'order_total', 'order_status', 'order_date', 'order_time', 'order_day', 'order_items', 'order_link', 'payment_link', 'payment_method', 'shipping_method', 'order_address', 'order_city' ) );
		?>

		<div class="wcma-status-list">
			<?php
			foreach ( $all_statuses as $status_key => $status_label ) :
				$config = $status_map[ $status_key ] ?? array(
					'active' => 'no',
					'text'   => '',
				);
				$wcma_base   = 'wcma[os_statuses][' . $status_key . ']';
				?>
				<div class="wcma-status-row">
					<div class="wcma-status-row__head">
						<label class="wcma-switch wcma-switch--sm">
							<input type="checkbox" name="<?php echo esc_attr( $wcma_base ); ?>[active]" value="yes" <?php checked( 'yes', $config['active'] ); ?> />
							<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
						</label>
						<strong><?php echo esc_html( $status_label ); ?></strong>
					</div>
					<textarea name="<?php echo esc_attr( $wcma_base ); ?>[text]" rows="2" placeholder="متن پیام برای این وضعیت..."><?php echo esc_textarea( $config['text'] ); ?></textarea>
				</div>
			<?php endforeach; ?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'اطلاع‌رسانی به مدیر فروشگاه', '', 'admin-users' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'os_admin_new_order', 'ارسال پیامک به مدیر هنگام ثبت سفارش جدید' );

		WCMA_Admin_Fields::text(
			'os_admin_phone',
			'شماره موبایل مدیر',
			array( 'placeholder' => '09121234567' )
		);

		WCMA_Admin_Fields::placeholder_help(
			array( 'order_number', 'order_total', 'order_status', 'order_date', 'order_time', 'order_items', 'order_link', 'payment_method', 'shipping_method', 'order_address', 'order_city' )
		);

		WCMA_Admin_Fields::textarea(
			'os_admin_text',
			'متن پیامک مدیر',
			array(
				'rows'    => 2,
				'counter' => true,
			)
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
