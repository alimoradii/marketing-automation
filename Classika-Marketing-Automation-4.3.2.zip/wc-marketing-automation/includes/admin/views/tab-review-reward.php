<?php
/**
 * تب ۳: پاداش ثبت نظر.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$channels = WCMA_Sender::channels();
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'پاداش ثبت نظر', 'به‌محض تأیید نظر مشتری، یک کد تخفیف اختصاصی ساخته و برایش ارسال می‌شود.', 'awards' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'rw_enabled', 'فعال بودن پاداش ثبت نظر' );

		WCMA_Admin_Fields::select( 'rw_channel', 'کانال ارسال', $channels );

		WCMA_Admin_Fields::select(
			'rw_min_rating',
			'حداقل امتیاز لازم برای دریافت پاداش',
			array(
				1 => 'همه‌ی نظرها (۱ ستاره به بالا)',
				2 => '۲ ستاره به بالا',
				3 => '۳ ستاره به بالا',
				4 => '۴ ستاره به بالا',
				5 => 'فقط ۵ ستاره',
			),
			array( 'description' => 'توجه: محدود کردن پاداش به امتیازهای بالا می‌تواند بی‌طرفی نظرات را خدشه‌دار کند.' )
		);

		WCMA_Admin_Fields::toggle(
			'rw_require_verified',
			'فقط خریداران واقعی محصول پاداش بگیرند',
			'نظر باید از سوی کسی باشد که محصول را خریده است (خرید تأییدشده).'
		);

		WCMA_Admin_Fields::toggle(
			'rw_once_per_customer',
			'هر مشتری فقط یک بار پاداش بگیرد',
			'اگر غیرفعال باشد، مشتری برای هر نظر جدید روی محصولات مختلف پاداش می‌گیرد.'
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'مشخصات کد تخفیف', '', 'tickets-alt' ); ?>
		<div class="wcma-row wcma-row--4">
			<?php
			WCMA_Admin_Fields::select(
				'rw_coupon_type',
				'نوع تخفیف',
				array(
					'percent' => 'درصدی',
					'fixed'   => 'مبلغ ثابت',
				)
			);

			WCMA_Admin_Fields::text(
				'rw_coupon_amount',
				'مقدار تخفیف',
				array(
					'type' => 'number',
					'min'  => 0,
					'step' => '0.01',
				)
			);

			WCMA_Admin_Fields::text(
				'rw_coupon_days',
				'اعتبار کد',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);

			WCMA_Admin_Fields::text(
				'rw_coupon_min_spend',
				'حداقل مبلغ سفارش',
				array(
					'type'        => 'number',
					'min'         => 0,
					'description' => 'صفر یعنی بدون محدودیت.',
				)
			);
			?>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>کد تخفیف به‌صورت یکتا ساخته می‌شود، فقط برای ایمیل همان مشتری قابل استفاده است و یک بار مصرف خواهد بود.</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'متن پیام', '', 'edit' ); ?>
		<?php
		WCMA_Admin_Fields::placeholder_help( array( 'product_name', 'product_link', 'order_number', 'coupon_code', 'coupon_amount', 'coupon_expiry', 'unsubscribe' ) );

		WCMA_Admin_Fields::text( 'rw_subject', 'موضوع ایمیل' );

		WCMA_Admin_Fields::textarea(
			'rw_sms_text',
			'متن پیامک',
			array(
				'rows'    => 3,
				'counter' => true,
			)
		);

		WCMA_Admin_Fields::textarea( 'rw_email_text', 'متن ایمیل (HTML مجاز است)', array( 'rows' => 7 ) );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
