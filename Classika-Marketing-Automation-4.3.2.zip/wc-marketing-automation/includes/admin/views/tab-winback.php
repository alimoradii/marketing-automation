<?php
/**
 * تب ۴: خرید مجدد (بازگرداندن مشتریان غیرفعال).
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$channels = WCMA_Sender::channels();
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'خرید مجدد', 'مشتریانی که مدتی است خرید نکرده‌اند را با یک پیشنهاد ویژه بازگردانید.', 'update' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'wb_enabled', 'فعال بودن ورک‌فلو خرید مجدد' );

		WCMA_Admin_Fields::select( 'wb_channel', 'کانال ارسال', $channels );
		?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'wb_inactive_days',
				'بدون خرید به مدت',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);

			WCMA_Admin_Fields::text(
				'wb_min_orders',
				'حداقل تعداد سفارش قبلی',
				array(
					'type'        => 'number',
					'min'         => 1,
					'description' => 'فقط مشتریانی که حداقل این تعداد خرید داشته‌اند هدف قرار می‌گیرند.',
				)
			);

			WCMA_Admin_Fields::text(
				'wb_repeat_days',
				'فاصله تا ارسال بعدی به همان مشتری',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);
			?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پیشنهاد تشویقی', '', 'tickets-alt' ); ?>
		<?php WCMA_Admin_Fields::toggle( 'wb_coupon', 'همراه پیام، کد تخفیف اختصاصی ارسال شود' ); ?>

		<div class="wcma-row wcma-row--3 wcma-coupon-fields">
			<?php
			WCMA_Admin_Fields::select(
				'wb_coupon_type',
				'نوع تخفیف',
				array(
					'percent' => 'درصدی',
					'fixed'   => 'مبلغ ثابت',
				)
			);

			WCMA_Admin_Fields::text(
				'wb_coupon_amount',
				'مقدار تخفیف',
				array(
					'type' => 'number',
					'min'  => 0,
					'step' => '0.01',
				)
			);

			WCMA_Admin_Fields::text(
				'wb_coupon_days',
				'اعتبار کد',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);
			?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'متن پیام', '', 'edit' ); ?>
		<?php
		WCMA_Admin_Fields::placeholder_help( array( 'site_url', 'order_date', 'order_count', 'coupon_code', 'coupon_amount', 'coupon_expiry', 'unsubscribe' ) );

		WCMA_Admin_Fields::text( 'wb_subject', 'موضوع ایمیل' );

		WCMA_Admin_Fields::textarea(
			'wb_sms_text',
			'متن پیامک',
			array(
				'rows'    => 3,
				'counter' => true,
			)
		);

		WCMA_Admin_Fields::textarea( 'wb_email_text', 'متن ایمیل (HTML مجاز است)', array( 'rows' => 7 ) );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
