<?php
/**
 * تب پیشخوان: نمای کلی وضعیت.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$stats       = WCMA_Logger::stats( 30 );
$queue_stats = WCMA_Queue::stats();
$cart_stats  = WCMA_Carts::stats();
$workflows   = WCMA_Plugin::instance()->get_workflows();

$conversion_rate = $stats['sent'] > 0 ? round( ( $stats['conversions'] / $stats['sent'] ) * 100, 1 ) : 0;
?>

<div class="wcma-stats">
	<div class="wcma-stat wcma-stat--blue">
		<span class="wcma-stat__icon dashicons dashicons-email-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['sent'] ) ); ?></span>
			<span class="wcma-stat__label">پیام ارسال‌شده (۳۰ روز اخیر)</span>
		</div>
	</div>

	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-cart"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['conversions'] ) ); ?></span>
			<span class="wcma-stat__label">خرید انجام‌شده در پی پیام‌ها</span>
		</div>
	</div>

	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-chart-line"></span>
		<div>
			<span class="wcma-stat__value"><?php echo wp_kses_post( WCMA_Date::price( $stats['revenue'] ) ); ?></span>
			<span class="wcma-stat__label">درآمد بازیابی‌شده</span>
		</div>
	</div>

	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-performance"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $conversion_rate, 1 ) ); ?>٪</span>
			<span class="wcma-stat__label">نرخ تبدیل پیام‌ها</span>
		</div>
	</div>
</div>

<div class="wcma-grid wcma-grid--2">

	<?php WCMA_Admin_Fields::card_start( 'وضعیت ورک‌فلوها', 'برای پیکربندی هر ورک‌فلو روی آن کلیک کنید.', 'admin-settings' ); ?>
		<ul class="wcma-workflow-list">
			<?php
			$wcma_tab_map = array(
				'abandoned_cart'  => 'abandoned',
				'review_reminder' => 'review-reminder',
				'review_reward'   => 'review-reward',
				'winback'         => 'winback',
				'stock_alert'     => 'stock',
				'vip_club'        => 'vip',
				'birthday'        => 'extras',
				'order_status'    => 'extras',
			);

			foreach ( $workflows as $workflow ) :
				$wf_id     = $workflow->get_id();
				$wf_active = $workflow->is_enabled();
				$wf_tab    = $wcma_tab_map[ $wf_id ] ?? 'general';
				$wf_stats  = $stats['by_workflow'][ $wf_id ] ?? array(
					'sent'        => 0,
					'conversions' => 0,
				);
				?>
				<li>
					<a href="<?php echo esc_url( WCMA_Admin::tab_url( $wf_tab ) ); ?>" class="wcma-workflow-item">
						<span class="wcma-workflow-item__status <?php echo $wf_active ? 'is-on' : 'is-off'; ?>"></span>
						<span class="wcma-workflow-item__title"><?php echo esc_html( $workflow->get_title() ); ?></span>
						<span class="wcma-workflow-item__meta">
							<?php echo esc_html( number_format_i18n( $wf_stats['sent'] ) ); ?> ارسال
							/
							<?php echo esc_html( number_format_i18n( $wf_stats['conversions'] ) ); ?> تبدیل
						</span>
						<span class="wcma-workflow-item__state <?php echo $wf_active ? 'is-on' : 'is-off'; ?>">
							<?php echo $wf_active ? 'فعال' : 'غیرفعال'; ?>
						</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'سبد خرید و صف ارسال', 'خلاصه‌ی وضعیت لحظه‌ای سیستم.', 'clock' ); ?>
		<div class="wcma-minigrid">
			<div class="wcma-mini">
				<span class="wcma-mini__value"><?php echo esc_html( number_format_i18n( $cart_stats['abandoned'] ) ); ?></span>
				<span class="wcma-mini__label">سبد رها شده</span>
			</div>
			<div class="wcma-mini">
				<span class="wcma-mini__value"><?php echo esc_html( number_format_i18n( $cart_stats['purchased'] ) ); ?></span>
				<span class="wcma-mini__label">سبد بازیابی‌شده</span>
			</div>
			<div class="wcma-mini">
				<span class="wcma-mini__value"><?php echo esc_html( number_format_i18n( $queue_stats['pending'] ) ); ?></span>
				<span class="wcma-mini__label">در صف ارسال</span>
			</div>
			<div class="wcma-mini">
				<span class="wcma-mini__value wcma-mini__value--danger"><?php echo esc_html( number_format_i18n( $stats['failed'] ) ); ?></span>
				<span class="wcma-mini__label">ارسال ناموفق</span>
			</div>
		</div>

		<div class="wcma-health">
			<h3>بررسی سلامت راه‌اندازی</h3>
			<ul class="wcma-checklist">
				<?php
				$wcma_checks = array(
					array(
						'ok'   => WCMA_Settings::is( 'enabled' ),
						'text' => 'افزونه در تنظیمات عمومی فعال است.',
						'fix'  => WCMA_Admin::tab_url( 'general' ),
					),
					array(
						'ok'   => WCMA_Settings::is( 'sms_enabled' ) && WCMA_Settings::get( 'sms_api_key' ) . WCMA_Settings::get( 'sms_username' ),
						'text' => 'پنل پیامک پیکربندی شده است.',
						'fix'  => WCMA_Admin::tab_url( 'sms' ),
					),
					array(
						'ok'   => (bool) wp_next_scheduled( 'wcma_worker_event' ),
						'text' => 'زمان‌بند وردپرس (کرون) فعال است.',
						'fix'  => WCMA_Admin::tab_url( 'general' ),
					),
					array(
						'ok'   => WCMA_Settings::is( 'ab_enabled' ) || WCMA_Settings::is( 'rr_enabled' ) || WCMA_Settings::is( 'wb_enabled' ),
						'text' => 'حداقل یک ورک‌فلو فعال است.',
						'fix'  => WCMA_Admin::tab_url( 'abandoned' ),
					),
				);

				foreach ( $wcma_checks as $check ) :
					?>
					<li class="<?php echo $check['ok'] ? 'is-ok' : 'is-warn'; ?>">
						<span class="dashicons dashicons-<?php echo $check['ok'] ? 'yes-alt' : 'warning'; ?>"></span>
						<span><?php echo esc_html( $check['text'] ); ?></span>
						<?php if ( ! $check['ok'] ) : ?>
							<a href="<?php echo esc_url( $check['fix'] ); ?>">اصلاح</a>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

</div>

<?php WCMA_Admin_Fields::card_start( 'روند ارسال ۳۰ روز اخیر', '', 'chart-bar' ); ?>
	<?php if ( ! empty( $stats['daily'] ) ) : ?>
		<?php
		$max = 1;
		foreach ( $stats['daily'] as $day ) {
			$max = max( $max, (int) $day['total'] );
		}
		?>
		<div class="wcma-chart">
			<?php foreach ( $stats['daily'] as $day ) : ?>
				<div class="wcma-chart__col" title="<?php echo esc_attr( $day['day'] . ' — ' . $day['total'] . ' ارسال' ); ?>">
					<div class="wcma-chart__bar" style="height: <?php echo esc_attr( max( 4, round( ( (int) $day['total'] / $max ) * 100 ) ) ); ?>%"></div>
					<span class="wcma-chart__label"><?php echo WCMA_Date::html( $day['day'], 'date' ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="wcma-empty">هنوز ارسالی ثبت نشده است. پس از فعال کردن ورک‌فلوها، نمودار اینجا نمایش داده می‌شود.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
