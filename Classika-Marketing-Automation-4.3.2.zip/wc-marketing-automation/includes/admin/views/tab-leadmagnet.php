<?php
/**
 * برگه‌ی لید مگنت: مسیر ربات تلگرام و فرم روی سایت.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_leads    = WCMA_Lead_Magnet::count();
$wcma_bot_link = WCMA_Settings::get( 'telegram_bot_username' );
$wcma_seq      = WCMA_Bot_Manager::sequence();
?>

<div class="wcma-stats">
	<div class="wcma-stat wcma-stat--blue">
		<span class="wcma-stat__icon dashicons dashicons-groups"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_leads ) ); ?></span>
			<span class="wcma-stat__label">سرنخ جذب‌شده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-format-status"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( count( $wcma_seq ) ) ); ?></span>
			<span class="wcma-stat__label">روز تعریف‌شده در دنباله‌ی ربات</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-tickets-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Lead_Magnet::rewards()[ WCMA_Settings::get( 'lm_reward', 'coupon' ) ] ?? '—' ); ?></span>
			<span class="wcma-stat__label">پاداش فرم</span>
		</div>
	</div>
</div>

<?php WCMA_Admin_Fields::card_start( 'راه اول: ربات تلگرام، خودش لید مگنت', 'بهترین گزینه برای ایران — نرخ باز شدن تلگرام چند برابر ایمیل است و شماره‌ی موبایل هم می‌گیرید.', 'format-chat', '', 'lm-telegram' ); ?>

	<div class="wcma-funnel">
		<div class="wcma-funnel__step">
			<span class="wcma-funnel__num">۱</span>
			<strong>کاربر <code>start/</code> می‌زند</strong>
			<span>از لینک ربات که در اینستاگرام یا سایت گذاشته‌اید.</span>
		</div>
		<div class="wcma-funnel__step">
			<span class="wcma-funnel__num">۲</span>
			<strong>دکمه‌ی اشتراک شماره</strong>
			<span>با یک لمس، شماره‌اش را می‌دهد.</span>
		</div>
		<div class="wcma-funnel__step">
			<span class="wcma-funnel__num">۳</span>
			<strong>ثبت در پرونده‌ی مشتریان</strong>
			<span>شماره خودکار در CRM می‌نشیند.</span>
		</div>
		<div class="wcma-funnel__step">
			<span class="wcma-funnel__num">۴</span>
			<strong>دنباله‌ی ۷ روزه</strong>
			<span>هر روز یک نکته، خودکار.</span>
		</div>
		<div class="wcma-funnel__step is-last">
			<span class="wcma-funnel__num">۵</span>
			<strong>روز آخر: کد تخفیف</strong>
			<span>سرنخ به خریدار تبدیل می‌شود.</span>
		</div>
	</div>

	<div class="wcma-info">
		<span class="dashicons dashicons-lightbulb"></span>
		<div>
			پیام تبلیغی‌تان می‌تواند این باشد:
			<strong>«۷ روز، هر روز یک نکته‌ی رایگان درباره‌ی [موضوع] — ربات را استارت کنید»</strong>
			<?php if ( $wcma_bot_link ) : ?>
				<br />لینک ربات شما:
				<code dir="ltr">https://t.me/<?php echo esc_html( ltrim( $wcma_bot_link, '@' ) ); ?></code>
			<?php else : ?>
				<br />نام کاربری ربات را در «کانال‌های ارتباطی» وارد کنید تا لینک آماده‌ی اشتراک‌گذاری اینجا بیاید.
			<?php endif; ?>
		</div>
	</div>

	<h3 class="wcma-subtitle">راه‌اندازی خودکار</h3>

	<p class="wcma-field__desc">
		موضوع دوره را بنویسید تا افزونه پیام خوش‌آمد، دکمه‌ی شماره و اسکلت ۷ روز را یک‌جا بسازد.
		بعد فقط متن هر روز را در برگه‌ی «ربات تلگرام» پر می‌کنید.
	</p>

	<div class="wcma-conntest__row">
		<input type="text" id="wcma-lm-topic" placeholder="موضوع، مثلاً: نگهداری از پوست" />
		<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-lm-setup">
			<span class="dashicons dashicons-superhero"></span>
			ساخت دنباله‌ی ۷ روزه
		</button>
	</div>

	<div id="wcma-lm-setup-result"></div>

	<p class="wcma-field__desc">
		اگر از قبل دنباله‌ای تعریف کرده باشید، چیزی بازنویسی نمی‌شود.
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'راه دوم: فرم روی سایت', 'فرم را هرجای سایت بگذارید؛ سرنخ مستقیم در پرونده‌ی مشتریان ثبت می‌شود.', 'feedback' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'lm_enabled', 'فعال بودن فرم جذب سرنخ', '', 'تا روشن نباشد، شورت‌کد چیزی نشان نمی‌دهد و فرم‌های ثبت‌شده هم پذیرفته نمی‌شوند.' );

		WCMA_Admin_Fields::text( 'lm_title', 'عنوان فرم' );
		WCMA_Admin_Fields::text( 'lm_subtitle', 'یک خط توضیح' );
		WCMA_Admin_Fields::text( 'lm_button', 'متن دکمه' );

		WCMA_Admin_Fields::toggle( 'lm_ask_name', 'نام هم پرسیده شود' );
		WCMA_Admin_Fields::toggle( 'lm_ask_email', 'ایمیل هم پرسیده شود (اختیاری برای کاربر)' );

		WCMA_Admin_Fields::text( 'lm_tag', 'برچسبی که روی این سرنخ‌ها بخورد', array( 'description' => 'برای فیلتر کردنشان در پرونده‌ی مشتریان و ساخت کمپین.', 'help' => 'با این برچسب می‌توانید بعداً فقط همین گروه را در CRM فیلتر کنید یا برایشان کمپین بفرستید.' ) );
		WCMA_Admin_Fields::textarea( 'lm_consent', 'متن رضایت زیر فرم', array( 'rows' => 2 ) );
		WCMA_Admin_Fields::textarea( 'lm_success', 'پیام پس از ثبت موفق', array( 'rows' => 2 ) );
		?>

		<div class="wcma-info">
			<span class="dashicons dashicons-shortcode"></span>
			<div>
				این شورت‌کد را در هر برگه، نوشته یا ابزارک بگذارید:
				<code dir="ltr">[wcma_lead_form]</code>
				<br />
				می‌توانید عنوان را همان‌جا هم عوض کنید:
				<code dir="ltr">[wcma_lead_form title="عنوان دلخواه"]</code>
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پاداش و پیام تحویل', 'چیزی که بلافاصله پس از ثبت به سرنخ می‌رسد.', 'awards', 'این پیام پاسخِ درخواست خود کاربر است، پس حتی به کسانی که تبلیغات را لغو کرده‌اند هم فرستاده می‌شود.' ); ?>
		<?php
		WCMA_Admin_Fields::select( 'lm_reward', 'پاداش', WCMA_Lead_Magnet::rewards(), array( 'help' => 'کد تخفیف، یک کوپن واقعی ووکامرس می‌سازد که فقط برای همین شخص است. فایل دانلودی، لینک را در پیام می‌فرستد.' ) );
		?>

		<div class="wcma-lm-reward" data-reward="file">
			<?php WCMA_Admin_Fields::text( 'lm_file', 'نشانی فایل', array( 'placeholder' => 'https://example.com/guide.pdf', 'description' => 'فایل را در «رسانه» آپلود و نشانی‌اش را اینجا بگذارید.' ) ); ?>
		</div>

		<div class="wcma-lm-reward" data-reward="coupon">
			<?php
			WCMA_Admin_Fields::select( 'lm_coupon_type', 'نوع تخفیف', array( 'percent' => 'درصدی', 'fixed_cart' => 'مبلغ ثابت' ) );
			WCMA_Admin_Fields::text( 'lm_coupon_amount', 'مقدار تخفیف', array( 'type' => 'number', 'min' => 1 ) );
			WCMA_Admin_Fields::text( 'lm_coupon_days', 'اعتبار کد (روز)', array( 'type' => 'number', 'min' => 1 ) );
			WCMA_Admin_Fields::text( 'lm_coupon_min', 'حداقل مبلغ سبد برای استفاده', array( 'type' => 'number', 'min' => 0 ) );
			?>
		</div>

		<h3 class="wcma-subtitle">پیام تحویل</h3>

		<?php
		WCMA_Admin_Fields::select( 'lm_channel', 'از چه راهی فرستاده شود', WCMA_Sender::channels() );
		WCMA_Admin_Fields::text( 'lm_subject', 'موضوع ایمیل' );
		WCMA_Admin_Fields::textarea( 'lm_sms_text', 'متن پیامک', array( 'rows' => 3 ) );
		WCMA_Admin_Fields::textarea( 'lm_email_text', 'متن ایمیل', array( 'rows' => 4, 'description' => 'خالی بگذارید تا همان متن پیامک استفاده شود.' ) );
		?>

		<?php WCMA_Admin_Fields::placeholder_help( array( 'first_name', 'coupon_code', 'site_title', 'site_url', 'shop_phone' ) ); ?>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				اگر پاداش «فایل دانلودی» باشد، از متغیر <code>{file_link}</code> در متن پیام استفاده کنید.
				این پیام پاسخِ درخواست خود کاربر است، پس حتی به کسانی که تبلیغات را لغو کرده‌اند هم می‌رسد.
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
