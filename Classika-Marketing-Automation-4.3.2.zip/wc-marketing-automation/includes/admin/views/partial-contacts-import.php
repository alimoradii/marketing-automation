<?php
/**
 * کارت ورود مخاطبان از اکسل؛ هم در برگه‌ی ربات، هم در پرونده‌ی مشتریان.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_import_report = WCMA_Contacts_Import::last_report();
$wcma_import_stats  = WCMA_Contacts_Import::stats();
$wcma_template_url  = add_query_arg(
	array(
		'wcma_export' => 'contacts_template',
		'_wpnonce'    => wp_create_nonce( 'wcma_contacts_template' ),
	),
	admin_url( 'admin.php?page=wcma' )
);

WCMA_Admin_Fields::card_start(
	'ورود مخاطبان از اکسل',
	'فهرست نام، نام خانوادگی و موبایل را یک‌جا وارد کنید. هر کس با همان شماره ربات را باز کند و شماره‌اش را بدهد، ربات او را به نام می‌شناسد.',
	'upload',
	'مخاطبان در «پرونده‌ی مشتریان» ذخیره می‌شوند. تلگرام شماره‌ی کسی را به ربات نمی‌دهد مگر خودش دکمه‌ی «اشتراک‌گذاری شماره» را بزند؛ پس شناختن، همان لحظه‌ی دادن شماره رخ می‌دهد.',
	'contacts-import'
);
?>
	<div class="wcma-import__stats">
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo esc_html( WCMA_Date::number( $wcma_import_stats['phones'] ) ); ?></span>
			<span class="wcma-mini__label">مخاطب دارای موبایل در پنل</span>
		</div>
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo esc_html( WCMA_Date::number( $wcma_import_stats['imported'] ) ); ?></span>
			<span class="wcma-mini__label">واردشده از فایل</span>
		</div>
		<div class="wcma-mini">
			<span class="wcma-mini__value"><?php echo esc_html( WCMA_Date::number( $wcma_import_stats['in_bot'] ) ); ?></span>
			<span class="wcma-mini__label">شناخته‌شده در ربات</span>
		</div>
	</div>

	<form method="post" enctype="multipart/form-data" class="wcma-import">
		<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
		<input type="hidden" name="wcma_action" value="contacts_import" />

		<div class="wcma-import__row">
			<label class="wcma-import__file">
				<span class="dashicons dashicons-media-spreadsheet"></span>
				<span class="wcma-import__file-text">فایل اکسل (xlsx) یا CSV را انتخاب کنید</span>
				<input type="file" name="wcma_contacts_file" accept=".xlsx,.csv,.txt" required />
			</label>

			<label class="wcma-import__tag">
				<span>برچسب این گروه</span>
				<input type="text" name="wcma_import_tag" value="<?php echo esc_attr( WCMA_Contacts_Import::DEFAULT_TAG ); ?>" />
			</label>
		</div>

		<label class="wcma-import__check">
			<input type="checkbox" name="wcma_import_overwrite" value="1" />
			اگر کسی از قبل در پنل هست، نامش با نام فایل جایگزین شود
		</label>

		<div class="wcma-actions">
			<button type="submit" class="wcma-btn wcma-btn--primary">
				<span class="dashicons dashicons-upload"></span>
				ورود مخاطبان
			</button>
			<a href="<?php echo esc_url( $wcma_template_url ); ?>" class="wcma-btn wcma-btn--ghost">
				<span class="dashicons dashicons-download"></span>
				دانلود فایل نمونه
			</a>
		</div>

		<p class="wcma-field__desc">
			ستون‌ها از روی عنوانشان شناخته می‌شوند: «نام»، «نام خانوادگی» و «موبایل» (یا «نام و نام خانوادگی» در یک ستون).
			شماره با ارقام فارسی، بدون صفر، با ۹۸+ یا با فاصله هم پذیرفته می‌شود. شماره‌ی تکراری یک‌بار ثبت می‌شود.
			حداکثر <?php echo esc_html( WCMA_Date::number( WCMA_Contacts_Import::MAX_ROWS ) ); ?> ردیف در هر فایل.
			مدیران ربات می‌توانند همین فایل را مستقیم در خود ربات هم بفرستند.
		</p>
	</form>

	<?php if ( $wcma_import_report ) : ?>
		<div class="wcma-import__report">
			<div class="wcma-notice wcma-notice--success">
				<span class="dashicons dashicons-yes-alt"></span>
				<span><?php echo esc_html( $wcma_import_report['message'] ); ?></span>
			</div>

			<?php if ( ! empty( $wcma_import_report['samples'] ) ) : ?>
				<p class="wcma-field__desc">این ردیف‌ها شماره‌ی موبایل معتبر نداشتند و وارد نشدند:</p>
				<div class="wcma-table-wrap">
					<table class="wcma-table">
						<thead>
							<tr>
								<th>ردیف</th>
								<th>نام</th>
								<th>مقدار ستون موبایل</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $wcma_import_report['samples'] as $wcma_sample ) : ?>
								<tr>
									<td><?php echo esc_html( WCMA_Date::number( $wcma_sample['row'] ) ); ?></td>
									<td><?php echo esc_html( $wcma_sample['name'] ? $wcma_sample['name'] : '—' ); ?></td>
									<td dir="ltr"><?php echo esc_html( '' !== $wcma_sample['phone'] ? $wcma_sample['phone'] : '(خالی)' ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>

			<a class="wcma-btn wcma-btn--ghost" href="<?php echo esc_url( add_query_arg( array( 'c_source' => 'import' ), WCMA_Admin::tab_url( 'crm' ) ) ); ?>">
				<span class="dashicons dashicons-id-alt"></span>
				دیدن مخاطبان واردشده در پرونده‌ی مشتریان
			</a>
		</div>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
