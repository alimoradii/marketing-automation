<?php
/**
 * چارچوب کلی صفحه‌ی مدیریت.
 *
 * @package WCMA
 *
 * @var string $tab      تب جاری.
 * @var array  $tabs     فهرست تب‌ها.
 * @var array  $groups   گروه‌های منو.
 * @var array  $notices  اعلان‌ها.
 * @var array  $settings تنظیمات.
 */

defined( 'ABSPATH' ) || exit;

$wcma_master_on = WCMA_Settings::is( 'enabled' );
$wcma_last_run  = get_option( 'wcma_last_run' );
?>
<div class="wrap wcma-wrap" dir="rtl">

	<div class="wcma-topbar">
		<div class="wcma-topbar__brand">
			<span class="wcma-topbar__logo dashicons dashicons-megaphone"></span>
			<div>
				<h1 class="wcma-topbar__title">اتوماسیون بازاریابی کلاسیکا</h1>
				<span class="wcma-topbar__team">تیم دکتر علی مرادی</span>
				<p class="wcma-topbar__subtitle">فروش بیشتر با پیگیری خودکار مشتریان</p>
			</div>
		</div>

		<div class="wcma-topbar__meta">
			<span class="wcma-pill <?php echo $wcma_master_on ? 'wcma-pill--on' : 'wcma-pill--off'; ?>">
				<span class="wcma-dot"></span>
				<?php echo $wcma_master_on ? 'افزونه فعال است' : 'افزونه غیرفعال است'; ?>
			</span>

			<?php if ( $wcma_last_run ) : ?>
				<span class="wcma-pill wcma-pill--muted" title="آخرین اجرای زمان‌بند">
					<span class="dashicons dashicons-clock"></span>
					آخرین اجرا: <?php echo WCMA_Date::html( $wcma_last_run ); ?>
				</span>
			<?php endif; ?>

			<?php if ( WCMA_SMS_Gateways::has_balance() ) : ?>
				<span
					class="wcma-pill wcma-pill--muted wcma-credit"
					id="wcma-sms-credit"
					title="اعتبار پنل پیامک — برای استعلام دوباره کلیک کنید"
					role="button"
					tabindex="0"
				>
					<span class="dashicons dashicons-chart-pie"></span>
					<span class="wcma-credit__text">اعتبار پیامک: در حال استعلام…</span>
				</span>
			<?php endif; ?>

			<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-run-now">
				<span class="dashicons dashicons-update"></span>
				اجرای فوری زمان‌بند
			</button>
		</div>
	</div>

	<?php foreach ( $notices as $notice ) : ?>
		<div class="wcma-notice wcma-notice--<?php echo esc_attr( $notice[0] ); ?>">
			<span class="dashicons dashicons-<?php echo 'success' === $notice[0] ? 'yes-alt' : 'warning'; ?>"></span>
			<span><?php echo esc_html( $notice[1] ); ?></span>
		</div>
	<?php endforeach; ?>

	<div class="wcma-layout">

		<nav class="wcma-nav">
			<?php foreach ( $groups as $group_key => $group_label ) : ?>
				<div class="wcma-nav__group">
					<span class="wcma-nav__group-title"><?php echo esc_html( $group_label ); ?></span>
					<ul>
						<?php
						foreach ( $tabs as $tab_key => $tab_data ) :
							if ( $tab_data['group'] !== $group_key ) {
								continue;
							}
							$is_active = ( $tab_key === $tab );
							$wcma_kids = isset( $tab_data['children'] ) ? (array) $tab_data['children'] : array();
							?>
							<li class="wcma-nav__row<?php echo $wcma_kids ? ' has-flyout' : ''; ?>">
								<a href="<?php echo esc_url( WCMA_Admin::tab_url( $tab_key ) ); ?>" class="wcma-nav__item <?php echo $is_active ? 'is-active' : ''; ?>"<?php echo $wcma_kids ? ' aria-haspopup="true"' : ''; ?>>
									<span class="dashicons dashicons-<?php echo esc_attr( $tab_data['icon'] ); ?>"></span>
									<span class="wcma-nav__label"><?php echo esc_html( $tab_data['title'] ); ?></span>
									<?php if ( ! empty( $tab_data['badge'] ) ) : ?>
										<span class="wcma-nav__badge"><?php echo esc_html( $tab_data['badge'] ); ?></span>
									<?php endif; ?>
									<?php if ( $wcma_kids ) : ?>
										<span class="wcma-nav__caret dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
									<?php endif; ?>
								</a>
								
								<?php if ( $wcma_kids ) : ?>
									<div class="wcma-flyout">
										<span class="wcma-flyout__title">تنظیمات هر بخش</span>
										<ul>
											<?php foreach ( $wcma_kids as $wcma_kid ) : ?>
												<li>
													<a class="wcma-flyout__item" href="<?php echo esc_url( WCMA_Admin::section_url( $wcma_kid ) ); ?>">
														<span class="dashicons dashicons-<?php echo esc_attr( $wcma_kid['icon'] ); ?>"></span>
														<span><?php echo esc_html( $wcma_kid['title'] ); ?></span>
													</a>
												</li>
											<?php endforeach; ?>
										</ul>
									</div>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</nav>

		<main class="wcma-content">
			<?php
			$wcma_view = WCMA_PATH . 'includes/admin/views/tab-' . $tab . '.php';

			if ( file_exists( $wcma_view ) ) {
				include $wcma_view;
			} else {
				echo '<p>صفحه پیدا نشد.</p>';
			}
			?>
		</main>

	</div>

	<div class="wcma-footer">
		<span>اتوماسیون بازاریابی کلاسیکا — تیم دکتر علی مرادی · نسخه <?php echo esc_html( WCMA_Date::digits( WCMA_VERSION ) ); ?></span>
	</div>

</div>

<div class="wcma-toast" id="wcma-toast"></div>
