<?php
/**
 * تب کمپین‌ها (ایمیل / پیامک / تلگرام).
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wcma_cpage = isset( $_GET['campage'] ) ? max( 1, (int) $_GET['campage'] ) : 1;
$wcma_cper  = WCMA_Admin::per_page( 'cam_per' );
$campaigns  = WCMA_Campaigns::all( $wcma_cper, $wcma_cpage );
$wcma_ctot  = WCMA_Campaigns::count();
$audiences = WCMA_Campaigns::audience_types();
// کمپین‌ها روی هر کانالی جز حالت ترکیبی «پیامک و ایمیل» ارسال می‌شوند.
$channels = WCMA_Sender::channels();
unset( $channels['both'] );

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$edit_id  = isset( $_GET['campaign'] ) ? (int) $_GET['campaign'] : 0;
$editing  = $edit_id ? WCMA_Campaigns::get( $edit_id ) : null;
$audience = $editing ? $editing['audience'] : array();

$status_labels = array(
	'draft'     => array( 'پیش‌نویس', 'gray' ),
	'running'   => array( 'در حال ارسال', 'blue' ),
	'paused'    => array( 'متوقف شده', 'amber' ),
	'completed' => array( 'تکمیل شده', 'green' ),
);
?>

<?php WCMA_Admin_Fields::card_start( $editing ? 'ویرایش کمپین' : 'ساخت کمپین جدید', 'یک پیام را برای گروهی از مشتریان ارسال کنید.', 'megaphone' ); ?>
	<form method="post" class="wcma-form" id="wcma-campaign-form">
		<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
		<input type="hidden" name="wcma_action" value="save_campaign" />
		<input type="hidden" name="campaign_id" value="<?php echo esc_attr( $editing ? $editing['id'] : 0 ); ?>" />

		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::text(
				'campaign_title',
				'عنوان کمپین (فقط برای مدیریت داخلی)',
				array(
					'name'  => 'campaign_title',
					'value' => $editing ? $editing['title'] : '',
				)
			);

			WCMA_Admin_Fields::select(
				'campaign_channel',
				'کانال ارسال',
				$channels,
				array(
					'name'  => 'campaign_channel',
					'value' => $editing ? $editing['channel'] : 'email',
				)
			);
			?>
		</div>

		<h3 class="wcma-subtitle">۱. انتخاب مخاطبان</h3>

		<?php
		WCMA_Admin_Fields::select(
			'audience_type',
			'مخاطبان این کمپین',
			$audiences,
			array(
				'name'  => 'audience_type',
				'value' => $audience['type'] ?? 'all_customers',
			)
		);
		?>

		<div class="wcma-audience-fields">
			<div data-audience="buyers_product">
				<label class="wcma-field__label" for="audience_product_ids">محصولات موردنظر</label>
				<select name="audience_product_ids[]" id="audience_product_ids" multiple class="wc-product-search" data-placeholder="جستجوی محصول..." data-action="woocommerce_json_search_products_and_variations" style="width:100%">
					<?php
					foreach ( (array) ( $audience['product_ids'] ?? array() ) as $pid ) {
						$product = wc_get_product( $pid );
						if ( $product ) {
							printf( '<option value="%d" selected>%s</option>', (int) $pid, esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ) );
						}
					}
					?>
				</select>
			</div>

			<div data-audience="buyers_cat">
				<?php
				$cats    = get_terms(
					array(
						'taxonomy'   => 'product_cat',
						'hide_empty' => false,
					)
				);
				$cat_opts = array();
				foreach ( (array) $cats as $cat ) {
					if ( ! is_wp_error( $cat ) && isset( $cat->term_id ) ) {
						$cat_opts[ $cat->term_id ] = $cat->name;
					}
				}

				WCMA_Admin_Fields::select(
					'audience_category_ids',
					'دسته‌بندی‌ها',
					$cat_opts,
					array(
						'name'     => 'audience_category_ids',
						'value'    => $audience['category_ids'] ?? array(),
						'multiple' => true,
						'class'    => 'wc-enhanced-select',
					)
				);
				?>
			</div>

			<div data-audience="top_spenders">
				<?php
				WCMA_Admin_Fields::text(
					'audience_min_spend',
					'حداقل مجموع خرید',
					array(
						'type'  => 'number',
						'min'   => 0,
						'name'  => 'audience_min_spend',
						'value' => $audience['min_spend'] ?? 0,
					)
				);
				?>
			</div>

			<div data-audience="inactive">
				<?php
				WCMA_Admin_Fields::text(
					'audience_inactive_days',
					'بدون خرید به مدت (روز)',
					array(
						'type'  => 'number',
						'min'   => 1,
						'name'  => 'audience_inactive_days',
						'value' => $audience['inactive_days'] ?? 60,
					)
				);
				?>
			</div>

			<div data-audience="manual">
				<?php
				WCMA_Admin_Fields::textarea(
					'audience_manual_list',
					'فهرست دستی (هر ایمیل یا شماره در یک خط)',
					array(
						'rows'  => 5,
						'name'  => 'audience_manual_list',
						'value' => $audience['manual_list'] ?? '',
					)
				);
				?>
			</div>
		</div>

		<div class="wcma-audience-preview">
			<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-preview-audience">
				<span class="dashicons dashicons-groups"></span>
				محاسبه‌ی تعداد مخاطبان
			</button>
			<span class="wcma-audience-preview__result"></span>
		</div>

		<h3 class="wcma-subtitle">۲. نوشتن پیام</h3>

		<?php WCMA_Admin_Fields::placeholder_help( array( 'site_title', 'site_url', 'unsubscribe', 'coupon_code', 'coupon_amount', 'coupon_expiry', 'order_count' ) ); ?>

		<?php
		WCMA_Admin_Fields::text(
			'campaign_subject',
			'موضوع (برای ایمیل)',
			array(
				'name'  => 'campaign_subject',
				'value' => $editing ? $editing['subject'] : '',
			)
		);

		WCMA_Admin_Fields::textarea(
			'campaign_content',
			'متن پیام',
			array(
				'rows'        => 10,
				'name'        => 'campaign_content',
				'value'       => $editing ? $editing['content'] : '',
				'counter'     => true,
				'description' => 'برای ایمیل می‌توانید از تگ‌های HTML استفاده کنید. برای پیامک، تگ‌ها به‌صورت خودکار حذف می‌شوند.',
			)
		);
		?>

		<?php if ( WCMA_AI::is_ready() ) : ?>
			<div class="wcma-ai-box">
				<span class="dashicons dashicons-lightbulb"></span>
				<div>
					<strong>کمک هوش مصنوعی</strong>
					<p>موضوع یا نکات کمپین را بنویسید تا متن پیشنهادی تولید شود.</p>
					<textarea id="wcma-ai-brief" rows="2" placeholder="مثال: جشنواره‌ی تخفیف پاییزی روی چسب‌های صنعتی، ۲۰٪ تخفیف تا پایان هفته"></textarea>
					<button type="button" class="wcma-btn wcma-btn--ai" data-target="campaign_content" data-template="campaign_email">
						<span class="dashicons dashicons-superhero"></span>
						تولید متن با هوش مصنوعی
					</button>
				</div>
			</div>
		<?php else : ?>
			<div class="wcma-info">
				<span class="dashicons dashicons-lightbulb"></span>
				<div>می‌توانید با فعال کردن <a href="<?php echo esc_url( WCMA_Admin::tab_url( 'ai' ) ); ?>">محتوای هوشمند (AI)</a>، متن کمپین را به‌صورت خودکار تولید کنید.</div>
			</div>
		<?php endif; ?>

		<h3 class="wcma-subtitle">۳. زمان ارسال</h3>

		<?php
		WCMA_Admin_Fields::text(
			'campaign_scheduled_at',
			'زمان شروع ارسال (خالی = بلافاصله)',
			array(
				'type'        => 'datetime-local',
				'attrs'       => array( 'data-wcma-jalali' => '1' ),
				'name'        => 'campaign_scheduled_at',
				'value'       => $editing && $editing['scheduled_at'] ? gmdate( 'Y-m-d\TH:i', strtotime( $editing['scheduled_at'] ) ) : '',
				'description' => sprintf(
					'ارسال به‌صورت دسته‌ای انجام می‌شود: هر %s دقیقه، %s پیام.',
					esc_html( number_format_i18n( WCMA_Settings::get( 'campaign_interval', 5 ) ) ),
					esc_html( number_format_i18n( WCMA_Settings::get( 'campaign_batch_size', 50 ) ) )
				),
			)
		);
		?>

		<div class="wcma-actions">
			<button type="submit" class="wcma-btn wcma-btn--secondary">
				<span class="dashicons dashicons-saved"></span>
				ذخیره به‌عنوان پیش‌نویس
			</button>
			<button type="submit" name="campaign_send_now" value="1" class="wcma-btn wcma-btn--primary" data-confirm="آیا از شروع ارسال این کمپین مطمئن هستید؟">
				<span class="dashicons dashicons-megaphone"></span>
				ذخیره و شروع ارسال
			</button>
		</div>
	</form>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'کمپین‌های ساخته‌شده', '', 'list-view' ); ?>
	<?php
	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 'cam_per',
			'current' => $wcma_cper,
			'total'   => $wcma_ctot,
		)
	);
	?>

	<?php if ( $campaigns ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>عنوان</th>
						<th>کانال</th>
						<th>وضعیت</th>
						<th>پیشرفت</th>
						<th>تاریخ ساخت</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $campaigns as $campaign ) : ?>
						<?php
						$label    = $status_labels[ $campaign['status'] ] ?? array( $campaign['status'], 'gray' );
						$total    = max( 1, (int) $campaign['total_recipients'] );
						$progress = min( 100, round( ( ( (int) $campaign['sent_count'] + (int) $campaign['failed_count'] ) / $total ) * 100 ) );
						?>
						<tr>
							<td><strong><?php echo esc_html( $campaign['title'] ); ?></strong></td>
							<td><?php echo esc_html( $channels[ $campaign['channel'] ] ?? $campaign['channel'] ); ?></td>
							<td><span class="wcma-badge wcma-badge--<?php echo esc_attr( $label[1] ); ?>"><?php echo esc_html( $label[0] ); ?></span></td>
							<td>
								<div class="wcma-progress" title="<?php echo esc_attr( $campaign['sent_count'] . ' از ' . $campaign['total_recipients'] ); ?>">
									<span style="width: <?php echo esc_attr( $progress ); ?>%"></span>
								</div>
								<small><?php echo esc_html( number_format_i18n( $campaign['sent_count'] ) ); ?> ارسال / <?php echo esc_html( number_format_i18n( $campaign['failed_count'] ) ); ?> ناموفق</small>
							</td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $campaign['created_at'] ); ?></td>
							<td class="wcma-table__actions">
								<a class="wcma-btn wcma-btn--tiny" href="<?php echo esc_url( WCMA_Admin::tab_url( 'campaigns' ) . '&campaign=' . (int) $campaign['id'] ); ?>">ویرایش</a>

								<form method="post" class="wcma-inline-form">
									<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
									<input type="hidden" name="campaign_id" value="<?php echo esc_attr( $campaign['id'] ); ?>" />
									<?php if ( 'running' === $campaign['status'] ) : ?>
										<input type="hidden" name="wcma_action" value="campaign_pause" />
										<button type="submit" class="wcma-btn wcma-btn--tiny">توقف</button>
									<?php else : ?>
										<input type="hidden" name="wcma_action" value="campaign_start" />
										<button type="submit" class="wcma-btn wcma-btn--tiny" data-confirm="شروع ارسال این کمپین؟">شروع ارسال</button>
									<?php endif; ?>
								</form>

								<form method="post" class="wcma-inline-form">
									<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
									<input type="hidden" name="wcma_action" value="campaign_delete" />
									<input type="hidden" name="campaign_id" value="<?php echo esc_attr( $campaign['id'] ); ?>" />
									<button type="submit" class="wcma-btn wcma-btn--tiny wcma-btn--danger" data-confirm="این کمپین حذف شود؟">حذف</button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'campage',
				'current' => $wcma_cpage,
				'pages'   => (int) ceil( $wcma_ctot / $wcma_cper ),
			)
		);
		?>
	<?php else : ?>
		<p class="wcma-empty">هنوز کمپینی ساخته نشده است.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
