<?php
/**
 * صندوق تیکت‌های پشتیبانی.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended
$wcma_open_id  = isset( $_GET['ticket'] ) ? (int) $_GET['ticket'] : 0;
$wcma_status   = isset( $_GET['t_status'] ) ? sanitize_key( wp_unslash( $_GET['t_status'] ) ) : '';
$wcma_dept     = isset( $_GET['t_dept'] ) ? sanitize_key( wp_unslash( $_GET['t_dept'] ) ) : '';
$wcma_search   = isset( $_GET['t_search'] ) ? sanitize_text_field( wp_unslash( $_GET['t_search'] ) ) : '';
$wcma_page_no  = isset( $_GET['tpage'] ) ? max( 1, (int) $_GET['tpage'] ) : 1;
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$wcma_ticket      = $wcma_open_id ? WCMA_Tickets::get( $wcma_open_id ) : null;
$wcma_departments = WCMA_Tickets::departments();
$wcma_statuses    = WCMA_Tickets::statuses();
$wcma_priorities  = WCMA_Tickets::priorities();
$wcma_base        = WCMA_Admin::tab_url( 'tickets' );

if ( $wcma_ticket ) {
	WCMA_Tickets::mark_read( (int) $wcma_ticket['id'], true );
}
?>

<?php if ( ! WCMA_Tickets::is_on() ) : ?>
	<div class="wcma-notice wcma-notice--warn">
		<span class="dashicons dashicons-warning"></span>
		<span>
			بخش تیکت خاموش است. در برگه‌ی «پنل کاربری» روشنش کنید تا مشتری‌ها بتوانند تیکت بزنند.
		</span>
	</div>
<?php endif; ?>

<?php if ( $wcma_ticket ) : ?>

	<?php
	$wcma_who   = get_userdata( (int) $wcma_ticket['user_id'] );
	$wcma_phone = WCMA_Accounts::phone( (int) $wcma_ticket['user_id'] );
	?>

	<?php
	WCMA_Admin_Fields::card_start(
		'تیکت #' . WCMA_Date::digits( (string) $wcma_ticket['id'] ) . ' — ' . $wcma_ticket['subject'],
		sprintf(
			'%s · %s · %s',
			$wcma_who ? $wcma_who->display_name : 'کاربر حذف‌شده',
			$wcma_departments[ $wcma_ticket['department'] ] ?? $wcma_ticket['department'],
			'اهمیت ' . ( $wcma_priorities[ $wcma_ticket['priority'] ] ?? $wcma_ticket['priority'] )
		),
		'sos'
	);
	?>
		<div class="wcma-actions wcma-actions--split">
			<a href="<?php echo esc_url( $wcma_base ); ?>" class="wcma-btn wcma-btn--ghost">
				<span class="dashicons dashicons-arrow-right-alt"></span>
				بازگشت به فهرست
			</a>

			<div class="wcma-ticket__tools">
				<?php if ( $wcma_phone ) : ?>
					<a class="wcma-btn wcma-btn--ghost" href="tel:<?php echo esc_attr( $wcma_phone ); ?>">
						<span class="dashicons dashicons-phone"></span>
						<span dir="ltr"><?php echo esc_html( WCMA_Date::digits( $wcma_phone ) ); ?></span>
					</a>
				<?php endif; ?>

				<?php if ( $wcma_ticket['contact_id'] ) : ?>
					<a class="wcma-btn wcma-btn--ghost" href="<?php echo esc_url( add_query_arg( array( 'contact' => (int) $wcma_ticket['contact_id'] ), WCMA_Admin::tab_url( 'crm' ) ) ); ?>">
						<span class="dashicons dashicons-id-alt"></span>
						پرونده‌ی مشتری
					</a>
				<?php endif; ?>

				<form method="post" class="wcma-inline-form">
					<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
					<input type="hidden" name="wcma_action" value="ticket_status" />
					<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $wcma_ticket['id'] ); ?>" />
					<input type="hidden" name="status" value="<?php echo 'closed' === $wcma_ticket['status'] ? 'open' : 'closed'; ?>" />

					<button type="submit" class="wcma-btn wcma-btn--ghost">
						<span class="dashicons dashicons-<?php echo 'closed' === $wcma_ticket['status'] ? 'update' : 'yes'; ?>"></span>
						<?php echo 'closed' === $wcma_ticket['status'] ? 'باز کردن دوباره' : 'بستن تیکت'; ?>
					</button>
				</form>
			</div>
		</div>

		<div class="wcma-ticket">
			<?php foreach ( WCMA_Tickets::replies( (int) $wcma_ticket['id'] ) as $wcma_reply ) : ?>
				<article class="wcma-tmsg wcma-tmsg--<?php echo 'staff' === $wcma_reply['author'] ? 'staff' : 'user'; ?>">
					<header>
						<strong><?php echo esc_html( $wcma_reply['author_name'] ); ?></strong>
						<span><?php echo WCMA_Date::html( $wcma_reply['created_at'], 'datetime' ); ?></span>
					</header>

					<?php if ( '' !== trim( (string) $wcma_reply['body'] ) ) : ?>
						<div class="wcma-tmsg__body"><?php echo wp_kses_post( wpautop( $wcma_reply['body'] ) ); ?></div>
					<?php endif; ?>

					<?php if ( $wcma_reply['att_url'] ) : ?>
						<a class="wcma-tmsg__file" href="<?php echo esc_url( $wcma_reply['att_url'] ); ?>" target="_blank" rel="noopener">
							<span class="dashicons dashicons-paperclip"></span>
							<?php echo esc_html( $wcma_reply['att_name'] ); ?>
						</a>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>

		<form method="post" class="wcma-treply">
			<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
			<input type="hidden" name="wcma_action" value="ticket_reply" />
			<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $wcma_ticket['id'] ); ?>" />

			<textarea name="body" rows="4" placeholder="پاسخ شما به مشتری…" required></textarea>

			<div class="wcma-actions">
				<button type="submit" class="wcma-btn wcma-btn--primary">
					<span class="dashicons dashicons-email-alt"></span>
					ارسال پاسخ
				</button>

				<?php if ( WCMA_Settings::is( 'ticket_notify_user' ) ) : ?>
					<span class="wcma-field__desc">با ارسال پاسخ، برای مشتری پیامک خبر می‌رود.</span>
				<?php endif; ?>
			</div>
		</form>
	<?php WCMA_Admin_Fields::card_end(); ?>

<?php else : ?>

	<?php
	$wcma_list = WCMA_Tickets::query(
		array(
			'status'     => $wcma_status,
			'department' => $wcma_dept,
			'search'     => $wcma_search,
			'page'       => $wcma_page_no,
			'per_page'   => WCMA_Admin::per_page( 't_per' ),
		)
	);
	?>

	<div class="wcma-stats wcma-stats--compact">
		<div class="wcma-stat">
			<span class="wcma-stat__icon dashicons dashicons-sos"></span>
			<div>
				<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( (int) $wcma_list['total'] ) ); ?></span>
				<span class="wcma-stat__label">همه‌ی تیکت‌ها</span>
			</div>
		</div>

		<div class="wcma-stat wcma-stat--amber">
			<span class="wcma-stat__icon dashicons dashicons-clock"></span>
			<div>
				<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( WCMA_Tickets::waiting() ) ); ?></span>
				<span class="wcma-stat__label">منتظر پاسخ شما</span>
			</div>
		</div>
	</div>

	<?php WCMA_Admin_Fields::card_start( 'تیکت‌های پشتیبانی', 'هر تیکت را باز کنید تا گفتگو را ببینید و پاسخ بدهید.', 'sos' ); ?>
		<form method="get" class="wcma-filters is-instant">
			<input type="hidden" name="page" value="wcma" />
			<input type="hidden" name="tab" value="tickets" />

			<input type="search" name="t_search" value="<?php echo esc_attr( $wcma_search ); ?>" placeholder="جستجوی موضوع" />

			<select name="t_status">
				<option value="">همه‌ی وضعیت‌ها</option>
				<?php foreach ( $wcma_statuses as $wcma_key => $wcma_label ) : ?>
					<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( $wcma_status, $wcma_key ); ?>><?php echo esc_html( $wcma_label ); ?></option>
				<?php endforeach; ?>
			</select>

			<select name="t_dept">
				<option value="">همه‌ی بخش‌ها</option>
				<?php foreach ( $wcma_departments as $wcma_key => $wcma_label ) : ?>
					<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( $wcma_dept, $wcma_key ); ?>><?php echo esc_html( $wcma_label ); ?></option>
				<?php endforeach; ?>
			</select>

			<button type="submit" class="screen-reader-text">اعمال فیلتر</button>
			<a href="<?php echo esc_url( $wcma_base ); ?>" class="wcma-btn wcma-btn--ghost">پاک کردن</a>
		</form>

		<?php
		WCMA_Admin_Fields::list_bar(
			array(
				'key'     => 't_per',
				'current' => WCMA_Admin::per_page( 't_per' ),
				'total'   => (int) $wcma_list['total'],
			)
		);
		?>

		<?php if ( $wcma_list['items'] ) : ?>
			<div class="wcma-table-wrap">
				<table class="wcma-table">
					<thead>
						<tr>
							<th>موضوع</th>
							<th>مشتری</th>
							<th>بخش</th>
							<th>وضعیت</th>
							<th>آخرین پیام</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $wcma_list['items'] as $wcma_row ) : ?>
							<?php $wcma_user_row = get_userdata( (int) $wcma_row['user_id'] ); ?>
							<tr class="<?php echo $wcma_row['unread_staff'] ? 'is-unread' : ''; ?>">
								<td>
									<a href="<?php echo esc_url( add_query_arg( array( 'ticket' => (int) $wcma_row['id'] ), $wcma_base ) ); ?>">
										<strong><?php echo esc_html( $wcma_row['subject'] ); ?></strong>
									</a>
									<?php if ( $wcma_row['unread_staff'] ) : ?>
										<span class="wcma-badge wcma-badge--green">تازه</span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $wcma_user_row ? $wcma_user_row->display_name : '—' ); ?></td>
								<td><?php echo esc_html( $wcma_departments[ $wcma_row['department'] ] ?? $wcma_row['department'] ); ?></td>
								<td><?php echo esc_html( $wcma_statuses[ $wcma_row['status'] ] ?? $wcma_row['status'] ); ?></td>
								<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_row['last_reply_at'], 'datetime' ); ?></td>
								<td class="wcma-nowrap">
									<a class="wcma-btn wcma-btn--ghost" href="<?php echo esc_url( add_query_arg( array( 'ticket' => (int) $wcma_row['id'] ), $wcma_base ) ); ?>">باز کردن</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<?php
			WCMA_Admin_Fields::pagination(
				array(
					'key'     => 'tpage',
					'current' => (int) $wcma_list['page'],
					'pages'   => (int) $wcma_list['pages'],
				)
			);
			?>
		<?php else : ?>
			<p class="wcma-empty">تیکتی با این فیلترها نیست.</p>
		<?php endif; ?>
	<?php WCMA_Admin_Fields::card_end(); ?>

<?php endif; ?>
