<?php
/**
 * تب باشگاه مشتریان VIP.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$channels = WCMA_Sender::channels();
$report   = WCMA_VIP::report();
$tiers    = WCMA_Settings::get( 'vip_tiers', array() );
$tiers    = is_array( $tiers ) ? array_values( $tiers ) : array();
?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-star-filled"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $report['total_members'] ) ); ?></span>
			<span class="wcma-stat__label">مشتری بررسی‌شده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-money-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo wp_kses_post( WCMA_Date::price( $report['total_revenue'] ) ); ?></span>
			<span class="wcma-stat__label">فروش در بازه‌ی محاسبه</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-chart-pie"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $report['top_share'], 1 ) ); ?>٪</span>
			<span class="wcma-stat__label">سهم ۲۰٪ برتر از فروش</span>
		</div>
	</div>
</div>

<?php WCMA_Admin_Fields::card_start( 'تحلیل ۲۰/۸۰', 'واقعیت فروشگاه شما، نه یک قاعده‌ی کلی.', 'chart-pie' ); ?>
	<?php if ( $report['total_members'] > 0 ) : ?>
		<p class="wcma-vip-headline">
			<strong><?php echo esc_html( number_format_i18n( $report['top_count'] ) ); ?> مشتری برتر</strong>
			(۲۰٪ بالای فهرست)
			<strong><?php echo esc_html( number_format_i18n( $report['top_share'], 1 ) ); ?>٪</strong>
			از کل فروش بازه را ساخته‌اند.
		</p>

		<?php if ( $report['by_tier'] ) : ?>
			<div class="wcma-table-wrap">
				<table class="wcma-table">
					<thead>
						<tr>
							<th>سطح</th>
							<th>تعداد اعضا</th>
							<th>سهم از اعضا</th>
							<th>فروش</th>
							<th>سهم از فروش</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $report['by_tier'] as $row ) : ?>
							<?php
							$tier_info    = WCMA_VIP::tier( (int) $row['tier'] );
							$member_share = $report['total_members'] > 0 ? ( $row['members'] / $report['total_members'] ) * 100 : 0;
							$rev_share    = $report['total_revenue'] > 0 ? ( $row['revenue'] / $report['total_revenue'] ) * 100 : 0;
							?>
							<tr>
								<td>
									<?php if ( $tier_info ) : ?>
										<span class="wcma-badge" style="background: <?php echo esc_attr( $tier_info['color'] ); ?>; color:#fff"><?php echo esc_html( $tier_info['name'] ); ?></span>
									<?php else : ?>
										<span class="wcma-badge wcma-badge--gray">بدون سطح</span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( number_format_i18n( $row['members'] ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( $member_share, 1 ) ); ?>٪</td>
								<td><?php echo wp_kses_post( WCMA_Date::price( $row['revenue'] ) ); ?></td>
								<td>
									<div class="wcma-progress"><span style="width: <?php echo esc_attr( min( 100, $rev_share ) ); ?>%"></span></div>
									<small><?php echo esc_html( number_format_i18n( $rev_share, 1 ) ); ?>٪</small>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	<?php else : ?>
		<p class="wcma-empty">هنوز محاسبه‌ای انجام نشده است. دکمه‌ی زیر را بزنید.</p>
	<?php endif; ?>

	<div class="wcma-actions">
		<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-vip-recalc">
			<span class="dashicons dashicons-update"></span>
			محاسبه‌ی دوباره‌ی سطوح
		</button>
		<span id="wcma-vip-recalc-result" class="wcma-field__desc"></span>
		<?php if ( $report['last_recalc'] ) : ?>
			<span class="wcma-field__desc">آخرین محاسبه: <?php echo WCMA_Date::html( $report['last_recalc'] ); ?></span>
		<?php endif; ?>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'باشگاه مشتریان', '۲۰٪ مشتری‌ها بخش بزرگی از فروش را می‌سازند؛ اینجا شناسایی و نگهشان می‌دارید.', 'star-filled' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'vip_enabled', 'فعال بودن باشگاه مشتریان' );

		WCMA_Admin_Fields::select( 'vip_channel', 'کانال اطلاع‌رسانی', $channels );

		WCMA_Admin_Fields::select(
			'vip_basis',
			'مبنای سطح‌بندی',
			WCMA_VIP::bases(),
			array( 'description' => 'می‌توانید فقط مبلغ، فقط تعداد سفارش، یا ترکیب هر دو را ملاک قرار دهید. حالت «هر کدام که زودتر برسد» سخاوتمندانه‌تر و «هر دو با هم» سخت‌گیرانه‌تر است.' )
		);
		?>

		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::select(
				'vip_window',
				'بازه‌ی محاسبه',
				WCMA_VIP::windows(),
				array( 'description' => 'بازه‌ی متحرک، مشتری فعال امروز را از مشتری قدیمیِ رفته جدا می‌کند. «کل تاریخچه» سطح را دائمی می‌کند.' )
			);

			WCMA_Admin_Fields::text(
				'vip_window_custom',
				'بازه‌ی دلخواه',
				array(
					'type'        => 'number',
					'min'         => 1,
					'suffix'      => 'روز',
					'description' => 'فقط وقتی گزینه‌ی «بازه‌ی دلخواه» انتخاب شده باشد اعمال می‌شود.',
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::select(
			'vip_order_statuses',
			'وضعیت سفارش‌هایی که محاسبه می‌شوند',
			WCMA_Admin_Fields::order_status_options(),
			array(
				'multiple'    => true,
				'class'       => 'wc-enhanced-select',
				'description' => 'معمولاً «تکمیل شده» و «در حال پردازش». سفارش لغوشده یا مسترد نباید سطح بسازد.',
			)
		);

		WCMA_Admin_Fields::toggle(
			'vip_realtime',
			'بازبینی فوری پس از هر سفارش تکمیل‌شده',
			'اگر خاموش باشد، سطوح فقط یک بار در روز به‌روز می‌شوند.'
		);

		WCMA_Admin_Fields::toggle( 'vip_show_in_account', 'نمایش سطح و مزایا در حساب کاربری مشتری' );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'سطوح باشگاه', 'هر سطح آستانه، رنگ، مزایا و کد تخفیف خودش را دارد. سطح بدون نام نادیده گرفته می‌شود.', 'awards' ); ?>
		<div class="wcma-tiers">
			<?php
			for ( $i = 0; $i < 4; $i++ ) :
				$tier = $tiers[ $i ] ?? array();
				$tier = wp_parse_args(
					$tier,
					array(
						'active'        => 'no',
						'name'          => '',
						'min_amount'    => 0,
						'min_orders'    => 0,
						'color'         => '#6b7280',
						'perk'          => '',
						'coupon_type'   => 'percent',
						'coupon_amount' => 0,
						'coupon_days'   => 30,
					)
				);

				$wcma_tier_name = 'wcma[vip_tiers][' . $i . ']';
				?>
				<div class="wcma-tier <?php echo 'yes' === $tier['active'] ? 'is-active' : ''; ?>">
					<header class="wcma-tier__head">
						<span class="wcma-tier__dot" style="background: <?php echo esc_attr( $tier['color'] ); ?>"></span>
						<h3>سطح <?php echo esc_html( $i + 1 ); ?></h3>
						<label class="wcma-switch wcma-switch--sm">
							<input type="checkbox" name="<?php echo esc_attr( $wcma_tier_name ); ?>[active]" value="yes" <?php checked( 'yes', $tier['active'] ); ?> class="wcma-tier__toggle" />
							<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
						</label>
					</header>

					<div class="wcma-tier__body">
						<div class="wcma-row wcma-row--3">
							<?php
							WCMA_Admin_Fields::text(
								'vip_tier_name_' . $i,
								'نام سطح',
								array(
									'name'        => $wcma_tier_name . '[name]',
									'value'       => $tier['name'],
									'placeholder' => 'مثلاً طلایی',
								)
							);

							WCMA_Admin_Fields::text(
								'vip_tier_amount_' . $i,
								'حداقل مجموع خرید',
								array(
									'type'  => 'number',
									'min'   => 0,
									'name'  => $wcma_tier_name . '[min_amount]',
									'value' => $tier['min_amount'],
								)
							);

							WCMA_Admin_Fields::text(
								'vip_tier_orders_' . $i,
								'حداقل تعداد سفارش',
								array(
									'type'  => 'number',
									'min'   => 0,
									'name'  => $wcma_tier_name . '[min_orders]',
									'value' => $tier['min_orders'],
								)
							);
							?>
						</div>

						<div class="wcma-row wcma-row--4">
							<?php
							WCMA_Admin_Fields::text(
								'vip_tier_color_' . $i,
								'رنگ نشان',
								array(
									'type'  => 'color',
									'name'  => $wcma_tier_name . '[color]',
									'value' => $tier['color'],
								)
							);

							WCMA_Admin_Fields::select(
								'vip_tier_ctype_' . $i,
								'نوع تخفیف',
								array(
									'percent' => 'درصدی',
									'fixed'   => 'مبلغ ثابت',
								),
								array(
									'name'  => $wcma_tier_name . '[coupon_type]',
									'value' => $tier['coupon_type'],
								)
							);

							WCMA_Admin_Fields::text(
								'vip_tier_camount_' . $i,
								'مقدار تخفیف',
								array(
									'type'  => 'number',
									'min'   => 0,
									'step'  => '0.01',
									'name'  => $wcma_tier_name . '[coupon_amount]',
									'value' => $tier['coupon_amount'],
								)
							);

							WCMA_Admin_Fields::text(
								'vip_tier_cdays_' . $i,
								'اعتبار کد',
								array(
									'type'   => 'number',
									'min'    => 1,
									'suffix' => 'روز',
									'name'   => $wcma_tier_name . '[coupon_days]',
									'value'  => $tier['coupon_days'],
								)
							);
							?>
						</div>

						<?php
						WCMA_Admin_Fields::text(
							'vip_tier_perk_' . $i,
							'مزایای این سطح (به مشتری نشان داده می‌شود)',
							array(
								'name'        => $wcma_tier_name . '[perk]',
								'value'       => $tier['perk'],
								'placeholder' => 'مثلاً ارسال رایگان و پشتیبانی اولویت‌دار',
							)
						);
						?>
					</div>
				</div>
			<?php endfor; ?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پیام ارتقای سطح', 'وقتی مشتری به سطح بالاتری می‌رسد.', 'awards' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'vip_notify_promotion', 'ارسال پیام هنگام ارتقا' );

		WCMA_Admin_Fields::placeholder_help( array( 'vip_tier', 'vip_perk', 'vip_total', 'vip_orders', 'vip_next_tier', 'vip_next_remaining', 'coupon_code', 'coupon_amount', 'coupon_expiry' ) );

		WCMA_Admin_Fields::text( 'vip_promote_subject', 'موضوع ایمیل' );
		WCMA_Admin_Fields::textarea( 'vip_promote_sms_text', 'متن پیامک', array( 'rows' => 3, 'counter' => true ) );
		WCMA_Admin_Fields::textarea( 'vip_promote_email_text', 'متن ایمیل', array( 'rows' => 6 ) );

		WCMA_Admin_Fields::toggle(
			'vip_notify_demotion',
			'اطلاع‌رسانی هنگام تنزل سطح',
			'پیش‌فرض خاموش است؛ خبر دادن از دست رفتن سطح می‌تواند حس بدی ایجاد کند. اگر روشنش کنید، متن آن را تشویقی بنویسید.'
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پاداش دوره‌ای اعضا', 'به‌جای یک تخفیف یک‌باره، دلیلی همیشگی برای ماندن.', 'tickets-alt' ); ?>
		<?php WCMA_Admin_Fields::toggle( 'vip_reward_enabled', 'ارسال پاداش دوره‌ای به اعضا' ); ?>

		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::text(
				'vip_reward_every_days',
				'هر چند وقت یک‌بار',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);

			WCMA_Admin_Fields::text(
				'vip_reward_min_tier',
				'از کدام سطح به بالا',
				array(
					'type'        => 'number',
					'min'         => 1,
					'max'         => 4,
					'description' => 'مثلاً ۲ یعنی فقط سطح دوم و بالاتر پاداش می‌گیرند.',
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::text( 'vip_reward_subject', 'موضوع ایمیل' );
		WCMA_Admin_Fields::textarea( 'vip_reward_sms_text', 'متن پیامک', array( 'rows' => 3, 'counter' => true ) );
		WCMA_Admin_Fields::textarea( 'vip_reward_email_text', 'متن ایمیل', array( 'rows' => 5 ) );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'هشدار ریزش مشتری ارزشمند', 'پیش از آنکه یک مشتری خوب را از دست بدهید.', 'warning' ); ?>
		<?php WCMA_Admin_Fields::toggle( 'vip_churn_enabled', 'فعال بودن هشدار ریزش' ); ?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'vip_churn_days',
				'بدون خرید به مدت',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);

			WCMA_Admin_Fields::text(
				'vip_churn_min_tier',
				'از کدام سطح به بالا',
				array(
					'type' => 'number',
					'min'  => 1,
					'max'  => 4,
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::toggle( 'vip_churn_coupon', 'همراه هشدار، کد تخفیف سطح مشتری ارسال شود' );

		WCMA_Admin_Fields::text( 'vip_churn_subject', 'موضوع ایمیل' );
		WCMA_Admin_Fields::textarea( 'vip_churn_sms_text', 'متن پیامک', array( 'rows' => 3, 'counter' => true ) );
		WCMA_Admin_Fields::textarea( 'vip_churn_email_text', 'متن ایمیل', array( 'rows' => 5 ) );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php WCMA_Admin_Fields::card_start( 'اعضای باشگاه', 'مرتب‌شده بر اساس مجموع خرید در بازه‌ی محاسبه.', 'groups' ); ?>
	<?php $members = WCMA_VIP::members( array( 'limit' => 30 ) ); ?>

	<?php if ( $members ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>مشتری</th>
						<th>سطح</th>
						<th>مجموع خرید</th>
						<th>تعداد سفارش</th>
						<th>آخرین خرید</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $members as $member ) : ?>
						<?php $tier_info = WCMA_VIP::tier( (int) $member['tier'] ); ?>
						<tr>
							<td>
								<?php echo esc_html( $member['first_name'] ? $member['first_name'] : '—' ); ?>
								<br /><small class="wcma-ltr"><?php echo esc_html( $member['email'] ); ?></small>
							</td>
							<td>
								<?php if ( $tier_info ) : ?>
									<span class="wcma-badge" style="background: <?php echo esc_attr( $tier_info['color'] ); ?>; color:#fff"><?php echo esc_html( $tier_info['name'] ); ?></span>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--gray">بدون سطح</span>
								<?php endif; ?>
							</td>
							<td><?php echo wp_kses_post( WCMA_Date::price( $member['total_amount'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $member['order_count'] ) ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $member['last_order_at'], 'date' ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-empty">هنوز عضوی محاسبه نشده است. دکمه‌ی «محاسبه‌ی دوباره‌ی سطوح» را بزنید.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
