<?php
/**
 * تب ۱: سبد خرید رها شده و سفارش تکمیل‌نشده.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$steps      = WCMA_Settings::get( 'ab_steps', array() );
$cart_stats = WCMA_Carts::stats();
$channels   = WCMA_Sender::channels();
$recent     = WCMA_Carts::recent( 10 );
?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-cart"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $cart_stats['abandoned'] ) ); ?></span>
			<span class="wcma-stat__label">سبد رها شده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-yes-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $cart_stats['purchased'] ) ); ?></span>
			<span class="wcma-stat__label">بازیابی‌شده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-money-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo wp_kses_post( WCMA_Date::price( $cart_stats['value'] ) ); ?></span>
			<span class="wcma-stat__label">ارزش سبدهای رها شده</span>
		</div>
	</div>
</div>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'تنظیمات ردیابی', 'مشخص کنید چه سبدها و سفارش‌هایی پیگیری شوند.', 'visibility' ); ?>
		<?php
		WCMA_Admin_Fields::toggle(
			'ab_enabled',
			'فعال بودن پیگیری سبد رها شده',
			'با فعال کردن این گزینه، سبدهای نیمه‌کاره و سفارش‌های پرداخت‌نشده به‌صورت خودکار پیگیری می‌شوند.'
		);

		WCMA_Admin_Fields::toggle(
			'ab_track_guests',
			'ردیابی کاربران مهمان (بدون ثبت‌نام)',
			'به‌محض اینکه کاربر ایمیل یا موبایل خود را در فرم پرداخت وارد کند، سبد او ذخیره می‌شود.'
		);

		WCMA_Admin_Fields::text(
			'ab_cart_timeout',
			'بعد از چند دقیقه بی‌حرکتی، سبد «رها شده» محسوب شود؟',
			array(
				'type'   => 'number',
				'min'    => 5,
				'suffix' => 'دقیقه',
			)
		);

		WCMA_Admin_Fields::select(
			'ab_order_statuses',
			'وضعیت سفارش‌هایی که پیگیری شوند',
			WCMA_Admin_Fields::order_status_options(),
			array(
				'multiple'    => true,
				'class'       => 'wc-enhanced-select',
				'description' => 'برای سفارش‌هایی که ثبت شده اما پرداخت نشده‌اند (مانند «در انتظار پرداخت» و «ناموفق»).',
			)
		);

		WCMA_Admin_Fields::toggle(
			'ab_stop_on_order',
			'توقف پیگیری پس از تکمیل خرید',
			'به‌محض پرداخت سفارش، پیام‌های باقی‌مانده لغو می‌شوند تا مشتری پیام اضافی دریافت نکند.'
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'مراحل پیگیری', 'می‌توانید تا سه مرحله‌ی یادآوری با فاصله‌ی زمانی و متن متفاوت تعریف کنید.', 'controls-repeat' ); ?>

		<?php WCMA_Admin_Fields::placeholder_help( array( 'cart_items', 'cart_total', 'cart_count', 'recovery_link', 'product_name', 'product_link', 'product_price', 'coupon_code', 'coupon_amount', 'coupon_expiry', 'unsubscribe' ) ); ?>

		<div class="wcma-steps">
			<?php
			for ( $i = 0; $i < 3; $i++ ) :
				$step = $steps[ $i ] ?? array();
				$step = wp_parse_args(
					$step,
					array(
						'active'        => 'no',
						'delay'         => 60,
						'unit'          => 'minute',
						'channel'       => 'email',
						'subject'       => '',
						'sms_text'      => '',
						'email_text'    => '',
						'coupon'        => 'no',
						'coupon_type'   => 'percent',
						'coupon_amount' => 10,
						'coupon_days'   => 3,
					)
				);

				$wcma_base = 'wcma[ab_steps][' . $i . ']';
				?>
				<div class="wcma-step <?php echo 'yes' === $step['active'] ? 'is-active' : ''; ?>">
					<header class="wcma-step__head">
						<span class="wcma-step__number"><?php echo esc_html( $i + 1 ); ?></span>
						<h3>مرحله‌ی <?php echo esc_html( $i + 1 ); ?></h3>
						<label class="wcma-switch wcma-switch--sm">
							<input type="checkbox" name="<?php echo esc_attr( $wcma_base ); ?>[active]" value="yes" <?php checked( 'yes', $step['active'] ); ?> class="wcma-step__toggle" />
							<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
						</label>
						<span class="wcma-step__state">فعال</span>
					</header>

					<div class="wcma-step__body">
						<div class="wcma-row wcma-row--3">
							<?php
							WCMA_Admin_Fields::text(
								'ab_step_delay_' . $i,
								'ارسال پس از',
								array(
									'type'  => 'number',
									'min'   => 0,
									'name'  => $wcma_base . '[delay]',
									'value' => $step['delay'],
								)
							);

							WCMA_Admin_Fields::select(
								'ab_step_unit_' . $i,
								'واحد زمان',
								array(
									'minute' => 'دقیقه',
									'hour'   => 'ساعت',
									'day'    => 'روز',
								),
								array(
									'name'  => $wcma_base . '[unit]',
									'value' => $step['unit'],
								)
							);

							WCMA_Admin_Fields::select(
								'ab_step_channel_' . $i,
								'کانال ارسال',
								$channels,
								array(
									'name'  => $wcma_base . '[channel]',
									'value' => $step['channel'],
								)
							);
							?>
						</div>

						<?php
						WCMA_Admin_Fields::text(
							'ab_step_subject_' . $i,
							'موضوع ایمیل',
							array(
								'name'  => $wcma_base . '[subject]',
								'value' => $step['subject'],
							)
						);

						WCMA_Admin_Fields::textarea(
							'ab_step_sms_' . $i,
							'متن پیامک',
							array(
								'rows'    => 3,
								'name'    => $wcma_base . '[sms_text]',
								'value'   => $step['sms_text'],
								'counter' => true,
							)
						);

						WCMA_Admin_Fields::textarea(
							'ab_step_email_' . $i,
							'متن ایمیل (HTML مجاز است)',
							array(
								'rows'  => 6,
								'name'  => $wcma_base . '[email_text]',
								'value' => $step['email_text'],
							)
						);
						?>

						<div class="wcma-subcard">
							<label class="wcma-check">
								<input type="checkbox" name="<?php echo esc_attr( $wcma_base ); ?>[coupon]" value="yes" <?php checked( 'yes', $step['coupon'] ); ?> class="wcma-coupon-toggle" />
								<span>در این مرحله یک کد تخفیف اختصاصی ساخته و ارسال شود</span>
							</label>

							<div class="wcma-row wcma-row--3 wcma-coupon-fields">
								<?php
								WCMA_Admin_Fields::select(
									'ab_step_ctype_' . $i,
									'نوع تخفیف',
									array(
										'percent' => 'درصدی',
										'fixed'   => 'مبلغ ثابت',
									),
									array(
										'name'  => $wcma_base . '[coupon_type]',
										'value' => $step['coupon_type'],
									)
								);

								WCMA_Admin_Fields::text(
									'ab_step_camount_' . $i,
									'مقدار تخفیف',
									array(
										'type'  => 'number',
										'min'   => 0,
										'step'  => '0.01',
										'name'  => $wcma_base . '[coupon_amount]',
										'value' => $step['coupon_amount'],
									)
								);

								WCMA_Admin_Fields::text(
									'ab_step_cdays_' . $i,
									'اعتبار کد',
									array(
										'type'   => 'number',
										'min'    => 1,
										'suffix' => 'روز',
										'name'   => $wcma_base . '[coupon_days]',
										'value'  => $step['coupon_days'],
									)
								);
								?>
							</div>
						</div>
					</div>
				</div>
			<?php endfor; ?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php WCMA_Admin_Fields::card_start( 'آخرین سبدهای رها شده', '', 'list-view' ); ?>
	<?php if ( $recent ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>مشتری</th>
						<th>راه تماس</th>
						<th>تعداد اقلام</th>
						<th>مبلغ</th>
						<th>وضعیت</th>
						<th>آخرین فعالیت</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $recent as $cart ) : ?>
						<tr>
							<td><?php echo esc_html( $cart['first_name'] ? $cart['first_name'] : 'مهمان' ); ?></td>
							<td class="wcma-ltr"><?php echo esc_html( $cart['email'] ? $cart['email'] : $cart['phone'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $cart['item_count'] ) ); ?></td>
							<td><?php echo wp_kses_post( WCMA_Date::price( $cart['cart_total'] ) ); ?></td>
							<td>
								<?php if ( 'purchased' === $cart['status'] ) : ?>
									<span class="wcma-badge wcma-badge--green">بازیابی شد</span>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--amber">رها شده</span>
								<?php endif; ?>
							</td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $cart['updated_at'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-empty">هنوز سبد رها شده‌ای ثبت نشده است.</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
