<?php
/**
 * تب ۵: هشدار موجودی — «موجود شد خبرم کن».
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$channels = WCMA_Sender::channels();
$stats    = WCMA_Stock_Alerts::stats();
$demand   = WCMA_Stock_Alerts::demand_list( 25 );
?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-clock"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['pending'] ) ); ?></span>
			<span class="wcma-stat__label">مشتری در انتظار</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--blue">
		<span class="wcma-stat__icon dashicons dashicons-archive"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['products'] ) ); ?></span>
			<span class="wcma-stat__label">محصول دارای تقاضا</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-yes-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( number_format_i18n( $stats['notified'] ) ); ?></span>
			<span class="wcma-stat__label">اطلاع‌رسانی انجام‌شده</span>
		</div>
	</div>
</div>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'هشدار موجودی', 'مشتری منتظر یک محصول ناموجود است؟ لحظه‌ای که موجود شد خودکار خبرش کنید.', 'archive' ); ?>
		<?php
		WCMA_Admin_Fields::toggle(
			'st_enabled',
			'فعال بودن هشدار موجودی',
			'با فعال کردن این گزینه، در صفحه‌ی محصولات ناموجود فرم «موجود شد خبرم کن» نمایش داده می‌شود.'
		);

		WCMA_Admin_Fields::toggle(
			'st_show_form',
			'نمایش فرم در صفحه‌ی محصول',
			'اگر خاموش باشد، درخواست‌ها فقط از طریق کد یا شورت‌کد ثبت می‌شوند و فرم خودکار نمایش داده نمی‌شود.'
		);

		WCMA_Admin_Fields::select(
			'st_channel',
			'کانال اطلاع‌رسانی (ترجیحی)',
			$channels,
			array( 'description' => 'اگر مشتری فقط یکی از راه‌های تماس را وارد کرده باشد، افزونه خودکار از همان استفاده می‌کند تا پیام بی‌مقصد نماند.' )
		);

		WCMA_Admin_Fields::select(
			'st_contact_mode',
			'فرم از مشتری چه بخواهد؟',
			array(
				'auto'  => 'یک فیلد هوشمند — ایمیل یا موبایل (پیشنهادی)',
				'email' => 'فقط ایمیل',
				'phone' => 'فقط شماره موبایل',
				'both'  => 'هر دو فیلد جداگانه',
			),
			array( 'description' => 'در حالت هوشمند، مشتری هرکدام را که راحت‌تر است وارد می‌کند و نوع آن خودکار تشخیص داده می‌شود.' )
		);
		?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'st_min_stock',
				'حداقل موجودی (اختیاری)',
				array(
					'type'        => 'number',
					'min'         => 0,
					'suffix'      => 'عدد',
					'description' => '<strong>صفر یعنی بدون شرط</strong>؛ همین که محصول «موجود» شود پیام می‌رود. عدد بزرگ‌تر از صفر فقط وقتی اثر دارد که محصول مدیریت موجودی داشته باشد و از خبر دادن بابت یک عدد باقی‌مانده جلوگیری می‌کند.',
				)
			);

			WCMA_Admin_Fields::text(
				'st_delay',
				'تأخیر پس از موجود شدن',
				array(
					'type' => 'number',
					'min'  => 0,
				)
			);

			WCMA_Admin_Fields::select(
				'st_delay_unit',
				'واحد تأخیر',
				array(
					'minute' => 'دقیقه',
					'hour'   => 'ساعت',
					'day'    => 'روز',
				)
			);
			?>
		</div>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'st_max_per_product',
				'سقف فهرست انتظار هر محصول',
				array(
					'type'        => 'number',
					'min'         => 0,
					'description' => 'صفر یعنی بدون محدودیت.',
				)
			);

			WCMA_Admin_Fields::text(
				'st_expire_days',
				'حذف درخواست‌های پاسخ‌داده‌شده پس از',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::toggle(
			'st_send_immediately',
			'ارسال فوری، بدون انتظار برای زمان‌بند',
			'به‌محض موجود شدن کالا، پیام همان لحظه ارسال می‌شود. اگر خاموش باشد پیام‌ها در صف می‌مانند تا زمان‌بند وردپرس اجرا شود — که در سایت کم‌بازدید ممکن است دیر یا اصلاً اجرا نشود.'
		);

		$wcma_quiet = WCMA_Queue::quiet_hours_status();

		WCMA_Admin_Fields::toggle(
			'st_ignore_quiet_hours',
			'نادیده گرفتن ساعات استراحت برای این ورک‌فلو',
			'خبر موجود شدن کالا حساس به زمان است؛ نگه داشتن آن تا صبح ارزشش را کم می‌کند. وضعیت فعلی: <strong>' . esc_html( $wcma_quiet['text'] ) . '</strong>'
		);

		WCMA_Admin_Fields::toggle(
			'st_prefill',
			'پیش‌پر کردن فرم برای کاربران وارد‌شده',
			'اگر روشن باشد، ایمیل یا شماره‌ی حساب کاربری داخل فرم نوشته می‌شود. خاموش بودن یعنی فرم همیشه خالی است.'
		);

		WCMA_Admin_Fields::toggle(
			'st_show_count',
			'نمایش تعداد افراد در انتظار به مشتری',
			'دیدن اینکه دیگران هم منتظرند، انگیزه‌ی ثبت‌نام و خرید سریع را بالا می‌برد.'
		);

		WCMA_Admin_Fields::toggle(
			'st_require_login',
			'فقط کاربران وارد‌شده بتوانند ثبت‌نام کنند'
		);

		WCMA_Admin_Fields::toggle(
			'st_admin_notify',
			'اطلاع به مدیر هنگام ارسال اطلاع‌رسانی',
			'یک ایمیل خلاصه به مدیر می‌فرستد که چه محصولی موجود شد و برای چند نفر پیام رفت.'
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'متن فرم', 'آنچه مشتری در صفحه‌ی محصول ناموجود می‌بیند.', 'edit' ); ?>
		<?php
		WCMA_Admin_Fields::text( 'st_title', 'عنوان فرم' );
		WCMA_Admin_Fields::textarea( 'st_description', 'توضیح زیر عنوان', array( 'rows' => 2 ) );
		WCMA_Admin_Fields::text( 'st_button_label', 'متن دکمه' );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پیشنهاد تشویقی (اختیاری)', '', 'tickets-alt' ); ?>
		<?php
		WCMA_Admin_Fields::toggle(
			'st_coupon',
			'همراه خبر موجود شدن، کد تخفیف کوتاه‌مدت ارسال شود',
			'کد فقط برای همان محصول ساخته می‌شود و حس فوریت ایجاد می‌کند.'
		);
		?>

		<div class="wcma-row wcma-row--3 wcma-coupon-fields">
			<?php
			WCMA_Admin_Fields::select(
				'st_coupon_type',
				'نوع تخفیف',
				array(
					'percent' => 'درصدی',
					'fixed'   => 'مبلغ ثابت',
				)
			);

			WCMA_Admin_Fields::text(
				'st_coupon_amount',
				'مقدار تخفیف',
				array(
					'type' => 'number',
					'min'  => 0,
					'step' => '0.01',
				)
			);

			WCMA_Admin_Fields::text(
				'st_coupon_days',
				'اعتبار کد',
				array(
					'type'   => 'number',
					'min'    => 1,
					'suffix' => 'روز',
				)
			);
			?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'متن پیام اطلاع‌رسانی', '', 'email-alt' ); ?>
		<?php
		WCMA_Admin_Fields::placeholder_help( array( 'product_name', 'product_link', 'product_price', 'product_sku', 'stock_qty', 'coupon_code', 'coupon_amount', 'coupon_expiry', 'cancel_link' ) );

		WCMA_Admin_Fields::text( 'st_subject', 'موضوع ایمیل' );

		WCMA_Admin_Fields::textarea(
			'st_sms_text',
			'متن پیامک',
			array(
				'rows'    => 3,
				'counter' => true,
			)
		);

		WCMA_Admin_Fields::textarea( 'st_email_text', 'متن ایمیل (HTML مجاز است)', array( 'rows' => 8 ) );
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php WCMA_Admin_Fields::card_start( 'درخواست‌های ثبت‌شده', 'اینجا می‌بینید ثبت‌نام‌ها روی کدام محصول نشسته‌اند و در چه وضعیتی هستند.', 'groups' ); ?>
	<?php $wcma_requests = WCMA_Stock_Alerts::recent_requests( 15 ); ?>

	<?php if ( $wcma_requests ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>تاریخ ثبت</th>
						<th>محصول</th>
						<th>راه تماس</th>
						<th>وضعیت درخواست</th>
						<th>موجودی فعلی</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$wcma_status_labels = array(
						'pending'   => array( 'در انتظار', 'amber' ),
						'queued'    => array( 'در صف ارسال', 'blue' ),
						'notified'  => array( 'اطلاع داده شد', 'green' ),
						'cancelled' => array( 'لغو شده', 'gray' ),
					);

					foreach ( $wcma_requests as $wcma_req ) :
						$wcma_pid  = ! empty( $wcma_req['variation_id'] ) ? (int) $wcma_req['variation_id'] : (int) $wcma_req['product_id'];
						$wcma_prod = wc_get_product( $wcma_pid );
						$wcma_lbl  = $wcma_status_labels[ $wcma_req['status'] ] ?? array( $wcma_req['status'], 'gray' );
						?>
						<tr>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_req['created_at'] ); ?></td>
							<td>
								<?php if ( $wcma_prod ) : ?>
									<?php echo esc_html( $wcma_prod->get_name() ); ?>
									<small class="wcma-muted">(<?php echo (int) $wcma_pid; ?>)</small>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--red">محصول حذف شده (<?php echo (int) $wcma_pid; ?>)</span>
								<?php endif; ?>
							</td>
							<td class="wcma-ltr"><?php echo esc_html( $wcma_req['email'] ? $wcma_req['email'] : $wcma_req['phone'] ); ?></td>
							<td><span class="wcma-badge wcma-badge--<?php echo esc_attr( $wcma_lbl[1] ); ?>"><?php echo esc_html( $wcma_lbl[0] ); ?></span></td>
							<td>
								<?php if ( ! $wcma_prod ) : ?>
									<span class="wcma-muted">—</span>
								<?php elseif ( $wcma_prod->is_in_stock() ) : ?>
									<span class="wcma-badge wcma-badge--green">موجود<?php echo $wcma_prod->managing_stock() ? ' (' . esc_html( $wcma_prod->get_stock_quantity() ) . ')' : ''; ?></span>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--gray">ناموجود</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				اگر ردیفی «در انتظار» است ولی موجودی آن «موجود» نشان داده می‌شود، دکمه‌ی
				«اجرای فوری زمان‌بند» در بالای صفحه را بزنید؛ اسکن دوره‌ای آن را می‌گیرد و
				پیام را می‌فرستد.
			</div>
		</div>
	<?php else : ?>
		<p class="wcma-empty">
			هیچ درخواستی ثبت نشده است. یعنی فرم صفحه‌ی محصول یا نمایش داده نمی‌شود، یا
			ثبت‌نام ذخیره نمی‌شود. با شبیه‌ساز پایین بررسی کنید.
		</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php require WCMA_PATH . 'includes/admin/views/partial-stock-diagnostics.php'; ?>

<?php WCMA_Admin_Fields::card_start( 'محصولات دارای بیشترین تقاضا', 'این فهرست نشان می‌دهد مشتریان منتظر چه چیزی هستند — راهنمای خوبی برای سفارش خرید بعدی شما.', 'chart-bar' ); ?>
	<?php if ( $demand ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>محصول</th>
						<th>در انتظار</th>
						<th>وضعیت موجودی</th>
						<th>قدیمی‌ترین درخواست</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $demand as $row ) :
						$pid     = ! empty( $row['variation_id'] ) ? (int) $row['variation_id'] : (int) $row['product_id'];
						$product = wc_get_product( $pid );

						if ( ! $product ) {
							continue;
						}

						$in_stock = $product->is_in_stock();
						?>
						<tr>
							<td>
								<a href="<?php echo esc_url( get_edit_post_link( (int) $row['product_id'] ) ); ?>" target="_blank">
									<?php echo esc_html( $product->get_name() ); ?>
								</a>
							</td>
							<td><strong><?php echo esc_html( number_format_i18n( $row['waiting'] ) ); ?></strong> نفر</td>
							<td>
								<?php if ( $in_stock ) : ?>
									<span class="wcma-badge wcma-badge--green">موجود شد</span>
								<?php else : ?>
									<span class="wcma-badge wcma-badge--gray">ناموجود</span>
								<?php endif; ?>
							</td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $row['oldest'] ); ?></td>
							<td class="wcma-table__actions">
								<?php if ( $in_stock ) : ?>
									<button type="button" class="wcma-btn wcma-btn--tiny wcma-order-action" data-order="<?php echo esc_attr( $pid ); ?>" data-op="stock">
										ارسال اطلاع‌رسانی
									</button>
								<?php else : ?>
									<span class="wcma-muted">—</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="wcma-empty">هنوز کسی برای محصول ناموجودی ثبت‌نام نکرده است.</p>
	<?php endif; ?>

	<div class="wcma-info">
		<span class="dashicons dashicons-info"></span>
		<div>
			اطلاع‌رسانی به‌صورت خودکار و به‌محض موجود شدن محصول انجام می‌شود. دکمه‌ی «ارسال
			اطلاع‌رسانی» فقط برای مواقعی است که می‌خواهید دستی و فوری اقدام کنید. ارسال‌ها از
			صف عبور می‌کنند، بنابراین ساعات استراحت و سقف تعداد پیام در هر اجرا رعایت می‌شود.
		</div>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>
