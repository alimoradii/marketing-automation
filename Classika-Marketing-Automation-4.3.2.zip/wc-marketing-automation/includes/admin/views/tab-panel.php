<?php
/**
 * تنظیمات پنل کاربری، ورود با کد و کیف پول.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_sms_ok = WCMA_SMS_Gateways::is_ready();
?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php
	WCMA_Admin_Fields::card_start(
		'پنل کاربری',
		'یک پنل کامل روی همین دامنه: سفارش‌ها، کیف پول، تیکت و اطلاعات مشتری — با ورود به‌جای رمز، کد پیامکی.',
		'admin-users',
		'پنل روی مسیری که اینجا می‌گذارید سرو می‌شود و به پوسته‌ی فروشگاه کاری ندارد، پس با هر قالبی یکسان دیده می‌شود.',
		'panel'
	);
	?>
		<?php
		WCMA_Admin_Fields::toggle(
			'panel_enabled',
			'پنل کاربری فعال باشد',
			'تا وقتی خاموش است، مسیر پنل چیزی نشان نمی‌دهد و ورود با کد هم کار نمی‌کند.'
		);
		?>

		<?php if ( ! $wcma_sms_ok ) : ?>
			<div class="wcma-info wcma-info--warn">
				<span class="dashicons dashicons-warning"></span>
				<div>
					پنل پیامک آماده نیست، پس کد ورود فرستاده نمی‌شود. در برگه‌ی
					«کانال‌های ارتباطی» سرویس پیامک را روشن و کلید API را وارد کنید.
				</div>
			</div>
		<?php endif; ?>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::text(
				'panel_slug',
				'مسیر پنل روی سایت',
				array(
					'placeholder' => 'my-panel',
					'description' => sprintf(
						'نشانی پنل: <code dir="ltr">%s</code>',
						esc_html( WCMA_Panel::url() )
					),
				)
			);

			WCMA_Admin_Fields::text(
				'panel_title',
				'عنوان پنل',
				array( 'placeholder' => 'پنل کاربری' )
			);
			?>
		</div>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::select(
				'panel_demo',
				'قالب پنل',
				WCMA_Panel::demos(),
				array( 'description' => 'سه چیدمان آماده؛ هرکدام را بخواهید همان به مشتری نشان داده می‌شود.' )
			);

			WCMA_Admin_Fields::text(
				'panel_color',
				'رنگ اصلی پنل',
				array( 'type' => 'color' )
			);
			?>
		</div>

		<h3 class="wcma-subtitle">پیامکِ کد ورود</h3>

		<?php
		WCMA_Admin_Fields::textarea(
			'otp_sms_text',
			'متن پیامک',
			array(
				'rows'        => 2,
				'description' => 'با <code>{code}</code> کد، با <code>{site}</code> نام سایت و با <code>{minutes}</code> مدت اعتبار نوشته می‌شود.',
			)
		);

		WCMA_Admin_Fields::toggle(
			'otp_autofill',
			'کد روی گوشی خودکار پر شود',
			'دو خط کوتاه به انتهای پیامک افزوده می‌شود تا مرورگر گوشی کد را خودش در فرم بگذارد و کاربر تایپ نکند.'
		);

		WCMA_Admin_Fields::select(
			'panel_role',
			'نقش کاربران تازه',
			WCMA_Panel::roles(),
			array( 'description' => 'خالی یعنی «مشتری» ووکامرس، که برای فروشگاه درست‌ترین است.' )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php
	WCMA_Admin_Fields::card_start(
		'کیف پول',
		'مشتری کیف پولش را شارژ می‌کند و می‌تواند سفارش‌ها را از همان پرداخت کند.',
		'money-alt',
		'شارژ با همان درگاهی انجام می‌شود که فروشگاه دارد؛ افزونه سفارشی به مبلغ شارژ می‌سازد و پس از پرداخت، موجودی را بالا می‌برد.',
		'wallet'
	);
	?>
		<?php
		WCMA_Admin_Fields::toggle(
			'wallet_enabled',
			'کیف پول فعال باشد'
		);
		?>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::text(
				'wallet_min',
				'کمترین مبلغ شارژ',
				array( 'type' => 'number', 'min' => 0, 'suffix' => 'تومان' )
			);

			WCMA_Admin_Fields::text(
				'wallet_max',
				'بیشترین مبلغ شارژ',
				array( 'type' => 'number', 'min' => 0, 'suffix' => 'تومان' )
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::toggle(
			'wallet_gateway',
			'پرداخت سفارش از کیف پول ممکن باشد',
			'یک روش پرداخت تازه به تسویه‌حساب اضافه می‌شود که از موجودی کیف پول کم می‌کند.'
		);

		WCMA_Admin_Fields::text(
			'wallet_gateway_title',
			'نام این روش پرداخت در تسویه‌حساب',
			array( 'placeholder' => 'پرداخت از کیف پول' )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php
	WCMA_Admin_Fields::card_start(
		'تیکت پشتیبانی',
		'مشتری از پنل خودش تیکت می‌زند و شما در برگه‌ی «تیکت‌ها» پاسخ می‌دهید.',
		'sos',
		'پیوست تیکت‌ها در همان پوشه‌ی امنِ گفتگو می‌نشیند، نه در رسانه‌ی وردپرس؛ پس با نشانی حدسی قابل دیدن نیست.',
		'tickets'
	);
	?>
		<?php
		WCMA_Admin_Fields::toggle(
			'tickets_enabled',
			'بخش تیکت فعال باشد'
		);

		WCMA_Admin_Fields::textarea(
			'ticket_departments',
			'بخش‌های پشتیبانی',
			array( 'rows' => 3, 'description' => 'هر بخش در یک خط.' )
		);
		?>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::toggle(
				'ticket_notify_staff',
				'تیکت تازه، ایمیل خبر بدهد'
			);

			WCMA_Admin_Fields::toggle(
				'ticket_notify_user',
				'پاسخ شما، به مشتری پیامک شود'
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::text(
			'ticket_staff_email',
			'ایمیل دریافت خبر تیکت',
			array( 'type' => 'email', 'placeholder' => get_option( 'admin_email' ) )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
