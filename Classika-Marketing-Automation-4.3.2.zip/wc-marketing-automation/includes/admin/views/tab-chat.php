<?php
/**
 * تب گفتگو و چت‌بات: پاسخ خودکار و پاسخ دستی اپراتور.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_missing  = ! WCMA_Install::table_exists( 'wcma_chats' );
$wcma_skills   = WCMA_Chatbot::skills();
$wcma_rules    = WCMA_Chatbot::rules();
$wcma_enabled  = (array) WCMA_Settings::get( 'chat_skills', array() );
$wcma_matches  = WCMA_Chatbot::match_types();

// phpcs:disable WordPress.Security.NonceVerification.Recommended
$wcma_status = isset( $_GET['ch_status'] ) ? sanitize_key( wp_unslash( $_GET['ch_status'] ) ) : 'open';
$wcma_mode   = isset( $_GET['ch_mode'] ) ? sanitize_key( wp_unslash( $_GET['ch_mode'] ) ) : '';
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$wcma_chats = $wcma_missing
	? array( 'items' => array(), 'total' => 0 )
	: WCMA_Chatbot::chats(
		array(
			'status'   => $wcma_status,
			'mode'     => $wcma_mode,
			'per_page' => WCMA_Admin::per_page( 'i_per' ),
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'page'     => isset( $_GET['ipage'] ) ? max( 1, (int) $_GET['ipage'] ) : 1,
		)
	);

$wcma_ready = array();

foreach ( WCMA_Messengers::all() as $wcma_key => $wcma_msgr ) {
	if ( ! empty( $wcma_msgr['per_customer'] ) && WCMA_Messengers::is_ready( $wcma_key ) ) {
		$wcma_ready[] = $wcma_msgr['label'];
	}
}
?>

<?php if ( $wcma_missing ) : ?>
	<div class="wcma-notice wcma-notice--error">
		<span class="dashicons dashicons-warning"></span>
		<span>جدول گفتگوها ساخته نشده است. به تب «تست ارسال» بروید و «ترمیم جدول‌ها» را بزنید.</span>
	</div>
<?php endif; ?>

<?php if ( ! WCMA_Settings::is( 'chat_enabled' ) ) : ?>
	<div class="wcma-notice wcma-notice--warning">
		<span class="dashicons dashicons-info"></span>
		<span>چت‌بات خاموش است. پایین همین صفحه آن را روشن کنید تا پیام‌های ربات پاسخ خودکار بگیرند.</span>
	</div>
<?php elseif ( ! $wcma_ready && ! WCMA_Settings::is( 'lc_enabled' ) ) : ?>
	<div class="wcma-notice wcma-notice--warning">
		<span class="dashicons dashicons-info"></span>
		<span>هیچ پیام‌رسانی متصل نیست. در تب «پیامک و پیام‌رسان‌ها» توکن ربات را وارد و وب‌هوک را ثبت کنید.</span>
	</div>
<?php endif; ?>

<?php
$wcma_online  = WCMA_LiveChat::online_visitors();
$wcma_rating  = WCMA_LiveChat::rating_summary();
$wcma_waiting = 0;

foreach ( $wcma_chats['items'] as $wcma_row ) {
	if ( (int) $wcma_row['unread'] > 0 ) {
		$wcma_waiting++;
	}
}
?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat">
		<span class="wcma-stat__icon dashicons dashicons-format-chat"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_chats['total'] ) ); ?></span>
			<span class="wcma-stat__label">کل گفتگوها</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-bell"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_waiting ) ); ?></span>
			<span class="wcma-stat__label">منتظر پاسخ</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-visibility"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( count( $wcma_online ) ) ); ?></span>
			<span class="wcma-stat__label">همین حالا روی سایت</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-star-filled"></span>
		<div>
			<span class="wcma-stat__value">
				<?php echo esc_html( $wcma_rating['count'] ? WCMA_Date::digits( $wcma_rating['avg'] ) . ' از ۵' : '—' ); ?>
			</span>
			<span class="wcma-stat__label">میانگین رضایت (<?php echo esc_html( WCMA_Date::number( $wcma_rating['count'] ) ); ?> رأی)</span>
		</div>
	</div>
</div>

<?php WCMA_Admin_Fields::card_start( 'صندوق گفتگوها', 'پیام‌های چت سایت و ربات‌های پیام‌رسان. هر گفتگو را باز کنید تا تاریخچه را ببینید و دستی پاسخ دهید. فهرست هر ۸ ثانیه خودکار تازه می‌شود.', 'format-chat' ); ?>
	<div class="wcma-filters">
		<a href="<?php echo esc_url( add_query_arg( array( 'ch_status' => 'open' ), WCMA_Admin::tab_url( 'chat' ) ) ); ?>" class="wcma-btn <?php echo 'open' === $wcma_status ? 'wcma-btn--secondary' : 'wcma-btn--ghost'; ?>">باز</a>
		<a href="<?php echo esc_url( add_query_arg( array( 'ch_status' => 'closed' ), WCMA_Admin::tab_url( 'chat' ) ) ); ?>" class="wcma-btn <?php echo 'closed' === $wcma_status ? 'wcma-btn--secondary' : 'wcma-btn--ghost'; ?>">بسته‌شده</a>
		<a href="<?php echo esc_url( add_query_arg( array( 'ch_status' => 'open', 'ch_mode' => 'human' ), WCMA_Admin::tab_url( 'chat' ) ) ); ?>" class="wcma-btn <?php echo 'human' === $wcma_mode ? 'wcma-btn--secondary' : 'wcma-btn--ghost'; ?>">منتظر اپراتور</a>
	</div>

	<?php
	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 'i_per',
			'current' => WCMA_Admin::per_page( 'i_per' ),
			'total'   => (int) ( $wcma_chats['found'] ?? $wcma_chats['total'] ),
		)
	);
	?>

	<div class="wcma-inbox">
		<div class="wcma-inbox__list">
			<?php if ( $wcma_chats['items'] ) : ?>
				<?php foreach ( $wcma_chats['items'] as $wcma_chat ) : ?>
					<button
						type="button"
						class="wcma-inbox__item <?php echo (int) $wcma_chat['unread'] > 0 ? 'is-unread' : ''; ?>"
						data-chat="<?php echo esc_attr( (int) $wcma_chat['id'] ); ?>"
					>
						<span class="wcma-inbox__top">
							<strong><?php echo esc_html( $wcma_chat['name'] ? $wcma_chat['name'] : 'مهمان' ); ?></strong>
							<span class="wcma-badge wcma-badge--soft"><?php echo esc_html( WCMA_Chatbot::channel_label( $wcma_chat['channel'] ) ); ?></span>
							<?php if ( WCMA_LiveChat::visitor_online( $wcma_chat ) ) : ?>
								<span class="wcma-live-dot" title="همین حالا روی سایت است"></span>
							<?php endif; ?>
							<?php if ( 'human' === $wcma_chat['mode'] ) : ?>
								<span class="wcma-badge wcma-badge--amber">اپراتور</span>
							<?php endif; ?>
						</span>
						<span class="wcma-inbox__preview"><?php echo esc_html( mb_substr( (string) $wcma_chat['last_message'], 0, 70 ) ); ?></span>
						<span class="wcma-inbox__time"><?php echo WCMA_Date::html( $wcma_chat['last_message_at'] ); ?></span>
					</button>
				<?php endforeach; ?>
				<?php
				WCMA_Admin_Fields::pagination(
					array(
						'key'     => 'ipage',
						'current' => (int) ( $wcma_chats['page'] ?? 1 ),
						'pages'   => (int) ( $wcma_chats['pages'] ?? 1 ),
					)
				);
				?>
			<?php else : ?>
				<div class="wcma-empty wcma-empty--small">
					<span class="dashicons dashicons-format-chat"></span>
					<p>هنوز گفتگویی نیست. وقتی مشتری به ربات پیام بدهد، همین‌جا نمایش داده می‌شود.</p>
				</div>
			<?php endif; ?>
		</div>

		<div class="wcma-inbox__thread" id="wcma-chat-thread">
			<div class="wcma-inbox__empty">
				<span class="dashicons dashicons-format-chat"></span>
				<p>یک گفتگو را از فهرست کنار انتخاب کنید.</p>
			</div>
		</div>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'آزمودن ربات', 'پیام مشتری را اینجا بنویسید تا ببینید ربات چه پاسخی می‌دهد. چیزی برای کسی ارسال نمی‌شود.', 'controls-play' ); ?>
	<div class="wcma-sim">
		<input type="text" id="wcma-chat-sim" placeholder="مثلاً: سلام، سفارش من کی می‌رسد؟" />
		<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-chat-sim-run">
			<span class="dashicons dashicons-controls-play"></span>
			آزمایش
		</button>
	</div>
	<div id="wcma-chat-sim-result"></div>
<?php WCMA_Admin_Fields::card_end(); ?>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'چت آنلاین سایت', 'یک دکمه‌ی شناور در گوشه‌ی سایت که بازدیدکننده از همان‌جا با شما حرف می‌زند — مثل سرویس‌های گفتگوی آنلاین.', 'admin-site-alt3', '', 'chat-widget' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'lc_enabled', 'نمایش دکمه‌ی گفتگو روی سایت' );
		?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::select(
				'lc_position',
				'جای دکمه',
				array(
					'left'  => 'گوشه‌ی پایین چپ',
					'right' => 'گوشه‌ی پایین راست',
				)
			);

			WCMA_Admin_Fields::text( 'lc_color', 'رنگ اصلی', array( 'type' => 'color' ) );
			WCMA_Admin_Fields::image( 'lc_avatar', 'تصویر پشتیبان', array( 'description' => 'از کتابخانه‌ی رسانه انتخاب یا آپلود کنید. تصویر مربعی و کوچک (مثلاً ۱۵۰×۱۵۰) بهترین نتیجه را می‌دهد.' ) );
			?>
		</div>

		<h3 class="wcma-subtitle">
			تیم پشتیبانی
			<?php WCMA_Admin_Fields::help( 'تصویر این همکاران کنار عنوان پنجره روی هم می‌نشیند و حس «تیم پشت گفتگو» می‌دهد. خالی گذاشتنشان اشکالی ندارد؛ فقط همان تصویر پشتیبان نشان داده می‌شود.' ); ?>
		</h3>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::image( 'lc_avatar_2', 'تصویر همکار دوم' );
			WCMA_Admin_Fields::image( 'lc_avatar_3', 'تصویر همکار سوم' );
			?>
		</div>

		<div class="wcma-row">
			<?php
			WCMA_Admin_Fields::text( 'lc_title', 'عنوان پنجره' );
			WCMA_Admin_Fields::text( 'lc_subtitle', 'زیرعنوان (زمان پاسخ‌گویی)' );
			?>
		</div>

		<?php
		WCMA_Admin_Fields::textarea( 'lc_welcome', 'پیام خوش‌آمد داخل پنجره', array( 'rows' => 2 ) );

		WCMA_Admin_Fields::textarea(
			'lc_greeting',
			'پیام دعوت (حباب کوچک کنار دکمه)',
			array( 'rows' => 2, 'description' => 'خالی بگذارید تا حبابی نمایش داده نشود.' )
		);
		?>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::text(
				'lc_greeting_delay',
				'چند ثانیه بعد از ورود؟',
				array( 'type' => 'number', 'min' => 0, 'max' => 300, 'suffix' => 'ثانیه' )
			);

			WCMA_Admin_Fields::text(
				'lc_hours_start',
				'ساعت شروع پاسخ‌گویی',
				array( 'type' => 'number', 'min' => 0, 'max' => 23 )
			);

			WCMA_Admin_Fields::text(
				'lc_hours_end',
				'ساعت پایان پاسخ‌گویی',
				array( 'type' => 'number', 'min' => 0, 'max' => 23 )
			);
			?>
		</div>

		<p class="wcma-field__desc">اگر هر دو ساعت را صفر بگذارید، محدودیت ساعتی اعمال نمی‌شود.</p>

		<?php
		WCMA_Admin_Fields::textarea(
			'lc_offline_text',
			'پیام خارج از ساعت کاری',
			array( 'rows' => 2 )
		);

		WCMA_Admin_Fields::textarea(
			'lc_quick_replies',
			'دکمه‌های پاسخ سریع',
			array( 'rows' => 2, 'description' => 'با ویرگول یا خط جدید جدا کنید. حداکثر شش مورد.' )
		);
		?>

		<h3 class="wcma-subtitle">فرم تماس، خارج از ساعت کاری</h3>

		<?php
		WCMA_Admin_Fields::toggle(
			'lc_lead_form',
			'بیرون از ساعت کاری، فرم مشخصات نشان داده شود',
			'به‌جای یک پیام خشکِ «الان نیستیم»، بازدیدکننده فرم کوتاهی پر می‌کند و پرونده‌اش در «مدیریت ارتباط با مشتریان» ساخته می‌شود.'
		);

		WCMA_Admin_Fields::textarea(
			'lc_lead_form_text',
			'متن بالای فرم',
			array(
				'rows'        => 3,
				'description' => 'با <code>{hours}</code> ساعت کاریِ همین بالا خودش نوشته می‌شود.',
			)
		);
		?>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::toggle(
				'lc_lead_form_name',
				'نام و نام خانوادگی هم پرسیده شود'
			);

			WCMA_Admin_Fields::toggle(
				'lc_lead_form_order',
				'شماره سفارش هم پرسیده شود',
				'اختیاری می‌ماند؛ کسی که هنوز سفارشی ندارد هم می‌تواند فرم را بفرستد.'
			);
			?>
		</div>

		<?php
		WCMA_Admin_Fields::textarea(
			'lc_lead_form_thanks',
			'پیام پس از ثبت فرم',
			array( 'rows' => 2 )
		);
		?>

		<h3 class="wcma-subtitle">پیش از شروع گفتگو چه بپرسیم؟</h3>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::toggle( 'lc_ask_name', 'نام' );
			WCMA_Admin_Fields::toggle( 'lc_ask_phone', 'شماره موبایل' );
			WCMA_Admin_Fields::toggle( 'lc_ask_email', 'ایمیل' );
			?>
		</div>

		<p class="wcma-field__desc">
			هر شماره یا ایمیلی که اینجا گرفته شود، خودکار به
			<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'crm' ) ); ?>">پرونده‌ی مشتریان</a>
			اضافه می‌شود.
		</p>

		<div class="wcma-row wcma-row--3">
			<?php
			WCMA_Admin_Fields::toggle( 'lc_rating', 'پرسیدن رضایت در پایان گفتگو' );
			WCMA_Admin_Fields::toggle( 'lc_sound', 'صدای اعلان پیام تازه' );
			WCMA_Admin_Fields::toggle( 'lc_logged_in_only', 'فقط برای کاربران وارد شده' );
			?>
		</div>

		<div class="wcma-lc-preview">
			<div class="wcma-lc-preview__bubble" style="background: <?php echo esc_attr( WCMA_Settings::get( 'lc_color', '#2563eb' ) ); ?>">
				<span class="dashicons dashicons-format-chat"></span>
			</div>
			<div class="wcma-lc-preview__note">
				<?php echo esc_html( WCMA_Settings::get( 'lc_title', '' ) ); ?> —
				<?php echo esc_html( 'left' === WCMA_Settings::get( 'lc_position', 'left' ) ? 'گوشه‌ی پایین چپ' : 'گوشه‌ی پایین راست' ); ?>
				<br />
				<?php if ( WCMA_LiveChat::within_hours() ) : ?>
					همین حالا در ساعت کاری هستید.
				<?php else : ?>
					همین حالا خارج از ساعت کاری هستید؛ پیام آفلاین نمایش داده می‌شود.
				<?php endif; ?>
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php
	WCMA_Admin_Fields::card_start(
		'فایل و پیام صوتی در گفتگو',
		'اجازه می‌دهید مشتری و اپراتور در گفتگو عکس، فایل متنی، ویدیو، فایل فشرده و ویس رد و بدل کنند.',
		'paperclip',
		'فایل‌ها در پوشه‌ای جدا از رسانه‌ی وردپرس ذخیره می‌شوند و اجرای اسکریپت در آن پوشه بسته است.',
		'chat-files'
	);
	?>
		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::toggle( 'lc_files_enabled', 'ارسال فایل در گفتگو', '', 'با خاموش کردن، دکمه‌ی پیوست از هر دو طرف برداشته می‌شود و سرور هم فایلی نمی‌پذیرد.' );
			WCMA_Admin_Fields::toggle( 'lc_voice_enabled', 'ضبط و ارسال پیام صوتی', '', 'مرورگر برای میکروفون به HTTPS نیاز دارد؛ روی سایت بدون گواهی، دکمه‌ی ضبط نمایش داده نمی‌شود.' );
			?>
		</div>

		<?php
		WCMA_Admin_Fields::text(
			'lc_file_max_mb',
			'بیشترین حجم هر فایل',
			array(
				'type'        => 'number',
				'min'         => 1,
				'max'         => 100,
				'suffix'      => 'مگابایت',
				'description' => sprintf(
					'سقف خود سرور %s است و هر عدد بزرگ‌تری از آن بی‌اثر می‌ماند.',
					esc_html( WCMA_Chat_Files::human_size( (int) wp_max_upload_size() ) )
				),
			)
		);
		?>

		<div class="wcma-info">
			<span class="dashicons dashicons-yes"></span>
			<div>
				نوع‌های پذیرفته‌شده:
				<?php
				$wcma_types = array();

				foreach ( WCMA_Chat_Files::kinds() as $wcma_kind ) {
					$wcma_types[] = $wcma_kind['label'] . ' (' . implode( '، ', $wcma_kind['ext'] ) . ')';
				}

				echo esc_html( implode( ' — ', $wcma_types ) );
				?>
				<br />
				هر نوع دیگری — از جمله فایل اجرایی و اسکریپت — رد می‌شود.
			</div>
		</div>

		<h3 class="wcma-subtitle">نگهداری یا پاک‌سازی دوره‌ای</h3>

		<?php
		$wcma_usage = WCMA_Chat_Files::usage();
		?>

		<div class="wcma-row wcma-row--2">
			<?php
			WCMA_Admin_Fields::toggle( 'lc_files_prune', 'پاک‌سازی خودکار فایل‌های قدیمی', '', 'هر شب یک‌بار اجرا می‌شود. با خاموش بودن، هیچ فایلی خودکار پاک نمی‌شود و هاست به مرور پر می‌شود.' );

			WCMA_Admin_Fields::text(
				'lc_files_keep_days',
				'فایل‌ها چند روز نگه داشته شوند؟',
				array(
					'type'        => 'number',
					'min'         => 1,
					'max'         => 3650,
					'suffix'      => 'روز',
					'description' => 'پس از این مدت، فایل از هاست پاک می‌شود و در گفتگو به‌جای آن «فایل پاک شده» می‌ماند. متن پیام‌ها دست نمی‌خورد.',
				)
			);
			?>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-database"></span>
			<div>
				هم‌اکنون
				<strong id="wcma-files-count"><?php echo esc_html( WCMA_Date::number( $wcma_usage['count'] ) ); ?></strong>
				فایل با مجموع
				<strong id="wcma-files-size"><?php echo esc_html( WCMA_Chat_Files::human_size( $wcma_usage['bytes'] ) ); ?></strong>
				روی هاست ذخیره است.
				<br />
				<button type="button" class="wcma-btn wcma-btn--ghost" id="wcma-files-purge">
					<span class="dashicons dashicons-trash"></span>
					پاک کردن همه‌ی فایل‌ها همین حالا
				</button>
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پاسخ خودکار', 'ربات پیش از هر چیز قاعده‌های شما را بررسی می‌کند، بعد مهارت‌های آماده و در پایان هوش مصنوعی. این قاعده‌ها هم روی چت سایت کار می‌کنند و هم در پیام‌رسان‌ها.', 'admin-generic', '', 'chat-rules' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'chat_enabled', 'پاسخ خودکار به پیام‌های ربات' );
		?>

		<h3 class="wcma-subtitle">مهارت‌های آماده</h3>

		<input type="hidden" name="wcma[chat_skills][]" value="" />

		<div class="wcma-skills">
			<?php foreach ( $wcma_skills as $wcma_key => $wcma_skill ) : ?>
				<label class="wcma-skill">
					<input
						type="checkbox"
						name="wcma[chat_skills][]"
						value="<?php echo esc_attr( $wcma_key ); ?>"
						<?php checked( in_array( $wcma_key, $wcma_enabled, true ) ); ?>
					/>
					<span class="wcma-skill__body">
						<strong>
							<span class="dashicons dashicons-<?php
							echo esc_attr(
								array(
									'order_status' => 'cart',
									'product'      => 'products',
									'hours'        => 'clock',
									'operator'     => 'businessperson',
								)[ $wcma_key ] ?? 'admin-comments'
							);
							?>"></span>
							<?php echo esc_html( $wcma_skill['label'] ); ?>
						</strong>
						<small><?php echo esc_html( $wcma_skill['desc'] ); ?></small>
						<em>کلیدواژه‌ها: <?php echo esc_html( $wcma_skill['keywords'] ); ?></em>
					</span>
				</label>
			<?php endforeach; ?>
		</div>

		<h3 class="wcma-subtitle">قاعده‌های دلخواه</h3>
		<p class="wcma-field__desc">
			قاعده‌ها از بالا به پایین بررسی می‌شوند و اولین قاعده‌ی منطبق پاسخ می‌دهد. برای پاسخ به
			همه‌ی پیام‌ها، حالت «هر پیامی» را در آخرین قاعده بگذارید.
		</p>

		<?php WCMA_Admin_Fields::placeholder_help( array( 'order_number', 'order_status', 'order_link', 'product_name', 'coupon_code' ) ); ?>

		<div class="wcma-rules">
			<?php for ( $wcma_i = 0; $wcma_i < 6; $wcma_i++ ) : ?>
				<?php
				$wcma_rule = $wcma_rules[ $wcma_i ] ?? array();
				$wcma_on   = ! empty( $wcma_rule['enabled'] );
				?>
				<div class="wcma-rule <?php echo $wcma_on ? 'is-active' : ''; ?>">
					<div class="wcma-rule__head">
						<label class="wcma-switch">
							<input type="hidden" name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][enabled]" value="" />
							<input
								type="checkbox"
								class="wcma-rule__toggle"
								name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][enabled]"
								value="yes"
								<?php checked( $wcma_on ); ?>
							/>
							<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
						</label>
						<strong>قاعده‌ی <?php echo esc_html( WCMA_Date::number( $wcma_i + 1 ) ); ?></strong>
					</div>

					<div class="wcma-rule__body">
						<div class="wcma-row wcma-row--3">
							<div class="wcma-field">
								<label class="wcma-field__label">روش تطبیق</label>
								<div class="wcma-field__input">
									<select name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][match]">
										<?php foreach ( $wcma_matches as $wcma_mkey => $wcma_mlabel ) : ?>
											<option value="<?php echo esc_attr( $wcma_mkey ); ?>" <?php selected( $wcma_rule['match'] ?? 'contains', $wcma_mkey ); ?>><?php echo esc_html( $wcma_mlabel ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>
							<div class="wcma-field" style="grid-column: span 2;">
								<label class="wcma-field__label">کلیدواژه‌ها</label>
								<div class="wcma-field__input">
									<input
										type="text"
										name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][keywords]"
										value="<?php echo esc_attr( $wcma_rule['keywords'] ?? '' ); ?>"
										placeholder="ارسال، هزینه ارسال، پست"
									/>
								</div>
								<p class="wcma-field__desc">با ویرگول جدا کنید. هر کدام که در پیام باشد، این قاعده اجرا می‌شود.</p>
							</div>
						</div>

						<div class="wcma-field">
							<label class="wcma-field__label">پاسخ ربات</label>
							<div class="wcma-field__input">
								<textarea
									name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][reply]"
									rows="3"
									placeholder="ارسال به سراسر کشور با پست پیشتاز، ۲ تا ۴ روز کاری."
								><?php echo esc_textarea( $wcma_rule['reply'] ?? '' ); ?></textarea>
							</div>
						</div>

						<label class="wcma-check">
							<input type="hidden" name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][handover]" value="" />
							<input
								type="checkbox"
								name="wcma[chat_rules][<?php echo esc_attr( $wcma_i ); ?>][handover]"
								value="yes"
								<?php checked( ! empty( $wcma_rule['handover'] ) ); ?>
							/>
							<span>پس از این پاسخ، گفتگو به اپراتور سپرده شود</span>
						</label>
					</div>
				</div>
			<?php endfor; ?>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'متن‌های پیش‌فرض', '', 'editor-textcolor' ); ?>
		<?php
		WCMA_Admin_Fields::textarea(
			'chat_welcome_text',
			'پیام خوش‌آمد',
			array( 'rows' => 2, 'description' => 'وقتی مشتری برای نخستین بار /start می‌فرستد.' )
		);

		WCMA_Admin_Fields::textarea(
			'chat_fallback_text',
			'پاسخ پیش‌فرض (وقتی هیچ قاعده‌ای نخواند)',
			array( 'rows' => 2, 'description' => 'خالی بگذارید تا ربات در این حالت ساکت بماند.' )
		);

		WCMA_Admin_Fields::toggle( 'chat_fallback_handover', 'پیام‌های بی‌پاسخ به اپراتور سپرده شوند' );

		WCMA_Admin_Fields::textarea(
			'chat_handover_text',
			'پیام هنگام ارجاع به اپراتور',
			array( 'rows' => 2 )
		);

		WCMA_Admin_Fields::textarea(
			'chat_hours_text',
			'ساعت کاری و راه تماس',
			array( 'rows' => 3, 'description' => 'خالی بگذارید تا از نام فروشگاه، تلفن و آدرس سایت ساخته شود.' )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'هوش مصنوعی و اپراتور', '', 'lightbulb' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'chat_ai_enabled', 'اگر هیچ قاعده‌ای نخواند، هوش مصنوعی پاسخ بدهد' );
		?>

		<?php if ( ! WCMA_AI::is_ready() ) : ?>
			<div class="wcma-info">
				<span class="dashicons dashicons-info"></span>
				<div>
					برای این گزینه باید در تب
					<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'ai' ) ); ?>">محتوای هوشمند</a>
					یکی از سرویس‌ها (ChatGPT، Claude یا Gemini) را وصل کنید.
				</div>
			</div>
		<?php endif; ?>

		<?php
		WCMA_Admin_Fields::text(
			'chat_notify_phone',
			'شماره‌ی اپراتور برای اطلاع از گفتگوهای منتظر',
			array( 'placeholder' => '09121234567', 'description' => 'حداکثر هر ۱۵ دقیقه یک پیامک برای هر گفتگو.' )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>
