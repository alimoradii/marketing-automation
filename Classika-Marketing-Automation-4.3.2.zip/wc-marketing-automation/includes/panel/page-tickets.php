<?php
/**
 * تیکت‌های پشتیبانی مشتری.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_id = (int) $wcma_user->ID;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wcma_open_id = isset( $_GET['ticket'] ) ? (int) $_GET['ticket'] : 0;
$wcma_ticket  = $wcma_open_id ? WCMA_Tickets::get( $wcma_open_id ) : null;

// تیکت کسِ دیگری، انگار وجود ندارد.
if ( $wcma_ticket && (int) $wcma_ticket['user_id'] !== $wcma_id ) {
	$wcma_ticket = null;
}

if ( $wcma_ticket ) {
	WCMA_Tickets::mark_read( (int) $wcma_ticket['id'], false );
}

$wcma_departments = WCMA_Tickets::departments();
$wcma_priorities  = WCMA_Tickets::priorities();
$wcma_statuses    = WCMA_Tickets::statuses();
$wcma_post        = esc_url( admin_url( 'admin-post.php' ) );
?>

<?php if ( $wcma_ticket ) : ?>

	<div class="wp-crumbs">
		<a href="<?php echo esc_url( WCMA_Panel::url( 'tickets' ) ); ?>">تیکت‌ها</a>
		<span>›</span>
		<span><?php echo esc_html( $wcma_ticket['subject'] ); ?></span>
	</div>

	<h1 class="wp-h1"><?php echo esc_html( $wcma_ticket['subject'] ); ?></h1>

	<p class="wp-lead">
		<span class="wp-chip wp-chip--<?php echo esc_attr( $wcma_ticket['status'] ); ?>">
			<?php echo esc_html( $wcma_statuses[ $wcma_ticket['status'] ] ?? $wcma_ticket['status'] ); ?>
		</span>
		<?php echo esc_html( $wcma_departments[ $wcma_ticket['department'] ] ?? $wcma_ticket['department'] ); ?>
		·
		<?php echo esc_html( WCMA_Date::mysql( $wcma_ticket['created_at'], 'datetime' ) ); ?>
	</p>

	<section class="wp-thread">
		<?php foreach ( WCMA_Tickets::replies( (int) $wcma_ticket['id'] ) as $wcma_reply ) : ?>
			<article class="wp-msg wp-msg--<?php echo 'staff' === $wcma_reply['author'] ? 'staff' : 'me'; ?>">
				<header>
					<strong><?php echo esc_html( $wcma_reply['author_name'] ); ?></strong>
					<time><?php echo esc_html( WCMA_Date::mysql( $wcma_reply['created_at'], 'datetime' ) ); ?></time>
				</header>

				<?php if ( '' !== trim( (string) $wcma_reply['body'] ) ) : ?>
					<div class="wp-msg__body"><?php echo wp_kses_post( wpautop( $wcma_reply['body'] ) ); ?></div>
				<?php endif; ?>

				<?php if ( $wcma_reply['att_url'] ) : ?>
					<?php if ( 'image' === $wcma_reply['att_kind'] ) : ?>
						<a class="wp-msg__shot" href="<?php echo esc_url( $wcma_reply['att_url'] ); ?>" target="_blank" rel="noopener">
							<img src="<?php echo esc_url( $wcma_reply['att_url'] ); ?>" alt="<?php echo esc_attr( $wcma_reply['att_name'] ); ?>" loading="lazy" />
						</a>
					<?php else : ?>
						<a class="wp-msg__file" href="<?php echo esc_url( $wcma_reply['att_url'] ); ?>" target="_blank" rel="noopener">
							📎 <?php echo esc_html( $wcma_reply['att_name'] ); ?>
						</a>
					<?php endif; ?>
				<?php endif; ?>
			</article>
		<?php endforeach; ?>
	</section>

	<?php if ( 'closed' === $wcma_ticket['status'] ) : ?>
		<p class="wp-empty">این تیکت بسته شده است. اگر موضوع تازه‌ای دارید، تیکت جدید بزنید.</p>
	<?php else : ?>
		<form class="wp-card wp-replybox" method="post" action="<?php echo $wcma_post; ?>" enctype="multipart/form-data">
			<?php wp_nonce_field( 'wcma_panel' ); ?>
			<input type="hidden" name="action" value="wcma_panel" />
			<input type="hidden" name="wcma_do" value="ticket_reply" />
			<input type="hidden" name="ticket" value="<?php echo esc_attr( (int) $wcma_ticket['id'] ); ?>" />

			<label class="wp-field">
				<span>پاسخ شما</span>
				<textarea name="body" rows="4" required></textarea>
			</label>

			<?php if ( WCMA_Chat_Files::enabled() ) : ?>
				<label class="wp-file">
					<input type="file" name="attachment" accept="<?php echo esc_attr( WCMA_Chat_Files::accept_attr() ); ?>" />
					<span class="wp-file__btn">
						<svg class="wp-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5 12.5 20a5 5 0 0 1-7-7l8-8a3.5 3.5 0 0 1 5 5l-8 8a2 2 0 0 1-3-3l7.5-7.5"/></svg>
						انتخاب فایل
					</span>
					<span class="wp-file__name">پیوست فایل (اختیاری)</span>
				</label>
			<?php endif; ?>

			<button type="submit" class="wp-btn wp-btn--primary">ارسال پاسخ</button>
		</form>
	<?php endif; ?>

<?php else : ?>

	<h1 class="wp-h1">تیکت‌های پشتیبانی</h1>

	<?php
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$wcma_page_no = isset( $_GET['p'] ) ? max( 1, (int) $_GET['p'] ) : 1;
	$wcma_list    = WCMA_Tickets::query( array( 'user_id' => $wcma_id, 'page' => $wcma_page_no ) );
	?>

	<details class="wp-card wp-newticket" <?php echo $wcma_list['items'] ? '' : 'open'; ?>>
		<summary>ثبت تیکت تازه</summary>

		<form method="post" action="<?php echo $wcma_post; ?>" enctype="multipart/form-data">
			<?php wp_nonce_field( 'wcma_panel' ); ?>
			<input type="hidden" name="action" value="wcma_panel" />
			<input type="hidden" name="wcma_do" value="ticket_open" />

			<label class="wp-field">
				<span>موضوع</span>
				<input type="text" name="subject" maxlength="190" required />
			</label>

			<div class="wp-two">
				<label class="wp-field">
					<span>بخش</span>
					<select name="department">
						<?php foreach ( $wcma_departments as $wcma_key => $wcma_label ) : ?>
							<option value="<?php echo esc_attr( $wcma_key ); ?>"><?php echo esc_html( $wcma_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label class="wp-field">
					<span>اهمیت</span>
					<select name="priority">
						<?php foreach ( $wcma_priorities as $wcma_key => $wcma_label ) : ?>
							<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( 'normal', $wcma_key ); ?>><?php echo esc_html( $wcma_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			</div>

			<label class="wp-field">
				<span>شرح کامل</span>
				<textarea name="body" rows="5" required></textarea>
			</label>

			<?php if ( WCMA_Chat_Files::enabled() ) : ?>
				<label class="wp-file">
					<input type="file" name="attachment" accept="<?php echo esc_attr( WCMA_Chat_Files::accept_attr() ); ?>" />
					<span class="wp-file__btn">
						<svg class="wp-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5 12.5 20a5 5 0 0 1-7-7l8-8a3.5 3.5 0 0 1 5 5l-8 8a2 2 0 0 1-3-3l7.5-7.5"/></svg>
						انتخاب فایل
					</span>
					<span class="wp-file__name">پیوست فایل (اختیاری)</span>
				</label>
			<?php endif; ?>

			<button type="submit" class="wp-btn wp-btn--primary">ثبت تیکت</button>
		</form>
	</details>

	<section class="wp-card">
		<?php if ( $wcma_list['items'] ) : ?>
			<div class="wp-list">
				<?php foreach ( $wcma_list['items'] as $wcma_row ) : ?>
					<a class="wp-row wp-row--link<?php echo $wcma_row['unread_user'] ? ' is-fresh' : ''; ?>"
						href="<?php echo esc_url( WCMA_Panel::url( 'tickets', array( 'ticket' => (int) $wcma_row['id'] ) ) ); ?>">
						<div class="wp-row__main">
							<strong><?php echo esc_html( $wcma_row['subject'] ); ?></strong>
							<span>
								<?php echo esc_html( $wcma_departments[ $wcma_row['department'] ] ?? $wcma_row['department'] ); ?>
								·
								<?php echo esc_html( WCMA_Date::mysql( $wcma_row['last_reply_at'], 'datetime' ) ); ?>
							</span>
						</div>

						<?php if ( $wcma_row['unread_user'] ) : ?>
							<span class="wp-dot" title="پاسخ تازه"></span>
						<?php endif; ?>

						<span class="wp-chip wp-chip--<?php echo esc_attr( $wcma_row['status'] ); ?>">
							<?php echo esc_html( $wcma_statuses[ $wcma_row['status'] ] ?? $wcma_row['status'] ); ?>
						</span>
					</a>
				<?php endforeach; ?>
			</div>

			<?php if ( $wcma_list['pages'] > 1 ) : ?>
				<div class="wp-pages">
					<?php for ( $wcma_i = 1; $wcma_i <= min( 20, (int) $wcma_list['pages'] ); $wcma_i++ ) : ?>
						<a
							class="<?php echo $wcma_i === (int) $wcma_list['page'] ? 'is-current' : ''; ?>"
							href="<?php echo esc_url( WCMA_Panel::url( 'tickets', array( 'p' => $wcma_i ) ) ); ?>"
						><?php echo esc_html( WCMA_Date::number( $wcma_i ) ); ?></a>
					<?php endfor; ?>
				</div>
			<?php endif; ?>
		<?php else : ?>
			<p class="wp-empty">هنوز تیکتی ثبت نکرده‌اید.</p>
		<?php endif; ?>
	</section>

<?php endif; ?>
