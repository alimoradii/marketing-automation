<?php
/**
 * خانه‌ی پنل: یک نگاه به همه‌چیز.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_id = (int) $wcma_user->ID;

$wcma_orders = function_exists( 'wc_get_orders' )
	? wc_get_orders( array( 'customer_id' => $wcma_id, 'limit' => 3, 'orderby' => 'date', 'order' => 'DESC' ) )
	: array();

$wcma_spent = function_exists( 'wc_get_customer_total_spent' ) ? (float) wc_get_customer_total_spent( $wcma_id ) : 0.0;
$wcma_count = function_exists( 'wc_get_customer_order_count' ) ? (int) wc_get_customer_order_count( $wcma_id ) : 0;
?>

<h1 class="wp-h1">سلام <?php echo esc_html( WCMA_Accounts::display_name( $wcma_user ) ); ?> 👋</h1>
<p class="wp-lead">اینجا خلاصه‌ی حساب شماست.</p>

<div class="wp-tiles">
	<div class="wp-tile wp-tile--a">
		<span class="wp-tile__label">سفارش‌های شما</span>
		<strong class="wp-tile__value"><?php echo esc_html( WCMA_Date::number( $wcma_count ) ); ?></strong>
	</div>

	<div class="wp-tile wp-tile--b">
		<span class="wp-tile__label">مجموع خرید</span>
		<strong class="wp-tile__value"><?php echo wp_kses_post( WCMA_Date::price( $wcma_spent ) ); ?></strong>
	</div>

	<?php if ( WCMA_Wallet::is_on() ) : ?>
		<div class="wp-tile wp-tile--c">
			<span class="wp-tile__label">موجودی کیف پول</span>
			<strong class="wp-tile__value"><?php echo wp_kses_post( WCMA_Date::price( WCMA_Wallet::balance( $wcma_id ) ) ); ?></strong>
			<a class="wp-tile__link" href="<?php echo esc_url( WCMA_Panel::url( 'wallet' ) ); ?>">شارژ کیف پول</a>
		</div>
	<?php endif; ?>

	<?php if ( WCMA_Tickets::is_on() ) : ?>
		<div class="wp-tile wp-tile--d">
			<span class="wp-tile__label">تیکت‌های باز</span>
			<strong class="wp-tile__value"><?php echo esc_html( WCMA_Date::number( WCMA_Tickets::open_count( $wcma_id ) ) ); ?></strong>
			<a class="wp-tile__link" href="<?php echo esc_url( WCMA_Panel::url( 'tickets' ) ); ?>">پشتیبانی</a>
		</div>
	<?php endif; ?>
</div>

<section class="wp-card">
	<header class="wp-card__head">
		<h2>آخرین سفارش‌ها</h2>
		<a href="<?php echo esc_url( WCMA_Panel::url( 'orders' ) ); ?>">همه</a>
	</header>

	<?php if ( $wcma_orders ) : ?>
		<div class="wp-list">
			<?php foreach ( $wcma_orders as $wcma_order ) : ?>
				<?php if ( ! $wcma_order instanceof WC_Order ) { continue; } ?>
				<div class="wp-row">
					<div class="wp-row__main">
						<strong>#<?php echo esc_html( WCMA_Date::digits( $wcma_order->get_order_number() ) ); ?></strong>
						<span><?php echo esc_html( WCMA_Date::mysql( $wcma_order->get_date_created() ? $wcma_order->get_date_created()->date( 'Y-m-d H:i:s' ) : '', 'datetime' ) ); ?></span>
					</div>

					<span class="wp-chip"><?php echo esc_html( wc_get_order_status_name( $wcma_order->get_status() ) ); ?></span>
					<span class="wp-row__price"><?php echo wp_kses_post( WCMA_Date::digits( $wcma_order->get_formatted_order_total() ) ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="wp-empty">هنوز سفارشی ثبت نکرده‌اید.</p>
	<?php endif; ?>
</section>
