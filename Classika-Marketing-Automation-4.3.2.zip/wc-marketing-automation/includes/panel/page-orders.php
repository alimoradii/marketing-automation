<?php
/**
 * سفارش‌های مشتری.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_id = (int) $wcma_user->ID;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wcma_page_no = isset( $_GET['p'] ) ? max( 1, (int) $_GET['p'] ) : 1;
$wcma_per     = 20;

$wcma_result = function_exists( 'wc_get_orders' )
	? wc_get_orders(
		array(
			'customer_id' => $wcma_id,
			'limit'       => $wcma_per,
			'paged'       => $wcma_page_no,
			'orderby'     => 'date',
			'order'       => 'DESC',
			'paginate'    => true,
		)
	)
	: null;

$wcma_orders = is_object( $wcma_result ) ? (array) $wcma_result->orders : array();
$wcma_pages  = is_object( $wcma_result ) ? (int) $wcma_result->max_num_pages : 1;
?>

<h1 class="wp-h1">سفارش‌های من</h1>

<section class="wp-card">
	<?php if ( $wcma_orders ) : ?>
		<div class="wp-list">
			<?php foreach ( $wcma_orders as $wcma_order ) : ?>
				<?php if ( ! $wcma_order instanceof WC_Order ) { continue; } ?>

				<div class="wp-row wp-row--order">
					<div class="wp-row__main">
						<strong>
							سفارش #<?php echo esc_html( WCMA_Date::digits( $wcma_order->get_order_number() ) ); ?>
							<?php if ( WCMA_Wallet::is_topup( $wcma_order ) ) : ?>
								<span class="wp-chip wp-chip--soft">شارژ کیف پول</span>
							<?php endif; ?>
						</strong>
						<span>
							<?php echo esc_html( WCMA_Date::mysql( $wcma_order->get_date_created() ? $wcma_order->get_date_created()->date( 'Y-m-d H:i:s' ) : '', 'datetime' ) ); ?>
							·
							<?php
							printf(
								'%s قلم',
								esc_html( WCMA_Date::number( $wcma_order->get_item_count() ) )
							);
							?>
						</span>
					</div>

					<span class="wp-chip wp-chip--<?php echo esc_attr( $wcma_order->get_status() ); ?>">
						<?php echo esc_html( wc_get_order_status_name( $wcma_order->get_status() ) ); ?>
					</span>

					<span class="wp-row__price">
						<?php
						// بدون digits، مبلغِ سفارش لاتین می‌ماند و کنارِ تاریخِ فارسی ناجور می‌شود.
						echo wp_kses_post( WCMA_Date::digits( $wcma_order->get_formatted_order_total() ) );
						?>
					</span>

					<a class="wp-btn wp-btn--ghost" href="<?php echo esc_url( $wcma_order->get_view_order_url() ); ?>">جزئیات</a>
				</div>
			<?php endforeach; ?>
		</div>

		<?php if ( $wcma_pages > 1 ) : ?>
			<div class="wp-pages">
				<?php for ( $wcma_i = 1; $wcma_i <= min( 20, $wcma_pages ); $wcma_i++ ) : ?>
					<a
						class="<?php echo $wcma_i === $wcma_page_no ? 'is-current' : ''; ?>"
						href="<?php echo esc_url( WCMA_Panel::url( 'orders', array( 'p' => $wcma_i ) ) ); ?>"
					><?php echo esc_html( WCMA_Date::number( $wcma_i ) ); ?></a>
				<?php endfor; ?>
			</div>
		<?php endif; ?>
	<?php else : ?>
		<p class="wp-empty">هنوز سفارشی ثبت نکرده‌اید.</p>
	<?php endif; ?>
</section>
