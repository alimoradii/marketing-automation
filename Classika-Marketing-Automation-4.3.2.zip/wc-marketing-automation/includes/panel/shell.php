<?php
/**
 * چارچوب صفحه‌های پنل کاربری.
 *
 * @package WCMA
 *
 * @var array  $context اطلاعات صفحه.
 */

defined( 'ABSPATH' ) || exit;

$wcma_page   = (string) $context['page'];
$wcma_pages  = (array) $context['pages'];
$wcma_user   = $context['user'];
$wcma_demo   = (string) $context['demo'];
$wcma_notice = $context['notice'];
$wcma_view   = (string) $context['view'];
$wcma_login  = 'login' === $wcma_page;
$wcma_color  = (string) WCMA_Settings::get( 'panel_color', '#2563eb' );
$wcma_title  = (string) WCMA_Settings::get( 'panel_title', 'پنل کاربری' );
?><!doctype html>
<html dir="rtl" lang="fa">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
	<meta name="robots" content="noindex, nofollow" />
	<title><?php echo esc_html( $wcma_title . ' — ' . get_bloginfo( 'name' ) ); ?></title>

	<link rel="stylesheet" href="<?php echo esc_url( WCMA_URL . 'assets/css/font.css?v=' . WCMA_VERSION ); ?>" />
	<link rel="stylesheet" href="<?php echo esc_url( WCMA_URL . 'assets/css/panel.css?v=' . WCMA_VERSION ); ?>" />

	<style>:root { --wp-color: <?php echo esc_html( $wcma_color ); ?>; }</style>
</head>

<body class="wcma-p wcma-p--<?php echo esc_attr( $wcma_demo ); ?><?php echo $wcma_login ? ' wcma-p--auth' : ''; ?>">

<?php if ( $wcma_login ) : ?>

	<?php require $wcma_view; ?>

<?php else : ?>

	<header class="wp-top">
		<div class="wp-top__brand">
			<span class="wp-logo" aria-hidden="true">
				<?php echo esc_html( mb_substr( (string) get_bloginfo( 'name' ), 0, 1 ) ); ?>
			</span>
			<div class="wp-top__id">
				<strong><?php echo esc_html( $wcma_title ); ?></strong>
				<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			</div>
		</div>

		<div class="wp-top__side">
			<span class="wp-who">
				<span class="wp-who__name"><?php echo esc_html( WCMA_Accounts::display_name( $wcma_user ) ); ?></span>
				<span class="wp-who__phone" dir="ltr"><?php echo esc_html( WCMA_Date::digits( WCMA_Accounts::phone( $wcma_user->ID ) ) ); ?></span>
			</span>

			<a class="wp-out" href="<?php echo esc_url( wp_logout_url( WCMA_Panel::url() ) ); ?>">خروج</a>
		</div>
	</header>

	<div class="wp-shell">
		<nav class="wp-nav" aria-label="منوی پنل">
			<?php foreach ( $wcma_pages as $wcma_key => $wcma_item ) : ?>
				<a
					class="wp-nav__item<?php echo $wcma_key === $wcma_page ? ' is-active' : ''; ?>"
					href="<?php echo esc_url( WCMA_Panel::url( $wcma_key ) ); ?>"
					<?php echo $wcma_key === $wcma_page ? 'aria-current="page"' : ''; ?>
				>
					<?php WCMA_Panel::icon( $wcma_item['icon'] ); ?>
					<span><?php echo esc_html( $wcma_item['title'] ); ?></span>

					<?php if ( 'tickets' === $wcma_key ) : ?>
						<?php $wcma_open = WCMA_Tickets::open_count( $wcma_user->ID ); ?>
						<?php if ( $wcma_open ) : ?>
							<span class="wp-badge"><?php echo esc_html( WCMA_Date::number( $wcma_open ) ); ?></span>
						<?php endif; ?>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</nav>

		<main class="wp-main">
			<?php if ( $wcma_notice ) : ?>
				<div class="wp-note wp-note--<?php echo esc_attr( $wcma_notice['type'] ); ?>">
					<?php echo esc_html( $wcma_notice['text'] ); ?>
				</div>
			<?php endif; ?>

			<?php require $wcma_view; ?>
		</main>
	</div>

	<footer class="wp-foot">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>">بازگشت به فروشگاه</a>
	</footer>

<?php endif; ?>

<script src="<?php echo esc_url( WCMA_URL . 'assets/js/panel.js?v=' . WCMA_VERSION ); ?>"></script>
</body>
</html>
