<?php
/**
 * کیف پول: موجودی، شارژ و دفتر تراکنش‌ها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_id = (int) $wcma_user->ID;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$wcma_page_no = isset( $_GET['p'] ) ? max( 1, (int) $_GET['p'] ) : 1;

$wcma_balance = WCMA_Wallet::balance( $wcma_id );
$wcma_log     = WCMA_Wallet::history( $wcma_id, array( 'page' => $wcma_page_no ) );
$wcma_limits  = WCMA_Wallet::limits();
$wcma_quick   = array( 100000, 200000, 500000, 1000000 );
?>

<h1 class="wp-h1">کیف پول</h1>

<section class="wp-wallet">
	<div class="wp-wallet__balance">
		<?php WCMA_Panel::icon( 'wallet' ); ?>
		<span>موجودی شما</span>
		<strong><?php echo wp_kses_post( WCMA_Date::price( $wcma_balance ) ); ?></strong>
	</div>

	<form class="wp-wallet__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'wcma_panel' ); ?>
		<input type="hidden" name="action" value="wcma_panel" />
		<input type="hidden" name="wcma_do" value="topup" />

		<label class="wp-field">
			<span>مبلغ شارژ (تومان)</span>
			<input
				type="text"
				name="amount"
				id="wcma-amount"
				dir="ltr"
				inputmode="numeric"
				placeholder="<?php echo esc_attr( WCMA_Date::number( $wcma_limits['min'] ) ); ?>"
				required
			/>
		</label>

		<div class="wp-chips">
			<?php foreach ( $wcma_quick as $wcma_amount ) : ?>
				<button type="button" class="wp-chip wp-chip--pick" data-amount="<?php echo esc_attr( $wcma_amount ); ?>">
					<?php echo esc_html( WCMA_Date::number( $wcma_amount ) ); ?>
				</button>
			<?php endforeach; ?>
		</div>

		<button type="submit" class="wp-btn wp-btn--primary">پرداخت و شارژ</button>

		<p class="wp-hint">
			<?php
			printf(
				'کمترین مبلغ %s و بیشترین %s است. پرداخت با همان درگاهی انجام می‌شود که فروشگاه دارد.',
				esc_html( WCMA_Date::price_text( $wcma_limits['min'] ) ),
				esc_html( WCMA_Date::price_text( $wcma_limits['max'] ) )
			);
			?>
		</p>
	</form>
</section>

<section class="wp-card">
	<header class="wp-card__head">
		<h2>تراکنش‌ها</h2>
	</header>

	<?php if ( $wcma_log['items'] ) : ?>
		<div class="wp-list">
			<?php foreach ( $wcma_log['items'] as $wcma_tx ) : ?>
				<?php $wcma_plus = 'credit' === $wcma_tx['kind']; ?>

				<div class="wp-row wp-row--tx">
					<span class="wp-tx__sign <?php echo $wcma_plus ? 'is-plus' : 'is-minus'; ?>" aria-hidden="true">
						<?php echo $wcma_plus ? '+' : '−'; ?>
					</span>

					<div class="wp-row__main">
						<strong><?php echo esc_html( WCMA_Wallet::source_label( $wcma_tx['source'] ) ); ?></strong>
						<span>
							<?php echo esc_html( WCMA_Date::mysql( $wcma_tx['created_at'], 'datetime' ) ); ?>
							<?php if ( $wcma_tx['note'] ) : ?>
								· <?php echo esc_html( $wcma_tx['note'] ); ?>
							<?php endif; ?>
						</span>
					</div>

					<span class="wp-row__price <?php echo $wcma_plus ? 'is-plus' : 'is-minus'; ?>">
						<?php echo wp_kses_post( WCMA_Date::price( abs( (float) $wcma_tx['amount'] ) ) ); ?>
					</span>

					<span class="wp-row__after">
						مانده: <?php echo wp_kses_post( WCMA_Date::price( (float) $wcma_tx['balance'] ) ); ?>
					</span>
				</div>
			<?php endforeach; ?>
		</div>

		<?php if ( $wcma_log['pages'] > 1 ) : ?>
			<div class="wp-pages">
				<?php for ( $wcma_i = 1; $wcma_i <= min( 20, (int) $wcma_log['pages'] ); $wcma_i++ ) : ?>
					<a
						class="<?php echo $wcma_i === (int) $wcma_log['page'] ? 'is-current' : ''; ?>"
						href="<?php echo esc_url( WCMA_Panel::url( 'wallet', array( 'p' => $wcma_i ) ) ); ?>"
					><?php echo esc_html( WCMA_Date::number( $wcma_i ) ); ?></a>
				<?php endfor; ?>
			</div>
		<?php endif; ?>
	<?php else : ?>
		<p class="wp-empty">هنوز تراکنشی ندارید.</p>
	<?php endif; ?>
</section>
