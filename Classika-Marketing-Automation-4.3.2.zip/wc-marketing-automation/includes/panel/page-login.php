<?php
/**
 * ورود و ثبت‌نام با شماره موبایل.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_ready = WCMA_SMS_Gateways::is_ready();
?>

<div class="wp-auth">
	<div class="wp-auth__card">
		<span class="wp-logo wp-logo--big" aria-hidden="true">
			<?php echo esc_html( mb_substr( (string) get_bloginfo( 'name' ), 0, 1 ) ); ?>
		</span>

		<h1><?php echo esc_html( (string) WCMA_Settings::get( 'panel_title', 'پنل کاربری' ) ); ?></h1>
		<p class="wp-auth__sub">برای ورود یا ثبت‌نام، شماره موبایل خود را وارد کنید.</p>

		<?php if ( ! $wcma_ready ) : ?>
			<div class="wp-note wp-note--error">
				پنل پیامک هنوز تنظیم نشده است؛ کد ورود فرستاده نمی‌شود.
			</div>
		<?php endif; ?>

		<form class="wp-form" id="wcma-auth" novalidate>
			<div class="wp-step" data-step="phone">
				<label class="wp-field">
					<span>شماره موبایل</span>
					<input
						type="tel"
						name="phone"
						id="wcma-phone"
						dir="ltr"
						inputmode="numeric"
						autocomplete="tel"
						placeholder="۰۹۱۲۳۴۵۶۷۸۹"
						required
					/>
				</label>

				<button type="submit" class="wp-btn wp-btn--primary" id="wcma-send">دریافت کد</button>
			</div>

			<div class="wp-step" data-step="code" hidden>
				<p class="wp-auth__to">
					کد پنج‌رقمی به شماره‌ی <b id="wcma-to" dir="ltr"></b> پیامک شد.
					<button type="button" class="wp-link" id="wcma-back">تغییر شماره</button>
				</p>

				<div class="wp-newbie" id="wcma-newbie" hidden>
					<label class="wp-field">
						<span>نام</span>
						<input type="text" name="first_name" id="wcma-first" autocomplete="given-name" />
					</label>

					<label class="wp-field">
						<span>نام خانوادگی</span>
						<input type="text" name="last_name" id="wcma-last" autocomplete="family-name" />
					</label>
				</div>

				<label class="wp-field">
					<span>کد پیامک‌شده</span>
					<?php
					/*
					 * autocomplete="one-time-code" همان چیزی است که iOS برای پر
					 * کردن خودکارِ کد می‌خواهد؛ اندروید از راه WebOTP در
					 * panel.js پر می‌شود.
					 */
					?>
					<input
						type="text"
						name="code"
						id="wcma-code"
						dir="ltr"
						inputmode="numeric"
						autocomplete="one-time-code"
						maxlength="5"
						class="wp-code"
						placeholder="- - - - -"
						required
					/>
				</label>

				<button type="submit" class="wp-btn wp-btn--primary" id="wcma-verify">ورود</button>

				<p class="wp-auth__again">
					<button type="button" class="wp-link" id="wcma-again" disabled>ارسال دوباره‌ی کد</button>
					<span id="wcma-timer"></span>
				</p>
			</div>

			<p class="wp-error" id="wcma-error" hidden></p>
		</form>
	</div>

	<a class="wp-auth__home" href="<?php echo esc_url( home_url( '/' ) ); ?>">بازگشت به فروشگاه</a>
</div>

<script>
	window.wcmaPanel = <?php echo wp_json_encode(
		array(
			'root'  => esc_url_raw( rest_url( 'wcma/v1' ) ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
			'panel' => WCMA_Panel::url(),
		)
	); ?>;
</script>
