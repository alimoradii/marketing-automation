<?php
/**
 * اطلاعات کاربر.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_id = (int) $wcma_user->ID;
?>

<h1 class="wp-h1">اطلاعات من</h1>

<form class="wp-card wp-profile" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<?php wp_nonce_field( 'wcma_panel' ); ?>
	<input type="hidden" name="action" value="wcma_panel" />
	<input type="hidden" name="wcma_do" value="profile" />

	<div class="wp-two">
		<label class="wp-field">
			<span>نام</span>
			<input type="text" name="first_name" value="<?php echo esc_attr( $wcma_user->first_name ); ?>" required />
		</label>

		<label class="wp-field">
			<span>نام خانوادگی</span>
			<input type="text" name="last_name" value="<?php echo esc_attr( $wcma_user->last_name ); ?>" />
		</label>
	</div>

	<label class="wp-field">
		<span>ایمیل (اختیاری)</span>
		<input type="email" name="email" dir="ltr" value="<?php echo esc_attr( $wcma_user->user_email ); ?>" />
	</label>

	<label class="wp-field wp-field--locked">
		<span>شماره موبایل</span>
		<input type="tel" dir="ltr" value="<?php echo esc_attr( WCMA_Date::digits( WCMA_Accounts::phone( $wcma_id ) ) ); ?>" readonly />
		<small>شماره‌ی ورود شماست و از اینجا عوض نمی‌شود؛ برای تغییرش با پشتیبانی تماس بگیرید.</small>
	</label>

	<button type="submit" class="wp-btn wp-btn--primary">ذخیره‌ی اطلاعات</button>
</form>

<section class="wp-card">
	<header class="wp-card__head">
		<h2>حساب شما</h2>
	</header>

	<div class="wp-facts">
		<div>
			<span>تاریخ عضویت</span>
			<strong><?php echo esc_html( WCMA_Date::mysql( $wcma_user->user_registered, 'date' ) ); ?></strong>
		</div>

		<div>
			<span>نام کاربری</span>
			<strong dir="ltr"><?php echo esc_html( WCMA_Date::digits( $wcma_user->user_login ) ); ?></strong>
		</div>
	</div>

	<p class="wp-hint">
		ورود شما با کد پیامکی انجام می‌شود، پس رمزی برای به‌خاطر سپردن ندارید.
	</p>
</section>
