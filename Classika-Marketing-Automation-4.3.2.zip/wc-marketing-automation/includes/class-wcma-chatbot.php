<?php
/**
 * چت‌بات فروشگاه: پاسخ خودکار بر پایه‌ی قاعده و هوش مصنوعی، به‌همراه پاسخ دستی اپراتور.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Chatbot
 */
class WCMA_Chatbot {

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_bot_message', array( __CLASS__, 'handle_message' ), 10, 2 );
	}

	/**
	 * جدول گفتگوها.
	 *
	 * @return string
	 */
	public static function chats_table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_chats';
	}

	/**
	 * جدول پیام‌ها.
	 *
	 * @return string
	 */
	public static function messages_table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_chat_messages';
	}

	/**
	 * حالت‌های گفتگو.
	 *
	 * @return array
	 */
	/**
	 * نام نمایشی کانال یک گفتگو.
	 *
	 * @param string $channel کانال.
	 * @return string
	 */
	public static function channel_label( $channel ) {
		if ( WCMA_LiveChat::CHANNEL === $channel ) {
			return 'چت سایت';
		}

		return WCMA_Messengers::label( $channel );
	}

	public static function modes() {
		return array(
			'bot'   => 'پاسخ خودکار ربات',
			'human' => 'در دست اپراتور',
		);
	}

	/**
	 * روش‌های تطبیق در قاعده‌ها.
	 *
	 * @return array
	 */
	public static function match_types() {
		return array(
			'contains' => 'شامل این عبارت باشد',
			'equals'   => 'دقیقاً برابر باشد',
			'starts'   => 'با این عبارت شروع شود',
			'any'      => 'هر پیامی (پاسخ پیش‌فرض)',
		);
	}

	/**
	 * مهارت‌های آماده‌ی ربات.
	 *
	 * @return array
	 */
	public static function skills() {
		return array(
			'order_status' => array(
				'label'    => 'پیگیری سفارش',
				'desc'     => 'اگر مشتری شماره‌ی سفارش بفرستد یا بنویسد «سفارش من»، وضعیت سفارش‌هایش را می‌گوید.',
				'keywords' => 'سفارش، پیگیری، مرسوله، ارسال شد، کد رهگیری',
			),
			'product'      => array(
				'label'    => 'جستجوی محصول و قیمت',
				'desc'     => 'نام محصول را می‌گیرد و قیمت، موجودی و لینک آن را می‌فرستد.',
				'keywords' => 'قیمت، موجود، محصول، دارید',
			),
			'hours'        => array(
				'label'    => 'ساعت کاری و راه تماس',
				'desc'     => 'ساعت کاری، تلفن و آدرس فروشگاه را پاسخ می‌دهد.',
				'keywords' => 'ساعت کاری، تماس، تلفن، آدرس، کجایید',
			),
			'operator'     => array(
				'label'    => 'ارجاع به اپراتور',
				'desc'     => 'گفتگو را به حالت دستی می‌برد تا اپراتور پاسخ دهد و به مدیر خبر می‌دهد.',
				'keywords' => 'اپراتور، پشتیبانی، انسان، کارشناس',
			),
		);
	}

	/**
	 * قاعده‌های دلخواه مدیر.
	 *
	 * @return array
	 */
	public static function rules() {
		$rules = WCMA_Settings::get( 'chat_rules', array() );

		if ( is_string( $rules ) ) {
			$rules = json_decode( $rules, true );
		}

		return is_array( $rules ) ? $rules : array();
	}

	/**
	 * آیا مهارت فعال است؟
	 *
	 * @param string $key مهارت.
	 * @return bool
	 */
	public static function skill_enabled( $key ) {
		$enabled = (array) WCMA_Settings::get( 'chat_skills', array( 'order_status', 'product', 'hours', 'operator' ) );

		return in_array( $key, $enabled, true );
	}

	/**
	 * دریافت پیام تازه از پیام‌رسان.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده‌ی استخراج‌شده.
	 */
	public static function handle_message( $messenger, array $parsed ) {
		if ( ! WCMA_Settings::is( 'chat_enabled' ) ) {
			return;
		}

		/**
		 * اگر بخش دیگری (مثل منوی ربات) پیام را پاسخ داده، ربات ساکت می‌ماند.
		 *
		 * @param bool $skip رد شدن.
		 */
		if ( apply_filters( 'wcma_chatbot_skip', false ) ) {
			return;
		}

		$text = trim( (string) ( $parsed['text'] ?? '' ) );

		if ( '' === $text ) {
			return;
		}

		$chat = self::touch_chat( $messenger, $parsed );

		if ( ! $chat ) {
			return;
		}

		self::log_message( (int) $chat['id'], 'in', 'customer', $text );

		// وقتی اپراتور گفتگو را در دست گرفته، ربات ساکت می‌ماند.
		if ( 'human' === $chat['mode'] ) {
			WCMA_Bot_Reply::later( array( __CLASS__, 'notify_operator' ), array( $chat, $text ) );

			return;
		}

		$reply = self::answer( $text, $chat );

		if ( ! $reply || empty( $reply['text'] ) ) {
			return;
		}

		if ( ! empty( $reply['handover'] ) ) {
			self::set_mode( (int) $chat['id'], 'human' );

			// پیامک اپراتور پس از رسیدن پاسخ به مشتری.
			WCMA_Bot_Reply::later( array( __CLASS__, 'notify_operator' ), array( $chat, $text ) );
		}

		self::send( (int) $chat['id'], $reply['text'], 'bot', $reply['rule'] ?? '' );
	}

	/**
	 * پاسخ ربات به یک متن.
	 *
	 * ترتیب: قاعده‌های مدیر ← مهارت‌های آماده ← هوش مصنوعی ← پاسخ پیش‌فرض.
	 *
	 * @param string $text متن مشتری.
	 * @param array  $chat گفتگو.
	 * @return array{text:string,rule:string,handover:bool}
	 */
	public static function answer( $text, array $chat = array() ) {
		$text  = trim( $text );
		$plain = self::normalize( $text );

		// ۱) قاعده‌های دلخواه مدیر بالاترین اولویت را دارند.
		foreach ( self::rules() as $index => $rule ) {
			if ( empty( $rule['reply'] ) || empty( $rule['enabled'] ) ) {
				continue;
			}

			if ( self::rule_matches( $rule, $plain ) ) {
				return array(
					'text'     => self::personalize( $rule['reply'], $chat ),
					'rule'     => 'قاعده ' . WCMA_Date::number( (int) $index + 1 ),
					'handover' => ! empty( $rule['handover'] ),
				);
			}
		}

		// ۲) مهارت‌های آماده.
		if ( self::skill_enabled( 'operator' ) && self::has_keyword( $plain, self::skills()['operator']['keywords'] ) ) {
			return array(
				'text'     => WCMA_Settings::get( 'chat_handover_text', 'درخواست شما برای گفتگو با کارشناس ثبت شد. لطفاً چند لحظه صبر کنید؛ همکاران ما همین‌جا پاسخ می‌دهند.' ),
				'rule'     => 'ارجاع به اپراتور',
				'handover' => true,
			);
		}

		if ( self::skill_enabled( 'order_status' ) ) {
			$answer = self::answer_order( $plain, $chat );

			if ( $answer ) {
				return array(
					'text'     => $answer,
					'rule'     => 'پیگیری سفارش',
					'handover' => false,
				);
			}
		}

		if ( self::skill_enabled( 'hours' ) && self::has_keyword( $plain, self::skills()['hours']['keywords'] ) ) {
			return array(
				'text'     => self::shop_info_text(),
				'rule'     => 'ساعت کاری',
				'handover' => false,
			);
		}

		if ( self::skill_enabled( 'product' ) ) {
			$answer = self::answer_product( $text, $plain );

			if ( $answer ) {
				return array(
					'text'     => $answer,
					'rule'     => 'جستجوی محصول',
					'handover' => false,
				);
			}
		}

		// ۳) هوش مصنوعی، اگر مدیر اجازه داده باشد.
		if ( WCMA_Settings::is( 'chat_ai_enabled' ) && WCMA_AI::is_ready() ) {
			$ai = self::answer_ai( $text, $chat );

			if ( $ai ) {
				return array(
					'text'     => $ai,
					'rule'     => 'هوش مصنوعی',
					'handover' => false,
				);
			}
		}

		// ۴) پاسخ پیش‌فرض.
		$fallback = WCMA_Settings::get( 'chat_fallback_text', '' );

		if ( ! $fallback ) {
			return array( 'text' => '', 'rule' => '', 'handover' => false );
		}

		return array(
			'text'     => self::personalize( $fallback, $chat ),
			'rule'     => 'پاسخ پیش‌فرض',
			'handover' => (bool) WCMA_Settings::is( 'chat_fallback_handover' ),
		);
	}

	/**
	 * آیا قاعده با متن می‌خواند؟
	 *
	 * @param array  $rule  قاعده.
	 * @param string $plain متن ساده‌شده.
	 * @return bool
	 */
	protected static function rule_matches( array $rule, $plain ) {
		$type = $rule['match'] ?? 'contains';

		if ( 'any' === $type ) {
			return true;
		}

		$keywords = self::keyword_list( $rule['keywords'] ?? '' );

		foreach ( $keywords as $keyword ) {
			$keyword = self::normalize( $keyword );

			if ( '' === $keyword ) {
				continue;
			}

			if ( 'equals' === $type && $plain === $keyword ) {
				return true;
			}

			if ( 'starts' === $type && 0 === strpos( $plain, $keyword ) ) {
				return true;
			}

			if ( 'contains' === $type && false !== strpos( $plain, $keyword ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * تبدیل رشته‌ی کلیدواژه‌ها به آرایه.
	 *
	 * @param string $keywords کلیدواژه‌ها.
	 * @return array
	 */
	public static function keyword_list( $keywords ) {
		$parts = preg_split( '/[،,\n]+/u', (string) $keywords );

		return array_values( array_filter( array_map( 'trim', (array) $parts ) ) );
	}

	/**
	 * آیا متن یکی از کلیدواژه‌ها را دارد؟
	 *
	 * @param string $plain    متن ساده‌شده.
	 * @param string $keywords کلیدواژه‌ها.
	 * @return bool
	 */
	protected static function has_keyword( $plain, $keywords ) {
		foreach ( self::keyword_list( $keywords ) as $keyword ) {
			$keyword = self::normalize( $keyword );

			if ( '' !== $keyword && false !== strpos( $plain, $keyword ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * ساده‌سازی متن برای تطبیق: ارقام لاتین، «ی» و «ک» یکدست، بدون نشانه‌گذاری.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	public static function normalize( $text ) {
		$text = WCMA_Date::to_latin_digits( (string) $text );
		$text = str_replace( array( 'ي', 'ك', 'ۀ', 'أ', 'إ', 'ٔ' ), array( 'ی', 'ک', 'ه', 'ا', 'ا', '' ), $text );
		$text = preg_replace( '/[\x{200c}\x{200f}\x{200e}]/u', ' ', $text );
		$text = preg_replace( '/[.,،!?؟:;()\[\]«»"\']/u', ' ', $text );
		$text = preg_replace( '/\s+/u', ' ', $text );

		return trim( mb_strtolower( (string) $text ) );
	}

	/**
	 * پاسخ درباره‌ی سفارش.
	 *
	 * @param string $plain متن.
	 * @param array  $chat  گفتگو.
	 * @return string
	 */
	protected static function answer_order( $plain, array $chat ) {
		$has_keyword = self::has_keyword( $plain, self::skills()['order_status']['keywords'] );

		// شماره‌ی سفارش در متن.
		$number = '';

		if ( preg_match( '/\b(\d{3,10})\b/', $plain, $m ) ) {
			$number = $m[1];
		}

		if ( ! $has_keyword && ! $number ) {
			return '';
		}

		if ( $number && function_exists( 'wc_get_order' ) ) {
			$order = wc_get_order( (int) $number );

			if ( $order instanceof WC_Order && self::owns_order( $order, $chat ) ) {
				return self::order_text( $order );
			}
		}

		// بدون شماره: آخرین سفارش‌های همین مشتری.
		$orders = self::orders_for_chat( $chat );

		if ( $orders ) {
			$lines = array( 'سفارش‌های اخیر شما:' );

			foreach ( $orders as $order ) {
				$lines[] = '• ' . self::order_line( $order );
			}

			return implode( "\n", $lines );
		}

		if ( ! $has_keyword ) {
			return '';
		}

		if ( empty( $chat['user_id'] ) && empty( $chat['phone'] ) ) {
			return 'برای پیگیری سفارش، لطفاً شماره‌ی موبایلی را که با آن خرید کرده‌اید بفرستید یا شماره‌ی سفارش را بنویسید.';
		}

		return 'سفارش فعالی برای شما پیدا نکردم. اگر شماره‌ی سفارش را بفرستید، دقیق‌تر بررسی می‌کنم.';
	}

	/**
	 * آیا این سفارش متعلق به همین مشتری است؟
	 *
	 * @param WC_Order $order سفارش.
	 * @param array    $chat  گفتگو.
	 * @return bool
	 */
	protected static function owns_order( $order, array $chat ) {
		$user_id = (int) ( $chat['user_id'] ?? 0 );

		if ( $user_id && (int) $order->get_customer_id() === $user_id ) {
			return true;
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( (string) ( $chat['phone'] ?? '' ) );

		if ( $phone && WCMA_SMS_Gateways::normalize_phone( (string) $order->get_billing_phone() ) === $phone ) {
			return true;
		}

		return false;
	}

	/**
	 * سفارش‌های مشتری این گفتگو.
	 *
	 * @param array $chat گفتگو.
	 * @return array
	 */
	protected static function orders_for_chat( array $chat ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$args = array(
			'limit'   => 3,
			'orderby' => 'date',
			'order'   => 'DESC',
		);

		if ( ! empty( $chat['user_id'] ) ) {
			$args['customer_id'] = (int) $chat['user_id'];
		} elseif ( ! empty( $chat['phone'] ) ) {
			$args['billing_phone'] = $chat['phone'];
		} else {
			return array();
		}

		$orders = wc_get_orders( $args );

		return is_array( $orders ) ? $orders : array();
	}

	/**
	 * یک خط خلاصه از سفارش.
	 *
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	protected static function order_line( $order ) {
		return sprintf(
			'سفارش #%s — %s — %s',
			WCMA_Date::digits( $order->get_order_number() ),
			wc_get_order_status_name( $order->get_status() ),
			WCMA_Date::mysql( $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '', 'date', '' )
		);
	}

	/**
	 * متن کامل وضعیت یک سفارش.
	 *
	 * @param WC_Order $order سفارش.
	 * @return string
	 */
	protected static function order_text( $order ) {
		$lines = array(
			sprintf( 'سفارش #%s', WCMA_Date::digits( $order->get_order_number() ) ),
			sprintf( 'وضعیت: %s', wc_get_order_status_name( $order->get_status() ) ),
			sprintf( 'مبلغ: %s', WCMA_Date::plain_price( $order->get_formatted_order_total() ) ),
		);

		$date = $order->get_date_created();

		if ( $date ) {
			$lines[] = 'تاریخ ثبت: ' . WCMA_Date::format( $date->getTimestamp(), 'date_long' );
		}

		$items = array();

		foreach ( $order->get_items() as $item ) {
			$items[] = $item->get_name() . ' ×' . WCMA_Date::number( $item->get_quantity() );
		}

		if ( $items ) {
			$lines[] = 'اقلام: ' . implode( '، ', array_slice( $items, 0, 5 ) );
		}

		return implode( "\n", $lines );
	}

	/**
	 * پاسخ درباره‌ی محصول.
	 *
	 * @param string $text  متن اصلی.
	 * @param string $plain متن ساده‌شده.
	 * @return string
	 */
	protected static function answer_product( $text, $plain ) {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return '';
		}

		$term = self::product_term( $text, $plain );

		if ( mb_strlen( $term ) < 3 ) {
			return '';
		}

		$products = wc_get_products(
			array(
				'limit'  => 3,
				'status' => 'publish',
				's'      => $term,
			)
		);

		if ( ! $products ) {
			return '';
		}

		$lines = array( 'این‌ها را پیدا کردم:' );

		foreach ( $products as $product ) {
			if ( ! $product instanceof WC_Product ) {
				continue;
			}

			$lines[] = sprintf(
				"• %s — %s — %s\n%s",
				$product->get_name(),
				WCMA_Date::plain_price( $product->get_price_html() ),
				$product->is_in_stock() ? 'موجود' : 'ناموجود',
				get_permalink( $product->get_id() )
			);
		}

		return count( $lines ) > 1 ? implode( "\n", $lines ) : '';
	}

	/**
	 * حدس نام محصول از متن مشتری.
	 *
	 * @param string $text  متن.
	 * @param string $plain متن ساده‌شده.
	 * @return string
	 */
	protected static function product_term( $text, $plain ) {
		$stop = array( 'قیمت', 'موجود', 'هست', 'دارید', 'داری', 'چند', 'است', 'چنده', 'میخوام', 'می‌خواهم', 'سلام', 'لطفا', 'لطفاً', 'محصول', 'خرید', 'را', 'رو', 'با', 'از', 'برای', 'یه', 'یک' );
		$words = preg_split( '/\s+/u', $plain );
		$words = array_diff( (array) $words, $stop );

		return trim( implode( ' ', $words ) );
	}

	/**
	 * اطلاعات تماس فروشگاه.
	 *
	 * @return string
	 */
	protected static function shop_info_text() {
		$custom = WCMA_Settings::get( 'chat_hours_text', '' );

		if ( $custom ) {
			return $custom;
		}

		$lines = array( get_bloginfo( 'name' ) );
		$phone = WCMA_Settings::get( 'shop_phone', '' );

		if ( $phone ) {
			$lines[] = 'تلفن: ' . WCMA_Date::digits( $phone );
		}

		$lines[] = 'وب‌سایت: ' . home_url();

		return implode( "\n", $lines );
	}

	/**
	 * پاسخ با هوش مصنوعی.
	 *
	 * @param string $text متن مشتری.
	 * @param array  $chat گفتگو.
	 * @return string
	 */
	protected static function answer_ai( $text, array $chat ) {
		$history = self::recent_messages( (int) ( $chat['id'] ?? 0 ), 6 );
		$lines   = array();

		foreach ( array_reverse( $history ) as $row ) {
			$who     = 'in' === $row['direction'] ? 'مشتری' : 'فروشگاه';
			$lines[] = $who . ': ' . $row['body'];
		}

		$brief = 'این گفتگوی پشتیبانی فروشگاه است. کوتاه (حداکثر ۳ جمله)، محترمانه و دقیق پاسخ بده. '
			. 'اگر پاسخ را نمی‌دانی یا به اطلاعات حساب مشتری نیاز است، بگو که به کارشناس وصل می‌شوی و چیزی از خودت نساز.';

		if ( $lines ) {
			$brief .= "\n\nپیام‌های قبلی:\n" . implode( "\n", $lines );
		}

		$brief .= "\n\nپیام تازه‌ی مشتری: " . $text;

		$result = WCMA_AI::generate( 'chat_reply', array( 'brief' => $brief, 'channel' => 'sms' ) );

		if ( empty( $result['success'] ) ) {
			return '';
		}

		return trim( wp_strip_all_tags( $result['content'] ) );
	}

	/**
	 * جایگذاری نام مشتری در متن پاسخ.
	 *
	 * @param string $text متن.
	 * @param array  $chat گفتگو.
	 * @return string
	 */
	protected static function personalize( $text, array $chat ) {
		$name = trim( (string) ( $chat['name'] ?? '' ) );

		return WCMA_Placeholders::replace(
			$text,
			array(
				'user' => ! empty( $chat['user_id'] ) ? get_userdata( (int) $chat['user_id'] ) : null,
				'vars' => array( '{first_name}' => $name ),
			)
		);
	}

	/**
	 * ساخت یا به‌روزرسانی گفتگو.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده.
	 * @return array|null
	 */
	public static function touch_chat( $messenger, array $parsed ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return null;
		}

		$chat_id = (string) ( $parsed['chat_id'] ?? '' );

		if ( '' === $chat_id ) {
			return null;
		}

		$table = self::chats_table();
		$now   = current_time( 'mysql' );

		$chat = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s", $messenger, $chat_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		$user_id = (int) WCMA_Bot_Link::user_for_chat( $messenger, $chat_id );
		$phone   = WCMA_SMS_Gateways::normalize_phone( (string) ( $parsed['phone'] ?? '' ) );
		$name    = sanitize_text_field( (string) ( $parsed['name'] ?? '' ) );
		$text    = (string) ( $parsed['text'] ?? '' );

		if ( ! $chat ) {
			$wpdb->insert( // phpcs:ignore WordPress.DB
				$table,
				array(
					'channel'         => $messenger,
					'chat_id'         => $chat_id,
					'user_id'         => $user_id,
					'name'            => $name,
					'username'        => sanitize_text_field( (string) ( $parsed['username'] ?? '' ) ),
					'phone'           => $phone,
					'mode'            => 'bot',
					'status'          => 'open',
					'unread'          => 1,
					'message_count'   => 0,
					'last_message'    => mb_substr( $text, 0, 300 ),
					'last_message_at' => $now,
					'created_at'      => $now,
				)
			);

			$chat = $wpdb->get_row( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $wpdb->insert_id ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);
		} else {
			$update = array(
				'unread'          => (int) $chat['unread'] + 1,
				'status'          => 'open',
				'last_message'    => mb_substr( $text, 0, 300 ),
				'last_message_at' => $now,
			);

			if ( $user_id ) {
				$update['user_id'] = $user_id;
			}

			if ( $phone ) {
				$update['phone'] = $phone;
			}

			if ( $name ) {
				$update['name'] = $name;
			}

			$wpdb->update( $table, $update, array( 'id' => (int) $chat['id'] ) ); // phpcs:ignore WordPress.DB

			$chat = array_merge( $chat, $update );
		}

		if ( $chat ) {
			$chat['contact_id'] = self::link_contact( $chat );
		}

		return $chat;
	}

	/**
	 * ساخت یا اتصال پرونده‌ی CRM برای گفتگو.
	 *
	 * @param array $chat گفتگو.
	 * @return int
	 */
	public static function link_contact( array $chat ) {
		global $wpdb;

		if ( ! empty( $chat['contact_id'] ) ) {
			return (int) $chat['contact_id'];
		}

		if ( ! WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			return 0;
		}

		$email = sanitize_email( (string) ( $chat['email'] ?? '' ) );
		$phone = (string) ( $chat['phone'] ?? '' );
		$user  = ! empty( $chat['user_id'] ) ? get_userdata( (int) $chat['user_id'] ) : null;

		if ( $user ) {
			$email = $email ? $email : $user->user_email;

			if ( ! $phone ) {
				$phone = (string) get_user_meta( $user->ID, 'billing_phone', true );
			}
		}

		if ( ! $email && ! $phone ) {
			return 0;
		}

		$contact_id = WCMA_CRM::upsert(
			array(
				'email'           => $email,
				'phone'           => $phone,
				'user_id'         => $user ? $user->ID : 0,
				'first_name'      => $user ? $user->first_name : (string) ( $chat['name'] ?? '' ),
				'last_name'       => $user ? $user->last_name : '',
				'source'          => 'chat',
				'last_contact_at' => current_time( 'mysql' ),
			)
		);

		if ( $contact_id ) {
			$wpdb->update( self::chats_table(), array( 'contact_id' => $contact_id ), array( 'id' => (int) $chat['id'] ) ); // phpcs:ignore WordPress.DB
		}

		return (int) $contact_id;
	}

	/**
	 * بررسی اینکه پیامِ ارجاع‌شده واقعاً در همین گفتگو هست.
	 *
	 * بدون این بررسی، هر کسی می‌توانست شناسه‌ی پیام گفتگوی دیگری را بفرستد و
	 * متن آن را در نقل‌قول ببیند.
	 *
	 * @param int $chat_id  گفتگو.
	 * @param int $reply_to شناسه‌ی پیام.
	 * @return int شناسه‌ی معتبر، یا صفر.
	 */
	public static function valid_reply( $chat_id, $reply_to ) {
		global $wpdb;

		$reply_to = (int) $reply_to;
		$chat_id  = (int) $chat_id;

		if ( $reply_to <= 0 || ! $chat_id || ! WCMA_Install::table_exists( 'wcma_chat_messages' ) ) {
			return 0;
		}

		$table = self::messages_table();

		$found = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id FROM {$table} WHERE id = %d AND chat_id = %d", $reply_to, $chat_id ) // phpcs:ignore WordPress.DB
		);

		return $found;
	}

	/**
	 * متن کوتاه پیام‌هایی که به آن‌ها پاسخ داده شده.
	 *
	 * یک پرس‌وجو برای همه‌ی ارجاع‌ها گرفته می‌شود، نه یکی برای هر پیام.
	 *
	 * @param array $ids شناسه‌ها.
	 * @return array شناسه => {text, side}
	 */
	public static function quotes( array $ids ) {
		global $wpdb;

		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );

		if ( ! $ids || ! WCMA_Install::table_exists( 'wcma_chat_messages' ) ) {
			return array();
		}

		$table  = self::messages_table();
		$holder = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id, body, direction, att_kind FROM {$table} WHERE id IN ({$holder})", $ids ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$out[ (int) $row['id'] ] = array(
				'text' => mb_substr( wp_strip_all_tags( (string) $row['body'] ), 0, 120 ),
				'kind' => (string) $row['att_kind'],
				// «in» یعنی پیام بازدیدکننده؛ هر طرف رنگ نقل‌قول خودش را دارد.
				'side' => 'in' === $row['direction'] ? 'visitor' : 'agent',
			);
		}

		return $out;
	}

	/**
	 * ثبت یک پیام در تاریخچه.
	 *
	 * @param int    $chat_id   گفتگو.
	 * @param string $direction in یا out.
	 * @param string $sender    customer، bot یا human.
	 * @param string $body      متن.
	 * @param string $rule      قاعده‌ی پاسخ‌دهنده.
	 * @param string $status    وضعیت.
	 * @param array  $file      پیوست، خروجی WCMA_Chat_Files::store().
	 * @param int    $reply_to  شناسه‌ی پیامی که این یکی پاسخ آن است.
	 * @return int
	 */
	public static function log_message( $chat_id, $direction, $sender, $body, $rule = '', $status = 'sent', $file = array(), $reply_to = 0 ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chat_messages' ) ) {
			return 0;
		}

		$now = current_time( 'mysql' );

		$row = array(
			'chat_id'    => (int) $chat_id,
			'direction'  => $direction,
			'sender'     => $sender,
			'author_id'  => 'human' === $sender ? get_current_user_id() : 0,
			'rule'       => $rule,
			'body'       => $body,
			'status'     => $status,
			'created_at' => $now,
		);

		// فقط پاسخ به پیامی از همین گفتگو پذیرفته می‌شود.
		$reply_to = self::valid_reply( $chat_id, $reply_to );

		if ( $reply_to ) {
			$row['reply_to'] = $reply_to;
		}

		if ( is_array( $file ) && ! empty( $file['file'] ) ) {
			$row['att_file'] = (string) $file['file'];
			$row['att_name'] = (string) ( $file['name'] ?? '' );
			$row['att_kind'] = (string) ( $file['kind'] ?? '' );
			$row['att_mime'] = (string) ( $file['mime'] ?? '' );
			$row['att_size'] = (int) ( $file['size'] ?? 0 );
			$row['att_ms']   = (int) ( $file['ms'] ?? 0 );
		}

		$wpdb->insert( self::messages_table(), $row ); // phpcs:ignore WordPress.DB

		$table = self::chats_table();

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET message_count = message_count + 1, last_message = %s, last_message_at = %s WHERE id = %d", // phpcs:ignore WordPress.DB
				mb_substr( (string) $body, 0, 300 ),
				$now,
				(int) $chat_id
			)
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * ارسال پیام به مشتری در همان پیام‌رسان.
	 *
	 * @param int    $chat_id گفتگو.
	 * @param string $text    متن.
	 * @param string $sender  bot یا human.
	 * @param string $rule    قاعده.
	 * @return array{success:bool,message:string}
	 */
	/**
	 * ارسال فایل یا پیام صوتی از سوی اپراتور.
	 *
	 * چت آنلاین سایت مقصد بیرونی ندارد و فقط ثبت می‌شود؛ پیام‌رسان‌ها فایل را
	 * با نشانی می‌گیرند، پس همان نشانی عمومی فرستاده می‌شود.
	 *
	 * @param int    $chat_id گفتگو.
	 * @param array  $file    خروجی WCMA_Chat_Files::store().
	 * @param string $caption متن همراه.
	 * @return array{success:bool,message:string}
	 */
	public static function send_file( $chat_id, array $file, $caption = '', $reply_to = 0 ) {
		global $wpdb;

		if ( empty( $file['file'] ) ) {
			return array( 'success' => false, 'message' => 'فایلی برای ارسال نیست.' );
		}

		$table = self::chats_table();

		$chat = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $chat_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( ! $chat ) {
			return array( 'success' => false, 'message' => 'گفتگو پیدا نشد.' );
		}

		$caption = trim( (string) $caption );
		$label   = $caption ? $caption : ( 'audio' === ( $file['kind'] ?? '' ) ? WCMA_Chat_Files::VOICE_LABEL : (string) ( $file['name'] ?? 'فایل' ) );

		if ( WCMA_LiveChat::CHANNEL === $chat['channel'] ) {
			$result = array( 'success' => true, 'message' => 'فایل برای بازدیدکننده ارسال شد.' );
		} else {
			$map = array(
				'image' => 'photo',
				'video' => 'video',
				'audio' => 'voice',
				'doc'   => 'document',
				'zip'   => 'document',
			);

			$result = WCMA_Messengers::send_content(
				$chat['channel'],
				$chat['chat_id'],
				array(
					'type' => $map[ $file['kind'] ?? '' ] ?? 'document',
					'text' => $caption,
					'file' => (string) ( $file['url'] ?? '' ),
				)
			);
		}

		$ok = ! empty( $result['success'] );

		self::log_message( (int) $chat['id'], 'out', 'human', $label, '', $ok ? 'sent' : 'failed', $file, $reply_to );

		if ( $ok ) {
			$wpdb->update( // phpcs:ignore WordPress.DB
				$table,
				array( 'unread' => 0, 'handled_by' => get_current_user_id() ),
				array( 'id' => (int) $chat['id'] )
			);
		}

		return array(
			'success' => $ok,
			'message' => $ok ? 'فایل ارسال شد.' : ( $result['message'] ?? 'ارسال ناموفق بود.' ),
		);
	}

	public static function send( $chat_id, $text, $sender = 'human', $rule = '', $reply_to = 0 ) {
		global $wpdb;

		$table = self::chats_table();

		$chat = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $chat_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( ! $chat ) {
			return array( 'success' => false, 'message' => 'گفتگو پیدا نشد.' );
		}

		$text = trim( (string) $text );

		if ( '' === $text ) {
			return array( 'success' => false, 'message' => 'متن پیام خالی است.' );
		}

		if ( WCMA_LiveChat::CHANNEL === $chat['channel'] ) {
			// چت آنلاین سایت مقصد بیرونی ندارد؛ پیام ذخیره می‌شود و ویجت آن را می‌گیرد.
			$result = array( 'success' => true, 'message' => 'پیام برای بازدیدکننده ارسال شد.' );
		} else {
			$result = WCMA_Messengers::send( $chat['channel'], $chat['chat_id'], $text );
		}

		$ok = ! empty( $result['success'] );

		self::log_message( (int) $chat['id'], 'out', $sender, $text, $rule, $ok ? 'sent' : 'failed', array(), $reply_to );

		if ( $ok && 'human' === $sender ) {
			$wpdb->update( // phpcs:ignore WordPress.DB
				$table,
				array(
					'unread'     => 0,
					'handled_by' => get_current_user_id(),
				),
				array( 'id' => (int) $chat['id'] )
			);

			if ( ! empty( $chat['contact_id'] ) ) {
				WCMA_CRM::add_note( (int) $chat['contact_id'], $text, 'message' );
			}
		}

		return array(
			'success' => $ok,
			'message' => $ok ? 'پیام ارسال شد.' : ( $result['message'] ?? 'ارسال ناموفق بود.' ),
		);
	}

	/**
	 * تغییر حالت گفتگو بین ربات و اپراتور.
	 *
	 * @param int    $chat_id گفتگو.
	 * @param string $mode    حالت.
	 * @return bool
	 */
	public static function set_mode( $chat_id, $mode ) {
		global $wpdb;

		$modes = self::modes();

		if ( ! isset( $modes[ $mode ] ) ) {
			return false;
		}

		return (bool) $wpdb->update( // phpcs:ignore WordPress.DB
			self::chats_table(),
			array(
				'mode'       => $mode,
				'handled_by' => 'human' === $mode ? get_current_user_id() : 0,
			),
			array( 'id' => (int) $chat_id )
		);
	}

	/**
	 * بستن یا بازکردن گفتگو.
	 *
	 * @param int    $chat_id گفتگو.
	 * @param string $status  وضعیت.
	 * @return bool
	 */
	public static function set_status( $chat_id, $status ) {
		global $wpdb;

		$status = in_array( $status, array( 'open', 'closed' ), true ) ? $status : 'open';

		return (bool) $wpdb->update( // phpcs:ignore WordPress.DB
			self::chats_table(),
			array( 'status' => $status, 'unread' => 0 ),
			array( 'id' => (int) $chat_id )
		);
	}

	/**
	 * خبر دادن به اپراتور که گفتگویی منتظر پاسخ است.
	 *
	 * @param array  $chat گفتگو.
	 * @param string $text متن مشتری.
	 */
	public static function notify_operator( array $chat, $text ) {
		$phone = WCMA_Settings::get( 'chat_notify_phone', '' );

		if ( ! $phone ) {
			return;
		}

		// بیش از یک بار در ۱۵ دقیقه برای یک گفتگو پیام نمی‌دهیم.
		$key = 'wcma_chat_notify_' . (int) $chat['id'];

		if ( get_transient( $key ) ) {
			return;
		}

		set_transient( $key, 1, 15 * MINUTE_IN_SECONDS );

		// پیش‌تر کلیدها to و message بود و فرستنده phone و text می‌خواست؛ پیامک هرگز نمی‌رفت.
		WCMA_Sender::send(
			array(
				'channel'     => 'sms',
				'phone'       => $phone,
				'text'        => sprintf(
					'گفتگوی تازه در %s منتظر پاسخ است: %s',
					WCMA_Messengers::label( $chat['channel'] ),
					mb_substr( $text, 0, 80 )
				),
				'workflow'    => 'chatbot',
				'step'        => 'operator',
				'object_type' => 'chat',
				'object_id'   => (int) $chat['id'],
				'skip_optout' => true,
			)
		);
	}

	/**
	 * پیام‌های اخیر یک گفتگو.
	 *
	 * @param int $chat_id گفتگو.
	 * @param int $limit   سقف.
	 * @return array
	 */
	public static function recent_messages( $chat_id, $limit = 50 ) {
		global $wpdb;

		if ( ! $chat_id || ! WCMA_Install::table_exists( 'wcma_chat_messages' ) ) {
			return array();
		}

		$table = self::messages_table();

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE chat_id = %d ORDER BY id DESC LIMIT %d", (int) $chat_id, (int) $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $rows ? $rows : array();
	}

	/**
	 * فهرست گفتگوها.
	 *
	 * @param array $args فیلترها.
	 * @return array
	 */
	public static function chats( array $args = array() ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$args = wp_parse_args(
			$args,
			array(
				'status'   => 'open',
				'mode'     => '',
				'channel'  => '',
				'search'   => '',
				'per_page' => 50,
				'page'     => 1,
			)
		);

		$table  = self::chats_table();
		$where  = array( '1=1' );
		$params = array();

		if ( $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}

		if ( $args['mode'] ) {
			$where[]  = 'mode = %s';
			$params[] = $args['mode'];
		}

		if ( $args['channel'] ) {
			$where[]  = 'channel = %s';
			$params[] = $args['channel'];
		}

		if ( $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(name LIKE %s OR phone LIKE %s OR last_message LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$clause   = implode( ' AND ', $where );
		$per_page = max( 5, min( 200, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );

		// شمار کل باید با همان فیلترها سنجیده شود، نه کل جدول؛ وگرنه
		// شماره‌ی صفحه‌ها با چیزی که روی صفحه است نمی‌خواند.
		$found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$clause}", $params ) ); // phpcs:ignore WordPress.DB

		$params[] = $per_page;
		$params[] = ( $page - 1 ) * $per_page;

		$items = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE {$clause} ORDER BY last_message_at DESC LIMIT %d OFFSET %d", $params ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return array(
			'items' => $items ? $items : array(),
			'page'  => $page,
			'pages' => (int) ceil( $found / $per_page ),
			'found' => $found,
			'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ), // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * یک گفتگو با شناسه.
	 *
	 * @param int $chat_id گفتگو.
	 * @return array|null
	 */
	public static function chat( $chat_id ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return null;
		}

		$table = self::chats_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $chat_id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $row ? $row : null;
	}

	/**
	 * شمار گفتگوهای خوانده‌نشده، برای نشان کنار منو.
	 *
	 * @return int
	 */
	public static function unread_count() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_chats' ) ) {
			return 0;
		}

		$table = self::chats_table();

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE unread > 0 AND status = 'open'" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * آزمودن پاسخ ربات بدون ارسال واقعی.
	 *
	 * @param string $text متن آزمایشی.
	 * @return array
	 */
	public static function simulate( $text ) {
		$reply = self::answer( $text, array( 'id' => 0, 'name' => 'مشتری آزمایشی' ) );

		return array(
			'text'     => $reply['text'] ? $reply['text'] : 'ربات پاسخی نداشت. یک «پاسخ پیش‌فرض» تعریف کنید تا هیچ پیامی بی‌جواب نماند.',
			'rule'     => $reply['rule'] ? $reply['rule'] : 'بدون تطبیق',
			'handover' => ! empty( $reply['handover'] ),
		);
	}
}
