<?php
/**
 * یادآوری پیگیری‌ها.
 *
 * هر یادداشت، تماس یا جلسه‌ای که تاریخ پیگیری گرفته باشد، سر وقتش به
 * ثبت‌کننده‌اش یادآوری می‌شود — در ربات، با پیامک یا با ایمیل.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Followups
 */
class WCMA_Followups {

	/**
	 * سقف یادآوری در هر اجرا.
	 *
	 * زمان‌بند وردپرس وقت محدودی دارد و فرستادن انبوه در یک اجرا، بقیه‌ی
	 * کارها را عقب می‌اندازد.
	 */
	const BATCH = 25;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		/*
		 * روی تیکِ کارگر می‌نشیند، نه روی اسکن روزانه: یادآوری ساعت ۹ صبح
		 * اگر یک‌بار در روز بررسی شود، می‌تواند ساعت‌ها دیر برسد. کارگر هر
		 * پنج دقیقه اجرا می‌شود، پس فاصله‌ی یادآوری با سررسید کوتاه می‌ماند.
		 * اسکن روزانه هم به‌عنوان تور ایمنی نگه داشته می‌شود، برای سایتی که
		 * کارگرش به هر دلیل نمی‌چرخد.
		 */
		add_action( 'wcma_worker_tick', array( __CLASS__, 'run' ) );
		add_action( 'wcma_daily_scan', array( __CLASS__, 'run' ) );
	}

	/**
	 * آیا یادآوری روشن است؟
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'followup_reminders' );
	}

	/**
	 * کانال‌های ممکن.
	 *
	 * @return array
	 */
	public static function channels() {
		return array(
			'auto'     => 'هرکدام که در دسترس بود (ربات، بعد پیامک، بعد ایمیل)',
			'telegram' => 'فقط ربات پیام‌رسان',
			'sms'      => 'فقط پیامک',
			'email'    => 'فقط ایمیل',
		);
	}

	/**
	 * فرستادن یادآوری‌های سررسیدشده.
	 *
	 * @param int $limit سقف.
	 * @return int شمار یادآوری فرستاده‌شده.
	 */
	public static function run( $limit = 0 ) {
		if ( ! self::is_on() || ! WCMA_Install::table_exists( 'wcma_crm_notes' ) ) {
			return 0;
		}

		$rows = self::pending( $limit ? (int) $limit : self::BATCH );
		$sent = 0;

		foreach ( $rows as $row ) {
			/*
			 * علامت «فرستاده شد» پیش از خودِ ارسال زده می‌شود: اگر ارسال
			 * خطا بدهد یا اجرای زمان‌بند نیمه‌کاره بماند، یادآوری در اجرای
			 * بعدی دوباره و دوباره نمی‌رود. نرسیدن یک یادآوری بهتر از
			 * بیست بار تکرارش است.
			 */
			self::mark_reminded( (int) $row['id'] );

			if ( self::deliver( $row ) ) {
				$sent++;
			}
		}

		return $sent;
	}

	/**
	 * کارهایی که سررسیدشان رسیده و هنوز یادآوری نشده‌اند.
	 *
	 * @param int $limit سقف.
	 * @return array
	 */
	public static function pending( $limit = 25 ) {
		global $wpdb;

		$notes    = WCMA_CRM::notes_table();
		$contacts = WCMA_CRM::table();
		$now      = current_time( 'mysql' );

		$sql = "SELECT n.*, c.first_name, c.last_name, c.company, c.phone, c.email
			FROM {$notes} n
			LEFT JOIN {$contacts} c ON c.id = n.contact_id
			WHERE n.due_at IS NOT NULL
			  AND n.due_at <= %s
			  AND n.done = 0
			  AND n.reminded = 0
			ORDER BY n.due_at ASC
			LIMIT %d";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $now, max( 1, (int) $limit ) ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $rows ? $rows : array();
	}

	/**
	 * علامت‌زدن یک کار به‌عنوان یادآوری‌شده.
	 *
	 * @param int $note_id یادداشت.
	 */
	protected static function mark_reminded( $note_id ) {
		global $wpdb;

		$wpdb->update( // phpcs:ignore WordPress.DB
			WCMA_CRM::notes_table(),
			array( 'reminded' => 1 ),
			array( 'id' => (int) $note_id ),
			array( '%d' ),
			array( '%d' )
		);
	}

	/**
	 * رساندن یک یادآوری به صاحبش.
	 *
	 * @param array $row کار، همراه با اطلاعات پرونده.
	 * @return bool
	 */
	public static function deliver( array $row ) {
		$who = self::person( (string) ( $row['assignee'] ?? '' ) );

		if ( ! $who ) {
			return false;
		}

		$text    = self::text( $row );
		$channel = (string) WCMA_Settings::get( 'followup_channel', 'auto' );
		$order   = ( 'auto' === $channel ) ? array( 'telegram', 'sms', 'email' ) : array( $channel );

		foreach ( $order as $try ) {
			if ( self::push( $try, $who, $row, $text ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * فرستادن روی یک کانال مشخص.
	 *
	 * @param string $channel کانال.
	 * @param array  $who     گیرنده.
	 * @param array  $row     کار.
	 * @param string $text    متن.
	 * @return bool
	 */
	protected static function push( $channel, array $who, array $row, $text ) {
		$result = null;

		if ( 'telegram' === $channel && ! empty( $who['chat'] ) ) {
			// همان پیام‌رسانی که خودِ همکار رویش وصل شده — تلگرام، بله یا روبیکا.
			$result = WCMA_Messengers::send( $who['channel'], $who['chat'], $text );
		}

		if ( 'sms' === $channel && ! empty( $who['phone'] ) ) {
			$result = WCMA_SMS_Gateways::send( $who['phone'], $text );
		}

		if ( 'email' === $channel && ! empty( $who['email'] ) ) {
			$ok = wp_mail(
				$who['email'],
				'یادآوری پیگیری — ' . get_bloginfo( 'name' ),
				$text
			);

			$result = array( 'success' => (bool) $ok );
		}

		if ( null === $result ) {
			return false;
		}

		$ok = ! empty( $result['success'] );

		WCMA_Logger::add(
			array(
				'workflow'    => 'followup',
				'step'        => 'reminder',
				'channel'     => $channel,
				'recipient'   => (string) ( $who['label'] ?? '' ),
				'subject'     => sprintf( 'یادآوری پیگیری #%d', (int) $row['id'] ),
				'status'      => $ok ? 'sent' : 'failed',
				'error'       => $ok ? '' : (string) ( $result['message'] ?? '' ),
				'object_type' => 'crm_note',
				'object_id'   => (int) $row['id'],
			)
		);

		return $ok;
	}

	/**
	 * متن یادآوری.
	 *
	 * @param array $row کار.
	 * @return string
	 */
	public static function text( array $row ) {
		$name  = WCMA_CRM::display_name( $row );
		$types = WCMA_CRM::note_types();
		$type  = $types[ $row['type'] ?? 'note' ] ?? 'پیگیری';

		$lines = array(
			'⏰ یادآوری پیگیری',
			'',
			sprintf( '%s: %s', $type, $name ),
		);

		if ( ! empty( $row['phone'] ) ) {
			$lines[] = 'موبایل: ' . WCMA_Date::digits( (string) $row['phone'] );
		}

		$body = trim( wp_strip_all_tags( (string) ( $row['body'] ?? '' ) ) );

		if ( '' !== $body ) {
			$lines[] = '';
			$lines[] = $body;
		}

		$lines[] = '';
		$lines[] = 'سررسید: ' . WCMA_Date::mysql( $row['due_at'], 'datetime' );
		$lines[] = sprintf( 'برای بستن این کار در ربات بنویسید: /done %d', (int) $row['id'] );

		return implode( "\n", $lines );
	}

	/**
	 * راه‌های رسیدن به صاحب یک کار.
	 *
	 * @param string $ref شناسه‌ی صاحب کار («wp:12» یا «app:3»).
	 * @return array|null
	 */
	public static function person( $ref ) {
		$ref = trim( (string) $ref );

		if ( '' === $ref || false === strpos( $ref, ':' ) ) {
			return null;
		}

		list( $kind, $id ) = array_pad( explode( ':', $ref, 2 ), 2, '' );
		$id                = (int) $id;

		if ( ! $id ) {
			return null;
		}

		if ( 'app' === $kind ) {
			return self::from_app_user( $id );
		}

		if ( 'wp' === $kind ) {
			return self::from_wp_user( $id );
		}

		return null;
	}

	/**
	 * گیرنده از روی حساب کنسول.
	 *
	 * @param int $id حساب.
	 * @return array|null
	 */
	protected static function from_app_user( $id ) {
		if ( ! class_exists( 'WCMA_App_Users' ) ) {
			return null;
		}

		$user = WCMA_App_Users::get( $id );

		if ( ! $user || empty( $user['active'] ) ) {
			return null;
		}

		$who = array(
			'label'   => (string) $user['name'],
			'chat'    => (string) ( $user['tg_chat_id'] ?? '' ),
			'channel' => class_exists( 'WCMA_Bot_Staff' ) ? WCMA_Bot_Staff::channel_of( $user ) : 'telegram',
			'phone'   => '',
			'email'   => '',
		);

		/*
		 * حساب کنسول فقط نام کاربری دارد، نه ایمیل و شماره. اگر به یک کاربر
		 * وردپرس گره خورده باشد، از همان‌جا برداشته می‌شود.
		 */
		if ( ! empty( $user['wp_user_id'] ) ) {
			$wp = self::from_wp_user( (int) $user['wp_user_id'] );

			if ( $wp ) {
				$who['phone'] = $wp['phone'];
				$who['email'] = $wp['email'];

				if ( '' === $who['chat'] ) {
					$who['chat']    = $wp['chat'];
					$who['channel'] = $wp['channel'];
				}
			}
		}

		return $who;
	}

	/**
	 * گیرنده از روی کاربر وردپرس.
	 *
	 * @param int $id کاربر.
	 * @return array|null
	 */
	protected static function from_wp_user( $id ) {
		$user = get_userdata( $id );

		if ( ! $user ) {
			return null;
		}

		$messenger = class_exists( 'WCMA_Bot_Staff' ) ? WCMA_Bot_Staff::channel() : 'telegram';
		$chat      = class_exists( 'WCMA_Bot_Link' )
			? (string) get_user_meta( $id, WCMA_Bot_Link::meta_key( $messenger ), true )
			: '';

		$phone = (string) get_user_meta( $id, 'billing_phone', true );

		return array(
			'label'   => (string) ( $user->display_name ? $user->display_name : $user->user_login ),
			'chat'    => $chat,
			'channel' => $messenger,
			'phone'   => $phone ? WCMA_SMS_Gateways::normalize_phone( $phone ) : '',
			'email'   => (string) $user->user_email,
		);
	}
}
