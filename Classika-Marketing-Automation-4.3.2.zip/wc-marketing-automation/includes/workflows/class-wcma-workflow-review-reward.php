<?php
/**
 * ورک‌فلو ۳: پاداش (کد تخفیف) پس از ثبت نظر.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Review_Reward
 */
class WCMA_Workflow_Review_Reward extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'review_reward';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'پاداش ثبت نظر';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'rw';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'comment_post', array( $this, 'on_comment_post' ), 20, 3 );
		add_action( 'transition_comment_status', array( $this, 'on_comment_status' ), 20, 3 );
	}

	/**
	 * هنگام ثبت نظر جدید (در صورت تأیید خودکار).
	 *
	 * @param int        $comment_id شناسه.
	 * @param int|string $approved   وضعیت تأیید.
	 * @param array      $data       داده‌های نظر.
	 */
	public function on_comment_post( $comment_id, $approved, $data = array() ) {
		if ( 1 === (int) $approved ) {
			$this->maybe_reward( $comment_id );
		}
	}

	/**
	 * هنگام تأیید نظر توسط مدیر.
	 *
	 * @param string     $new     وضعیت جدید.
	 * @param string     $old     وضعیت قبلی.
	 * @param WP_Comment $comment نظر.
	 */
	public function on_comment_status( $new, $old, $comment ) {
		if ( 'approved' === $new ) {
			$this->maybe_reward( $comment->comment_ID );
		}
	}

	/**
	 * بررسی شرایط و ارسال پاداش.
	 *
	 * @param int $comment_id شناسه‌ی نظر.
	 * @return bool
	 */
	public function maybe_reward( $comment_id ) {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		$comment = get_comment( $comment_id );
		if ( ! $comment ) {
			return false;
		}

		// فقط نقد و بررسی محصول.
		$post = get_post( $comment->comment_post_ID );
		if ( ! $post || 'product' !== $post->post_type ) {
			return false;
		}

		// جلوگیری از پاداش تکراری برای یک نظر.
		if ( get_comment_meta( $comment_id, '_wcma_rewarded', true ) ) {
			return false;
		}
		if ( WCMA_Logger::already_sent( $this->id, 'reward', 'comment', $comment_id ) ) {
			return false;
		}

		// حداقل امتیاز.
		$rating     = (int) get_comment_meta( $comment_id, 'rating', true );
		$min_rating = (int) $this->setting( 'min_rating', 1 );
		if ( $min_rating > 0 && $rating > 0 && $rating < $min_rating ) {
			return false;
		}

		// فقط خریداران تأییدشده.
		if ( WCMA_Settings::is( 'rw_require_verified' ) ) {
			$verified = get_comment_meta( $comment_id, 'verified', true );
			if ( '1' !== (string) $verified && ! $this->customer_has_bought( $comment->comment_author_email, $comment->comment_post_ID ) ) {
				return false;
			}
		}

		$email = $comment->comment_author_email;
		if ( ! $email ) {
			return false;
		}

		// فقط یک بار به ازای هر مشتری.
		if ( WCMA_Settings::is( 'rw_once_per_customer' ) ) {
			$user = get_user_by( 'email', $email );
			if ( $user && WCMA_Logger::last_sent_to_user( $this->id, $user->ID ) ) {
				return false;
			}
		}

		$coupon = $this->make_coupon( $email, array( 'prefix' => 'REV' ) );
		if ( ! $coupon ) {
			return false;
		}

		$user    = get_user_by( 'email', $email );
		$user_id = $user ? $user->ID : 0;
		$phone   = $this->find_phone( $email, $user_id );

		$context = array(
			'user_id' => $user_id,
			'product' => $comment->comment_post_ID,
			'coupon'  => $coupon,
			'vars'    => array(
				'first_name' => $comment->comment_author ? $comment->comment_author : 'مشتری',
				'email'      => $email,
				'phone'      => $phone,
			),
		);

		$result = $this->deliver(
			array(
				'context'     => $context,
				'email'       => $email,
				'phone'       => $phone,
				'user_id'     => $user_id,
				'object_type' => 'comment',
				'object_id'   => $comment_id,
				'step'        => 'reward',
				'coupon_code' => $coupon['code'],
			)
		);

		if ( $result['success'] ) {
			update_comment_meta( $comment_id, '_wcma_rewarded', $coupon['code'] );
		}

		return $result['success'];
	}

	/**
	 * بررسی خرید محصول توسط مشتری.
	 *
	 * @param string $email      ایمیل.
	 * @param int    $product_id شناسه‌ی محصول.
	 * @return bool
	 */
	protected function customer_has_bought( $email, $product_id ) {
		if ( ! $email || ! function_exists( 'wc_customer_bought_product' ) ) {
			return false;
		}

		$user    = get_user_by( 'email', $email );
		$user_id = $user ? $user->ID : 0;

		return wc_customer_bought_product( $email, $user_id, $product_id );
	}

	/**
	 * یافتن شماره موبایل مشتری.
	 *
	 * @param string $email   ایمیل.
	 * @param int    $user_id شناسه‌ی کاربر.
	 * @return string
	 */
	protected function find_phone( $email, $user_id ) {
		if ( $user_id ) {
			$phone = get_user_meta( $user_id, 'billing_phone', true );
			if ( $phone ) {
				return $phone;
			}
		}

		$orders = wc_get_orders(
			array(
				'billing_email' => $email,
				'limit'         => 1,
				'orderby'       => 'date',
				'order'         => 'DESC',
			)
		);

		if ( ! empty( $orders[0] ) && $orders[0] instanceof WC_Order ) {
			return $orders[0]->get_billing_phone();
		}

		return '';
	}
}
