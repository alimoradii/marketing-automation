<?php
/**
 * ورک‌فلو: تبریک تولد مشتری همراه با هدیه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Birthday
 */
class WCMA_Workflow_Birthday extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'birthday';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'تبریک تولد';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'bd';

	/**
	 * کلید متای تاریخ تولد.
	 */
	const META_KEY = 'wcma_birthday';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'wcma_daily_scan', array( $this, 'run_scheduled' ) );

		// فیلد تاریخ تولد در حساب کاربری و صفحه‌ی پرداخت.
		add_action( 'woocommerce_edit_account_form', array( $this, 'render_account_field' ) );
		add_action( 'woocommerce_save_account_details', array( $this, 'save_account_field' ) );
		add_filter( 'woocommerce_checkout_fields', array( $this, 'add_checkout_field' ) );
		add_action( 'woocommerce_checkout_update_customer', array( $this, 'save_checkout_field' ), 10, 2 );
		add_action( 'show_user_profile', array( $this, 'render_profile_field' ) );
		add_action( 'edit_user_profile', array( $this, 'render_profile_field' ) );
		add_action( 'personal_options_update', array( $this, 'save_profile_field' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_profile_field' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_datepicker' ) );
	}

	/**
	 * تقویم شمسی برای فیلد تاریخ تولد در حساب کاربری و صفحه‌ی پرداخت.
	 */
	public function enqueue_datepicker() {
		if ( ! WCMA_Settings::is( 'bd_field_enabled' ) || ! function_exists( 'is_account_page' ) ) {
			return;
		}

		if ( ! is_account_page() && ! is_checkout() ) {
			return;
		}

		WCMA_Admin::enqueue_datepicker();
	}

	/**
	 * یافتن تولدهای امروز و ارسال هدیه.
	 */
	public function run_scheduled() {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$days_before = max( 0, (int) $this->setting( 'days_before', 0 ) );
		$target      = gmdate( 'm-d', current_time( 'timestamp' ) + ( $days_before * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DateTime

		$users = get_users(
			array(
				'number'     => 200,
				// phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_query' => array(
					array(
						'key'     => self::META_KEY,
						'compare' => 'EXISTS',
					),
				),
				'fields'     => array( 'ID', 'user_email', 'display_name' ),
			)
		);

		foreach ( $users as $user ) {
			$birthday = get_user_meta( $user->ID, self::META_KEY, true );
			if ( ! $birthday ) {
				continue;
			}

			$timestamp = strtotime( $birthday );
			if ( ! $timestamp || gmdate( 'm-d', $timestamp ) !== $target ) {
				continue;
			}

			// جلوگیری از ارسال دوباره در همان سال.
			$last_year = get_user_meta( $user->ID, '_wcma_birthday_year', true );
			if ( (string) $last_year === gmdate( 'Y', current_time( 'timestamp' ) ) ) { // phpcs:ignore WordPress.DateTime
				continue;
			}

			if ( $this->send_to_user( $user->ID ) ) {
				update_user_meta( $user->ID, '_wcma_birthday_year', gmdate( 'Y', current_time( 'timestamp' ) ) ); // phpcs:ignore WordPress.DateTime
			}
		}
	}

	/**
	 * ارسال پیام تولد به یک کاربر.
	 *
	 * @param int $user_id شناسه.
	 * @return bool
	 */
	public function send_to_user( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		$email = get_user_meta( $user_id, 'billing_email', true );
		$email = $email ? $email : $user->user_email;
		$phone = get_user_meta( $user_id, 'billing_phone', true );

		if ( WCMA_Subscribers::is_opted_out( $email ) ) {
			return false;
		}

		$coupon = null;
		if ( WCMA_Settings::is( 'bd_coupon' ) ) {
			$coupon = $this->make_coupon( $email, array( 'prefix' => 'BDAY' ) );
		}

		$context = array(
			'user_id' => $user_id,
			'coupon'  => $coupon ? $coupon : array(),
		);

		$result = $this->deliver(
			array(
				'context'     => $context,
				'email'       => $email,
				'phone'       => $phone,
				'user_id'     => $user_id,
				'object_type' => 'customer',
				'object_id'   => $user_id,
				'step'        => 'birthday',
				'coupon_code' => $coupon ? $coupon['code'] : '',
			)
		);

		return $result['success'];
	}

	/**
	 * فیلد تاریخ تولد در فرم ویرایش حساب.
	 */
	public function render_account_field() {
		if ( ! WCMA_Settings::is( 'bd_field_enabled' ) ) {
			return;
		}

		$value = get_user_meta( get_current_user_id(), self::META_KEY, true );
		?>
		<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
			<label for="wcma_birthday">تاریخ تولد</label>
			<input type="date" data-wcma-jalali class="woocommerce-Input woocommerce-Input--text input-text" name="wcma_birthday" id="wcma_birthday" value="<?php echo esc_attr( $value ); ?>" />
			<span><small>با ثبت تاریخ تولد، هدیه‌ی ویژه‌ی تولد دریافت می‌کنید.</small></span>
		</p>
		<?php
	}

	/**
	 * ذخیره‌ی فیلد در فرم حساب.
	 *
	 * @param int $user_id شناسه.
	 */
	public function save_account_field( $user_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['wcma_birthday'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			update_user_meta( $user_id, self::META_KEY, WCMA_Date::parse( sanitize_text_field( wp_unslash( $_POST['wcma_birthday'] ) ) ) );
		}
	}

	/**
	 * افزودن فیلد به صفحه‌ی پرداخت.
	 *
	 * @param array $fields فیلدها.
	 * @return array
	 */
	public function add_checkout_field( $fields ) {
		if ( ! WCMA_Settings::is( 'bd_field_enabled' ) ) {
			return $fields;
		}

		$fields['billing']['wcma_birthday'] = array(
			'type'              => 'date',
			'label'             => 'تاریخ تولد (اختیاری)',
			'required'          => false,
			'class'             => array( 'form-row-wide' ),
			'priority'          => 999,
			'custom_attributes' => array( 'data-wcma-jalali' => '1' ),
		);

		return $fields;
	}

	/**
	 * ذخیره‌ی فیلد پرداخت روی مشتری.
	 *
	 * @param WC_Customer $customer مشتری.
	 * @param array       $data     داده‌ها.
	 */
	public function save_checkout_field( $customer, $data ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_POST['wcma_birthday'] ) && $customer->get_id() ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			update_user_meta( $customer->get_id(), self::META_KEY, WCMA_Date::parse( sanitize_text_field( wp_unslash( $_POST['wcma_birthday'] ) ) ) );
		}
	}

	/**
	 * فیلد تولد در پروفایل مدیریت.
	 *
	 * @param WP_User $user کاربر.
	 */
	public function render_profile_field( $user ) {
		$value = get_user_meta( $user->ID, self::META_KEY, true );
		?>
		<h2>اتوماسیون بازاریابی</h2>
		<table class="form-table">
			<tr>
				<th><label for="wcma_birthday">تاریخ تولد</label></th>
				<td><input type="date" data-wcma-jalali name="wcma_birthday" id="wcma_birthday" value="<?php echo esc_attr( $value ); ?>" class="regular-text" /></td>
			</tr>
			<?php foreach ( WCMA_Messengers::all() as $msgr_key => $msgr ) : ?>
				<?php if ( empty( $msgr['per_customer'] ) ) : ?>
					<tr>
						<th><label for="wcma_<?php echo esc_attr( $msgr_key ); ?>_chat_id">شناسه‌ی چت <?php echo esc_html( $msgr['label'] ); ?></label></th>
						<td>
							<input
								type="text"
								name="wcma_<?php echo esc_attr( $msgr_key ); ?>_chat_id"
								id="wcma_<?php echo esc_attr( $msgr_key ); ?>_chat_id"
								value="<?php echo esc_attr( get_user_meta( $user->ID, 'wcma_' . $msgr_key . '_chat_id', true ) ); ?>"
								class="regular-text"
								dir="ltr"
							/>
							<p class="description">در صورت تکمیل، پیام‌های <?php echo esc_html( $msgr['label'] ); ?> این مشتری به‌جای کانال عمومی به همین چت ارسال می‌شود.</p>
						</td>
					</tr>
				<?php endif; ?>
			<?php endforeach; ?>
			<tr>
				<th>وضعیت اشتراک</th>
				<td>
					<label>
						<input type="checkbox" name="wcma_opted_out" value="yes" <?php checked( 'yes', get_user_meta( $user->ID, 'wcma_opted_out', true ) ); ?> />
						این کاربر اشتراک پیام‌های تبلیغاتی را لغو کرده است.
					</label>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * ذخیره‌ی فیلدهای پروفایل.
	 *
	 * @param int $user_id شناسه.
	 */
	public function save_profile_field( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['wcma_birthday'] ) ) {
			update_user_meta( $user_id, self::META_KEY, WCMA_Date::parse( sanitize_text_field( wp_unslash( $_POST['wcma_birthday'] ) ) ) );
		}

		foreach ( array_keys( WCMA_Messengers::all() ) as $msgr_key ) {
			$field = 'wcma_' . $msgr_key . '_chat_id';

			if ( isset( $_POST[ $field ] ) ) {
				$value = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );

				if ( '' === $value ) {
					delete_user_meta( $user_id, $field );
				} else {
					update_user_meta( $user_id, $field, $value );
				}
			}
		}

		$user = get_userdata( $user_id );
		if ( $user ) {
			if ( ! empty( $_POST['wcma_opted_out'] ) ) {
				WCMA_Subscribers::opt_out( $user->user_email );
			} else {
				WCMA_Subscribers::opt_in( $user->user_email );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}
}
