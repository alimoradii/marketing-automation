<?php
/**
 * ورک‌فلو: باشگاه مشتریان VIP.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_VIP
 */
class WCMA_Workflow_VIP extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'vip_club';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'باشگاه مشتریان';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'vip';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'wcma_daily_scan', array( $this, 'run_scheduled' ) );

		// پس از هر سفارش تکمیل‌شده، همان مشتری فوری بازبینی می‌شود تا ارتقا دیر اعلام نشود.
		add_action( 'woocommerce_order_status_completed', array( $this, 'on_order_completed' ), 20 );
	}

	/**
	 * اجرای روزانه: بازمحاسبه و اقدام بر اساس تغییرات.
	 */
	public function run_scheduled() {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$result = WCMA_VIP::recalculate( (int) $this->setting( 'scan_limit', 5000 ) );

		foreach ( $result['promoted'] as $change ) {
			$this->notify_promotion( $change );
		}

		if ( WCMA_Settings::is( 'vip_notify_demotion' ) ) {
			foreach ( $result['demoted'] as $change ) {
				$this->notify_demotion( $change );
			}
		}

		$this->send_periodic_rewards();
		$this->send_churn_warnings();
	}

	/**
	 * بازبینی فوری یک مشتری پس از تکمیل سفارش.
	 *
	 * @param int $order_id شناسه‌ی سفارش.
	 */
	public function on_order_completed( $order_id ) {
		if ( ! $this->is_enabled() || ! WCMA_Settings::is( 'vip_realtime' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order || ! $order->get_billing_email() ) {
			return;
		}

		$before = WCMA_VIP::get_by_email( $order->get_billing_email() );
		$before = $before ? (int) $before['tier'] : 0;

		WCMA_VIP::recalculate( (int) $this->setting( 'scan_limit', 5000 ) );

		$after = WCMA_VIP::get_by_email( $order->get_billing_email() );

		if ( $after && (int) $after['tier'] > $before ) {
			$this->notify_promotion(
				array(
					'id'    => (int) $after['id'],
					'email' => $after['email'],
					'from'  => $before,
					'to'    => (int) $after['tier'],
				)
			);
		}
	}

	/**
	 * پیام ارتقا به سطح بالاتر.
	 *
	 * @param array $change اطلاعات تغییر.
	 * @return bool
	 */
	protected function notify_promotion( array $change ) {
		if ( ! WCMA_Settings::is( 'vip_notify_promotion' ) ) {
			return false;
		}

		$member = WCMA_VIP::get( $change['id'] );

		if ( ! $member ) {
			return false;
		}

		$step = 'promote_' . (int) $change['to'];

		if ( WCMA_Logger::already_sent( $this->id, $step, 'vip_member', (int) $member['id'] ) ) {
			return false;
		}

		$tier   = WCMA_VIP::tier( (int) $change['to'] );
		$coupon = null;

		if ( $tier && $tier['coupon_amount'] > 0 ) {
			$coupon = WCMA_Coupons::create(
				array(
					'type'     => $tier['coupon_type'],
					'amount'   => $tier['coupon_amount'],
					'days'     => $tier['coupon_days'],
					'email'    => $member['email'],
					'prefix'   => 'VIP',
					'workflow' => $this->title . ' — ' . $tier['name'],
				)
			);
		}

		$result = $this->deliver_to_member(
			$member,
			$step,
			$this->setting( 'promote_subject', '' ),
			$this->setting( 'promote_sms_text', '' ),
			$this->setting( 'promote_email_text', '' ),
			$coupon
		);

		return $result['success'];
	}

	/**
	 * پیام تنزل سطح (اختیاری و پیش‌فرض خاموش).
	 *
	 * @param array $change اطلاعات تغییر.
	 * @return bool
	 */
	protected function notify_demotion( array $change ) {
		$member = WCMA_VIP::get( $change['id'] );

		if ( ! $member ) {
			return false;
		}

		$step = 'demote_' . (int) $change['to'];

		if ( WCMA_Logger::already_sent( $this->id, $step, 'vip_member', (int) $member['id'] ) ) {
			return false;
		}

		$result = $this->deliver_to_member(
			$member,
			$step,
			$this->setting( 'demote_subject', '' ),
			$this->setting( 'demote_sms_text', '' ),
			$this->setting( 'demote_email_text', '' ),
			null
		);

		return $result['success'];
	}

	/**
	 * پاداش دوره‌ای اعضا.
	 */
	protected function send_periodic_rewards() {
		if ( ! WCMA_Settings::is( 'vip_reward_enabled' ) ) {
			return;
		}

		global $wpdb;

		$every    = max( 1, (int) $this->setting( 'reward_every_days', 30 ) );
		$min_tier = max( 1, (int) $this->setting( 'reward_min_tier', 1 ) );
		$table    = WCMA_VIP::table();

		$members = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table}
				 WHERE tier >= %d AND ( last_reward_at IS NULL OR last_reward_at < DATE_SUB(%s, INTERVAL %d DAY) )
				 ORDER BY total_amount DESC LIMIT 200", // phpcs:ignore WordPress.DB
				$min_tier,
				current_time( 'mysql' ),
				$every
			),
			ARRAY_A
		);

		foreach ( $members as $member ) {
			$tier = WCMA_VIP::tier( (int) $member['tier'] );

			if ( ! $tier ) {
				continue;
			}

			$coupon = null;

			if ( $tier['coupon_amount'] > 0 ) {
				$coupon = WCMA_Coupons::create(
					array(
						'type'     => $tier['coupon_type'],
						'amount'   => $tier['coupon_amount'],
						'days'     => $tier['coupon_days'],
						'email'    => $member['email'],
						'prefix'   => 'VIP',
						'workflow' => $this->title . ' — پاداش دوره‌ای',
					)
				);
			}

			$result = $this->deliver_to_member(
				$member,
				'reward',
				$this->setting( 'reward_subject', '' ),
				$this->setting( 'reward_sms_text', '' ),
				$this->setting( 'reward_email_text', '' ),
				$coupon
			);

			if ( $result['success'] ) {
				$wpdb->update( // phpcs:ignore WordPress.DB
					$table,
					array( 'last_reward_at' => current_time( 'mysql' ) ),
					array( 'id' => (int) $member['id'] )
				);
			}
		}
	}

	/**
	 * هشدار ریزش مشتری ارزشمند.
	 */
	protected function send_churn_warnings() {
		if ( ! WCMA_Settings::is( 'vip_churn_enabled' ) ) {
			return;
		}

		global $wpdb;

		$days     = max( 1, (int) $this->setting( 'churn_days', 60 ) );
		$min_tier = max( 1, (int) $this->setting( 'churn_min_tier', 1 ) );
		$table    = WCMA_VIP::table();

		$members = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table}
				 WHERE tier >= %d AND last_order_at IS NOT NULL AND last_order_at < DATE_SUB(%s, INTERVAL %d DAY)
				 AND ( last_churn_at IS NULL OR last_churn_at < DATE_SUB(%s, INTERVAL %d DAY) )
				 ORDER BY total_amount DESC LIMIT 100", // phpcs:ignore WordPress.DB
				$min_tier,
				current_time( 'mysql' ),
				$days,
				current_time( 'mysql' ),
				$days
			),
			ARRAY_A
		);

		foreach ( $members as $member ) {
			$tier   = WCMA_VIP::tier( (int) $member['tier'] );
			$coupon = null;

			if ( WCMA_Settings::is( 'vip_churn_coupon' ) && $tier && $tier['coupon_amount'] > 0 ) {
				$coupon = WCMA_Coupons::create(
					array(
						'type'     => $tier['coupon_type'],
						'amount'   => $tier['coupon_amount'],
						'days'     => $tier['coupon_days'],
						'email'    => $member['email'],
						'prefix'   => 'VIPBACK',
						'workflow' => $this->title . ' — بازگشت',
					)
				);
			}

			$result = $this->deliver_to_member(
				$member,
				'churn',
				$this->setting( 'churn_subject', '' ),
				$this->setting( 'churn_sms_text', '' ),
				$this->setting( 'churn_email_text', '' ),
				$coupon
			);

			if ( $result['success'] ) {
				$wpdb->update( // phpcs:ignore WordPress.DB
					$table,
					array( 'last_churn_at' => current_time( 'mysql' ) ),
					array( 'id' => (int) $member['id'] )
				);
			}
		}
	}

	/**
	 * ارسال پیام به یک عضو با متغیرهای باشگاه.
	 *
	 * @param array      $member  عضو.
	 * @param string     $step    مرحله.
	 * @param string     $subject موضوع.
	 * @param string     $sms     متن پیامک.
	 * @param string     $email   متن ایمیل.
	 * @param array|null $coupon  کد تخفیف.
	 * @return array
	 */
	protected function deliver_to_member( array $member, $step, $subject, $sms, $email, $coupon = null ) {
		$tier = WCMA_VIP::tier( (int) $member['tier'] );
		$next = WCMA_VIP::next_tier( (float) $member['total_amount'], (int) $member['order_count'] );

		$remaining = '';

		if ( $next ) {
			$basis = WCMA_Settings::get( 'vip_basis', 'amount' );
			$parts = array();

			if ( in_array( $basis, array( 'amount', 'any', 'all' ), true ) && $next['amount_remaining'] > 0 ) {
				$parts[] = trim( wp_strip_all_tags( wc_price( $next['amount_remaining'] ) ) );
			}

			if ( in_array( $basis, array( 'orders', 'any', 'all' ), true ) && $next['orders_remaining'] > 0 ) {
				$parts[] = number_format_i18n( $next['orders_remaining'] ) . ' سفارش';
			}

			$remaining = implode( 'all' === $basis ? ' و ' : ' یا ', $parts );
		}

		$context = array(
			'user_id' => (int) $member['user_id'],
			'coupon'  => $coupon ? $coupon : array(),
			'vars'    => array(
				'first_name'         => $member['first_name'] ? $member['first_name'] : 'مشتری',
				'email'              => $member['email'],
				'phone'              => $member['phone'],
				'vip_tier'           => $tier ? $tier['name'] : 'بدون سطح',
				'vip_perk'           => $tier ? $tier['perk'] : '',
				'vip_total'          => trim( wp_strip_all_tags( wc_price( (float) $member['total_amount'] ) ) ),
				'vip_orders'         => number_format_i18n( (int) $member['order_count'] ),
				'vip_next_tier'      => $next ? $next['tier']['name'] : '',
				'vip_next_remaining' => $remaining,
			),
		);

		return $this->deliver(
			array(
				'channel'     => $this->resolve_channel(
					array(
						'email'   => $member['email'],
						'phone'   => $member['phone'],
						'user_id' => (int) $member['user_id'],
					)
				),
				'context'     => $context,
				'subject'     => $subject,
				'sms_text'    => $sms,
				'email_text'  => $email,
				'email'       => $member['email'],
				'phone'       => $member['phone'],
				'user_id'     => (int) $member['user_id'],
				'object_type' => 'vip_member',
				'object_id'   => (int) $member['id'],
				'step'        => $step,
				'coupon_code' => $coupon ? $coupon['code'] : '',
			)
		);
	}

	/**
	 * بازمحاسبه‌ی دستی از پیشخوان.
	 *
	 * @return array
	 */
	public function recalculate_now() {
		$result = WCMA_VIP::recalculate( (int) $this->setting( 'scan_limit', 5000 ) );

		return array(
			'success' => true,
			'message' => sprintf(
				'%s مشتری بررسی شد. %s ارتقا و %s تنزل سطح.',
				number_format_i18n( $result['scanned'] ),
				number_format_i18n( count( $result['promoted'] ) ),
				number_format_i18n( count( $result['demoted'] ) )
			),
		);
	}
}
