<?php
/**
 * ورک‌فلو ۱: سبد خرید رها شده و سفارش تکمیل‌نشده.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Abandoned
 */
class WCMA_Workflow_Abandoned extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'abandoned_cart';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'سبد خرید رها شده / سفارش تکمیل‌نشده';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'ab';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'wcma_scheduled_scan', array( $this, 'run_scheduled' ) );
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 10, 4 );
	}

	/**
	 * مراحل پیکربندی‌شده.
	 *
	 * @return array
	 */
	public function get_steps() {
		$steps = WCMA_Settings::get( 'ab_steps', array() );
		return is_array( $steps ) ? array_values( $steps ) : array();
	}

	/**
	 * اسکن دوره‌ای: سبدهای رها شده و سفارش‌های تکمیل‌نشده.
	 */
	public function run_scheduled() {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$this->scan_carts();
		$this->scan_orders();
	}

	/**
	 * زمان‌بندی پیام‌ها برای سبدهای رها شده.
	 */
	protected function scan_carts() {
		$carts = WCMA_Carts::mark_abandoned();

		foreach ( (array) $carts as $cart ) {
			if ( ! $cart['email'] && ! $cart['phone'] ) {
				continue;
			}

			$base = $cart['updated_at'];

			foreach ( $this->get_steps() as $index => $step ) {
				if ( empty( $step['active'] ) || 'yes' !== $step['active'] ) {
					continue;
				}

				$step_key = 'step_' . ( $index + 1 );

				if ( WCMA_Logger::already_sent( $this->id, $step_key, 'cart', $cart['id'] ) ) {
					continue;
				}
				if ( WCMA_Queue::exists( $this->id, $step_key, 'cart', $cart['id'] ) ) {
					continue;
				}

				$delay = WCMA_Queue::delay_to_seconds( $step['delay'] ?? 60, $step['unit'] ?? 'minute' );

				WCMA_Queue::add(
					array(
						'workflow'     => $this->id,
						'step'         => $step_key,
						'channel'      => $step['channel'] ?? 'email',
						'object_type'  => 'cart',
						'object_id'    => (int) $cart['id'],
						'user_id'      => (int) $cart['user_id'],
						'recipient'    => $cart['email'] ? $cart['email'] : $cart['phone'],
						'payload'      => array( 'step_index' => $index ),
						'scheduled_at' => WCMA_Queue::schedule_from_local( $base, $delay ),
					)
				);
			}
		}
	}

	/**
	 * زمان‌بندی پیام‌ها برای سفارش‌های تکمیل‌نشده (در انتظار پرداخت/ناموفق).
	 */
	protected function scan_orders() {
		$statuses = (array) WCMA_Settings::get( 'ab_order_statuses', array( 'pending', 'failed' ) );
		if ( ! $statuses ) {
			return;
		}

		$orders = wc_get_orders(
			array(
				'status'       => $statuses,
				'limit'        => 100,
				'orderby'      => 'date',
				'order'        => 'DESC',
				'date_created' => '>' . ( time() - ( 14 * DAY_IN_SECONDS ) ),
			)
		);

		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$email = $order->get_billing_email();
			$phone = $order->get_billing_phone();

			if ( ! $email && ! $phone ) {
				continue;
			}

			$created = $order->get_date_created();
			if ( ! $created ) {
				continue;
			}
			$base = $created->getTimestamp();

			foreach ( $this->get_steps() as $index => $step ) {
				if ( empty( $step['active'] ) || 'yes' !== $step['active'] ) {
					continue;
				}

				$step_key = 'step_' . ( $index + 1 );

				if ( WCMA_Logger::already_sent( $this->id, $step_key, 'order', $order->get_id() ) ) {
					continue;
				}
				if ( WCMA_Queue::exists( $this->id, $step_key, 'order', $order->get_id() ) ) {
					continue;
				}

				$delay = WCMA_Queue::delay_to_seconds( $step['delay'] ?? 60, $step['unit'] ?? 'minute' );

				WCMA_Queue::add(
					array(
						'workflow'     => $this->id,
						'step'         => $step_key,
						'channel'      => $step['channel'] ?? 'email',
						'object_type'  => 'order',
						'object_id'    => $order->get_id(),
						'user_id'      => $order->get_customer_id(),
						'recipient'    => $email ? $email : $phone,
						'payload'      => array( 'step_index' => $index ),
						'scheduled_at' => WCMA_Queue::schedule_from_utc( $base, $delay ),
					)
				);
			}
		}
	}

	/**
	 * لغو پیگیری وقتی سفارش پرداخت شد.
	 *
	 * @param int      $order_id شناسه.
	 * @param string   $from     وضعیت قبلی.
	 * @param string   $to       وضعیت جدید.
	 * @param WC_Order $order    سفارش.
	 */
	public function on_order_status_changed( $order_id, $from, $to, $order ) {
		if ( ! WCMA_Settings::is( 'ab_stop_on_order' ) ) {
			return;
		}

		$paid_statuses = array( 'processing', 'completed', 'on-hold' );
		if ( ! in_array( $to, $paid_statuses, true ) ) {
			return;
		}

		WCMA_Queue::cancel_for_object( 'order', $order_id, $this->id );

		// علامت‌گذاری تبدیل برای پیام‌های ارسال‌شده‌ی این سفارش.
		global $wpdb;
		$logs   = WCMA_Logger::table();
		$log_id = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT id FROM {$logs} WHERE workflow = %s AND object_type = 'order' AND object_id = %d AND status = 'sent' ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB
				$this->id,
				$order_id
			)
		);

		if ( $log_id && $order instanceof WC_Order ) {
			WCMA_Logger::mark_converted( (int) $log_id, (float) $order->get_total() );
		}
	}

	/**
	 * اجرای کار صف.
	 *
	 * @param array $job     رکورد صف.
	 * @param array $payload داده‌ها.
	 * @return bool
	 */
	public function run_queued( $job, $payload ) {
		if ( ! $this->is_enabled() ) {
			return true;
		}

		$steps = $this->get_steps();
		$index = (int) ( $payload['step_index'] ?? 0 );

		if ( ! isset( $steps[ $index ] ) ) {
			return true;
		}

		$step     = $steps[ $index ];
		$step_key = 'step_' . ( $index + 1 );

		if ( 'cart' === $job['object_type'] ) {
			return $this->send_for_cart( (int) $job['object_id'], $step, $step_key );
		}

		return $this->send_for_order( (int) $job['object_id'], $step, $step_key );
	}

	/**
	 * ارسال پیام برای یک سبد رها شده.
	 *
	 * @param int    $cart_id  شناسه‌ی سبد.
	 * @param array  $step     تنظیمات مرحله.
	 * @param string $step_key کلید مرحله.
	 * @return bool
	 */
	protected function send_for_cart( $cart_id, array $step, $step_key ) {
		$cart = WCMA_Carts::get( $cart_id );

		if ( ! $cart || 'abandoned' !== $cart['status'] ) {
			return true; // سبد بازیابی یا حذف شده است.
		}

		$coupon = null;
		if ( ! empty( $step['coupon'] ) && 'yes' === $step['coupon'] ) {
			$coupon = $this->make_coupon(
				$cart['email'],
				array(
					'type'   => $step['coupon_type'] ?? 'percent',
					'amount' => $step['coupon_amount'] ?? 10,
					'days'   => $step['coupon_days'] ?? 3,
					'prefix' => 'CART',
				)
			);
		}

		$context = array(
			'cart'    => $cart,
			'user_id' => (int) $cart['user_id'],
			'coupon'  => $coupon ? $coupon : array(),
		);

		$result = $this->deliver(
			array(
				'channel'     => $step['channel'] ?? 'email',
				'context'     => $context,
				'subject'     => $step['subject'] ?? '',
				'sms_text'    => $step['sms_text'] ?? '',
				'email_text'  => $step['email_text'] ?? '',
				'email'       => $cart['email'],
				'phone'       => $cart['phone'],
				'user_id'     => (int) $cart['user_id'],
				'object_type' => 'cart',
				'object_id'   => $cart_id,
				'step'        => $step_key,
				'coupon_code' => $coupon ? $coupon['code'] : '',
			)
		);

		return $result['success'];
	}

	/**
	 * ارسال پیام برای یک سفارش تکمیل‌نشده.
	 *
	 * @param int    $order_id شناسه‌ی سفارش.
	 * @param array  $step     تنظیمات مرحله.
	 * @param string $step_key کلید مرحله.
	 * @return bool
	 */
	protected function send_for_order( $order_id, array $step, $step_key ) {
		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return true;
		}

		$statuses = (array) WCMA_Settings::get( 'ab_order_statuses', array( 'pending', 'failed' ) );
		if ( ! in_array( $order->get_status(), $statuses, true ) ) {
			return true; // سفارش دیگر تکمیل‌نشده نیست.
		}

		$coupon = null;
		if ( ! empty( $step['coupon'] ) && 'yes' === $step['coupon'] ) {
			$coupon = $this->make_coupon(
				$order->get_billing_email(),
				array(
					'type'   => $step['coupon_type'] ?? 'percent',
					'amount' => $step['coupon_amount'] ?? 10,
					'days'   => $step['coupon_days'] ?? 3,
					'prefix' => 'CART',
				)
			);
		}

		$context = array(
			'order'   => $order,
			'user_id' => $order->get_customer_id(),
			'coupon'  => $coupon ? $coupon : array(),
			'vars'    => array(
				'recovery_link' => $order->get_checkout_payment_url(),
				'cart_items'    => WCMA_Placeholders::format_order_items( $order ),
				'cart_total'    => trim( wp_strip_all_tags( $order->get_formatted_order_total() ) ),
			),
		);

		$result = $this->deliver(
			array(
				'channel'     => $step['channel'] ?? 'email',
				'context'     => $context,
				'subject'     => $step['subject'] ?? '',
				'sms_text'    => $step['sms_text'] ?? '',
				'email_text'  => $step['email_text'] ?? '',
				'email'       => $order->get_billing_email(),
				'phone'       => $order->get_billing_phone(),
				'user_id'     => $order->get_customer_id(),
				'object_type' => 'order',
				'object_id'   => $order_id,
				'step'        => $step_key,
				'coupon_code' => $coupon ? $coupon['code'] : '',
			)
		);

		return $result['success'];
	}

	/**
	 * ارسال دستی و فوری برای یک سفارش (از تب سفارش‌های اخیر).
	 *
	 * @param int $order_id شناسه.
	 * @return array
	 */
	public function send_now_for_order( $order_id ) {
		$steps = $this->get_steps();
		if ( ! $steps ) {
			return array(
				'success' => false,
				'message' => 'هیچ مرحله‌ای تعریف نشده است.',
			);
		}

		$step = $steps[0];
		$sent = $this->send_for_order( (int) $order_id, $step, 'manual' );

		return array(
			'success' => $sent,
			'message' => $sent ? 'پیام یادآوری ارسال شد.' : 'ارسال ناموفق بود؛ گزارش‌ها را بررسی کنید.',
		);
	}
}
