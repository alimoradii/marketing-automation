<?php
/**
 * ورک‌فلو: اطلاع‌رسانی تغییر وضعیت سفارش به مشتری و مدیر.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Order_Status
 */
class WCMA_Workflow_Order_Status extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'order_status';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'اطلاع‌رسانی وضعیت سفارش';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'os';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status_changed' ), 20, 4 );
		add_action( 'woocommerce_new_order', array( $this, 'on_new_order' ), 20 );
	}

	/**
	 * ارسال پیام به مشتری هنگام تغییر وضعیت.
	 *
	 * @param int      $order_id شناسه.
	 * @param string   $from     وضعیت قبلی.
	 * @param string   $to       وضعیت جدید.
	 * @param WC_Order $order    سفارش.
	 */
	public function on_status_changed( $order_id, $from, $to, $order ) {
		if ( ! $this->is_enabled() || ! $order instanceof WC_Order ) {
			return;
		}

		$map = (array) WCMA_Settings::get( 'os_statuses', array() );
		if ( empty( $map[ $to ]['active'] ) || 'yes' !== $map[ $to ]['active'] ) {
			return;
		}

		$step = 'status_' . $to;
		if ( WCMA_Logger::already_sent( $this->id, $step, 'order', $order_id ) ) {
			return;
		}

		$text    = $map[ $to ]['text'] ?? '';
		$context = array(
			'order'   => $order,
			'user_id' => $order->get_customer_id(),
		);

		$this->deliver(
			array(
				'channel'     => $this->setting( 'channel', 'sms' ),
				'context'     => $context,
				'subject'     => sprintf( 'وضعیت سفارش #%s', $order->get_order_number() ),
				'sms_text'    => $text,
				'email_text'  => wpautop( $text ),
				'email'       => $order->get_billing_email(),
				'phone'       => $order->get_billing_phone(),
				'user_id'     => $order->get_customer_id(),
				'object_type' => 'order',
				'object_id'   => $order_id,
				'step'        => $step,
			)
		);
	}

	/**
	 * اطلاع‌رسانی سفارش جدید به مدیر.
	 *
	 * @param int $order_id شناسه.
	 */
	public function on_new_order( $order_id ) {
		if ( ! $this->is_enabled() || ! WCMA_Settings::is( 'os_admin_new_order' ) ) {
			return;
		}

		$phone = WCMA_Settings::get( 'os_admin_phone' );
		if ( ! $phone ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		if ( WCMA_Logger::already_sent( $this->id, 'admin_new_order', 'order', $order_id ) ) {
			return;
		}

		$text = WCMA_Placeholders::replace(
			WCMA_Settings::get( 'os_admin_text' ),
			array( 'order' => $order )
		);

		WCMA_Sender::send(
			array(
				'channel'     => 'sms',
				'phone'       => $phone,
				'text'        => $text,
				'workflow'    => $this->id,
				'step'        => 'admin_new_order',
				'object_type' => 'order',
				'object_id'   => $order_id,
				'skip_optout' => true,
			)
		);
	}
}
