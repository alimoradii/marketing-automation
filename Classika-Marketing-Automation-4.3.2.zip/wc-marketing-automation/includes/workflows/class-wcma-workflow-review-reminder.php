<?php
/**
 * ورک‌فلو ۲: یادآوری ثبت نظر پس از خرید.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Review_Reminder
 */
class WCMA_Workflow_Review_Reminder extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'review_reminder';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'یادآوری ثبت نظر';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'rr';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 10, 4 );
		add_action( 'wcma_scheduled_scan', array( $this, 'run_scheduled' ) );
	}

	/**
	 * زمان‌بندی یادآوری هنگام رسیدن سفارش به وضعیت هدف.
	 *
	 * @param int      $order_id شناسه.
	 * @param string   $from     وضعیت قبلی.
	 * @param string   $to       وضعیت جدید.
	 * @param WC_Order $order    سفارش.
	 */
	public function on_order_status_changed( $order_id, $from, $to, $order ) {
		if ( ! $this->is_enabled() ) {
			return;
		}

		if ( $to !== $this->setting( 'only_status', 'completed' ) ) {
			return;
		}

		$this->schedule_for_order( $order );
	}

	/**
	 * اسکن پشتیبان برای سفارش‌هایی که هوک آن‌ها از دست رفته است.
	 */
	public function run_scheduled() {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$status = $this->setting( 'only_status', 'completed' );
		$delay  = WCMA_Queue::delay_to_seconds( $this->setting( 'delay', 7 ), $this->setting( 'unit', 'day' ) );

		$orders = wc_get_orders(
			array(
				'status'       => array( $status ),
				'limit'        => 50,
				'orderby'      => 'date',
				'order'        => 'DESC',
				'date_created' => '>' . ( time() - $delay - ( 7 * DAY_IN_SECONDS ) ),
			)
		);

		foreach ( (array) $orders as $order ) {
			if ( $order instanceof WC_Order ) {
				$this->schedule_for_order( $order );
			}
		}
	}

	/**
	 * افزودن سفارش به صف یادآوری.
	 *
	 * @param WC_Order $order سفارش.
	 */
	protected function schedule_for_order( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$order_id = $order->get_id();

		if ( WCMA_Logger::already_sent( $this->id, 'reminder', 'order', $order_id ) ) {
			return;
		}
		if ( WCMA_Queue::exists( $this->id, 'reminder', 'order', $order_id ) ) {
			return;
		}

		$email = $order->get_billing_email();
		$phone = $order->get_billing_phone();

		if ( ! $email && ! $phone ) {
			return;
		}

		$delay = WCMA_Queue::delay_to_seconds( $this->setting( 'delay', 7 ), $this->setting( 'unit', 'day' ) );

		$paid = $order->get_date_paid() ? $order->get_date_paid() : $order->get_date_created();
		$base = $paid ? $paid->getTimestamp() : time();

		WCMA_Queue::add(
			array(
				'workflow'     => $this->id,
				'step'         => 'reminder',
				'channel'      => $this->setting( 'channel', 'sms' ),
				'object_type'  => 'order',
				'object_id'    => $order_id,
				'user_id'      => $order->get_customer_id(),
				'recipient'    => $email ? $email : $phone,
				'scheduled_at' => WCMA_Queue::schedule_from_utc( $base, $delay ),
			)
		);
	}

	/**
	 * اجرای کار صف.
	 *
	 * @param array $job     رکورد صف.
	 * @param array $payload داده‌ها.
	 * @return bool
	 */
	public function run_queued( $job, $payload ) {
		if ( ! $this->is_enabled() ) {
			return true;
		}

		return $this->send_for_order( (int) $job['object_id'] );
	}

	/**
	 * ارسال یادآوری برای یک سفارش.
	 *
	 * @param int $order_id شناسه.
	 * @return bool
	 */
	public function send_for_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return true;
		}

		$product = $this->pick_product( $order );

		// اگر مشتری قبلاً نظر داده است، رد شود.
		if ( WCMA_Settings::is( 'rr_skip_reviewed' ) && $product && $this->has_reviewed( $order, $product ) ) {
			return true;
		}

		$context = array(
			'order'   => $order,
			'product' => $product,
			'user_id' => $order->get_customer_id(),
		);

		$result = $this->deliver(
			array(
				'context'     => $context,
				'email'       => $order->get_billing_email(),
				'phone'       => $order->get_billing_phone(),
				'user_id'     => $order->get_customer_id(),
				'object_type' => 'order',
				'object_id'   => $order_id,
				'step'        => 'reminder',
			)
		);

		return $result['success'];
	}

	/**
	 * انتخاب محصولی از سفارش که هنوز نظری برایش ثبت نشده است.
	 *
	 * @param WC_Order $order سفارش.
	 * @return WC_Product|null
	 */
	protected function pick_product( $order ) {
		$fallback = null;

		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( ! $product ) {
				continue;
			}

			if ( ! $fallback ) {
				$fallback = $product;
			}

			if ( ! $this->has_reviewed( $order, $product ) ) {
				return $product;
			}
		}

		return $fallback;
	}

	/**
	 * بررسی ثبت نظر توسط این مشتری برای این محصول.
	 *
	 * @param WC_Order   $order   سفارش.
	 * @param WC_Product $product محصول.
	 * @return bool
	 */
	protected function has_reviewed( $order, $product ) {
		$email = $order->get_billing_email();
		if ( ! $email ) {
			return false;
		}

		$comments = get_comments(
			array(
				'post_id'     => $product->get_id(),
				'author_email'=> $email,
				'type'        => 'review',
				'count'       => true,
				'status'      => 'all',
			)
		);

		return $comments > 0;
	}
}
