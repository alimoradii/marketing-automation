<?php
/**
 * کلاس پایه‌ی ورک‌فلوها.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow
 */
abstract class WCMA_Workflow {

	/**
	 * شناسه‌ی یکتای ورک‌فلو.
	 *
	 * @var string
	 */
	protected $id = '';

	/**
	 * عنوان نمایشی.
	 *
	 * @var string
	 */
	protected $title = '';

	/**
	 * پیشوند کلیدهای تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = '';

	/**
	 * سازنده.
	 */
	public function __construct() {
		$this->hooks();
	}

	/**
	 * ثبت هوک‌ها.
	 */
	abstract protected function hooks();

	/**
	 * شناسه.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * عنوان.
	 *
	 * @return string
	 */
	public function get_title() {
		return $this->title;
	}

	/**
	 * آیا ورک‌فلو فعال است؟
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return WCMA_Settings::is( 'enabled' ) && WCMA_Settings::is( $this->prefix . '_enabled' );
	}

	/**
	 * دریافت یک تنظیم مربوط به این ورک‌فلو.
	 *
	 * @param string $key     کلید بدون پیشوند.
	 * @param mixed  $default پیش‌فرض.
	 * @return mixed
	 */
	protected function setting( $key, $default = null ) {
		return WCMA_Settings::get( $this->prefix . '_' . $key, $default );
	}

	/**
	 * انتخاب کانال مؤثر بر اساس اطلاعات تماسی که واقعاً در دست داریم.
	 *
	 * کانال تنظیمات یک ترجیح است، نه الزام: اگر مشتری فقط شماره داده باشد و کانال روی
	 * ایمیل باشد، بی‌کانال کردن او یعنی از دست دادن همان مشتری‌ای که ورک‌فلو برای او
	 * نوشته شده است.
	 *
	 * @param array $contact آرایه‌ای شامل email، phone و در صورت وجود user_id.
	 * @return string
	 */
	protected function resolve_channel( array $contact ) {
		$configured = $this->setting( 'channel', 'email' );

		// «هر دو» فقط وقتی معنا دارد که هر دو راه تماس را داشته باشیم.
		if ( 'both' === $configured ) {
			if ( WCMA_Sender::can_reach( 'both', $contact ) ) {
				return 'both';
			}

			return WCMA_Sender::first_reachable( $contact, 'email' );
		}

		// کانال انتخابی مدیر، اگر برای این مشتری کار می‌کند، همان است.
		if ( WCMA_Sender::can_reach( $configured, $contact ) ) {
			return $configured;
		}

		// وگرنه به ترتیب اولویتی که مدیر در تنظیمات عمومی تعیین کرده جایگزین می‌شود.
		return WCMA_Sender::first_reachable( $contact, $configured );
	}

	/**
	 * اجرای کار زمان‌بندی‌شده‌ی صف (اختیاری).
	 *
	 * @param array $job     رکورد صف.
	 * @param array $payload داده‌ها.
	 * @return bool
	 */
	public function run_queued( $job, $payload ) {
		return false;
	}

	/**
	 * اجرای دوره‌ای (اختیاری).
	 */
	public function run_scheduled() {
	}

	/**
	 * ساخت کد تخفیف بر اساس تنظیمات این ورک‌فلو.
	 *
	 * @param string $email  ایمیل مشتری.
	 * @param array  $args   بازنویسی پارامترها.
	 * @return array|false
	 */
	protected function make_coupon( $email = '', array $args = array() ) {
		$defaults = array(
			'type'      => $this->setting( 'coupon_type', 'percent' ),
			'amount'    => $this->setting( 'coupon_amount', 10 ),
			'days'      => $this->setting( 'coupon_days', 7 ),
			'min_spend' => $this->setting( 'coupon_min_spend', 0 ),
			'email'     => $email,
			'prefix'    => strtoupper( substr( str_replace( '_', '', $this->id ), 0, 3 ) ),
			'workflow'  => $this->title,
		);

		return WCMA_Coupons::create( array_merge( $defaults, $args ) );
	}

	/**
	 * آماده‌سازی و ارسال پیام با استفاده از قالب‌های تنظیمات.
	 *
	 * @param array $args پارامترها.
	 * @return array
	 */
	protected function deliver( array $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'channel'     => $this->setting( 'channel', 'email' ),
				'context'     => array(),
				'subject'     => $this->setting( 'subject', '' ),
				'sms_text'    => $this->setting( 'sms_text', '' ),
				'email_text'  => $this->setting( 'email_text', '' ),
				'email'       => '',
				'phone'       => '',
				'user_id'     => 0,
				'object_type' => 'order',
				'object_id'   => 0,
				'step'        => 'default',
				'coupon_code' => '',
			)
		);

		$context = $args['context'];

		return WCMA_Sender::send(
			array(
				'channel'     => $args['channel'],
				'email'       => $args['email'],
				'phone'       => $args['phone'],
				'user_id'     => $args['user_id'],
				'subject'     => WCMA_Placeholders::replace( $args['subject'], $context ),
				'text'        => WCMA_Placeholders::replace( $args['sms_text'], $context ),
				'html'        => WCMA_Placeholders::replace( $args['email_text'], $context ),
				'workflow'    => $this->id,
				'step'        => $args['step'],
				'object_type' => $args['object_type'],
				'object_id'   => $args['object_id'],
				'coupon_code' => $args['coupon_code'],
			)
		);
	}
}
