<?php
/**
 * ورک‌فلو: هشدار موجودی — «موجود شد خبرم کن».
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Stock_Alert
 */
class WCMA_Workflow_Stock_Alert extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'stock_alert';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'هشدار موجودی';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'st';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		// تغییر وضعیت موجودی محصول ساده و متغیر.
		add_action( 'woocommerce_product_set_stock_status', array( $this, 'on_stock_status' ), 20, 3 );
		add_action( 'woocommerce_variation_set_stock_status', array( $this, 'on_stock_status' ), 20, 3 );

		// تغییر تعداد موجودی (بدون تغییر وضعیت).
		add_action( 'woocommerce_product_set_stock', array( $this, 'on_stock_change' ), 20 );
		add_action( 'woocommerce_variation_set_stock', array( $this, 'on_stock_change' ), 20 );

		// پس از ذخیره‌ی محصول از پیشخوان.
		add_action( 'woocommerce_update_product', array( $this, 'on_product_updated' ), 20 );
		add_action( 'woocommerce_update_product_variation', array( $this, 'on_product_updated' ), 20 );

		// شبکه‌ی ایمنی: اسکن دوره‌ای، مستقل از هر هوکی.
		add_action( 'wcma_scheduled_scan', array( $this, 'run_scheduled' ) );

		// در صورت درخواست مدیر، این ورک‌فلو از ساعات استراحت معاف می‌شود.
		add_filter( 'wcma_quiet_hours_exempt_workflows', array( $this, 'exempt_from_quiet_hours' ) );

		// پاک‌سازی روزانه.
		add_action( 'wcma_daily_scan', array( 'WCMA_Stock_Alerts', 'purge_old' ) );
	}

	/**
	 * معاف کردن این ورک‌فلو از ساعات استراحت در صورت تنظیم مدیر.
	 *
	 * @param array $exempt فهرست ورک‌فلوهای معاف.
	 * @return array
	 */
	public function exempt_from_quiet_hours( $exempt ) {
		if ( WCMA_Settings::is( 'st_ignore_quiet_hours' ) ) {
			$exempt[] = $this->id;
		}

		return (array) $exempt;
	}

	/**
	 * هنگام تغییر وضعیت موجودی.
	 *
	 * @param int        $product_id شناسه.
	 * @param string     $status     وضعیت جدید.
	 * @param WC_Product $product    محصول.
	 */
	public function on_stock_status( $product_id, $status = '', $product = null ) {
		if ( 'instock' !== $status ) {
			return;
		}

		$this->maybe_notify( $product ? $product : wc_get_product( $product_id ) );
	}

	/**
	 * هنگام تغییر تعداد موجودی.
	 *
	 * @param WC_Product $product محصول.
	 */
	public function on_stock_change( $product ) {
		$this->maybe_notify( $product );
	}

	/**
	 * هنگام به‌روزرسانی محصول از پیشخوان.
	 *
	 * @param int $product_id شناسه.
	 */
	public function on_product_updated( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return;
		}

		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$this->maybe_notify( wc_get_product( $child_id ) );
			}

			return;
		}

		$this->maybe_notify( $product );
	}

	/**
	 * بررسی موجود شدن محصول و افزودن اطلاع‌رسانی‌ها به صف.
	 *
	 * @param WC_Product|null $product محصول.
	 */
	public function maybe_notify( $product ) {
		if ( ! $this->is_enabled() || ! $product instanceof WC_Product ) {
			return;
		}

		if ( ! $product->is_in_stock() ) {
			return;
		}

		// شرط اصلی همان وضعیت «موجود» است. حداقل موجودی یک محدودیت اختیاری است و
		// تنها وقتی اعمال می‌شود که مدیر عددی بزرگ‌تر از صفر تنظیم کرده باشد.
		$min = (int) $this->setting( 'min_stock', 0 );

		if ( $min > 0 && $product->managing_stock() ) {
			$qty = $product->get_stock_quantity();

			if ( null !== $qty && $qty < $min ) {
				return;
			}
		}

		$is_variation = $product->is_type( 'variation' );
		$product_id   = $is_variation ? $product->get_parent_id() : $product->get_id();
		$variation_id = $is_variation ? $product->get_id() : 0;

		$alerts = WCMA_Stock_Alerts::pending_for( $product_id, $variation_id );

		if ( ! $alerts ) {
			return;
		}

		$delay = WCMA_Queue::delay_to_seconds( $this->setting( 'delay', 0 ), $this->setting( 'delay_unit', 'minute' ) );
		$base  = current_time( 'mysql' );

		// ارسال فوری فقط وقتی معنا دارد که تأخیری تنظیم نشده، در ساعات استراحت نباشیم
		// و تعداد گیرندگان کم باشد؛ وگرنه درخواست وب کاربر را طولانی می‌کند.
		$immediate = (
			WCMA_Settings::is( 'st_send_immediately' )
			&& 0 === $delay
			&& ( WCMA_Settings::is( 'st_ignore_quiet_hours' ) || ! WCMA_Queue::in_quiet_hours() )
		);

		$immediate_cap = (int) apply_filters( 'wcma_stock_immediate_cap', 25 );
		$sent_now      = 0;

		foreach ( $alerts as $alert ) {
			if ( WCMA_Queue::exists( $this->id, 'notify', 'stock_alert', (int) $alert['id'] ) ) {
				continue;
			}

			// مسیر فوری: منتظر اجرای بعدی کرون نمی‌مانیم. ارزش این ورک‌فلو در همان
			// «لحظه‌ای که موجود شد» است و کرون وردپرس در سایت کم‌بازدید ممکن است
			// دیر یا اصلاً اجرا نشود.
			if ( $immediate && $sent_now < $immediate_cap ) {
				WCMA_Stock_Alerts::set_status( (int) $alert['id'], 'queued' );

				$done = $this->run_queued(
					array(
						'object_id'   => (int) $alert['id'],
						'object_type' => 'stock_alert',
						'workflow'    => $this->id,
						'step'        => 'notify',
					),
					array()
				);

				$sent_now++;

				// موفق یا صرف‌نظر‌شده: کار تمام است.
				if ( $done ) {
					continue;
				}

				// ارسال فوری شکست خورد (مثلاً پنل پیامک موقتاً پاسخ نداد)؛ به صف
				// می‌سپاریم تا زمان‌بند دوباره تلاش کند و مشتری از دست نرود.
			}

			$queued = WCMA_Queue::add(
				array(
					'workflow'     => $this->id,
					'step'         => 'notify',
					'channel'      => $this->setting( 'channel', 'email' ),
					'object_type'  => 'stock_alert',
					'object_id'    => (int) $alert['id'],
					'user_id'      => (int) $alert['user_id'],
					'recipient'    => $alert['email'] ? $alert['email'] : $alert['phone'],
					'payload'      => array( 'notified_product' => $product->get_id() ),
					'scheduled_at' => WCMA_Queue::schedule_from_local( $base, $delay ),
				)
			);

			// فقط در صورت موفقیت صف‌بندی وضعیت را تغییر بده؛ در غیر این صورت درخواست
			// روی «queued» گیر می‌کرد و چون دیگر جزو pending نبود، هرگز ارسال نمی‌شد.
			if ( $queued ) {
				WCMA_Stock_Alerts::set_status( (int) $alert['id'], 'queued' );
			}
		}

		/**
		 * پس از صف‌بندی اطلاع‌رسانی‌های موجودی یک محصول.
		 *
		 * @param WC_Product $product محصول.
		 * @param array      $alerts  درخواست‌ها.
		 */
		do_action( 'wcma_stock_alerts_queued', $product, $alerts );

		$this->notify_admin( $product, count( $alerts ) );
	}

	/**
	 * اطلاع به مدیر درباره‌ی تقاضای موجود.
	 *
	 * @param WC_Product $product محصول.
	 * @param int        $count   تعداد.
	 */
	protected function notify_admin( $product, $count ) {
		if ( ! WCMA_Settings::is( 'st_admin_notify' ) || $count < 1 ) {
			return;
		}

		$to = WCMA_Settings::get( 'error_report_email' );

		if ( ! is_email( $to ) ) {
			$to = get_option( 'admin_email' );
		}

		wp_mail(
			$to,
			sprintf( '[%s] اطلاع‌رسانی موجودی برای %s', get_bloginfo( 'name' ), $product->get_name() ),
			sprintf(
				"محصول «%s» موجود شد و برای %s مشتری منتظر، پیام اطلاع‌رسانی در صف ارسال قرار گرفت.\n\n%s",
				$product->get_name(),
				number_format_i18n( $count ),
				get_permalink( $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id() )
			)
		);
	}

	/**
	 * اجرای کار صف.
	 *
	 * @param array $job     رکورد صف.
	 * @param array $payload داده‌ها.
	 * @return bool
	 */
	public function run_queued( $job, $payload ) {
		if ( ! $this->is_enabled() ) {
			return true;
		}

		$alert = WCMA_Stock_Alerts::get( (int) $job['object_id'] );

		if ( ! $alert || 'notified' === $alert['status'] || 'cancelled' === $alert['status'] ) {
			return true;
		}

		$product_id = ! empty( $alert['variation_id'] ) ? (int) $alert['variation_id'] : (int) $alert['product_id'];
		$product    = wc_get_product( $product_id );

		if ( ! $product ) {
			WCMA_Stock_Alerts::set_status( (int) $alert['id'], 'cancelled' );
			return true;
		}

		// اگر تا زمان ارسال دوباره ناموجود شده، پیام نفرست و در انتظار نگه دار.
		if ( ! $product->is_in_stock() ) {
			WCMA_Stock_Alerts::set_status( (int) $alert['id'], 'pending' );
			return true;
		}

		$coupon = null;

		if ( WCMA_Settings::is( 'st_coupon' ) ) {
			$coupon = $this->make_coupon(
				$alert['email'],
				array(
					'prefix'   => 'STOCK',
					'products' => array( (int) $alert['product_id'] ),
				)
			);
		}

		$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;

		$context = array(
			'user_id' => (int) $alert['user_id'],
			'product' => $product,
			'coupon'  => $coupon ? $coupon : array(),
			'vars'    => array(
				'first_name'    => $alert['first_name'] ? $alert['first_name'] : 'مشتری',
				'email'         => $alert['email'],
				'phone'         => $alert['phone'],
				'product_name'  => $product->get_name(),
				'product_link'  => get_permalink( $parent ? $parent->get_id() : $product->get_id() ),
				'product_price' => trim( wp_strip_all_tags( $product->get_price_html() ) ),
				'stock_qty'     => $product->managing_stock() ? number_format_i18n( (float) $product->get_stock_quantity() ) : '',
				'cancel_link'   => WCMA_Stock_Alerts::cancel_url( $alert ),
			),
		);

		$result = $this->deliver(
			array(
				'channel'     => $this->resolve_channel( $alert ),
				'context'     => $context,
				'email'       => $alert['email'],
				'phone'       => $alert['phone'],
				'user_id'     => (int) $alert['user_id'],
				'object_type' => 'stock_alert',
				'object_id'   => (int) $alert['id'],
				'step'        => 'notify',
				'coupon_code' => $coupon ? $coupon['code'] : '',
			)
		);

		if ( $result['success'] ) {
			WCMA_Stock_Alerts::set_status( (int) $alert['id'], 'notified' );
			return true;
		}

		// شکست ارسال: به حالت انتظار برگردان تا تلاش دوباره ممکن باشد.
		WCMA_Stock_Alerts::set_status( (int) $alert['id'], 'pending' );

		return false;
	}

	/**
	 * اسکن دوره‌ای محصولاتی که کسی منتظرشان است.
	 *
	 * هوک‌های ووکامرس همه‌ی راه‌های تغییر موجودی را پوشش نمی‌دهند: افزونه‌های
	 * انبارداری، درون‌ریزی گروهی، همگام‌سازی با سیستم حسابداری یا نوشتن مستقیم در
	 * دیتابیس هیچ‌کدام لزوماً هوکی اجرا نمی‌کنند. این اسکن مستقل از هوک کار می‌کند و
	 * تنها محصولاتی را می‌بیند که واقعاً کسی در انتظارشان است، پس سبک است.
	 */
	public function run_scheduled() {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$product_ids = WCMA_Stock_Alerts::pending_product_ids( 100 );

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( (int) $product_id );

			if ( ! $product ) {
				continue;
			}

			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $child_id ) {
					$child = wc_get_product( $child_id );

					if ( $child ) {
						$this->maybe_notify( $child );
					}
				}

				// محصول والد هم ممکن است خودش درخواست بدون تنوع داشته باشد.
				$this->maybe_notify( $product );

				continue;
			}

			$this->maybe_notify( $product );
		}
	}

	/**
	 * شبیه‌سازی کامل مسیر اطلاع‌رسانی، قدم‌به‌قدم.
	 *
	 * هر مرحله را جداگانه گزارش می‌دهد تا معلوم شود زنجیره دقیقاً کجا پاره می‌شود:
	 * جدول، تنظیمات، ثبت درخواست، تشخیص موجودی، انتخاب کانال یا خود ارسال.
	 *
	 * @param string $product_id شناسه، نام، کد محصول، لینک یا نامک محصول.
	 * @param string $contact    ایمیل یا شماره‌ی گیرنده‌ی آزمایشی.
	 * @return array{steps:array,success:bool}
	 */
	public function simulate( $product_id, $contact ) {
		$steps   = array();
		$success = false;

		$add = static function ( $label, $ok, $detail = '' ) use ( &$steps ) {
			$steps[] = array(
				'label'  => $label,
				'ok'     => (bool) $ok,
				'detail' => (string) $detail,
			);
		};

		// ۱) جدول.
		$missing = WCMA_Install::missing_tables();
		$add( 'جدول درخواست‌ها در دیتابیس', ! in_array( 'wcma_stock_alerts', $missing, true ), $missing ? 'جدول‌های نداشته: ' . implode( '، ', $missing ) : 'موجود است' );

		if ( in_array( 'wcma_stock_alerts', $missing, true ) ) {
			return array(
				'steps'   => $steps,
				'success' => false,
			);
		}

		// ۲) تنظیمات.
		$add( 'کلید اصلی افزونه', WCMA_Settings::is( 'enabled' ), WCMA_Settings::is( 'enabled' ) ? 'روشن' : 'خاموش است' );
		$add( 'ورک‌فلو هشدار موجودی', WCMA_Settings::is( 'st_enabled' ), WCMA_Settings::is( 'st_enabled' ) ? 'روشن' : 'خاموش است' );

		if ( ! $this->is_enabled() ) {
			return array(
				'steps'   => $steps,
				'success' => false,
			);
		}

		// ۳) محصول — با شناسه، نام، کد محصول، لینک یا نامک.
		$lookup  = WCMA_Stock_Alerts::resolve_product( $product_id );
		$product = $lookup['product'];

		if ( ! $product ) {
			$detail = $lookup['note'];

			if ( ! empty( $lookup['suggestions'] ) ) {
				$names = array();

				foreach ( $lookup['suggestions'] as $suggestion ) {
					$names[] = sprintf( '%s (شناسه %d)', $suggestion['name'], $suggestion['id'] );
				}

				$detail .= ' نزدیک‌ترین گزینه‌ها: ' . implode( '، ', $names );
			} else {
				$samples = WCMA_Stock_Alerts::sample_products( 4 );

				if ( $samples ) {
					$names = array();

					foreach ( $samples as $sample ) {
						$names[] = sprintf( '%s (شناسه %d)', $sample['name'], $sample['id'] );
					}

					$detail .= ' چند محصول اخیر فروشگاه: ' . implode( '، ', $names );
				}
			}

			$add( 'یافتن محصول', false, $detail );

			return array(
				'steps'   => $steps,
				'success' => false,
			);
		}

		$add(
			'یافتن محصول',
			true,
			sprintf( '%s (شناسه %d) — از راه %s', $product->get_name(), $product->get_id(), $lookup['how'] )
		);
		$add(
			'وضعیت موجودی',
			$product->is_in_stock(),
			$product->is_in_stock()
				? ( $product->managing_stock() ? 'موجود، تعداد ' . $product->get_stock_quantity() : 'موجود' )
				: 'ناموجود است — ابتدا محصول را موجود کنید'
		);

		// ادامه دادن پس از این مرحله گمراه‌کننده است: در شرایط واقعی همین‌جا متوقف می‌شود.
		if ( ! $product->is_in_stock() ) {
			return array(
				'steps'   => $steps,
				'success' => false,
			);
		}

		// حداقل موجودی تنها وقتی مانع است که مدیر آن را بزرگ‌تر از صفر گذاشته باشد.
		if ( $product->managing_stock() && (int) $this->setting( 'min_stock', 0 ) > 0 ) {
			$min = (int) $this->setting( 'min_stock', 0 );
			$qty = $product->get_stock_quantity();
			$ok  = ( null === $qty ) || ( $qty >= $min );

			$add(
				'حداقل موجودی لازم',
				$ok,
				$ok
					? sprintf( 'موجودی %s ≥ حد لازم %s', number_format_i18n( (float) $qty ), number_format_i18n( $min ) )
					: sprintf( 'موجودی %s کمتر از حد لازم %s است — پیامی ارسال نمی‌شود', number_format_i18n( (float) $qty ), number_format_i18n( $min ) )
			);

			if ( ! $ok ) {
				return array(
					'steps'   => $steps,
					'success' => false,
				);
			}
		}

		// ۴) درخواست آزمایشی.
		$parsed = self::parse_contact( $contact );

		if ( ! $parsed ) {
			$add( 'اطلاعات تماس آزمایشی', false, 'مقدار واردشده نه ایمیل معتبر است و نه شماره موبایل.' );

			return array(
				'steps'   => $steps,
				'success' => false,
			);
		}

		$add( 'اطلاعات تماس آزمایشی', true, ( 'email' === $parsed['type'] ? 'ایمیل: ' : 'موبایل: ' ) . $parsed['value'] );

		$alert = array(
			'id'           => 0,
			'product_id'   => $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id(),
			'variation_id' => $product->is_type( 'variation' ) ? $product->get_id() : 0,
			'user_id'      => 0,
			'email'        => 'email' === $parsed['type'] ? $parsed['value'] : '',
			'phone'        => 'phone' === $parsed['type'] ? $parsed['value'] : '',
			'first_name'   => 'مشتری آزمایشی',
			'status'       => 'pending',
			'token'        => 'simulation',
		);

		// ۵) کانال مؤثر.
		$channel = $this->resolve_channel( $alert );
		$labels  = WCMA_Sender::channels();
		$add(
			'کانال انتخاب‌شده',
			true,
			sprintf( 'تنظیمات: %s ← استفاده‌شده: %s', $labels[ $this->setting( 'channel', 'email' ) ] ?? '-', $labels[ $channel ] ?? $channel )
		);

		// ۶) صف در انتظار.
		$waiting = WCMA_Stock_Alerts::count_pending( (int) $alert['product_id'] );
		$add( 'مشتریان واقعی در انتظار این محصول', true, number_format_i18n( $waiting ) . ' نفر' );

		// ۷) ارسال واقعی.
		$parent  = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		$context = array(
			'product' => $product,
			'vars'    => array(
				'first_name'    => 'مشتری آزمایشی',
				'email'         => $alert['email'],
				'phone'         => $alert['phone'],
				'product_name'  => $product->get_name(),
				'product_link'  => get_permalink( $parent ? $parent->get_id() : $product->get_id() ),
				'product_price' => trim( wp_strip_all_tags( $product->get_price_html() ) ),
				'stock_qty'     => $product->managing_stock() ? (string) $product->get_stock_quantity() : '',
				'cancel_link'   => home_url(),
				'coupon_code'   => 'TESTCODE',
				'coupon_expiry' => date_i18n( 'Y/m/d' ),
			),
		);

		$result = WCMA_Sender::send(
			array(
				'channel'     => $channel,
				'email'       => $alert['email'],
				'phone'       => $alert['phone'],
				'subject'     => WCMA_Placeholders::replace( $this->setting( 'subject', '' ), $context ),
				'text'        => WCMA_Placeholders::replace( $this->setting( 'sms_text', '' ), $context ),
				'html'        => WCMA_Placeholders::replace( $this->setting( 'email_text', '' ), $context ),
				'workflow'    => $this->id,
				'step'        => 'simulate',
				'object_type' => 'stock_alert',
				'object_id'   => 0,
				'skip_optout' => true,
			)
		);

		$add( 'ارسال واقعی پیام', $result['success'], $result['message'] );

		$success = (bool) $result['success'];

		return array(
			'steps'   => $steps,
			'success' => $success,
		);
	}

	/**
	 * تشخیص نوع اطلاعات تماس.
	 *
	 * @param string $contact ورودی.
	 * @return array|false
	 */
	public static function parse_contact( $contact ) {
		$contact = trim( (string) $contact );

		if ( '' === $contact ) {
			return false;
		}

		if ( false !== strpos( $contact, '@' ) ) {
			$email = sanitize_email( $contact );

			return is_email( $email ) ? array(
				'type'  => 'email',
				'value' => $email,
			) : false;
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( $contact );

		return $phone ? array(
			'type'  => 'phone',
			'value' => $phone,
		) : false;
	}

	/**
	 * ارسال دستی برای یک محصول (از پیشخوان).
	 *
	 * @param int $product_id شناسه.
	 * @return array
	 */
	public function send_now_for_product( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return array(
				'success' => false,
				'message' => 'محصول پیدا نشد.',
			);
		}

		if ( ! $product->is_in_stock() ) {
			return array(
				'success' => false,
				'message' => 'این محصول هنوز موجود نیست.',
			);
		}

		$before = WCMA_Stock_Alerts::count_pending( $product_id );

		$this->maybe_notify( $product );

		$after = WCMA_Stock_Alerts::count_pending( $product_id );
		$sent  = max( 0, $before - $after );

		return array(
			'success' => $sent > 0,
			'message' => $sent > 0
				? sprintf( '%s اطلاع‌رسانی در صف ارسال قرار گرفت.', number_format_i18n( $sent ) )
				: 'درخواست در انتظاری برای این محصول وجود ندارد.',
		);
	}
}
