<?php
/**
 * ورک‌فلو ۴: خرید مجدد (بازگرداندن مشتریان غیرفعال).
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Workflow_Winback
 */
class WCMA_Workflow_Winback extends WCMA_Workflow {

	/**
	 * شناسه.
	 *
	 * @var string
	 */
	protected $id = 'winback';

	/**
	 * عنوان.
	 *
	 * @var string
	 */
	protected $title = 'خرید مجدد';

	/**
	 * پیشوند تنظیمات.
	 *
	 * @var string
	 */
	protected $prefix = 'wb';

	/**
	 * ثبت هوک‌ها.
	 */
	protected function hooks() {
		add_action( 'wcma_daily_scan', array( $this, 'run_scheduled' ) );
	}

	/**
	 * یافتن مشتریان غیرفعال و ارسال پیشنهاد.
	 */
	public function run_scheduled() {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$customers = $this->find_inactive_customers();

		foreach ( $customers as $customer ) {
			$this->send_to_customer( $customer );
		}
	}

	/**
	 * یافتن مشتریان بدون خرید در بازه‌ی مشخص.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public function find_inactive_customers( $limit = 50 ) {
		global $wpdb;

		$days       = max( 1, (int) $this->setting( 'inactive_days', 60 ) );
		$min_orders = max( 1, (int) $this->setting( 'min_orders', 1 ) );
		// ستون‌های date_created_gmt و post_date_gmt به وقت UTC هستند.
		$cutoff     = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		$statuses = array( 'wc-completed', 'wc-processing' );

		// پشتیبانی از HPOS و همچنین ذخیره‌سازی کلاسیک.
		if ( self::hpos_enabled() ) {
			$orders_table = $wpdb->prefix . 'wc_orders';
			$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

			$sql = "SELECT billing_email AS email, MAX(date_created_gmt) AS last_order, COUNT(*) AS order_count, customer_id
					FROM {$orders_table}
					WHERE status IN ({$placeholders}) AND billing_email <> ''
					GROUP BY billing_email, customer_id
					HAVING last_order < %s AND order_count >= %d
					ORDER BY last_order DESC
					LIMIT %d";

			$params = array_merge( $statuses, array( $cutoff, $min_orders, (int) $limit ) );
		} else {
			$sql = "SELECT pm.meta_value AS email, MAX(p.post_date_gmt) AS last_order, COUNT(*) AS order_count, 0 AS customer_id
					FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_billing_email'
					WHERE p.post_type = 'shop_order' AND p.post_status IN (" . implode( ',', array_fill( 0, count( $statuses ), '%s' ) ) . ") AND pm.meta_value <> ''
					GROUP BY pm.meta_value
					HAVING last_order < %s AND order_count >= %d
					ORDER BY last_order DESC
					LIMIT %d";

			$params = array_merge( $statuses, array( $cutoff, $min_orders, (int) $limit ) );
		}

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $rows ? $rows : array();
	}

	/**
	 * آیا ووکامرس از جدول سفارش سفارشی استفاده می‌کند؟
	 *
	 * @return bool
	 */
	public static function hpos_enabled() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) ) {
			return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		}
		return false;
	}

	/**
	 * ارسال پیام خرید مجدد به یک مشتری.
	 *
	 * @param array $customer اطلاعات مشتری.
	 * @return bool
	 */
	public function send_to_customer( array $customer ) {
		$email = $customer['email'] ?? '';
		if ( ! is_email( $email ) ) {
			return false;
		}

		if ( WCMA_Subscribers::is_opted_out( $email ) ) {
			return false;
		}

		$user    = get_user_by( 'email', $email );
		$user_id = $user ? $user->ID : (int) ( $customer['customer_id'] ?? 0 );

		// جلوگیری از ارسال مکرر.
		$repeat_days = max( 1, (int) $this->setting( 'repeat_days', 90 ) );
		$last        = $this->last_sent_to_email( $email );

		if ( $last && ( current_time( 'timestamp' ) - strtotime( $last ) ) < ( $repeat_days * DAY_IN_SECONDS ) ) { // phpcs:ignore WordPress.DateTime
			return false;
		}

		$coupon = null;
		if ( WCMA_Settings::is( 'wb_coupon' ) ) {
			$coupon = $this->make_coupon( $email, array( 'prefix' => 'BACK' ) );
		}

		$order = $this->last_order_of( $email );
		$phone = $order ? $order->get_billing_phone() : '';
		$first = $order ? $order->get_billing_first_name() : '';

		$context = array(
			'user_id' => $user_id,
			'coupon'  => $coupon ? $coupon : array(),
			'vars'    => array(
				'first_name' => $first ? $first : 'مشتری',
				'email'      => $email,
				'phone'      => $phone,
			),
		);

		$result = $this->deliver(
			array(
				'context'     => $context,
				'email'       => $email,
				'phone'       => $phone,
				'user_id'     => $user_id,
				'object_type' => 'customer',
				'object_id'   => $user_id ? $user_id : crc32( $email ),
				'step'        => 'winback',
				'coupon_code' => $coupon ? $coupon['code'] : '',
			)
		);

		return $result['success'];
	}

	/**
	 * آخرین زمان ارسال به یک ایمیل در این ورک‌فلو.
	 *
	 * @param string $email ایمیل.
	 * @return string|null
	 */
	protected function last_sent_to_email( $email ) {
		global $wpdb;

		$table = WCMA_Logger::table();
		return $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT created_at FROM {$table} WHERE workflow = %s AND recipient = %s AND status = 'sent' ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB
				$this->id,
				$email
			)
		);
	}

	/**
	 * آخرین سفارش یک ایمیل.
	 *
	 * @param string $email ایمیل.
	 * @return WC_Order|null
	 */
	protected function last_order_of( $email ) {
		$orders = wc_get_orders(
			array(
				'billing_email' => $email,
				'limit'         => 1,
				'orderby'       => 'date',
				'order'         => 'DESC',
			)
		);

		return ! empty( $orders[0] ) && $orders[0] instanceof WC_Order ? $orders[0] : null;
	}
}
