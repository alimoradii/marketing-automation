<?php
/**
 * ثبت‌نام و ورود با شماره موبایل.
 *
 * کاربر واقعیِ وردپرس ساخته می‌شود، نه یک حساب موازی؛ این‌طور سفارش‌ها،
 * صفحه‌ی «حساب کاربری» ووکامرس و پرونده‌ی مشتریان همه به یک نفر می‌خورند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Accounts
 */
class WCMA_Accounts {

	/**
	 * کلید متای شماره‌ی موبایلِ خود افزونه.
	 *
	 * ووکامرس شماره را در billing_phone نگه می‌دارد و کاربر می‌تواند عوضش
	 * کند؛ شماره‌ی ورود باید جدا و ثابت بماند.
	 */
	const PHONE_META = 'wcma_phone';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * آیا ورود با موبایل روشن است؟
	 *
	 * @return bool
	 */
	public static function is_on() {
		return WCMA_Settings::is( 'panel_enabled' );
	}

	/**
	 * ثبت مسیرهای REST.
	 */
	public static function register_routes() {
		$public = array( 'permission_callback' => '__return_true' );

		register_rest_route(
			'wcma/v1',
			'/auth/code',
			array_merge( $public, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_code' ) ) )
		);

		register_rest_route(
			'wcma/v1',
			'/auth/verify',
			array_merge( $public, array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_verify' ) ) )
		);
	}

	/**
	 * کاربری که این شماره مال اوست.
	 *
	 * @param string $phone شماره.
	 * @return WP_User|null
	 */
	public static function find( $phone ) {
		$phone = WCMA_SMS_Gateways::normalize_phone( $phone );

		if ( '' === $phone ) {
			return null;
		}

		$found = get_users(
			array(
				'meta_key'   => self::PHONE_META, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => $phone,           // phpcs:ignore WordPress.DB.SlowDBQuery
				'number'     => 1,
				'fields'     => 'all',
			)
		);

		if ( $found ) {
			return $found[0];
		}

		/*
		 * سایتی که پیش از این افزونه کاربر داشته، شماره را فقط در
		 * billing_phone دارد؛ آن‌ها هم باید بتوانند وارد شوند.
		 */
		$legacy = get_users(
			array(
				'meta_key'   => 'billing_phone', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => $phone,          // phpcs:ignore WordPress.DB.SlowDBQuery
				'number'     => 1,
				'fields'     => 'all',
			)
		);

		return $legacy ? $legacy[0] : null;
	}

	/**
	 * درخواست کد؛ همان مسیر ثبت‌نام و ورود.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_code( $request ) {
		if ( ! self::is_on() ) {
			return self::reply( false, 'پنل کاربری فعال نیست.' );
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( (string) $request->get_param( 'phone' ) );

		if ( '' === $phone ) {
			return self::reply( false, 'شماره موبایل معتبر نیست.' );
		}

		$user   = self::find( $phone );
		$known  = (bool) $user;
		$result = WCMA_OTP::request( $phone, $known ? 'login' : 'register' );

		return self::reply(
			! empty( $result['success'] ),
			(string) $result['message'],
			array(
				// رابط از این می‌فهمد که نام و نام خانوادگی هم باید پرسیده شود.
				'known' => $known,
				'wait'  => (int) ( $result['wait'] ?? 0 ),
			)
		);
	}

	/**
	 * بررسی کد و ورود یا ثبت‌نام.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function rest_verify( $request ) {
		if ( ! self::is_on() ) {
			return self::reply( false, 'پنل کاربری فعال نیست.' );
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( (string) $request->get_param( 'phone' ) );
		$code  = (string) $request->get_param( 'code' );
		$first = trim( sanitize_text_field( (string) $request->get_param( 'first_name' ) ) );
		$last  = trim( sanitize_text_field( (string) $request->get_param( 'last_name' ) ) );

		$check = WCMA_OTP::verify( $phone, $code );

		if ( empty( $check['success'] ) ) {
			return self::reply( false, (string) $check['message'] );
		}

		$user = self::find( $phone );

		if ( ! $user ) {
			if ( '' === $first ) {
				return self::reply( false, 'برای ثبت‌نام، نام خود را وارد کنید.' );
			}

			$user_id = self::create( $phone, $first, $last );

			if ( is_wp_error( $user_id ) ) {
				return self::reply( false, $user_id->get_error_message() );
			}

			$user = get_userdata( $user_id );
		} elseif ( $first ) {
			// نامی که هنگام ورود داده شده، فقط اگر جای خالی باشد پر می‌شود.
			self::fill_name( $user, $first, $last );
		}

		if ( ! $user ) {
			return self::reply( false, 'ساخت حساب انجام نشد.' );
		}

		self::sign_in( (int) $user->ID );

		return self::reply(
			true,
			'خوش آمدید.',
			array(
				'name' => self::display_name( $user ),
				'url'  => WCMA_Panel::url(),
			)
		);
	}

	/**
	 * ساخت کاربر تازه.
	 *
	 * @param string $phone شماره.
	 * @param string $first نام.
	 * @param string $last  نام خانوادگی.
	 * @return int|WP_Error
	 */
	public static function create( $phone, $first, $last = '' ) {
		$phone = WCMA_SMS_Gateways::normalize_phone( $phone );

		if ( '' === $phone ) {
			return new WP_Error( 'wcma_phone', 'شماره موبایل معتبر نیست.' );
		}

		if ( self::find( $phone ) ) {
			return new WP_Error( 'wcma_exists', 'این شماره از قبل ثبت شده است.' );
		}

		$login = self::free_login( $phone );

		$user_id = wp_insert_user(
			array(
				'user_login'   => $login,
				// رمز تصادفیِ بلند: ورود با کد است، پس کسی این رمز را نمی‌بیند.
				'user_pass'    => wp_generate_password( 24, true, true ),
				'first_name'   => $first,
				'last_name'    => $last,
				'display_name' => trim( $first . ' ' . $last ),
				'role'         => self::role(),
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		update_user_meta( $user_id, self::PHONE_META, $phone );
		update_user_meta( $user_id, 'billing_phone', $phone );
		update_user_meta( $user_id, 'billing_first_name', $first );
		update_user_meta( $user_id, 'billing_last_name', $last );

		// پرونده‌ی مشتری همان لحظه ساخته می‌شود تا سرنخ از دست نرود.
		if ( class_exists( 'WCMA_CRM' ) ) {
			WCMA_CRM::upsert(
				array(
					'user_id'    => $user_id,
					'phone'      => $phone,
					'first_name' => $first,
					'last_name'  => $last,
					'source'     => 'panel',
					'stage'      => 'lead',
				)
			);
		}

		/**
		 * پس از ثبت‌نام با موبایل.
		 *
		 * @param int    $user_id کاربر.
		 * @param string $phone   شماره.
		 */
		do_action( 'wcma_user_registered', $user_id, $phone );

		return (int) $user_id;
	}

	/**
	 * نقشی که کاربر تازه می‌گیرد.
	 *
	 * @return string
	 */
	public static function role() {
		$role = (string) WCMA_Settings::get( 'panel_role', '' );

		if ( $role && get_role( $role ) ) {
			return $role;
		}

		return get_role( 'customer' ) ? 'customer' : 'subscriber';
	}

	/**
	 * نام کاربریِ آزاد بر پایه‌ی شماره.
	 *
	 * @param string $phone شماره.
	 * @return string
	 */
	protected static function free_login( $phone ) {
		$base  = $phone;
		$login = $base;
		$n     = 1;

		while ( username_exists( $login ) ) {
			$login = $base . '_' . $n;
			$n++;
		}

		return $login;
	}

	/**
	 * پر کردن نامِ خالی.
	 *
	 * @param WP_User $user  کاربر.
	 * @param string  $first نام.
	 * @param string  $last  نام خانوادگی.
	 */
	protected static function fill_name( $user, $first, $last ) {
		$data = array();

		if ( '' === trim( (string) $user->first_name ) ) {
			$data['first_name'] = $first;
		}

		if ( $last && '' === trim( (string) $user->last_name ) ) {
			$data['last_name'] = $last;
		}

		if ( $data ) {
			$data['ID'] = $user->ID;
			wp_update_user( $data );
		}
	}

	/**
	 * نشاندن کاربر در نشست.
	 *
	 * @param int $user_id کاربر.
	 */
	public static function sign_in( $user_id ) {
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, true );

		do_action( 'wp_login', get_userdata( $user_id )->user_login, get_userdata( $user_id ) );
	}

	/**
	 * نام خواندنی کاربر.
	 *
	 * @param WP_User|int $user کاربر.
	 * @return string
	 */
	public static function display_name( $user ) {
		$user = is_numeric( $user ) ? get_userdata( (int) $user ) : $user;

		if ( ! $user ) {
			return '';
		}

		$name = trim( (string) $user->first_name . ' ' . (string) $user->last_name );

		if ( '' !== $name ) {
			return $name;
		}

		return (string) ( $user->display_name ? $user->display_name : $user->user_login );
	}

	/**
	 * شماره‌ی موبایل کاربر.
	 *
	 * @param int $user_id کاربر.
	 * @return string
	 */
	public static function phone( $user_id ) {
		$phone = (string) get_user_meta( (int) $user_id, self::PHONE_META, true );

		if ( '' === $phone ) {
			$phone = (string) get_user_meta( (int) $user_id, 'billing_phone', true );
		}

		return $phone;
	}

	/**
	 * پاسخ یکدست REST.
	 *
	 * @param bool   $ok      موفق؟
	 * @param string $message پیام.
	 * @param array  $extra   داده‌ی اضافه.
	 * @return WP_REST_Response
	 */
	protected static function reply( $ok, $message, array $extra = array() ) {
		return new WP_REST_Response(
			array_merge( array( 'ok' => (bool) $ok, 'message' => $message ), $extra ),
			200
		);
	}
}
