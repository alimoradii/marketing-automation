<?php
/**
 * کمپین‌های گروهی ایمیل / پیامک / تلگرام.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Campaigns
 */
class WCMA_Campaigns {

	/**
	 * نام جدول کمپین‌ها.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcma_campaigns';
	}

	/**
	 * راه‌اندازی هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_worker_tick', array( __CLASS__, 'process_running' ) );
	}

	/**
	 * فهرست انواع مخاطب.
	 *
	 * @return array
	 */
	public static function audience_types() {
		return array(
			'all_customers'  => 'همه‌ی مشتریان (دارای حداقل یک سفارش)',
			'all_users'      => 'همه‌ی کاربران سایت',
			'buyers_product' => 'خریداران یک محصول مشخص',
			'buyers_cat'     => 'خریداران یک دسته‌بندی',
			'top_spenders'   => 'مشتریان با خرید بیش از مبلغ مشخص',
			'inactive'       => 'مشتریان غیرفعال (بدون خرید در N روز)',
			'no_orders'      => 'کاربران بدون هیچ خرید',
			'manual'         => 'فهرست دستی (ایمیل یا شماره در هر خط)',
		);
	}

	/**
	 * ذخیره‌ی کمپین.
	 *
	 * @param array $data داده‌ها.
	 * @return int
	 */
	public static function save( array $data ) {
		global $wpdb;

		$row = array(
			'title'        => sanitize_text_field( $data['title'] ?? '' ),
			'channel'      => sanitize_text_field( $data['channel'] ?? 'email' ),
			'subject'      => sanitize_text_field( $data['subject'] ?? '' ),
			'content'      => wp_kses_post( $data['content'] ?? '' ),
			'audience'     => wp_json_encode( $data['audience'] ?? array() ),
			'status'       => sanitize_text_field( $data['status'] ?? 'draft' ),
			'scheduled_at' => ! empty( $data['scheduled_at'] ) ? $data['scheduled_at'] : null,
			'updated_at'   => current_time( 'mysql' ),
		);

		if ( ! empty( $data['id'] ) ) {
			$wpdb->update( self::table(), $row, array( 'id' => (int) $data['id'] ) ); // phpcs:ignore WordPress.DB
			return (int) $data['id'];
		}

		$row['created_at'] = current_time( 'mysql' );
		$wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB

		return (int) $wpdb->insert_id;
	}

	/**
	 * دریافت یک کمپین.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		if ( $row ) {
			$row['audience'] = json_decode( (string) $row['audience'], true );
			if ( ! is_array( $row['audience'] ) ) {
				$row['audience'] = array();
			}
		}

		return $row;
	}

	/**
	 * فهرست کمپین‌ها.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public static function all( $limit = 50, $page = 1 ) {
		global $wpdb;

		$table  = self::table();
		$limit  = max( 1, (int) $limit );
		$offset = ( max( 1, (int) $page ) - 1 ) * $limit;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $rows ? $rows : array();
	}

	/**
	 * شمار کل کمپین‌ها.
	 *
	 * @return int
	 */
	public static function count() {
		global $wpdb;

		$table = self::table();

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * حذف کمپین.
	 *
	 * @param int $id شناسه.
	 */
	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB
		WCMA_Queue::cancel_for_object( 'campaign', (int) $id );
	}

	/**
	 * تغییر وضعیت کمپین.
	 *
	 * @param int   $id     شناسه.
	 * @param string $status وضعیت.
	 * @param array  $extra  فیلدهای اضافی.
	 */
	public static function set_status( $id, $status, array $extra = array() ) {
		global $wpdb;

		$data = array_merge(
			array(
				'status'     => $status,
				'updated_at' => current_time( 'mysql' ),
			),
			$extra
		);

		$wpdb->update( self::table(), $data, array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * ساخت فهرست گیرندگان بر اساس تعریف مخاطب.
	 *
	 * @param array $audience تعریف مخاطب.
	 * @return array فهرست آرایه‌هایی با کلیدهای email/phone/first_name/user_id.
	 */
	public static function resolve_recipients( array $audience ) {
		$type       = $audience['type'] ?? 'all_customers';
		$recipients = array();

		switch ( $type ) {
			case 'manual':
				$lines = preg_split( '/\r\n|\r|\n/', (string) ( $audience['manual_list'] ?? '' ) );
				foreach ( (array) $lines as $line ) {
					$line = trim( $line );
					if ( '' === $line ) {
						continue;
					}
					if ( is_email( $line ) ) {
						$recipients[] = array(
							'email'      => $line,
							'phone'      => '',
							'first_name' => '',
							'user_id'    => 0,
						);
					} else {
						$phone = WCMA_SMS_Gateways::normalize_phone( $line );
						if ( $phone ) {
							$recipients[] = array(
								'email'      => '',
								'phone'      => $phone,
								'first_name' => '',
								'user_id'    => 0,
							);
						}
					}
				}
				break;

			case 'all_users':
				$users = get_users( array( 'number' => 5000 ) );
				foreach ( $users as $user ) {
					$recipients[] = self::user_to_recipient( $user->ID, $user->user_email );
				}
				break;

			case 'no_orders':
				$users = get_users( array( 'number' => 5000 ) );
				foreach ( $users as $user ) {
					$count = wc_get_customer_order_count( $user->ID );
					if ( 0 === (int) $count ) {
						$recipients[] = self::user_to_recipient( $user->ID, $user->user_email );
					}
				}
				break;

			case 'buyers_product':
			case 'buyers_cat':
				$recipients = self::buyers_of( $type, $audience );
				break;

			case 'top_spenders':
				$recipients = self::top_spenders( (float) ( $audience['min_spend'] ?? 0 ) );
				break;

			case 'inactive':
				$days     = max( 1, (int) ( $audience['inactive_days'] ?? 60 ) );
				$winback  = new WCMA_Workflow_Winback();
				$settings = WCMA_Settings::all();

				// استفاده‌ی موقت از تنظیم روزهای غیرفعالی.
				WCMA_Settings::update( array( 'wb_inactive_days' => $days ) );
				$rows = $winback->find_inactive_customers( 2000 );
				WCMA_Settings::update( array( 'wb_inactive_days' => $settings['wb_inactive_days'] ) );

				foreach ( $rows as $row ) {
					$recipients[] = self::email_to_recipient( $row['email'] );
				}
				break;

			case 'all_customers':
			default:
				$recipients = self::all_customers();
				break;
		}

		// حذف تکراری‌ها و لغو اشتراک‌شده‌ها.
		$seen   = array();
		$output = array();

		foreach ( $recipients as $recipient ) {
			$key = $recipient['email'] ? strtolower( $recipient['email'] ) : $recipient['phone'];
			if ( ! $key || isset( $seen[ $key ] ) ) {
				continue;
			}
			if ( $recipient['email'] && WCMA_Subscribers::is_opted_out( $recipient['email'] ) ) {
				continue;
			}

			$seen[ $key ] = true;
			$output[]     = $recipient;
		}

		/**
		 * فیلتر فهرست نهایی گیرندگان کمپین.
		 *
		 * @param array $output   گیرندگان.
		 * @param array $audience تعریف مخاطب.
		 */
		return apply_filters( 'wcma_campaign_recipients', $output, $audience );
	}

	/**
	 * همه‌ی مشتریان دارای سفارش.
	 *
	 * @return array
	 */
	protected static function all_customers() {
		global $wpdb;

		if ( WCMA_Workflow_Winback::hpos_enabled() ) {
			$table = $wpdb->prefix . 'wc_orders';
			$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
				"SELECT DISTINCT billing_email AS email, customer_id FROM {$table} WHERE billing_email <> '' AND status NOT IN ('wc-failed','trash') LIMIT 5000", // phpcs:ignore WordPress.DB
				ARRAY_A
			);
		} else {
			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				"SELECT DISTINCT pm.meta_value AS email, 0 AS customer_id
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = '_billing_email' AND pm.meta_value <> '' AND p.post_type = 'shop_order' LIMIT 5000",
				ARRAY_A
			);
		}

		$recipients = array();
		foreach ( (array) $rows as $row ) {
			$recipients[] = self::email_to_recipient( $row['email'], (int) ( $row['customer_id'] ?? 0 ) );
		}

		return $recipients;
	}

	/**
	 * خریداران یک محصول یا دسته‌بندی.
	 *
	 * @param string $type     نوع.
	 * @param array  $audience تعریف.
	 * @return array
	 */
	protected static function buyers_of( $type, array $audience ) {
		$product_ids = array();

		if ( 'buyers_product' === $type ) {
			$product_ids = array_map( 'intval', (array) ( $audience['product_ids'] ?? array() ) );
		} else {
			$cat_ids = array_map( 'intval', (array) ( $audience['category_ids'] ?? array() ) );
			if ( $cat_ids ) {
				$product_ids = get_posts(
					array(
						'post_type'      => 'product',
						'posts_per_page' => 500,
						'fields'         => 'ids',
						// phpcs:ignore WordPress.DB.SlowDBQuery
						'tax_query'      => array(
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $cat_ids,
							),
						),
					)
				);
			}
		}

		if ( ! $product_ids ) {
			return array();
		}

		$orders = wc_get_orders(
			array(
				'status' => array( 'completed', 'processing' ),
				'limit'  => 2000,
			)
		);

		$recipients = array();

		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			foreach ( $order->get_items() as $item ) {
				$pid = $item->get_product_id();
				if ( in_array( (int) $pid, $product_ids, true ) ) {
					$recipients[] = array(
						'email'      => $order->get_billing_email(),
						'phone'      => $order->get_billing_phone(),
						'first_name' => $order->get_billing_first_name(),
						'user_id'    => $order->get_customer_id(),
					);
					break;
				}
			}
		}

		return $recipients;
	}

	/**
	 * مشتریان با مجموع خرید بالاتر از حد مشخص.
	 *
	 * @param float $min_spend حداقل مبلغ.
	 * @return array
	 */
	protected static function top_spenders( $min_spend ) {
		$orders = wc_get_orders(
			array(
				'status' => array( 'completed' ),
				'limit'  => 3000,
			)
		);

		$totals = array();

		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$email = $order->get_billing_email();
			if ( ! $email ) {
				continue;
			}

			if ( ! isset( $totals[ $email ] ) ) {
				$totals[ $email ] = array(
					'total'      => 0,
					'phone'      => $order->get_billing_phone(),
					'first_name' => $order->get_billing_first_name(),
					'user_id'    => $order->get_customer_id(),
				);
			}

			$totals[ $email ]['total'] += (float) $order->get_total();
		}

		$recipients = array();

		foreach ( $totals as $email => $info ) {
			if ( $info['total'] >= $min_spend ) {
				$recipients[] = array(
					'email'      => $email,
					'phone'      => $info['phone'],
					'first_name' => $info['first_name'],
					'user_id'    => $info['user_id'],
				);
			}
		}

		return $recipients;
	}

	/**
	 * ساخت گیرنده از شناسه‌ی کاربر.
	 *
	 * @param int    $user_id شناسه.
	 * @param string $email   ایمیل.
	 * @return array
	 */
	protected static function user_to_recipient( $user_id, $email = '' ) {
		$billing_email = get_user_meta( $user_id, 'billing_email', true );

		return array(
			'email'      => $billing_email ? $billing_email : $email,
			'phone'      => get_user_meta( $user_id, 'billing_phone', true ),
			'first_name' => get_user_meta( $user_id, 'billing_first_name', true ),
			'user_id'    => (int) $user_id,
		);
	}

	/**
	 * ساخت گیرنده از ایمیل.
	 *
	 * @param string $email   ایمیل.
	 * @param int    $user_id شناسه‌ی کاربر.
	 * @return array
	 */
	protected static function email_to_recipient( $email, $user_id = 0 ) {
		$phone = '';
		$first = '';

		if ( ! $user_id ) {
			$user    = get_user_by( 'email', $email );
			$user_id = $user ? $user->ID : 0;
		}

		if ( $user_id ) {
			$phone = get_user_meta( $user_id, 'billing_phone', true );
			$first = get_user_meta( $user_id, 'billing_first_name', true );
		}

		if ( ! $phone ) {
			$orders = wc_get_orders(
				array(
					'billing_email' => $email,
					'limit'         => 1,
					'orderby'       => 'date',
					'order'         => 'DESC',
				)
			);

			if ( ! empty( $orders[0] ) && $orders[0] instanceof WC_Order ) {
				$phone = $orders[0]->get_billing_phone();
				$first = $first ? $first : $orders[0]->get_billing_first_name();
			}
		}

		return array(
			'email'      => $email,
			'phone'      => $phone,
			'first_name' => $first,
			'user_id'    => (int) $user_id,
		);
	}

	/**
	 * شروع ارسال یک کمپین (افزودن گیرندگان به صف).
	 *
	 * @param int $campaign_id شناسه.
	 * @return array
	 */
	public static function start( $campaign_id ) {
		$campaign = self::get( $campaign_id );
		if ( ! $campaign ) {
			return array(
				'success' => false,
				'message' => 'کمپین یافت نشد.',
			);
		}

		$recipients = self::resolve_recipients( $campaign['audience'] );
		if ( ! $recipients ) {
			return array(
				'success' => false,
				'message' => 'هیچ گیرنده‌ای با این شرایط پیدا نشد.',
			);
		}

		global $wpdb;
		$queued = 0;
		$now    = current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime
		$start  = ! empty( $campaign['scheduled_at'] ) ? strtotime( $campaign['scheduled_at'] ) : $now;
		$start  = max( $start, $now );

		$batch_size = max( 1, (int) WCMA_Settings::get( 'campaign_batch_size', 50 ) );
		$interval   = max( 1, (int) WCMA_Settings::get( 'campaign_interval', 5 ) ) * MINUTE_IN_SECONDS;

		foreach ( array_values( $recipients ) as $index => $recipient ) {
			$offset = floor( $index / $batch_size ) * $interval;

			$wpdb->insert( // phpcs:ignore WordPress.DB
				WCMA_Queue::table(),
				array(
					'workflow'     => 'campaign',
					'step'         => 'campaign_' . $campaign_id,
					'channel'      => $campaign['channel'],
					'object_type'  => 'campaign',
					'object_id'    => (int) $campaign_id,
					'user_id'      => (int) $recipient['user_id'],
					'recipient'    => $recipient['email'] ? $recipient['email'] : $recipient['phone'],
					'payload'      => wp_json_encode( $recipient ),
					'status'       => 'pending',
					'scheduled_at' => gmdate( 'Y-m-d H:i:s', $start + $offset ),
					'created_at'   => current_time( 'mysql' ),
				)
			);

			$queued++;
		}

		self::set_status(
			$campaign_id,
			'running',
			array(
				'total_recipients' => $queued,
				'sent_count'       => 0,
				'failed_count'     => 0,
			)
		);

		return array(
			'success' => true,
			'message' => sprintf( 'کمپین شروع شد و %s گیرنده در صف ارسال قرار گرفت.', number_format_i18n( $queued ) ),
			'count'   => $queued,
		);
	}

	/**
	 * ارسال یک پیام کمپین (از صف).
	 *
	 * @param array $job     کار.
	 * @param array $payload گیرنده.
	 * @return bool
	 */
	public static function send_job( array $job, array $payload ) {
		$campaign = self::get( (int) $job['object_id'] );
		if ( ! $campaign || 'running' !== $campaign['status'] ) {
			return true; // کمپین متوقف یا حذف شده است.
		}

		$context = array(
			'user_id' => (int) ( $payload['user_id'] ?? 0 ),
			'vars'    => array(
				'first_name' => $payload['first_name'] ?? '',
				'email'      => $payload['email'] ?? '',
				'phone'      => $payload['phone'] ?? '',
			),
		);

		$result = WCMA_Sender::send(
			array(
				'channel'     => $campaign['channel'],
				'email'       => $payload['email'] ?? '',
				'phone'       => $payload['phone'] ?? '',
				'user_id'     => (int) ( $payload['user_id'] ?? 0 ),
				'subject'     => WCMA_Placeholders::replace( $campaign['subject'], $context ),
				'html'        => WCMA_Placeholders::replace( $campaign['content'], $context ),
				'text'        => WCMA_Placeholders::to_plain( WCMA_Placeholders::replace( $campaign['content'], $context ) ),
				'workflow'    => 'campaign',
				'step'        => 'campaign_' . $campaign['id'],
				'object_type' => 'campaign',
				'object_id'   => (int) $campaign['id'],
			)
		);

		global $wpdb;
		$table  = self::table();
		$column = $result['success'] ? 'sent_count' : 'failed_count';

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "UPDATE {$table} SET {$column} = {$column} + 1 WHERE id = %d", (int) $campaign['id'] ) // phpcs:ignore WordPress.DB
		);

		return $result['success'];
	}

	/**
	 * بستن کمپین‌هایی که صف آن‌ها خالی شده است.
	 */
	public static function process_running() {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} WHERE status = 'running'", ARRAY_A ); // phpcs:ignore WordPress.DB

		foreach ( (array) $rows as $row ) {
			$queue   = WCMA_Queue::table();
			$pending = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$queue} WHERE object_type = 'campaign' AND object_id = %d AND status IN ('pending','processing')", // phpcs:ignore WordPress.DB
					(int) $row['id']
				)
			);

			if ( 0 === $pending ) {
				self::set_status( (int) $row['id'], 'completed' );
			}
		}
	}
}
