<?php
/**
 * کد یک‌بارمصرف ورود.
 *
 * ساخت، فرستادن و بررسی کدی که با پیامک می‌رسد. کد هرگز خام ذخیره نمی‌شود
 * و شمار درخواست‌ها هم محدود است، وگرنه یک اسکریپت می‌تواند هم اعتبار پنل
 * پیامک را بسوزاند و هم کد را با آزمون‌وخطا پیدا کند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_OTP
 */
class WCMA_OTP {

	/**
	 * طول کد.
	 */
	const LENGTH = 5;

	/**
	 * اعتبار کد، به ثانیه.
	 */
	const TTL = 180;

	/**
	 * فاصله‌ی لازم میان دو درخواست برای یک شماره، به ثانیه.
	 */
	const COOLDOWN = 60;

	/**
	 * سقف کد در هر ساعت برای یک شماره.
	 */
	const MAX_PER_HOUR = 5;

	/**
	 * سقف کد در هر ساعت برای یک IP.
	 */
	const MAX_PER_IP = 15;

	/**
	 * سقف تلاش برای یک کد.
	 */
	const MAX_ATTEMPTS = 5;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_daily_scan', array( __CLASS__, 'purge_old' ) );
	}

	/**
	 * نام جدول.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_otp';
	}

	/**
	 * ساخت کد تازه و فرستادنش.
	 *
	 * @param string $phone   شماره موبایل.
	 * @param string $purpose login یا register.
	 * @return array{success:bool,message:string,wait:int}
	 */
	public static function request( $phone, $purpose = 'login' ) {
		global $wpdb;

		$phone = WCMA_SMS_Gateways::normalize_phone( $phone );

		if ( '' === $phone ) {
			return self::fail( 'شماره موبایل معتبر نیست.' );
		}

		if ( ! WCMA_Install::table_exists( 'wcma_otp' ) ) {
			return self::fail( 'جدول کدها ساخته نشده است. از «تنظیمات عمومی» جدول‌ها را ترمیم کنید.' );
		}

		$wait = self::cooldown_left( $phone );

		if ( $wait > 0 ) {
			return array(
				'success' => false,
				'message' => sprintf( 'تا %s ثانیه‌ی دیگر می‌توانید کد تازه بگیرید.', WCMA_Date::number( $wait ) ),
				'wait'    => $wait,
			);
		}

		if ( self::count_recent( 'phone', $phone ) >= self::MAX_PER_HOUR ) {
			return self::fail( 'درخواست کد برای این شماره زیاد شد. یک ساعت دیگر دوباره تلاش کنید.' );
		}

		$ip = WCMA_App_Users::ip();

		if ( $ip && self::count_recent( 'ip', $ip ) >= self::MAX_PER_IP ) {
			return self::fail( 'درخواست‌های شما زیاد شد. کمی بعد دوباره تلاش کنید.' );
		}

		$code = self::make_code();
		$now  = current_time( 'mysql' );

		// کدهای قبلیِ همین شماره باطل می‌شوند تا فقط تازه‌ترین کار کند.
		$wpdb->update( // phpcs:ignore WordPress.DB
			self::table(),
			array( 'used' => 1 ),
			array( 'phone' => $phone, 'used' => 0 ),
			array( '%d' ),
			array( '%s', '%d' )
		);

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'phone'      => $phone,
				'code_hash'  => self::hash( $code ),
				'purpose'    => 'register' === $purpose ? 'register' : 'login',
				'ip'         => $ip,
				'expires_at' => gmdate( 'Y-m-d H:i:s', strtotime( $now ) + self::TTL ),
				'created_at' => $now,
			)
		);

		$sent = self::deliver( $phone, $code );

		if ( empty( $sent['success'] ) ) {
			return self::fail( $sent['message'] ? $sent['message'] : 'پیامک فرستاده نشد.' );
		}

		return array(
			'success' => true,
			'message' => 'کد برای شما پیامک شد.',
			'wait'    => self::COOLDOWN,
		);
	}

	/**
	 * بررسی کد واردشده.
	 *
	 * @param string $phone شماره.
	 * @param string $code  کد.
	 * @return array{success:bool,message:string,purpose:string}
	 */
	public static function verify( $phone, $code ) {
		global $wpdb;

		$phone = WCMA_SMS_Gateways::normalize_phone( $phone );
		$code  = self::clean_code( $code );

		if ( '' === $phone || '' === $code ) {
			return self::fail( 'کد را کامل وارد کنید.' );
		}

		$table = self::table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE phone = %s AND used = 0 ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB
				$phone
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return self::fail( 'کدی برای این شماره فرستاده نشده. دوباره درخواست کنید.' );
		}

		if ( strtotime( $row['expires_at'] ) < strtotime( current_time( 'mysql' ) ) ) {
			return self::fail( 'این کد منقضی شده. کد تازه بگیرید.' );
		}

		if ( (int) $row['attempts'] >= self::MAX_ATTEMPTS ) {
			return self::fail( 'تعداد تلاش‌ها زیاد شد. کد تازه بگیرید.' );
		}

		/*
		 * مقایسه‌ی زمان‌ثابت: مقایسه‌ی معمولی رشته‌ها به‌محض نخستین نویسه‌ی
		 * متفاوت برمی‌گردد و همان اختلاف زمان می‌تواند کد را لو بدهد.
		 */
		if ( ! hash_equals( (string) $row['code_hash'], self::hash( $code ) ) ) {
			$wpdb->update( // phpcs:ignore WordPress.DB
				$table,
				array( 'attempts' => (int) $row['attempts'] + 1 ),
				array( 'id' => (int) $row['id'] ),
				array( '%d' ),
				array( '%d' )
			);

			return self::fail( 'کد درست نیست.' );
		}

		$wpdb->update( // phpcs:ignore WordPress.DB
			$table,
			array( 'used' => 1 ),
			array( 'id' => (int) $row['id'] ),
			array( '%d' ),
			array( '%d' )
		);

		return array(
			'success' => true,
			'message' => 'کد درست است.',
			'purpose' => (string) $row['purpose'],
		);
	}

	/**
	 * ثانیه‌ی باقی‌مانده تا امکان درخواست دوباره.
	 *
	 * @param string $phone شماره.
	 * @return int
	 */
	public static function cooldown_left( $phone ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_otp' ) ) {
			return 0;
		}

		$table = self::table();

		$last = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT created_at FROM {$table} WHERE phone = %s ORDER BY id DESC LIMIT 1", $phone ) // phpcs:ignore WordPress.DB
		);

		if ( ! $last ) {
			return 0;
		}

		$passed = strtotime( current_time( 'mysql' ) ) - strtotime( $last );

		return max( 0, self::COOLDOWN - $passed );
	}

	/**
	 * شمار کدهای یک ساعت گذشته.
	 *
	 * @param string $field phone یا ip.
	 * @param string $value مقدار.
	 * @return int
	 */
	protected static function count_recent( $field, $value ) {
		global $wpdb;

		$table = self::table();
		$field = 'ip' === $field ? 'ip' : 'phone';
		$since = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - HOUR_IN_SECONDS );

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$field} = %s AND created_at >= %s", $value, $since ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * ساخت کد تصادفی.
	 *
	 * @return string
	 */
	protected static function make_code() {
		$code = '';

		for ( $i = 0; $i < self::LENGTH; $i++ ) {
			$code .= (string) wp_rand( 0, 9 );
		}

		// کدی که با صفر شروع شود هم درست است؛ فقط نباید همه‌اش یک رقم باشد.
		if ( 1 === count( array_unique( str_split( $code ) ) ) ) {
			return self::make_code();
		}

		return $code;
	}

	/**
	 * درهم‌سازی کد.
	 *
	 * @param string $code کد.
	 * @return string
	 */
	protected static function hash( $code ) {
		return hash_hmac( 'sha256', (string) $code, wp_salt( 'auth' ) );
	}

	/**
	 * رقم‌های کد، بدون فاصله و با رقم لاتین.
	 *
	 * @param string $code ورودی.
	 * @return string
	 */
	public static function clean_code( $code ) {
		$code = WCMA_Date::to_latin_digits( (string) $code );
		$code = preg_replace( '/\D/', '', $code );

		return (string) mb_substr( (string) $code, 0, self::LENGTH );
	}

	/**
	 * متن پیامک کد.
	 *
	 * @param string $code کد.
	 * @return string
	 */
	public static function message( $code ) {
		$template = trim( (string) WCMA_Settings::get( 'otp_sms_text', '' ) );

		if ( '' === $template ) {
			$template = 'کد ورود شما به {site}: {code}';
		}

		$text = str_replace(
			array( '{code}', '{site}', '{minutes}' ),
			array( $code, get_bloginfo( 'name' ), WCMA_Date::number( (int) ceil( self::TTL / 60 ) ) ),
			$template
		);

		/*
		 * دو خط آخر، قراردادِ WebOTP است: کروم روی اندروید فقط وقتی کد را
		 * خودکار پر می‌کند که پیامک با «@دامنه #کد» تمام شود. برای کاربر
		 * هم مزاحمتی ندارد چون زیر متن اصلی می‌آید.
		 */
		if ( WCMA_Settings::is( 'otp_autofill' ) ) {
			$host = wp_parse_url( home_url(), PHP_URL_HOST );

			if ( $host ) {
				$text .= "\n\n@" . $host . ' #' . $code;
			}
		}

		return $text;
	}

	/**
	 * فرستادن پیامک.
	 *
	 * @param string $phone شماره.
	 * @param string $code  کد.
	 * @return array
	 */
	protected static function deliver( $phone, $code ) {
		$text = self::message( $code );

		/**
		 * امکان فرستادن کد از راه دیگر (مثلاً الگوی اختصاصیِ پنل پیامک).
		 *
		 * @param array|null $result نتیجه.
		 * @param string     $phone  شماره.
		 * @param string     $code   کد.
		 */
		$pre = apply_filters( 'wcma_pre_send_otp', null, $phone, $code );

		if ( is_array( $pre ) ) {
			return $pre;
		}

		$result = WCMA_SMS_Gateways::send( $phone, $text );

		WCMA_Logger::add(
			array(
				'workflow'  => 'otp',
				'step'      => 'code',
				'channel'   => 'sms',
				'recipient' => $phone,
				'subject'   => 'کد ورود',
				// خودِ کد هرگز در گزارش نمی‌نشیند؛ هرکس گزارش را ببیند واردش می‌شد.
				'status'    => empty( $result['success'] ) ? 'failed' : 'sent',
				'error'     => empty( $result['success'] ) ? (string) ( $result['message'] ?? '' ) : '',
			)
		);

		return $result;
	}

	/**
	 * پاک کردن کدهای کهنه.
	 */
	public static function purge_old() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_otp' ) ) {
			return;
		}

		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - DAY_IN_SECONDS );

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $since ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * پاسخ ناموفق.
	 *
	 * @param string $message پیام.
	 * @return array
	 */
	protected static function fail( $message ) {
		return array( 'success' => false, 'message' => $message, 'wait' => 0 );
	}
}
