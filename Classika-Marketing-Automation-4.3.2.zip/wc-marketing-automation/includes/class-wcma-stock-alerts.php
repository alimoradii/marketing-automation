<?php
/**
 * لایه‌ی داده و فرم «موجود شد خبرم کن».
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Stock_Alerts
 */
class WCMA_Stock_Alerts {

	/**
	 * یافتن محصول از روی هر چیزی که مدیر در دست دارد.
	 *
	 * مدیر لزوماً شناسه‌ی عددی محصول را نمی‌داند؛ ممکن است نام، کد محصول (SKU)،
	 * لینک صفحه یا نامک را وارد کند. همچنین عددی که وارد می‌کند ممکن است شناسه‌ی
	 * یک نوشته یا برگه باشد، نه محصول. این متد همه‌ی این حالت‌ها را پوشش می‌دهد و
	 * در صورت نیافتن، نزدیک‌ترین گزینه‌ها را پیشنهاد می‌کند.
	 *
	 * @param string $input ورودی مدیر.
	 * @return array{product:WC_Product|null,how:string,note:string,suggestions:array}
	 */
	public static function resolve_product( $input ) {
		$input = trim( (string) $input );

		$result = array(
			'product'     => null,
			'how'         => '',
			'note'        => '',
			'suggestions' => array(),
		);

		if ( '' === $input ) {
			$result['note'] = 'چیزی وارد نشده است.';

			return $result;
		}

		// ۱) شناسه‌ی عددی.
		if ( ctype_digit( $input ) ) {
			$id      = (int) $input;
			$product = wc_get_product( $id );

			if ( $product ) {
				$result['product'] = $product;
				$result['how']     = 'شناسه‌ی محصول';

				return $result;
			}

			// عدد وجود دارد ولی محصول نیست؛ بگوییم واقعاً چیست.
			$post = get_post( $id );

			if ( $post ) {
				$type_obj = get_post_type_object( $post->post_type );
				$type     = $type_obj ? $type_obj->labels->singular_name : $post->post_type;

				$result['note'] = sprintf(
					'شناسه‌ی %d متعلق به «%s» از نوع «%s» است، نه محصول.',
					$id,
					wp_strip_all_tags( $post->post_title ),
					$type
				);

				// اگر تنوع است، والدش را برگردان.
				if ( 'product_variation' === $post->post_type ) {
					$parent = wc_get_product( $post->post_parent );

					if ( $parent ) {
						$result['product'] = $parent;
						$result['how']     = 'محصول والدِ این تنوع';
						$result['note']    = '';

						return $result;
					}
				}
			} else {
				$result['note'] = sprintf( 'هیچ محتوایی با شناسه‌ی %d وجود ندارد.', $id );
			}
		}

		// ۲) لینک صفحه‌ی محصول.
		if ( false !== stripos( $input, 'http' ) ) {
			$id = url_to_postid( $input );

			if ( $id ) {
				$product = wc_get_product( $id );

				if ( $product ) {
					$result['product'] = $product;
					$result['how']     = 'لینک صفحه‌ی محصول';
					$result['note']    = '';

					return $result;
				}
			}
		}

		// ۳) کد محصول (SKU).
		if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
			$sku_id = wc_get_product_id_by_sku( $input );

			if ( $sku_id ) {
				$product = wc_get_product( $sku_id );

				if ( $product ) {
					$result['product'] = $product;
					$result['how']     = 'کد محصول (SKU)';
					$result['note']    = '';

					return $result;
				}
			}
		}

		// ۴) نامک (slug).
		$by_slug = get_page_by_path( sanitize_title( $input ), OBJECT, 'product' );

		if ( $by_slug ) {
			$product = wc_get_product( $by_slug->ID );

			if ( $product ) {
				$result['product'] = $product;
				$result['how']     = 'نامک محصول';
				$result['note']    = '';

				return $result;
			}
		}

		// ۵) جستجو در نام محصولات.
		$query = new WP_Query(
			array(
				'post_type'              => 'product',
				'post_status'            => 'publish',
				's'                      => $input,
				'posts_per_page'         => 6,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		$found = $query->posts;

		if ( 1 === count( $found ) ) {
			$product = wc_get_product( $found[0] );

			if ( $product ) {
				$result['product'] = $product;
				$result['how']     = 'جستجوی نام';
				$result['note']    = '';

				return $result;
			}
		}

		foreach ( (array) $found as $pid ) {
			$product = wc_get_product( $pid );

			if ( $product ) {
				$result['suggestions'][] = array(
					'id'   => $product->get_id(),
					'name' => $product->get_name(),
				);
			}
		}

		if ( ! $result['note'] ) {
			$result['note'] = 'محصولی با این مشخصات پیدا نشد.';
		}

		return $result;
	}

	/**
	 * راهنمای پیدا کردن شناسه‌ی محصول برای نمایش به مدیر.
	 *
	 * @param int $limit تعداد نمونه.
	 * @return array
	 */
	public static function sample_products( $limit = 5 ) {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => (int) $limit,
				'fields'         => 'ids',
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$out = array();

		foreach ( (array) $ids as $id ) {
			$product = wc_get_product( $id );

			if ( $product ) {
				$out[] = array(
					'id'       => $product->get_id(),
					'name'     => $product->get_name(),
					'in_stock' => $product->is_in_stock(),
				);
			}
		}

		return $out;
	}

	/**
	 * نام جدول.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcma_stock_alerts';
	}

	/**
	 * راه‌اندازی هوک‌های سمت کاربر.
	 */
	public static function init() {
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_form' ), 31 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_ajax_wcma_stock_subscribe', array( __CLASS__, 'ajax_subscribe' ) );
		add_action( 'wp_ajax_nopriv_wcma_stock_subscribe', array( __CLASS__, 'ajax_subscribe' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle_cancel' ) );
	}

	/**
	 * افزودن یک درخواست اطلاع‌رسانی.
	 *
	 * @param array $data داده‌ها.
	 * @return array{success:bool,message:string}
	 */
	public static function add( array $data ) {
		global $wpdb;

		$product_id   = (int) ( $data['product_id'] ?? 0 );
		$variation_id = (int) ( $data['variation_id'] ?? 0 );
		$email        = sanitize_email( (string) ( $data['email'] ?? '' ) );
		$phone        = WCMA_SMS_Gateways::normalize_phone( (string) ( $data['phone'] ?? '' ) );

		// فیلد یکپارچه: مشتری هرچه راحت‌تر است وارد می‌کند و نوعش خودکار تشخیص داده می‌شود.
		$contact = trim( (string) ( $data['contact'] ?? '' ) );

		if ( '' !== $contact ) {
			if ( false !== strpos( $contact, '@' ) ) {
				$email = sanitize_email( $contact );

				if ( ! is_email( $email ) ) {
					return array(
						'success' => false,
						'message' => 'ایمیل واردشده معتبر نیست.',
					);
				}
			} else {
				$phone = WCMA_SMS_Gateways::normalize_phone( $contact );

				if ( '' === $phone ) {
					return array(
						'success' => false,
						'message' => 'مقدار واردشده نه ایمیل معتبر است و نه شماره موبایل معتبر.',
					);
				}
			}
		}

		$product = wc_get_product( $variation_id ? $variation_id : $product_id );

		if ( ! $product ) {
			return array(
				'success' => false,
				'message' => 'محصول پیدا نشد.',
			);
		}

		// خطای دقیق‌تر بر خطای کلی مقدم است تا کاربر بداند کدام فیلد ایراد دارد.
		if ( ! empty( $data['email'] ) && ! is_email( $email ) ) {
			return array(
				'success' => false,
				'message' => 'ایمیل واردشده معتبر نیست.',
			);
		}

		if ( ! empty( $data['phone'] ) && '' === $phone ) {
			return array(
				'success' => false,
				'message' => 'شماره موبایل واردشده معتبر نیست.',
			);
		}

		if ( ! $email && ! $phone ) {
			return array(
				'success' => false,
				'message' => 'ایمیل یا شماره موبایل خود را وارد کنید.',
			);
		}

		// اگر محصول همین حالا موجود است، نیازی به ثبت نیست.
		if ( $product->is_in_stock() ) {
			return array(
				'success' => false,
				'message' => 'این محصول هم‌اکنون موجود است.',
			);
		}

		// جلوگیری از ثبت تکراری.
		if ( self::exists( $product_id, $variation_id, $email, $phone ) ) {
			return array(
				'success' => true,
				'message' => 'شما پیش‌تر برای این محصول ثبت‌نام کرده‌اید. به‌محض موجود شدن خبرتان می‌کنیم.',
			);
		}

		$limit = (int) WCMA_Settings::get( 'st_max_per_product', 0 );

		if ( $limit > 0 && self::count_pending( $product_id, $variation_id ) >= $limit ) {
			return array(
				'success' => false,
				'message' => 'ظرفیت فهرست انتظار این محصول تکمیل شده است.',
			);
		}

		$user_id = get_current_user_id();

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'user_id'      => $user_id,
				'email'        => $email,
				'phone'        => $phone,
				'first_name'   => sanitize_text_field( (string) ( $data['first_name'] ?? '' ) ),
				'status'       => 'pending',
				'token'        => wp_generate_password( 32, false, false ),
				'created_at'   => current_time( 'mysql' ),
			)
		);

		if ( ! $wpdb->insert_id ) {
			return array(
				'success' => false,
				'message' => 'ثبت درخواست انجام نشد. لطفاً دوباره تلاش کنید.',
			);
		}

		/**
		 * پس از ثبت درخواست اطلاع‌رسانی موجودی.
		 *
		 * @param int   $id   شناسه‌ی درخواست.
		 * @param array $data داده‌ها.
		 */
		do_action( 'wcma_stock_alert_added', (int) $wpdb->insert_id, $data );

		return array(
			'success' => true,
			'message' => 'ثبت شد. به‌محض موجود شدن این محصول به شما اطلاع می‌دهیم.',
		);
	}

	/**
	 * بررسی ثبت قبلی.
	 *
	 * @param int    $product_id   محصول.
	 * @param int    $variation_id تنوع.
	 * @param string $email        ایمیل.
	 * @param string $phone        موبایل.
	 * @return bool
	 */
	public static function exists( $product_id, $variation_id, $email, $phone ) {
		global $wpdb;

		$table = self::table();

		$count = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE product_id = %d AND variation_id = %d AND status = 'pending' AND ( ( email <> '' AND email = %s ) OR ( phone <> '' AND phone = %s ) )", // phpcs:ignore WordPress.DB
				$product_id,
				$variation_id,
				$email,
				$phone
			)
		);

		return $count > 0;
	}

	/**
	 * شمار درخواست‌های در انتظار یک محصول.
	 *
	 * @param int $product_id   محصول.
	 * @param int $variation_id تنوع.
	 * @return int
	 */
	public static function count_pending( $product_id, $variation_id = 0 ) {
		global $wpdb;

		$table = self::table();

		if ( $variation_id ) {
			return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE product_id = %d AND variation_id = %d AND status = 'pending'", $product_id, $variation_id ) // phpcs:ignore WordPress.DB
			);
		}

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE product_id = %d AND status = 'pending'", $product_id ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * درخواست‌های در انتظار برای یک محصول.
	 *
	 * @param int $product_id   محصول.
	 * @param int $variation_id تنوع (صفر یعنی همه).
	 * @param int $limit        سقف.
	 * @return array
	 */
	public static function pending_for( $product_id, $variation_id = 0, $limit = 500 ) {
		global $wpdb;

		$table = self::table();

		if ( $variation_id ) {
			return (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE product_id = %d AND variation_id IN (0, %d) AND status = 'pending' ORDER BY created_at ASC LIMIT %d", // phpcs:ignore WordPress.DB
					$product_id,
					$variation_id,
					$limit
				),
				ARRAY_A
			);
		}

		return (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE product_id = %d AND status = 'pending' ORDER BY created_at ASC LIMIT %d", // phpcs:ignore WordPress.DB
				$product_id,
				$limit
			),
			ARRAY_A
		);
	}

	/**
	 * دریافت یک درخواست.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		$table = self::table();

		return $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * تغییر وضعیت یک درخواست.
	 *
	 * @param int    $id     شناسه.
	 * @param string $status وضعیت.
	 */
	public static function set_status( $id, $status ) {
		global $wpdb;

		$data = array( 'status' => $status );

		if ( 'notified' === $status ) {
			$data['notified_at'] = current_time( 'mysql' );
		}

		$wpdb->update( self::table(), $data, array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * حذف یک درخواست.
	 *
	 * @param int $id شناسه.
	 */
	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * شناسه‌ی محصولاتی که دست‌کم یک نفر منتظرشان است.
	 *
	 * @param int $limit سقف.
	 * @return array
	 */
	public static function pending_product_ids( $limit = 100 ) {
		global $wpdb;

		$table = self::table();

		return array_map(
			'intval',
			(array) $wpdb->get_col( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT DISTINCT product_id FROM {$table} WHERE status = 'pending' LIMIT %d", (int) $limit ) // phpcs:ignore WordPress.DB
			)
		);
	}

	/**
	 * آخرین درخواست‌های ثبت‌شده، برای نمایش در پیشخوان.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public static function recent_requests( $limit = 15 ) {
		global $wpdb;

		$table = self::table();

		return (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", (int) $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * فهرست محصولات دارای بیشترین تقاضا.
	 *
	 * @param int $limit تعداد.
	 * @return array
	 */
	public static function demand_list( $limit = 30 ) {
		global $wpdb;

		$table = self::table();

		return (array) $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT product_id, variation_id, COUNT(*) AS waiting, MIN(created_at) AS oldest
				 FROM {$table} WHERE status = 'pending'
				 GROUP BY product_id, variation_id ORDER BY waiting DESC LIMIT %d", // phpcs:ignore WordPress.DB
				$limit
			),
			ARRAY_A
		);
	}

	/**
	 * آمار کلی.
	 *
	 * @return array
	 */
	public static function stats() {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_results( "SELECT status, COUNT(*) AS total FROM {$table} GROUP BY status", ARRAY_A ); // phpcs:ignore WordPress.DB

		$stats = array(
			'pending'  => 0,
			'notified' => 0,
			'products' => 0,
		);

		foreach ( (array) $rows as $row ) {
			$stats[ $row['status'] ] = (int) $row['total'];
		}

		$stats['products'] = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT product_id) FROM {$table} WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB

		return $stats;
	}

	/**
	 * حذف درخواست‌های خیلی قدیمی.
	 */
	public static function purge_old() {
		global $wpdb;

		$days = (int) WCMA_Settings::get( 'st_expire_days', 120 );

		if ( $days < 1 ) {
			return;
		}

		$table = self::table();

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "DELETE FROM {$table} WHERE status <> 'pending' AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)", $days ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * لینک لغو درخواست.
	 *
	 * @param array $alert رکورد.
	 * @return string
	 */
	public static function cancel_url( array $alert ) {
		if ( empty( $alert['token'] ) ) {
			return home_url();
		}

		return add_query_arg( 'wcma_stock_cancel', $alert['token'], home_url( '/' ) );
	}

	/**
	 * پردازش لغو درخواست.
	 */
	public static function handle_cancel() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['wcma_stock_cancel'] ) ) {
			return;
		}

		global $wpdb;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$token = sanitize_text_field( wp_unslash( $_GET['wcma_stock_cancel'] ) );
		$table = self::table();

		$alert = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE token = %s LIMIT 1", $token ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( ! $alert ) {
			wp_die( 'این لینک معتبر نیست یا پیش‌تر استفاده شده است.', 'لغو اطلاع‌رسانی', array( 'response' => 400 ) );
		}

		self::set_status( (int) $alert['id'], 'cancelled' );

		wp_die(
			'<p style="font-family:tahoma,sans-serif;direction:rtl">درخواست اطلاع‌رسانی شما لغو شد.</p>'
			. '<p style="direction:rtl"><a href="' . esc_url( home_url() ) . '">بازگشت به فروشگاه</a></p>',
			'لغو اطلاع‌رسانی',
			array( 'response' => 200 )
		);
	}

	/**
	 * بارگذاری اسکریپت فرم.
	 */
	public static function enqueue() {
		if ( ! WCMA_Settings::is( 'st_enabled' ) || ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}

		wp_enqueue_style( 'wcma-font', WCMA_URL . 'assets/css/font.css', array(), WCMA_Plugin::asset_version( 'assets/css/font.css' ) );
		wp_enqueue_script( 'wcma-stock-alert', WCMA_URL . 'assets/js/stock-alert.js', array( 'jquery' ), WCMA_Plugin::asset_version( 'assets/js/stock-alert.js' ), true );
		wp_localize_script(
			'wcma-stock-alert',
			'wcmaStock',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wcma_stock' ),
			)
		);
	}

	/**
	 * نمایش فرم در صفحه‌ی محصول ناموجود.
	 */
	public static function render_form() {
		if ( ! WCMA_Settings::is( 'st_enabled' ) || ! WCMA_Settings::is( 'st_show_form' ) ) {
			return;
		}

		global $product;

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		// برای محصولات متغیر، فرم با انتخاب تنوع ناموجود ظاهر می‌شود.
		$is_variable = $product->is_type( 'variable' );

		if ( ! $is_variable && $product->is_in_stock() ) {
			return;
		}

		if ( WCMA_Settings::is( 'st_require_login' ) && ! is_user_logged_in() ) {
			echo '<div class="wcma-stock"><p>برای اطلاع از موجود شدن این محصول، لطفاً <a href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">وارد حساب کاربری</a> شوید.</p></div>';
			return;
		}

		$user = wp_get_current_user();

		// پیش‌پر کردن فیلد فقط در صورت درخواست صریح مدیر؛ در غیر این صورت فرم خالی
		// می‌ماند تا مقدار حساب مدیر یا ایمیل نمونه‌ی نصب در آن دیده نشود.
		$prefill    = WCMA_Settings::is( 'st_prefill' ) && $user->ID;
		$email      = $prefill ? $user->user_email : '';
		$phone      = $prefill ? get_user_meta( $user->ID, 'billing_phone', true ) : '';
		$first_name = $user->ID ? get_user_meta( $user->ID, 'billing_first_name', true ) : '';
		$waiting    = self::count_pending( $product->get_id() );

		// حالت دریافت اطلاعات تماس؛ مستقل از کانال ارسال، چون مشتری ممکن است فقط
		// یکی از این دو را در اختیار داشته باشد یا ترجیح بدهد.
		$mode = WCMA_Settings::get( 'st_contact_mode', 'auto' );
		?>
		<div class="wcma-stock" data-product="<?php echo esc_attr( $product->get_id() ); ?>" <?php echo $is_variable ? 'data-variable="1" style="display:none"' : ''; ?>>
			<h4 class="wcma-stock__title"><?php echo esc_html( WCMA_Settings::get( 'st_title', 'منتظر این محصول هستید؟' ) ); ?></h4>
			<p class="wcma-stock__desc"><?php echo esc_html( WCMA_Settings::get( 'st_description', 'ایمیل یا شماره خود را وارد کنید تا لحظه‌ای که موجود شد به شما خبر دهیم.' ) ); ?></p>

			<?php if ( $waiting > 0 && WCMA_Settings::is( 'st_show_count' ) ) : ?>
				<p class="wcma-stock__count"><?php printf( '%s نفر در انتظار موجود شدن این محصول هستند.', esc_html( number_format_i18n( $waiting ) ) ); ?></p>
			<?php endif; ?>

			<?php /* اعتبارسنجی خودمان انجام می‌شود تا پیام‌ها فارسی و گویا باشند. */ ?>
			<form class="wcma-stock__form" novalidate>
				<input type="hidden" name="product_id" value="<?php echo esc_attr( $product->get_id() ); ?>" />
				<input type="hidden" name="variation_id" value="0" />
				<input type="hidden" name="first_name" value="<?php echo esc_attr( $first_name ); ?>" />

				<?php if ( 'email' === $mode ) : ?>
					<input type="text" inputmode="email" name="email" placeholder="ایمیل شما" value="<?php echo esc_attr( $email ); ?>" dir="ltr" />

				<?php elseif ( 'phone' === $mode ) : ?>
					<input type="text" inputmode="tel" name="phone" placeholder="شماره موبایل" value="<?php echo esc_attr( $phone ); ?>" dir="ltr" />

				<?php elseif ( 'both' === $mode ) : ?>
					<input type="text" inputmode="email" name="email" placeholder="ایمیل شما" value="<?php echo esc_attr( $email ); ?>" dir="ltr" />
					<input type="text" inputmode="tel" name="phone" placeholder="شماره موبایل" value="<?php echo esc_attr( $phone ); ?>" dir="ltr" />

				<?php else : ?>
					<?php /* حالت خودکار: یک فیلد که هر دو را می‌پذیرد. */ ?>
					<input type="text" name="contact" placeholder="ایمیل یا شماره موبایل" value="<?php echo esc_attr( $email ? $email : $phone ); ?>" dir="ltr" />
				<?php endif; ?>

				<button type="submit"><?php echo esc_html( WCMA_Settings::get( 'st_button_label', 'موجود شد خبرم کن' ) ); ?></button>
			</form>

			<div class="wcma-stock__result" role="status"></div>
		</div>

		<style>
			.wcma-stock, .wcma-stock * { font-family: 'Vazirmatn WCMA', Vazirmatn, Vazir, Tahoma, sans-serif; }
			.wcma-stock { border: 1px solid #e5e7eb; border-radius: 12px; padding: 18px; margin: 18px 0; background: #fafbfc; }
			.wcma-stock__title { margin: 0 0 6px; font-size: 16px; }
			.wcma-stock__desc { margin: 0 0 12px; font-size: 13px; color: #6b7280; line-height: 2; }
			.wcma-stock__count { margin: 0 0 12px; font-size: 12.5px; color: #d97706; }
			.wcma-stock__form { display: flex; gap: 8px; flex-wrap: wrap; }
			.wcma-stock__form input { flex: 1; min-width: 210px; direction: ltr; text-align: left; border: 1px solid #d1d5db; border-radius: 9px; padding: 10px 12px; font-size: 14px; font-family: inherit; }
			.wcma-stock__form input:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,.12); }
			.wcma-stock__form button { border: none; border-radius: 9px; padding: 10px 20px; background: #2563eb; color: #fff; font-size: 14px; font-family: inherit; font-weight: 600; cursor: pointer; }
			.wcma-stock__form button:hover { background: #1d4ed8; }
			.wcma-stock__form button[disabled] { opacity: .6; cursor: not-allowed; }
			.wcma-stock__result:not(:empty) { margin-top: 12px; font-size: 13px; border-radius: 8px; padding: 10px 14px; }
			.wcma-stock__result.is-success { background: #ecfdf5; color: #059669; }
			.wcma-stock__result.is-error { background: #fef2f2; color: #dc2626; }
		</style>
		<?php
	}

	/**
	 * ثبت درخواست از طریق ایجکس.
	 */
	public static function ajax_subscribe() {
		check_ajax_referer( 'wcma_stock', 'nonce' );

		if ( ! WCMA_Settings::is( 'st_enabled' ) ) {
			wp_send_json_error( array( 'message' => 'این قابلیت فعال نیست.' ) );
		}

		$result = self::add(
			array(
				'product_id'   => isset( $_POST['product_id'] ) ? (int) $_POST['product_id'] : 0,
				'variation_id' => isset( $_POST['variation_id'] ) ? (int) $_POST['variation_id'] : 0,
				'email'        => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
				'phone'        => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
				'contact'      => isset( $_POST['contact'] ) ? sanitize_text_field( wp_unslash( $_POST['contact'] ) ) : '',
				'first_name'   => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
			)
		);

		if ( $result['success'] ) {
			wp_send_json_success( array( 'message' => $result['message'] ) );
		}

		wp_send_json_error( array( 'message' => $result['message'] ) );
	}
}
