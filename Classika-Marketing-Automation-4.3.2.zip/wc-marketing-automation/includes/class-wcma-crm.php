<?php
/**
 * پرونده‌ی مشتریان (CRM): یک جای واحد برای شناخت هر مشتری و پیگیری او.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_CRM
 */
class WCMA_CRM {

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_daily_scan', array( __CLASS__, 'daily' ) );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'refresh_from_order' ) );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'refresh_from_order' ) );
	}

	/**
	 * کارهای روزانه: همگام‌سازی و یادآوری پیگیری‌ها.
	 */
	public static function daily() {
		if ( ! WCMA_Settings::is( 'crm_enabled' ) ) {
			return;
		}

		if ( WCMA_Settings::is( 'crm_auto_sync' ) ) {
			self::sync();
		}

		self::remind_followups();
	}

	/**
	 * پیامک یادآوری پیگیری‌های سررسیدشده به مسئول فروش.
	 */
	public static function remind_followups() {
		if ( ! WCMA_Settings::is( 'crm_followup_reminder' ) ) {
			return;
		}

		$phone = WCMA_Settings::get( 'crm_reminder_phone', '' );
		$due   = self::due_followups( 20 );

		if ( ! $phone || ! $due ) {
			return;
		}

		// روزی یک بار کافی است.
		if ( get_transient( 'wcma_crm_reminded' ) ) {
			return;
		}

		set_transient( 'wcma_crm_reminded', 1, DAY_IN_SECONDS );

		$names = array();

		foreach ( array_slice( $due, 0, 5 ) as $contact ) {
			$names[] = self::display_name( $contact );
		}

		WCMA_Sender::send(
			array(
				'channel'  => 'sms',
				'to'       => $phone,
				'message'  => sprintf(
					'%s پیگیری امروز سررسید شده است: %s',
					WCMA_Date::number( count( $due ) ),
					implode( '، ', $names )
				),
				'workflow' => 'crm',
			)
		);
	}

	/**
	 * به‌روزرسانی پرونده پس از هر سفارش موفق.
	 *
	 * @param int $order_id سفارش.
	 */
	public static function refresh_from_order( $order_id ) {
		if ( ! WCMA_Settings::is( 'crm_enabled' ) || ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$email = $order->get_billing_email();
		$phone = $order->get_billing_phone();

		if ( ! $email && ! $phone ) {
			return;
		}

		$existing = self::find( $email, $phone );
		$orders   = $existing ? (int) $existing['order_count'] + 1 : 1;
		$spent    = ( $existing ? (float) $existing['total_spent'] : 0 ) + (float) $order->get_total();
		$created  = $order->get_date_created();
		$date     = $created ? $created->date( 'Y-m-d H:i:s' ) : current_time( 'mysql' );

		self::upsert(
			array(
				'email'          => $email,
				'phone'          => $phone,
				'user_id'        => (int) $order->get_customer_id(),
				'first_name'     => $order->get_billing_first_name(),
				'last_name'      => $order->get_billing_last_name(),
				'city'           => $order->get_billing_city(),
				'company'        => $order->get_billing_company(),
				'order_count'    => $orders,
				'total_spent'    => $spent,
				'last_order_at'  => $date,
				'first_order_at' => $existing && $existing['first_order_at'] ? $existing['first_order_at'] : $date,
				'stage'          => self::guess_stage( $orders, $date, $existing['stage'] ?? '' ),
				'source'         => $existing && $existing['source'] ? $existing['source'] : 'order',
			)
		);
	}

	/**
	 * مراحل قیف فروش.
	 *
	 * @return array
	 */
	public static function stages() {
		return array(
			'lead'     => array(
				'label' => 'سرنخ',
				'desc'  => 'هنوز خریدی نکرده؛ فقط شماره یا ایمیلش را داریم.',
				'color' => '#94a3b8',
			),
			'prospect' => array(
				'label' => 'در حال بررسی',
				'desc'  => 'سبد خرید ساخته یا محصولی را دنبال می‌کند، ولی نهایی نکرده است.',
				'color' => '#f59e0b',
			),
			'customer' => array(
				'label' => 'مشتری',
				'desc'  => 'دست‌کم یک خرید موفق داشته است.',
				'color' => '#2563eb',
			),
			'repeat'   => array(
				'label' => 'مشتری وفادار',
				'desc'  => 'بیش از یک خرید داشته است.',
				'color' => '#16a34a',
			),
			'vip'      => array(
				'label' => 'ویژه (VIP)',
				'desc'  => 'در باشگاه مشتریان سطح دارد.',
				'color' => '#7c3aed',
			),
			'churn'    => array(
				'label' => 'در خطر ریزش',
				'desc'  => 'مدت زیادی است خرید نکرده است.',
				'color' => '#dc2626',
			),
		);
	}

	/**
	 * نام مرحله.
	 *
	 * @param string $stage مرحله.
	 * @return string
	 */
	public static function stage_label( $stage ) {
		$stages = self::stages();

		return $stages[ $stage ]['label'] ?? $stage;
	}

	/**
	 * منابع ورود مشتری.
	 *
	 * @return array
	 */
	public static function sources() {
		return array(
			'order'       => 'سفارش',
			'cart'        => 'سبد رها شده',
			'stock_alert' => 'هشدار موجودی',
			'chat'        => 'گفتگوی آنلاین',
			'bot'         => 'ربات پیام‌رسان',
			'lead_form'   => 'فرم لید مگنت',
			'subscriber'  => 'خبرنامه',
			'panel'       => 'پنل کاربری',
			'manual'      => 'ثبت دستی',
			'import'      => 'ورود گروهی',
		);
	}

	/**
	 * آیکون و رنگ هر منبع، برای نمایش در فهرست.
	 *
	 * @param string $source منبع.
	 * @return array{icon:string,color:string,label:string}
	 */
	public static function source_style( $source ) {
		$map = array(
			'order'       => array( 'icon' => 'cart', 'color' => '#16a34a' ),
			'cart'        => array( 'icon' => 'cart', 'color' => '#d97706' ),
			'stock_alert' => array( 'icon' => 'archive', 'color' => '#0891b2' ),
			'chat'        => array( 'icon' => 'format-chat', 'color' => '#7c3aed' ),
			'bot'         => array( 'icon' => 'admin-site-alt3', 'color' => '#2563eb' ),
			'lead_form'   => array( 'icon' => 'megaphone', 'color' => '#db2777' ),
			'subscriber'  => array( 'icon' => 'email-alt', 'color' => '#0284c7' ),
			'panel'       => array( 'icon' => 'admin-users', 'color' => '#0891b2' ),
			'manual'      => array( 'icon' => 'edit', 'color' => '#64748b' ),
			'import'      => array( 'icon' => 'upload', 'color' => '#64748b' ),
		);

		$style = $map[ $source ] ?? array( 'icon' => 'marker', 'color' => '#94a3b8' );

		$style['label'] = self::sources()[ $source ] ?? 'نامشخص';

		return $style;
	}

	/**
	 * انواع فعالیت در پرونده.
	 *
	 * @return array
	 */
	public static function note_types() {
		return array(
			'note'     => 'یادداشت',
			'call'     => 'تماس تلفنی',
			'meeting'  => 'جلسه',
			'message'  => 'پیام ارسالی',
			'stage'    => 'تغییر مرحله',
			'followup' => 'پیگیری',
		);
	}

	/**
	 * نام جدول پرونده‌ها.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_contacts';
	}

	/**
	 * نام جدول یادداشت‌ها.
	 *
	 * @return string
	 */
	public static function notes_table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_crm_notes';
	}

	/**
	 * یافتن پرونده با ایمیل یا شماره.
	 *
	 * @param string $email ایمیل.
	 * @param string $phone شماره.
	 * @return array|null
	 */
	public static function find( $email = '', $phone = '' ) {
		global $wpdb;

		$email = sanitize_email( (string) $email );
		$phone = WCMA_SMS_Gateways::normalize_phone( (string) $phone );

		if ( ! $email && ! $phone ) {
			return null;
		}

		$table = self::table();

		if ( $email && $phone ) {
			$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s OR phone = %s ORDER BY id ASC LIMIT 1", $email, $phone ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);
		} elseif ( $email ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE email = %s LIMIT 1", $email ), ARRAY_A ); // phpcs:ignore WordPress.DB
		} else {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE phone = %s LIMIT 1", $phone ), ARRAY_A ); // phpcs:ignore WordPress.DB
		}

		return $row ? $row : null;
	}

	/**
	 * یافتن پرونده با شناسه.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $row ? $row : null;
	}

	/**
	 * ساخت یا به‌روزرسانی پرونده.
	 *
	 * فیلدهایی که مقدار تازه‌ای ندارند، دست‌نخورده می‌مانند تا داده‌ی موجود پاک نشود.
	 *
	 * @param array $data داده.
	 * @return int شناسه‌ی پرونده.
	 */
	public static function upsert( array $data ) {
		global $wpdb;

		$email = sanitize_email( (string) ( $data['email'] ?? '' ) );
		$phone = WCMA_SMS_Gateways::normalize_phone( (string) ( $data['phone'] ?? '' ) );

		if ( ! $email && ! $phone ) {
			return 0;
		}

		$existing = self::find( $email, $phone );
		$now      = current_time( 'mysql' );

		$fields = array(
			'user_id'          => isset( $data['user_id'] ) ? (int) $data['user_id'] : null,
			'email'            => $email ? $email : null,
			'phone'            => $phone ? $phone : null,
			'first_name'       => isset( $data['first_name'] ) ? sanitize_text_field( $data['first_name'] ) : null,
			'last_name'        => isset( $data['last_name'] ) ? sanitize_text_field( $data['last_name'] ) : null,
			'company'          => isset( $data['company'] ) ? sanitize_text_field( $data['company'] ) : null,
			'city'             => isset( $data['city'] ) ? sanitize_text_field( $data['city'] ) : null,
			'stage'            => isset( $data['stage'] ) ? sanitize_key( $data['stage'] ) : null,
			'status'           => isset( $data['status'] ) ? sanitize_key( $data['status'] ) : null,
			'source'           => isset( $data['source'] ) ? sanitize_key( $data['source'] ) : null,
			'tags'             => isset( $data['tags'] ) ? self::clean_tags( $data['tags'] ) : null,
			'owner_id'         => isset( $data['owner_id'] ) ? (int) $data['owner_id'] : null,
			'order_count'      => isset( $data['order_count'] ) ? (int) $data['order_count'] : null,
			'total_spent'      => isset( $data['total_spent'] ) ? (float) $data['total_spent'] : null,
			'first_order_at'   => $data['first_order_at'] ?? null,
			'last_order_at'    => $data['last_order_at'] ?? null,
			'last_contact_at'  => $data['last_contact_at'] ?? null,
			'next_followup_at' => array_key_exists( 'next_followup_at', $data ) ? $data['next_followup_at'] : null,
			'followup_note'    => isset( $data['followup_note'] ) ? sanitize_text_field( $data['followup_note'] ) : null,
			'consent'          => isset( $data['consent'] ) ? sanitize_key( $data['consent'] ) : null,
		);

		// مقدارهای خالی حذف می‌شوند تا داده‌ی قبلی را پاک نکنند.
		$fields = array_filter(
			$fields,
			static function ( $value ) {
				return null !== $value && '' !== $value;
			}
		);

		// اجازه‌ی پاک کردن عمدی تاریخ پیگیری.
		if ( array_key_exists( 'next_followup_at', $data ) && ! $data['next_followup_at'] ) {
			$fields['next_followup_at'] = null;
			$fields['followup_note']    = '';
		}

		$fields['updated_at'] = $now;

		if ( $existing ) {
			$wpdb->update( self::table(), $fields, array( 'id' => (int) $existing['id'] ) ); // phpcs:ignore WordPress.DB

			return (int) $existing['id'];
		}

		$fields['created_at'] = $now;
		$fields['email']      = $email;
		$fields['phone']      = $phone;

		if ( empty( $fields['stage'] ) ) {
			$fields['stage'] = 'lead';
		}

		$wpdb->insert( self::table(), $fields ); // phpcs:ignore WordPress.DB

		return (int) $wpdb->insert_id;
	}

	/**
	 * پاک‌سازی برچسب‌ها.
	 *
	 * @param mixed $tags برچسب‌ها.
	 * @return string
	 */
	public static function clean_tags( $tags ) {
		if ( is_string( $tags ) ) {
			$tags = preg_split( '/[،,]/u', $tags );
		}

		$tags = array_map( 'trim', (array) $tags );
		$tags = array_filter( array_map( 'sanitize_text_field', $tags ) );
		$tags = array_slice( array_unique( $tags ), 0, 12 );

		return $tags ? ',' . implode( ',', $tags ) . ',' : '';
	}

	/**
	 * برچسب‌های یک پرونده به‌شکل آرایه.
	 *
	 * @param string $tags مقدار ذخیره‌شده.
	 * @return array
	 */
	public static function tag_list( $tags ) {
		return array_values( array_filter( explode( ',', (string) $tags ) ) );
	}

	/**
	 * همه‌ی برچسب‌های موجود، برای فیلتر.
	 *
	 * @return array
	 */
	public static function all_tags() {
		global $wpdb;

		$table = self::table();
		$rows  = $wpdb->get_col( "SELECT DISTINCT tags FROM {$table} WHERE tags <> ''" ); // phpcs:ignore WordPress.DB
		$tags  = array();

		foreach ( (array) $rows as $row ) {
			foreach ( self::tag_list( $row ) as $tag ) {
				$tags[ $tag ] = true;
			}
		}

		$tags = array_keys( $tags );
		sort( $tags );

		return $tags;
	}

	/**
	 * نامی که هنگام ثبت یادداشت کنار آن می‌نشیند.
	 *
	 * ثبت‌کننده همیشه کاربر وردپرس نیست؛ اپراتورهای پنل موبایل حساب جدا دارند
	 * و شناسه‌شان با شناسه‌ی کاربران وردپرس یکی نیست. پس نام در همان لحظه
	 * ذخیره می‌شود تا بعداً به کاربر اشتباهی نسبت داده نشود.
	 *
	 * @param int    $author_id   شناسه‌ی کاربر وردپرس.
	 * @param string $author_name نام آماده، وقتی ثبت‌کننده کاربر وردپرس نیست.
	 * @return string
	 */
	protected static function author_label( $author_id, $author_name = '' ) {
		$author_name = trim( (string) $author_name );

		if ( '' !== $author_name ) {
			return mb_substr( $author_name, 0, 190 );
		}

		$id   = $author_id ? (int) $author_id : get_current_user_id();
		$user = $id ? get_userdata( $id ) : null;

		if ( $user && ! empty( $user->display_name ) ) {
			return mb_substr( (string) $user->display_name, 0, 190 );
		}

		/*
		 * کاربر وردپرس نبود؛ شاید درخواست از پنل موبایل آمده باشد. آن حساب‌ها
		 * کاربر وردپرس ندارند، پس نامشان را از خودِ نشست می‌گیریم.
		 */
		if ( class_exists( 'WCMA_Agent_API' ) ) {
			$actor = WCMA_Agent_API::actor();

			if ( is_array( $actor ) && ! empty( $actor['name'] ) ) {
				return mb_substr( (string) $actor['name'], 0, 190 );
			}
		}

		return '';
	}

	/**
	 * نام ثبت‌کننده‌ی یک یادداشت برای نمایش.
	 *
	 * @param array $note سطر یادداشت.
	 * @return string
	 */
	public static function note_author( array $note ) {
		$stored = trim( (string) ( $note['author_name'] ?? '' ) );

		if ( '' !== $stored ) {
			return $stored;
		}

		// یادداشت‌های قدیمی فقط شناسه دارند.
		$user = ! empty( $note['author_id'] ) ? get_userdata( (int) $note['author_id'] ) : null;

		return $user && ! empty( $user->display_name ) ? (string) $user->display_name : '';
	}

	/**
	 * افزودن یادداشت یا فعالیت به پرونده.
	 *
	 * @param int    $contact_id پرونده.
	 * @param string $body       متن.
	 * @param string $type       نوع.
	 * @param int    $author_id  نویسنده (کاربر وردپرس).
	 * @param string $author_name نام ثبت‌کننده، وقتی کاربر وردپرس نیست.
	 * @return int
	 */
	public static function add_note( $contact_id, $body, $type = 'note', $author_id = 0, $author_name = '', $due = '' ) {
		global $wpdb;

		$contact_id = (int) $contact_id;
		$body       = trim( wp_kses_post( $body ) );

		if ( ! $contact_id || '' === $body ) {
			return 0;
		}

		$types = self::note_types();
		$type  = isset( $types[ $type ] ) ? $type : 'note';
		$now   = current_time( 'mysql' );
		$due   = self::clean_due( $due );

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::notes_table(),
			array(
				'contact_id'  => $contact_id,
				'author_id'   => $author_id ? (int) $author_id : get_current_user_id(),
				'author_name' => self::author_label( $author_id, $author_name ),
				'type'        => $type,
				'body'        => $body,
				'due_at'      => $due ? $due : null,
				'assignee'    => $due ? self::actor_ref() : '',
				'created_at'  => $now,
			)
		);

		$table = self::table();

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET notes_count = notes_count + 1, last_contact_at = %s, updated_at = %s WHERE id = %d", // phpcs:ignore WordPress.DB
				$now,
				$now,
				$contact_id
			)
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * ویرایش یک یادداشت.
	 *
	 * فقط متن، نوع و سررسید عوض می‌شوند؛ نام ثبت‌کننده و زمان ثبت دست‌نخورده
	 * می‌مانند، چون تاریخچه‌اند نه محتوا.
	 *
	 * @param int    $note_id یادداشت.
	 * @param string $body    متن تازه.
	 * @param string $type    نوع تازه.
	 * @param string $due     سررسید تازه (خالی یعنی بی‌سررسید).
	 * @return bool
	 */
	public static function update_note( $note_id, $body, $type = '', $due = '' ) {
		global $wpdb;

		$note_id = (int) $note_id;
		$body    = trim( wp_kses_post( $body ) );
		$note    = $note_id ? self::note( $note_id ) : null;

		if ( ! $note || '' === $body ) {
			return false;
		}

		$types = self::note_types();
		$type  = isset( $types[ $type ] ) ? $type : (string) $note['type'];
		$clean = self::clean_due( $due );

		$data = array(
			'body'   => $body,
			'type'   => $type,
			'due_at' => $clean ? $clean : null,
		);

		// سررسید که عوض شد، یادآوری‌اش باید دوباره برود.
		if ( (string) ( $note['due_at'] ?? '' ) !== (string) $clean ) {
			$data['reminded'] = 0;
			$data['done']     = 0;
		}

		// سررسید تازه روی یادداشتی که صاحب نداشت، به ویرایش‌کننده سپرده می‌شود.
		if ( $clean && '' === trim( (string) ( $note['assignee'] ?? '' ) ) ) {
			$data['assignee'] = self::actor_ref();
		}

		$done = $wpdb->update( // phpcs:ignore WordPress.DB
			self::notes_table(),
			$data,
			array( 'id' => $note_id )
		);

		return false !== $done;
	}

	/**
	 * حذف یک یادداشت.
	 *
	 * @param int $note_id یادداشت.
	 * @return bool
	 */
	public static function delete_note( $note_id ) {
		global $wpdb;

		$note_id = (int) $note_id;
		$note    = $note_id ? self::note( $note_id ) : null;

		if ( ! $note ) {
			return false;
		}

		$wpdb->delete( self::notes_table(), array( 'id' => $note_id ), array( '%d' ) ); // phpcs:ignore WordPress.DB

		// شمارنده‌ی پرونده نباید منفی شود، حتی اگر داده‌ها ناهماهنگ باشند.
		$table = self::table();

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET notes_count = GREATEST(0, notes_count - 1) WHERE id = %d", // phpcs:ignore WordPress.DB
				(int) $note['contact_id']
			)
		);

		return true;
	}

	/**
	 * یادداشت‌های یک پرونده.
	 *
	 * @param int $contact_id پرونده.
	 * @param int $limit      سقف.
	 * @return array
	 */
	/**
	 * آیکون هر نوع یادداشت.
	 *
	 * @param string $type نوع.
	 * @return string
	 */
	public static function note_icon( $type ) {
		$icons = array(
			'note'     => 'edit',
			'call'     => 'phone',
			'meeting'  => 'groups',
			'message'  => 'email-alt',
			'stage'    => 'randomize',
			'followup' => 'clock',
		);

		return $icons[ $type ] ?? 'edit';
	}

	/**
	 * دسته‌های گردش کار، برای فیلتر کردن.
	 *
	 * کلیدها با «kind» رویدادها می‌خوانند؛ یک دسته می‌تواند چند kind را بگیرد.
	 *
	 * @return array
	 */
	public static function journey_filters() {
		return array(
			'all'   => array( 'label' => 'همه', 'kinds' => array() ),
			'note'  => array( 'label' => 'یادداشت‌ها', 'kinds' => array( 'note' ) ),
			'msg'   => array( 'label' => 'پیام‌ها', 'kinds' => array( 'message', 'failed' ) ),
			'order' => array( 'label' => 'سفارش‌ها', 'kinds' => array( 'order' ) ),
			'chat'  => array( 'label' => 'گفتگوها', 'kinds' => array( 'chat', 'bot' ) ),
		);
	}

	/**
	 * گردش کار مشتری: همه‌ی رویدادها از همه‌ی جدول‌ها، مرتب بر پایه‌ی زمان.
	 *
	 * یادداشت‌ها تنها بخشی از داستان‌اند؛ سفارش‌ها، پیام‌های فرستاده‌شده،
	 * گفتگوها و عضویت در ربات هم بخشی از مسیر مشتری‌اند و اینجا کنار هم
	 * دیده می‌شوند.
	 *
	 * @param array $contact پرونده.
	 * @param int   $limit   سقف رویدادها.
	 * @return array
	 */
	public static function journey( array $contact, $limit = 60 ) {
		$events = array();

		$events = array_merge( $events, self::journey_start( $contact ) );
		$events = array_merge( $events, self::journey_notes( $contact ) );
		$events = array_merge( $events, self::journey_messages( $contact ) );
		$events = array_merge( $events, self::journey_orders( $contact ) );
		$events = array_merge( $events, self::journey_conversations( $contact ) );

		// تازه‌ترین بالا.
		usort(
			$events,
			static function ( $a, $b ) {
				return strcmp( (string) $b['time'], (string) $a['time'] );
			}
		);

		return array_slice( $events, 0, max( 1, (int) $limit ) );
	}

	/**
	 * رویداد ساخته شدن پرونده.
	 *
	 * @param array $contact پرونده.
	 * @return array
	 */
	protected static function journey_start( array $contact ) {
		if ( empty( $contact['created_at'] ) ) {
			return array();
		}

		$style = self::source_style( (string) ( $contact['source'] ?? '' ) );

		return array(
			array(
				'time'   => $contact['created_at'],
				'kind'   => 'source',
				'icon'   => $style['icon'],
				'color'  => $style['color'],
				'title'  => 'ورود به پرونده‌ی مشتریان',
				'detail' => 'از راه ' . $style['label'],
			),
		);
	}

	/**
	 * یادداشت‌ها و پیگیری‌ها.
	 *
	 * @param array $contact پرونده.
	 * @return array
	 */
	protected static function journey_notes( array $contact ) {
		$out   = array();
		$types = self::note_types();

		foreach ( self::notes( (int) $contact['id'], 40 ) as $note ) {
			$author = self::note_author( $note );

			$out[] = array(
				'time'   => $note['created_at'],
				'kind'   => 'note',
				// شناسه و نوعِ خام، تا ویرایش و حذف از همین‌جا ممکن باشد.
				'note'   => (int) $note['id'],
				'type'   => (string) $note['type'],
				'raw'    => (string) $note['body'],
				'dueRaw' => (string) ( $note['due_at'] ?? '' ),
				'icon'   => self::note_icon( $note['type'] ),
				'color'  => '#0f766e',
				'title'  => $types[ $note['type'] ] ?? 'یادداشت',
				'detail' => wp_strip_all_tags( (string) $note['body'] ),
				'author' => $author,
				// سررسید پیگیری، تا در گردش کار هم دیده شود نه فقط در «کارهای امروز».
				'due'    => empty( $note['due_at'] ) ? '' : WCMA_Date::html( $note['due_at'], 'datetime' ),
				'done'   => ! empty( $note['done'] ),
			);
		}

		return $out;
	}

	/**
	 * پیام‌هایی که افزونه برای این مشتری فرستاده است.
	 *
	 * @param array $contact پرونده.
	 * @return array
	 */
	protected static function journey_messages( array $contact ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_logs' ) ) {
			return array();
		}

		$targets = array_filter( array( $contact['email'] ?? '', $contact['phone'] ?? '' ) );

		if ( ! $targets ) {
			return array();
		}

		$table  = $wpdb->prefix . 'wcma_logs';
		$holder = implode( ', ', array_fill( 0, count( $targets ), '%s' ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE recipient IN ({$holder}) ORDER BY created_at DESC LIMIT 30", $targets ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		$labels   = class_exists( 'WCMA_Admin' ) ? WCMA_Admin::workflow_labels() : array();
		$channels = WCMA_Sender::channels();
		$out      = array();

		foreach ( (array) $rows as $row ) {
			$sent   = 'sent' === $row['status'];
			$detail = ( $channels[ $row['channel'] ] ?? $row['channel'] );

			if ( ! empty( $row['subject'] ) ) {
				$detail .= ' — ' . $row['subject'];
			}

			if ( ! $sent && ! empty( $row['error_message'] ) ) {
				$detail .= ' — ' . $row['error_message'];
			}

			if ( ! empty( $row['coupon_code'] ) ) {
				$detail .= ' — کد: ' . $row['coupon_code'];
			}

			$out[] = array(
				'time'   => $row['created_at'],
				'kind'   => $sent ? 'message' : 'failed',
				'icon'   => $sent ? 'email-alt' : 'warning',
				'color'  => $sent ? '#0284c7' : '#dc2626',
				'title'  => ( $labels[ $row['workflow'] ] ?? $row['workflow'] ) . ( $sent ? '' : ' (ناموفق)' ),
				'detail' => $detail,
			);
		}

		return $out;
	}

	/**
	 * سفارش‌های مشتری.
	 *
	 * @param array $contact پرونده.
	 * @return array
	 */
	protected static function journey_orders( array $contact ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$args = array( 'limit' => 15, 'orderby' => 'date', 'order' => 'DESC', 'return' => 'objects' );

		if ( ! empty( $contact['user_id'] ) ) {
			$args['customer_id'] = (int) $contact['user_id'];
		} elseif ( ! empty( $contact['email'] ) ) {
			$args['billing_email'] = $contact['email'];
		} else {
			return array();
		}

		$orders = wc_get_orders( $args );
		$out    = array();

		foreach ( (array) $orders as $order ) {
			if ( ! is_object( $order ) || ! method_exists( $order, 'get_date_created' ) ) {
				continue;
			}

			$date = $order->get_date_created();

			if ( ! $date ) {
				continue;
			}

			$out[] = array(
				'time'   => $date->date( 'Y-m-d H:i:s' ),
				'kind'   => 'order',
				'icon'   => 'cart',
				'color'  => '#16a34a',
				'title'  => 'سفارش #' . $order->get_order_number(),
				'detail' => wc_get_order_status_name( $order->get_status() ) . ' — ' . wp_strip_all_tags( wc_price( $order->get_total() ) ),
				'link'   => method_exists( $order, 'get_edit_order_url' ) ? $order->get_edit_order_url() : '',
			);
		}

		return $out;
	}

	/**
	 * گفتگوها و عضویت در ربات.
	 *
	 * @param array $contact پرونده.
	 * @return array
	 */
	protected static function journey_conversations( array $contact ) {
		global $wpdb;

		$out = array();
		$id  = (int) $contact['id'];

		if ( WCMA_Install::table_exists( 'wcma_chats' ) ) {
			$table = $wpdb->prefix . 'wcma_chats';

			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE contact_id = %d ORDER BY created_at DESC LIMIT 10", $id ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);

			foreach ( (array) $rows as $row ) {
				$out[] = array(
					'time'   => $row['created_at'] ?? $row['last_message_at'],
					'kind'   => 'chat',
					'icon'   => 'format-chat',
					'color'  => '#7c3aed',
					'title'  => 'گفتگو در ' . ( WCMA_Chatbot::channel_label( $row['channel'] ) ),
					'detail' => WCMA_Date::number( (int) $row['message_count'] ) . ' پیام'
						. ( ! empty( $row['last_message'] ) ? ' — آخرین پیام: ' . wp_strip_all_tags( (string) $row['last_message'] ) : '' ),
				);
			}
		}

		if ( WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			$table = $wpdb->prefix . 'wcma_bot_subs';

			$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE contact_id = %d ORDER BY id DESC LIMIT 1", $id ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);

			if ( $row ) {
				$out[] = array(
					'time'   => $row['started_at'],
					'kind'   => 'bot',
					'icon'   => 'admin-site-alt3',
					'color'  => '#2563eb',
					'title'  => 'عضویت در ربات',
					'detail' => WCMA_Date::number( (int) $row['sent_count'] ) . ' پیام دنباله گرفته'
						. ( ! empty( $row['phone'] ) ? ' — شماره داده است' : '' ),
				);
			}
		}

		return $out;
	}

	/**
	 * پاک‌سازی تاریخ سررسید.
	 *
	 * ورودی می‌تواند شمسی یا میلادی باشد، با ساعت یا بدون آن. بدون ساعت،
	 * سررسید نه نیمه‌شب که ابتدای ساعت کاری گذاشته می‌شود؛ یادآوریِ ساعت
	 * دوازدهِ شب به درد کسی نمی‌خورد.
	 *
	 * @param string $due ورودی.
	 * @return string خالی یا Y-m-d H:i:s.
	 */
	public static function clean_due( $due ) {
		$due = trim( (string) $due );

		if ( '' === $due ) {
			return '';
		}

		/*
		 * تشخیص ساعت باید روی رقم لاتین انجام شود: «۱۴:۳۰» با \d نمی‌خواند و
		 * آن‌وقت ساعتی که کاربر نوشته بی‌صدا دور ریخته می‌شد و سررسید به
		 * ساعت پیش‌فرض می‌افتاد.
		 */
		$plain    = WCMA_Date::to_latin_digits( $due );
		$has_time = (bool) preg_match( '/\d{1,2}:\d{2}/', $plain );
		$parsed   = WCMA_Date::parse( $due, $has_time ? 'datetime' : 'date' );

		if ( ! $parsed ) {
			return '';
		}

		if ( ! $has_time ) {
			return $parsed . ' ' . self::default_due_time();
		}

		return strlen( $parsed ) <= 16 ? $parsed . ':00' : $parsed;
	}

	/**
	 * ساعت پیش‌فرض یادآوری‌های بدون ساعت.
	 *
	 * @return string
	 */
	public static function default_due_time() {
		$time = trim( (string) WCMA_Settings::get( 'followup_hour', '09:00' ) );

		return preg_match( '/^\d{2}:\d{2}$/', $time ) ? $time . ':00' : '09:00:00';
	}

	/**
	 * شناسه‌ی کسی که همین حالا کار می‌کند.
	 *
	 * کاربر وردپرس و حساب کنسول دو فضای شناسه‌ی جدا دارند و شماره‌هایشان
	 * می‌تواند یکی باشد؛ پس پیشوند می‌گیرند تا یادآوری به آدرس اشتباه نرود.
	 *
	 * @return string
	 */
	public static function actor_ref() {
		if ( class_exists( 'WCMA_Agent_API' ) ) {
			$actor = WCMA_Agent_API::actor();

			if ( is_array( $actor ) && ! empty( $actor['id'] ) && 'app' === ( $actor['kind'] ?? '' ) ) {
				return 'app:' . (int) $actor['id'];
			}
		}

		$wp = get_current_user_id();

		return $wp ? 'wp:' . (int) $wp : '';
	}

	/**
	 * کارهای سررسیدشده.
	 *
	 * @param array $args فیلترها.
	 * @return array
	 */
	public static function due_items( array $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'assignee' => '',   // خالی یعنی همه.
				'until'    => '',   // پیش‌فرض: پایان امروز.
				'done'     => 0,
				'limit'    => 50,
			)
		);

		$notes    = self::notes_table();
		$contacts = self::table();
		$until    = $args['until'] ? $args['until'] : gmdate( 'Y-m-d 23:59:59', (int) current_time( 'timestamp' ) );

		$where  = array( 'n.due_at IS NOT NULL', 'n.due_at <= %s', 'n.done = %d' );
		$params = array( $until, (int) $args['done'] );

		if ( '' !== $args['assignee'] ) {
			$where[]  = 'n.assignee = %s';
			$params[] = $args['assignee'];
		}

		$params[] = max( 1, (int) $args['limit'] );

		$sql = "SELECT n.*, c.first_name, c.last_name, c.company, c.phone, c.email
			FROM {$notes} n
			LEFT JOIN {$contacts} c ON c.id = n.contact_id
			WHERE " . implode( ' AND ', $where ) . '
			ORDER BY n.due_at ASC
			LIMIT %d';

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $rows ? $rows : array();
	}

	/**
	 * شمار کارهای سررسیدشده.
	 *
	 * @param string $assignee صاحب کار.
	 * @return int
	 */
	public static function due_count( $assignee = '' ) {
		return count( self::due_items( array( 'assignee' => $assignee, 'limit' => 200 ) ) );
	}

	/**
	 * بستن یک کار.
	 *
	 * @param int  $note_id یادداشت.
	 * @param bool $done    انجام‌شده یا برگشت به فهرست.
	 * @return bool
	 */
	public static function mark_done( $note_id, $done = true ) {
		global $wpdb;

		$note_id = (int) $note_id;

		if ( ! $note_id ) {
			return false;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB
			self::notes_table(),
			array( 'done' => $done ? 1 : 0 ),
			array( 'id' => $note_id ),
			array( '%d' ),
			array( '%d' )
		);

		return false !== $updated;
	}

	/**
	 * تغییر سررسید یک کار.
	 *
	 * @param int    $note_id یادداشت.
	 * @param string $due     سررسید تازه.
	 * @return bool
	 */
	public static function set_due( $note_id, $due ) {
		global $wpdb;

		$note_id = (int) $note_id;
		$clean   = self::clean_due( $due );

		if ( ! $note_id ) {
			return false;
		}

		$updated = $wpdb->update( // phpcs:ignore WordPress.DB
			self::notes_table(),
			array(
				'due_at'   => $clean ? $clean : null,
				// سررسید که عوض شد، یادآوری دوباره باید برود.
				'reminded' => 0,
				'done'     => 0,
			),
			array( 'id' => $note_id ),
			array( '%s', '%d', '%d' ),
			array( '%d' )
		);

		return false !== $updated;
	}

	/**
	 * یک یادداشت با همه‌ی ستون‌هایش.
	 *
	 * @param int $note_id شناسه.
	 * @return array|null
	 */
	public static function note( $note_id ) {
		global $wpdb;

		$table = self::notes_table();

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $note_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $row ? $row : null;
	}

	public static function notes( $contact_id, $limit = 50 ) {
		global $wpdb;

		$table = self::notes_table();

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE contact_id = %d ORDER BY id DESC LIMIT %d", (int) $contact_id, (int) $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return $rows ? $rows : array();
	}

	/**
	 * فهرست پرونده‌ها با فیلتر و صفحه‌بندی.
	 *
	 * @param array $args فیلترها.
	 * @return array{items:array,total:int,pages:int}
	 */
	public static function query( array $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'search'   => '',
				'stage'    => '',
				'tag'      => '',
				'source'   => '',
				'owner'    => 0,
				'followup' => '',
				'orderby'  => 'updated_at',
				'order'    => 'DESC',
				'page'     => 1,
				'per_page' => 25,
			)
		);

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR phone LIKE %s OR company LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		if ( $args['stage'] ) {
			$where[]  = 'stage = %s';
			$params[] = $args['stage'];
		}

		if ( $args['source'] ) {
			$where[]  = 'source = %s';
			$params[] = $args['source'];
		}

		if ( $args['owner'] ) {
			$where[]  = 'owner_id = %d';
			$params[] = (int) $args['owner'];
		}

		if ( $args['tag'] ) {
			$where[]  = 'tags LIKE %s';
			$params[] = '%' . $wpdb->esc_like( ',' . $args['tag'] . ',' ) . '%';
		}

		if ( 'due' === $args['followup'] ) {
			$where[]  = 'next_followup_at IS NOT NULL AND next_followup_at <= %s';
			$params[] = current_time( 'mysql' );
		} elseif ( 'planned' === $args['followup'] ) {
			$where[] = 'next_followup_at IS NOT NULL';
		}

		$allowed_order = array( 'updated_at', 'created_at', 'total_spent', 'order_count', 'last_order_at', 'next_followup_at' );
		$orderby       = in_array( $args['orderby'], $allowed_order, true ) ? $args['orderby'] : 'updated_at';
		$order         = 'ASC' === strtoupper( $args['order'] ) ? 'ASC' : 'DESC';

		$per_page = max( 5, min( 200, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );
		$offset   = ( $page - 1 ) * $per_page;

		$clause = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$clause}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore WordPress.DB

		$sql             = "SELECT * FROM {$table} WHERE {$clause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$params_with_pag = array_merge( $params, array( $per_page, $offset ) );

		$items = $wpdb->get_results( $wpdb->prepare( $sql, $params_with_pag ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return array(
			'items' => $items ? $items : array(),
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
			'page'  => $page,
		);
	}

	/**
	 * آمار کلی برای کارت‌های بالای صفحه.
	 *
	 * @return array
	 */
	public static function stats() {
		global $wpdb;

		$table = self::table();

		if ( ! WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			return array(
				'total'    => 0,
				'stages'   => array(),
				'due'      => 0,
				'new_week' => 0,
				'revenue'  => 0.0,
			);
		}

		$stages = array();
		$rows   = $wpdb->get_results( "SELECT stage, COUNT(*) AS c FROM {$table} GROUP BY stage", ARRAY_A ); // phpcs:ignore WordPress.DB

		foreach ( (array) $rows as $row ) {
			$stages[ $row['stage'] ] = (int) ( $row['c'] ?? 0 );
		}

		$week = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - WEEK_IN_SECONDS );

		return array(
			'total'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ), // phpcs:ignore WordPress.DB
			'stages'   => $stages,
			'due'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE next_followup_at IS NOT NULL AND next_followup_at <= %s", current_time( 'mysql' ) ) ), // phpcs:ignore WordPress.DB
			'new_week' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", $week ) ), // phpcs:ignore WordPress.DB
			'revenue'  => (float) $wpdb->get_var( "SELECT SUM(total_spent) FROM {$table}" ), // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * مرحله‌ی مناسب بر اساس رفتار خرید.
	 *
	 * @param int    $orders  تعداد سفارش.
	 * @param string $last    آخرین سفارش.
	 * @param string $current مرحله‌ی فعلی.
	 * @return string
	 */
	public static function guess_stage( $orders, $last = '', $current = '' ) {
		// مرحله‌ای که مدیر دستی گذاشته، با همگام‌سازی خودکار بازنویسی نمی‌شود.
		if ( 'vip' === $current ) {
			return 'vip';
		}

		$churn_days = max( 30, (int) WCMA_Settings::get( 'crm_churn_days', 180 ) );

		if ( $orders > 0 && $last ) {
			$age = time() - strtotime( $last );

			if ( $age > $churn_days * DAY_IN_SECONDS ) {
				return 'churn';
			}
		}

		if ( $orders > 1 ) {
			return 'repeat';
		}

		if ( 1 === (int) $orders ) {
			return 'customer';
		}

		return in_array( $current, array( 'prospect', 'churn' ), true ) ? $current : 'lead';
	}

	/**
	 * همگام‌سازی پرونده‌ها با سفارش‌ها، سبدها و درخواست‌های موجودی.
	 *
	 * @param int $limit سقف رکورد در هر منبع.
	 * @return array
	 */
	public static function sync( $limit = 2000 ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			return array(
				'ok'      => false,
				'message' => 'جدول پرونده‌ی مشتریان ساخته نشده است. از تب «تست ارسال» دکمه‌ی ترمیم جدول‌ها را بزنید.',
			);
		}

		$created = 0;
		$updated = 0;

		// ۱) سفارش‌ها: مبلغ، تعداد و تاریخ اولین و آخرین خرید.
		foreach ( self::order_rows( $limit ) as $row ) {
			$email = sanitize_email( (string) $row['email'] );
			$phone = (string) ( $row['phone'] ?? '' );

			if ( ! $email && ! $phone ) {
				continue;
			}

			$existing = self::find( $email, $phone );
			$stage    = self::guess_stage( (int) $row['order_count'], (string) $row['last_order_at'], $existing['stage'] ?? '' );

			$id = self::upsert(
				array(
					'email'          => $email,
					'phone'          => $phone,
					'user_id'        => (int) ( $row['user_id'] ?? 0 ),
					'first_name'     => (string) ( $row['first_name'] ?? '' ),
					'last_name'      => (string) ( $row['last_name'] ?? '' ),
					'city'           => (string) ( $row['city'] ?? '' ),
					'order_count'    => (int) $row['order_count'],
					'total_spent'    => (float) $row['total_spent'],
					'first_order_at' => $row['first_order_at'],
					'last_order_at'  => $row['last_order_at'],
					'stage'          => $stage,
					'source'         => $existing ? ( $existing['source'] ? $existing['source'] : 'order' ) : 'order',
				)
			);

			if ( $id ) {
				$existing ? $updated++ : $created++;
			}
		}

		// ۲) سبدهای رها شده: کسی که هنوز خرید نکرده، سرنخ در حال بررسی است.
		if ( WCMA_Install::table_exists( 'wcma_carts' ) ) {
			$carts_table = $wpdb->prefix . 'wcma_carts';

			$carts = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT email, phone, first_name, user_id, updated_at FROM {$carts_table} ORDER BY id DESC LIMIT %d", (int) $limit ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);

			foreach ( (array) $carts as $cart ) {
				$existing = self::find( $cart['email'], $cart['phone'] );

				if ( $existing && (int) $existing['order_count'] > 0 ) {
					continue;
				}

				$id = self::upsert(
					array(
						'email'      => $cart['email'],
						'phone'      => $cart['phone'],
						'first_name' => $cart['first_name'],
						'user_id'    => (int) $cart['user_id'],
						'stage'      => 'prospect',
						'source'     => $existing ? ( $existing['source'] ? $existing['source'] : 'cart' ) : 'cart',
					)
				);

				if ( $id ) {
					$existing ? $updated++ : $created++;
				}
			}
		}

		// ۳) درخواست‌های هشدار موجودی.
		if ( WCMA_Install::table_exists( 'wcma_stock_alerts' ) ) {
			$alerts_table = $wpdb->prefix . 'wcma_stock_alerts';

			$alerts = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT email, phone, first_name, user_id FROM {$alerts_table} ORDER BY id DESC LIMIT %d", (int) $limit ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);

			foreach ( (array) $alerts as $alert ) {
				$existing = self::find( $alert['email'], $alert['phone'] );

				$id = self::upsert(
					array(
						'email'      => $alert['email'],
						'phone'      => $alert['phone'],
						'first_name' => $alert['first_name'],
						'user_id'    => (int) $alert['user_id'],
						'stage'      => $existing && (int) $existing['order_count'] > 0 ? $existing['stage'] : 'prospect',
						'source'     => $existing ? ( $existing['source'] ? $existing['source'] : 'stock_alert' ) : 'stock_alert',
					)
				);

				if ( $id ) {
					$existing ? $updated++ : $created++;
				}
			}
		}

		// ۴) اعضای باشگاه مشتریان مرحله‌ی ویژه می‌گیرند.
		if ( WCMA_Install::table_exists( 'wcma_vip_members' ) ) {
			$vip_table = $wpdb->prefix . 'wcma_vip_members';
			$table     = self::table();

			$wpdb->query( // phpcs:ignore WordPress.DB
				"UPDATE {$table} c INNER JOIN {$vip_table} v ON v.email = c.email
				SET c.stage = 'vip' WHERE v.tier > 0" // phpcs:ignore WordPress.DB
			);
		}

		update_option( 'wcma_crm_last_sync', current_time( 'mysql' ) );

		return array(
			'ok'      => true,
			'created' => $created,
			'updated' => $updated,
			'message' => sprintf(
				'%s پرونده‌ی تازه ساخته شد و %s پرونده به‌روز شد.',
				WCMA_Date::number( $created ),
				WCMA_Date::number( $updated )
			),
		);
	}

	/**
	 * خلاصه‌ی سفارش‌های هر مشتری، سازگار با HPOS و جدول‌های قدیمی.
	 *
	 * @param int $limit سقف.
	 * @return array
	 */
	protected static function order_rows( $limit ) {
		global $wpdb;

		$statuses     = array( 'wc-completed', 'wc-processing', 'wc-on-hold' );
		$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

		if ( WCMA_Workflow_Winback::hpos_enabled() ) {
			$orders    = $wpdb->prefix . 'wc_orders';
			$addresses = $wpdb->prefix . 'wc_order_addresses';

			$sql = "SELECT o.billing_email AS email,
					MAX(o.customer_id) AS user_id,
					COUNT(*) AS order_count,
					SUM(o.total_amount) AS total_spent,
					MIN(o.date_created_gmt) AS first_order_at,
					MAX(o.date_created_gmt) AS last_order_at,
					MAX(a.phone) AS phone,
					MAX(a.first_name) AS first_name,
					MAX(a.last_name) AS last_name,
					MAX(a.city) AS city
					FROM {$orders} o
					LEFT JOIN {$addresses} a ON a.order_id = o.id AND a.address_type = 'billing'
					WHERE o.status IN ({$placeholders}) AND o.billing_email <> ''
					GROUP BY o.billing_email
					ORDER BY total_spent DESC
					LIMIT %d";
		} else {
			$sql = "SELECT pm_email.meta_value AS email,
					0 AS user_id,
					COUNT(*) AS order_count,
					SUM(pm_total.meta_value) AS total_spent,
					MIN(p.post_date_gmt) AS first_order_at,
					MAX(p.post_date_gmt) AS last_order_at,
					MAX(pm_phone.meta_value) AS phone,
					MAX(pm_first.meta_value) AS first_name,
					MAX(pm_last.meta_value) AS last_name,
					MAX(pm_city.meta_value) AS city
					FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm_email ON pm_email.post_id = p.ID AND pm_email.meta_key = '_billing_email'
					INNER JOIN {$wpdb->postmeta} pm_total ON pm_total.post_id = p.ID AND pm_total.meta_key = '_order_total'
					LEFT JOIN {$wpdb->postmeta} pm_phone ON pm_phone.post_id = p.ID AND pm_phone.meta_key = '_billing_phone'
					LEFT JOIN {$wpdb->postmeta} pm_first ON pm_first.post_id = p.ID AND pm_first.meta_key = '_billing_first_name'
					LEFT JOIN {$wpdb->postmeta} pm_last ON pm_last.post_id = p.ID AND pm_last.meta_key = '_billing_last_name'
					LEFT JOIN {$wpdb->postmeta} pm_city ON pm_city.post_id = p.ID AND pm_city.meta_key = '_billing_city'
					WHERE p.post_type = 'shop_order' AND p.post_status IN ({$placeholders}) AND pm_email.meta_value <> ''
					GROUP BY pm_email.meta_value
					ORDER BY total_spent DESC
					LIMIT %d";
		}

		$params = array_merge( $statuses, array( (int) $limit ) );
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $rows ? $rows : array();
	}

	/**
	 * پیگیری‌های سررسیدشده.
	 *
	 * @param int $limit سقف.
	 * @return array
	 */
	public static function due_followups( $limit = 20 ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_contacts' ) ) {
			return array();
		}

		$table = self::table();

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE next_followup_at IS NOT NULL AND next_followup_at <= %s ORDER BY next_followup_at ASC LIMIT %d", // phpcs:ignore WordPress.DB
				current_time( 'mysql' ),
				(int) $limit
			),
			ARRAY_A
		);

		return $rows ? $rows : array();
	}

	/**
	 * نام نمایشی یک پرونده.
	 *
	 * @param array $contact پرونده.
	 * @return string
	 */
	public static function display_name( array $contact ) {
		$name = trim( ( $contact['first_name'] ?? '' ) . ' ' . ( $contact['last_name'] ?? '' ) );

		if ( $name ) {
			return $name;
		}

		if ( ! empty( $contact['email'] ) ) {
			return $contact['email'];
		}

		return $contact['phone'] ?? 'بدون نام';
	}

	/**
	 * خروجی CSV پرونده‌ها.
	 *
	 * @param array $args فیلترها.
	 * @return string
	 */
	public static function to_csv( array $args = array() ) {
		$args['per_page'] = 5000;
		$result           = self::query( $args );

		$out = "\xEF\xBB\xBF"; // BOM تا اکسل فارسی را درست بخواند.
		$out .= implode( ',', array( 'نام', 'ایمیل', 'موبایل', 'مرحله', 'برچسب‌ها', 'تعداد سفارش', 'مبلغ کل', 'آخرین خرید', 'پیگیری بعدی' ) ) . "\n";

		foreach ( $result['items'] as $row ) {
			$cells = array(
				self::display_name( $row ),
				$row['email'],
				$row['phone'],
				self::stage_label( $row['stage'] ),
				implode( ' | ', self::tag_list( $row['tags'] ) ),
				$row['order_count'],
				$row['total_spent'],
				! empty( $row['last_order_at'] ) ? WCMA_Date::mysql( $row['last_order_at'], 'date', '' ) : '',
				! empty( $row['next_followup_at'] ) ? WCMA_Date::mysql( $row['next_followup_at'], 'date', '' ) : '',
			);

			$out .= implode(
				',',
				array_map(
					static function ( $cell ) {
						return '"' . str_replace( '"', '""', (string) $cell ) . '"';
					},
					$cells
				)
			) . "\n";
		}

		return $out;
	}
}
