<?php
/**
 * Plugin Name: اتوماسیون بازاریابی کلاسیکا
 * Plugin URI:  https://example.com/klassika
 * Description: اتوماسیون کامل بازاریابی برای ووکامرس، ساخته‌ی تیم دکتر علی مرادی؛ بازیابی سبد خرید رها شده، هشدار موجودی، باشگاه مشتریان VIP، یادآوری و پاداش ثبت نظر، خرید مجدد، تولد مشتری، کمپین‌های ایمیل، پیامک، واتساپ، تلگرام، بله، ایتا و روبیکا، تولید محتوا با هوش مصنوعی و گزارش‌های دقیق.
 * Version:     4.1.0
 * Author:      تیم دکتر علی مرادی
 * Text Domain: wc-marketing-automation
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * WC requires at least: 6.0
 * WC tested up to: 9.4
 * License:     GPL-2.0-or-later
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

define( 'WCMA_VERSION', '4.1.0' );
define( 'WCMA_FILE', __FILE__ );
define( 'WCMA_PATH', plugin_dir_path( __FILE__ ) );
define( 'WCMA_URL', plugin_dir_url( __FILE__ ) );
define( 'WCMA_BASENAME', plugin_basename( __FILE__ ) );

/**
 * اعلام سازگاری با جدول‌های سفارش سفارشی ووکامرس (HPOS).
 */
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WCMA_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', WCMA_FILE, true );
		}
	}
);

require_once WCMA_PATH . 'includes/class-wcma-install.php';

register_activation_hook( WCMA_FILE, array( 'WCMA_Install', 'activate' ) );
register_deactivation_hook( WCMA_FILE, array( 'WCMA_Install', 'deactivate' ) );

/**
 * بارگذاری افزونه پس از اطمینان از فعال بودن ووکامرس.
 */
add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain( 'wc-marketing-automation', false, dirname( WCMA_BASENAME ) . '/languages' );

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-error"><p><strong>اتوماسیون بازاریابی کلاسیکا:</strong> برای کار کردن این افزونه باید ووکامرس نصب و فعال باشد.</p></div>';
				}
			);
			return;
		}

		require_once WCMA_PATH . 'includes/class-wcma-plugin.php';
		WCMA_Plugin::instance();
	},
	20
);

/**
 * دسترسی سریع به نمونه‌ی افزونه.
 *
 * @return WCMA_Plugin|null
 */
function wcma() {
	return class_exists( 'WCMA_Plugin' ) ? WCMA_Plugin::instance() : null;
}
