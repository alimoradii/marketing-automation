<?php
/**
 * مدیریت تنظیمات افزونه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Settings
 */
class WCMA_Settings {

	const OPTION = 'wcma_settings';

	/**
	 * کش تنظیمات.
	 *
	 * @var array|null
	 */
	protected static $cache = null;

	/**
	 * مقادیر موقتِ فقط برای همین درخواست (برای تست اتصال بدون ذخیره‌سازی).
	 *
	 * @var array
	 */
	protected static $overrides = array();

	/**
	 * مقادیر پیش‌فرض همه‌ی تنظیمات.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// --- عمومی ---
			'enabled'                     => 'yes',
			'sms_fallback_email'          => 'yes',
			'error_report_admin'          => 'no',
			'error_report_email'          => get_option( 'admin_email' ),
			'log_enabled'                 => 'yes',
			'log_retention_days'          => 90,
			'quiet_hours_enabled'         => 'yes',
			'quiet_hours_start'           => '23:00',
			'quiet_hours_end'             => '08:00',
			'batch_size'                  => 25,
			'from_name'                   => get_bloginfo( 'name' ),
			'from_email'                  => get_option( 'admin_email' ),
			'unsubscribe_enabled'         => 'yes',
			'date_calendar'               => 'jalali',
			'date_digits'                 => 'fa',
			'shop_phone'                  => '',

			// ترتیب جایگزینی کانال‌ها وقتی کانال انتخابی برای مشتری ممکن نیست.
			'channel_priority'            => array( 'sms', 'email', 'whatsapp', 'telegram', 'bale', 'eitaa', 'rubika' ),

			// چت‌بات.
			'chat_enabled'                => 'no',
			'chat_skills'                 => array( 'order_status', 'product', 'hours', 'operator' ),
			'chat_rules'                  => array(),
			'chat_ai_enabled'             => 'no',
			'chat_welcome_text'           => 'سلام! من دستیار فروشگاه هستم. برای پیگیری سفارش، قیمت محصول یا گفتگو با کارشناس، همین‌جا بنویسید.',
			'chat_fallback_text'          => 'پیام شما را دریافت کردم. اگر پاسخ فوری می‌خواهید بنویسید «اپراتور» تا کارشناس ما پاسخ دهد.',
			'chat_fallback_handover'      => 'no',
			'chat_handover_text'          => 'درخواست شما برای گفتگو با کارشناس ثبت شد. لطفاً چند لحظه صبر کنید؛ همکاران ما همین‌جا پاسخ می‌دهند.',
			'chat_hours_text'             => '',
			'chat_notify_phone'           => '',

			// مدیریت ربات تلگرام/بله.
			'tg_bot_enabled'              => 'no',
			'tg_bot_channel'              => 'telegram',
			'tg_welcome_text'             => 'سلام! به ربات ما خوش آمدید. برای شروع، شماره‌ی موبایل خود را با دکمه‌ی زیر بفرستید.',
			'tg_welcome_type'             => 'text',
			'tg_welcome_file'             => '',
			'tg_ask_phone'                => 'yes',
			'tg_phone_button'             => '📱 اشتراک‌گذاری شماره‌ی من',
			'tg_phone_thanks'             => 'ممنون! شماره‌ی شما ثبت شد. از فردا هر روز یک پیام برایتان می‌فرستیم.',
			'tg_menu'                     => array(),
			'tg_menu_cols'                => 2,
			'tg_messages'                 => array(),
			'tg_seq_enabled'              => 'no',
			'tg_seq_time'                 => '10:00',
			'tg_seq_first_now'            => 'yes',
			'tg_sequence'                 => array(),

			// کنسول کارکنان در ربات
			'staff_bot'                   => 'no',

			// پنل کاربری، ورود با کد و کیف پول
			'panel_enabled'               => 'no',
			'panel_slug'                  => 'my-panel',
			'panel_title'                 => 'پنل کاربری',
			'panel_demo'                  => 'sidebar',
			'panel_color'                 => '#2563eb',
			'panel_role'                  => '',
			'otp_sms_text'                => 'کد ورود شما به {site}: {code}',
			'otp_autofill'                => 'yes',

			'wallet_enabled'              => 'no',
			'wallet_min'                  => 10000,
			'wallet_max'                  => 50000000,
			'wallet_gateway'              => 'yes',
			'wallet_gateway_title'        => 'پرداخت از کیف پول',

			'tickets_enabled'             => 'no',
			'ticket_departments'          => "پشتیبانی فنی\nفروش\nمالی",
			'ticket_notify_staff'         => 'yes',
			'ticket_notify_user'          => 'yes',
			'ticket_staff_email'          => '',

			// یادآوری پیگیری‌ها
			'followup_reminders'          => 'yes',
			'followup_channel'            => 'auto',
			'followup_hour'               => '09:00',

			// لید مگنت
			'lm_enabled'                  => 'no',
			'lm_title'                    => 'راهنمای رایگان را دریافت کنید',
			'lm_subtitle'                 => 'شماره‌تان را بگذارید تا همین حالا برایتان بفرستیم.',
			'lm_button'                   => 'دریافت رایگان',
			'lm_ask_name'                 => 'yes',
			'lm_ask_email'                => 'no',
			'lm_tag'                      => 'لید مگنت',
			'lm_consent'                  => 'با ثبت شماره، با دریافت پیام از ما موافقت می‌کنید. هر زمان بخواهید می‌توانید لغو کنید.',
			'lm_success'                  => 'ثبت شد! هدیه‌ی شما همین حالا پیامک شد.',
			'lm_reward'                   => 'coupon',
			'lm_file'                     => '',
			'lm_coupon_type'              => 'percent',
			'lm_coupon_amount'            => '10',
			'lm_coupon_days'              => '7',
			'lm_coupon_min'               => '0',
			'lm_channel'                  => 'sms',
			'lm_subject'                  => 'هدیه‌ی شما',
			'lm_sms_text'                 => '{first_name} عزیز، کد تخفیف شما: {coupon_code}',
			'lm_email_text'               => '',

			// کنسول اپراتور
			'app_slug'                    => '',

			// چت آنلاین سایت.
			'lc_enabled'                  => 'no',
			'lc_position'                 => 'left',
			'lc_color'                    => '#2563eb',
			'lc_title'                    => 'پشتیبانی آنلاین',
			'lc_subtitle'                 => 'معمولاً در چند دقیقه پاسخ می‌دهیم',
			'lc_welcome'                  => 'سلام! چطور می‌توانیم کمکتان کنیم؟',
			'lc_offline_text'             => 'الان خارج از ساعت کاری هستیم. پیام بگذارید، به‌زودی پاسخ می‌دهیم.',
			'lc_greeting'                 => 'سؤالی دارید؟ همین‌جا بپرسید.',
			'lc_greeting_delay'           => 8,
			'lc_avatar'                   => '',
			'lc_avatar_2'                 => '',
			'lc_avatar_3'                 => '',
			'lc_ask_name'                 => 'yes',
			'lc_ask_phone'                => 'yes',
			'lc_ask_email'                => 'no',
			'lc_quick_replies'            => 'پیگیری سفارش، هزینه ارسال، مشاوره خرید',
			'lc_rating'                   => 'yes',
			'lc_sound'                    => 'yes',
			'lc_logged_in_only'           => 'no',
			'lc_hours_start'              => 0,
			'lc_hours_end'                => 0,

			// فرم تماس خارج از ساعت کاری
			'lc_lead_form'                => 'no',
			'lc_lead_form_text'           => 'کاربر گرامی، ساعت کاری بخش پشتیبانی {hours} می‌باشد. لطفاً مشخصات و مورد خود را ارسال نمایید تا تیم پشتیبانی در شروع ساعت کاری بررسی و پاسخگویی داشته باشند.',
			'lc_lead_form_name'           => 'no',
			'lc_lead_form_order'          => 'yes',
			'lc_lead_form_thanks'         => 'ممنون! مشخصات شما ثبت شد؛ در شروع ساعت کاری با شما تماس می‌گیریم.',

			// پیوست در گفتگو.
			'lc_files_enabled'            => 'yes',
			'lc_voice_enabled'            => 'yes',
			'lc_file_max_mb'              => 8,
			'lc_files_prune'              => 'yes',
			'lc_files_keep_days'          => 90,

			// پرونده‌ی مشتریان.
			'crm_enabled'                 => 'yes',
			'crm_auto_sync'               => 'yes',
			'crm_churn_days'              => 180,
			'crm_followup_reminder'       => 'yes',
			'crm_reminder_phone'          => '',
			'bot_connect_prompt'          => 'yes',
			'delete_data_on_uninstall'    => 'no',

			// --- ارسال ایمیل با SMTP ---
			'smtp_enabled'                => 'no',
			'smtp_host'                   => '',
			'smtp_port'                   => 587,
			'smtp_secure'                 => 'tls',
			'smtp_auth'                   => 'yes',
			'smtp_user'                   => '',
			'smtp_pass'                   => '',
			'smtp_from_email'             => '',
			'smtp_from_name'              => '',
			'smtp_force_from'             => 'yes',
			'smtp_debug'                  => 'no',

			// --- پنل پیامک ---
			'sms_enabled'                 => 'no',
			'sms_gateway'                 => 'kavenegar',
			'sms_api_key'                 => '',
			'sms_username'                => '',
			'sms_password'                => '',
			'sms_sender'                  => '',
			'sms_use_pattern'             => 'no',
			'sms_ippanel_api'             => 'auto',
			'sms_custom_url'              => '',
			'sms_custom_method'           => 'POST',
			'sms_custom_body'             => '{"receptor":"{phone}","message":"{message}"}',
			'sms_custom_headers'          => '',

			// --- پیام‌رسان‌ها ---
			'bot_webhook_secret'          => '',

			'telegram_enabled'            => 'no',
			'telegram_bot_token'          => '',
			'telegram_channel_id'         => '',
			'telegram_bot_username'       => '',

			'bale_enabled'                => 'no',
			'bale_bot_token'              => '',
			'bale_chat_id'                => '',
			'bale_bot_username'           => '',

			'eitaa_enabled'               => 'no',
			'eitaa_token'                 => '',
			'eitaa_chat_id'               => '',

			'rubika_enabled'              => 'no',
			'rubika_token'                => '',
			'rubika_chat_id'              => '',
			'rubika_bot_username'         => '',

			'whatsapp_enabled'            => 'no',
			'whatsapp_token'              => '',
			'whatsapp_phone_id'           => '',
			'whatsapp_api_version'        => 'v21.0',
			'whatsapp_template'           => '',
			'whatsapp_template_lang'      => 'fa',

			// --- ۱) سبد رها شده / سفارش تکمیل نشده ---
			'ab_enabled'                  => 'no',
			'ab_track_guests'             => 'yes',
			'ab_capture_phone'            => 'yes',
			'ab_order_statuses'           => array( 'pending', 'failed', 'cancelled' ),
			'ab_cart_timeout'             => 60,
			'ab_stop_on_order'            => 'yes',
			'ab_steps'                    => array(
				array(
					'active'        => 'yes',
					'delay'         => 60,
					'unit'          => 'minute',
					'channel'       => 'sms',
					'subject'       => 'سبد خرید شما در {site_title} منتظر شماست',
					'sms_text'      => '{first_name} عزیز، سبد خرید شما در {site_title} تکمیل نشده است. برای ادامه کلیک کنید: {recovery_link}',
					'email_text'    => "<p>{first_name} عزیز،</p><p>شما محصولاتی را در سبد خرید خود باقی گذاشته‌اید:</p>{cart_items}<p>مبلغ قابل پرداخت: <strong>{cart_total}</strong></p><p><a href=\"{recovery_link}\">تکمیل خرید</a></p>",
					'coupon'        => 'no',
					'coupon_amount' => 10,
					'coupon_type'   => 'percent',
					'coupon_days'   => 3,
				),
				array(
					'active'        => 'yes',
					'delay'         => 24,
					'unit'          => 'hour',
					'channel'       => 'sms',
					'subject'       => 'یک کد تخفیف برای تکمیل خرید شما',
					'sms_text'      => '{first_name} عزیز، کد تخفیف {coupon_code} برای تکمیل سبد خرید شما فعال شد. {recovery_link}',
					'email_text'    => "<p>{first_name} عزیز،</p><p>برای تکمیل خرید، کد تخفیف <strong>{coupon_code}</strong> را برای شما فعال کردیم.</p>{cart_items}<p><a href=\"{recovery_link}\">استفاده از کد تخفیف</a></p>",
					'coupon'        => 'yes',
					'coupon_amount' => 10,
					'coupon_type'   => 'percent',
					'coupon_days'   => 3,
				),
				array(
					'active'        => 'no',
					'delay'         => 3,
					'unit'          => 'day',
					'channel'       => 'email',
					'subject'       => 'آخرین یادآوری سبد خرید شما',
					'sms_text'      => '{first_name} عزیز، مهلت استفاده از کد تخفیف {coupon_code} رو به پایان است. {recovery_link}',
					'email_text'    => "<p>{first_name} عزیز،</p><p>این آخرین یادآوری برای سبد خرید شماست.</p>{cart_items}<p><a href=\"{recovery_link}\">تکمیل خرید</a></p>",
					'coupon'        => 'no',
					'coupon_amount' => 15,
					'coupon_type'   => 'percent',
					'coupon_days'   => 2,
				),
			),

			// --- ۲) یادآوری ثبت نظر ---
			'rr_enabled'                  => 'no',
			'rr_delay'                    => 7,
			'rr_unit'                     => 'day',
			'rr_channel'                  => 'sms',
			'rr_skip_reviewed'            => 'yes',
			'rr_only_status'              => 'completed',
			'rr_subject'                  => 'نظر شما درباره‌ی خرید اخیرتان',
			'rr_sms_text'                 => '{first_name} عزیز، از خرید شما سپاسگزاریم. لطفاً نظرتان را درباره‌ی {product_name} ثبت کنید: {product_link}',
			'rr_email_text'               => "<p>{first_name} عزیز،</p><p>از خرید شما از {site_title} سپاسگزاریم. خوشحال می‌شویم نظرتان را درباره‌ی محصولات خریداری‌شده ثبت کنید.</p>{order_items}<p><a href=\"{product_link}\">ثبت نظر</a></p>",

			// --- ۳) پاداش ثبت نظر ---
			'rw_enabled'                  => 'no',
			'rw_min_rating'               => 1,
			'rw_require_verified'         => 'yes',
			'rw_once_per_customer'        => 'no',
			'rw_channel'                  => 'sms',
			'rw_coupon_type'              => 'percent',
			'rw_coupon_amount'            => 10,
			'rw_coupon_days'              => 14,
			'rw_coupon_min_spend'         => 0,
			'rw_subject'                  => 'هدیه‌ی شما بابت ثبت نظر',
			'rw_sms_text'                 => '{first_name} عزیز، از ثبت نظر شما سپاسگزاریم. کد تخفیف اختصاصی شما: {coupon_code} (تا {coupon_expiry})',
			'rw_email_text'               => "<p>{first_name} عزیز،</p><p>از اینکه نظرتان را ثبت کردید سپاسگزاریم. کد تخفیف اختصاصی شما:</p><p style=\"font-size:22px\"><strong>{coupon_code}</strong></p><p>اعتبار تا {coupon_expiry}</p>",

			// --- ۴) خرید مجدد ---
			'wb_enabled'                  => 'no',
			'wb_inactive_days'            => 60,
			'wb_channel'                  => 'sms',
			'wb_min_orders'               => 1,
			'wb_repeat_days'              => 90,
			'wb_coupon'                   => 'yes',
			'wb_coupon_type'              => 'percent',
			'wb_coupon_amount'            => 15,
			'wb_coupon_days'              => 7,
			'wb_subject'                  => 'دلمان برایتان تنگ شده است!',
			'wb_sms_text'                 => '{first_name} عزیز، مدتی است از {site_title} خرید نکرده‌اید. کد تخفیف {coupon_code} تا {coupon_expiry} برای شما فعال است. {site_url}',
			'wb_email_text'               => "<p>{first_name} عزیز،</p><p>مدتی است شما را ندیده‌ایم. برای بازگشت شما کد تخفیف <strong>{coupon_code}</strong> را فعال کردیم.</p><p>اعتبار تا {coupon_expiry}</p><p><a href=\"{site_url}\">مشاهده‌ی فروشگاه</a></p>",

			// --- هشدار موجودی («موجود شد خبرم کن») ---
			'st_enabled'                  => 'no',
			'st_channel'                  => 'email',
			'st_contact_mode'             => 'auto',
			'st_send_immediately'         => 'yes',
			'st_ignore_quiet_hours'       => 'no',
			'st_prefill'                  => 'no',
			'st_show_form'                => 'yes',
			'st_require_login'            => 'no',
			'st_show_count'               => 'yes',
			'st_admin_notify'             => 'no',
			'st_min_stock'                => 0,
			'st_max_per_product'          => 0,
			'st_delay'                    => 0,
			'st_delay_unit'               => 'minute',
			'st_expire_days'              => 120,
			'st_title'                    => 'منتظر این محصول هستید؟',
			'st_description'              => 'ایمیل یا شماره خود را وارد کنید تا لحظه‌ای که موجود شد به شما خبر دهیم.',
			'st_button_label'             => 'موجود شد خبرم کن',
			'st_coupon'                   => 'no',
			'st_coupon_type'              => 'percent',
			'st_coupon_amount'            => 5,
			'st_coupon_days'              => 3,
			'st_subject'                  => '{product_name} دوباره موجود شد',
			'st_sms_text'                 => '{first_name} عزیز، {product_name} که منتظرش بودید موجود شد. برای سفارش: {product_link}',
			'st_email_text'               => "<p>{first_name} عزیز،</p><p>خبر خوب! محصولی که منتظرش بودید دوباره موجود شد:</p><p style=\"font-size:17px\"><strong>{product_name}</strong><br />{product_price}</p><p><a href=\"{product_link}\">مشاهده و سفارش</a></p><p style=\"font-size:12px;color:#888\">اگر دیگر مایل به دریافت این اطلاع‌رسانی نیستید، <a href=\"{cancel_link}\">اینجا کلیک کنید</a>.</p>",

			// --- باشگاه مشتریان VIP ---
			'vip_enabled'                 => 'no',
			'vip_channel'                 => 'sms',
			'vip_basis'                   => 'amount',
			'vip_window'                  => 365,
			'vip_window_custom'           => 365,
			'vip_order_statuses'          => array( 'completed', 'processing' ),
			'vip_realtime'                => 'yes',
			'vip_show_in_account'         => 'yes',
			'vip_scan_limit'              => 5000,
			'vip_notify_promotion'        => 'yes',
			'vip_notify_demotion'         => 'no',
			'vip_tiers'                   => array(
				array(
					'active'        => 'yes',
					'name'          => 'برنزی',
					'min_amount'    => 2000000,
					'min_orders'    => 2,
					'color'         => '#b45309',
					'perk'          => 'ارسال رایگان برای سفارش‌های بالای حد مشخص',
					'coupon_type'   => 'percent',
					'coupon_amount' => 5,
					'coupon_days'   => 30,
				),
				array(
					'active'        => 'yes',
					'name'          => 'نقره‌ای',
					'min_amount'    => 8000000,
					'min_orders'    => 5,
					'color'         => '#64748b',
					'perk'          => 'ارسال رایگان و پشتیبانی اولویت‌دار',
					'coupon_type'   => 'percent',
					'coupon_amount' => 10,
					'coupon_days'   => 30,
				),
				array(
					'active'        => 'yes',
					'name'          => 'طلایی',
					'min_amount'    => 20000000,
					'min_orders'    => 10,
					'color'         => '#ca8a04',
					'perk'          => 'ارسال رایگان، پشتیبانی اختصاصی و دسترسی زودهنگام به محصولات جدید',
					'coupon_type'   => 'percent',
					'coupon_amount' => 15,
					'coupon_days'   => 30,
				),
			),

			'vip_promote_subject'         => 'به سطح {vip_tier} باشگاه {site_title} رسیدید',
			'vip_promote_sms_text'        => '{first_name} عزیز، تبریک! شما به سطح {vip_tier} باشگاه مشتریان {site_title} ارتقا یافتید. کد هدیه: {coupon_code}',
			'vip_promote_email_text'      => "<p>{first_name} عزیز،</p><p>تبریک می‌گوییم! شما به سطح <strong>{vip_tier}</strong> باشگاه مشتریان {site_title} ارتقا یافتید.</p><p>{vip_perk}</p><p>کد هدیه‌ی شما: <strong>{coupon_code}</strong> (اعتبار تا {coupon_expiry})</p>",

			'vip_demote_subject'          => 'سطح شما در باشگاه مشتریان تغییر کرد',
			'vip_demote_sms_text'         => '{first_name} عزیز، سطح شما در باشگاه {site_title} به {vip_tier} تغییر کرد. با خرید بعدی دوباره ارتقا می‌یابید.',
			'vip_demote_email_text'       => "<p>{first_name} عزیز،</p><p>سطح شما در باشگاه مشتریان به <strong>{vip_tier}</strong> تغییر کرد.</p><p>برای بازگشت به سطح قبلی تنها {vip_next_remaining} فاصله دارید.</p>",

			'vip_reward_enabled'          => 'no',
			'vip_reward_every_days'       => 30,
			'vip_reward_min_tier'         => 1,
			'vip_reward_subject'          => 'هدیه‌ی دوره‌ای اعضای باشگاه',
			'vip_reward_sms_text'         => '{first_name} عزیز، به‌عنوان عضو {vip_tier} باشگاه {site_title}، کد تخفیف {coupon_code} برای شما فعال شد.',
			'vip_reward_email_text'       => "<p>{first_name} عزیز،</p><p>به‌عنوان عضو <strong>{vip_tier}</strong> باشگاه مشتریان، این هدیه برای شماست:</p><p style=\"font-size:22px\"><strong>{coupon_code}</strong></p><p>اعتبار تا {coupon_expiry}</p>",

			'vip_churn_enabled'           => 'no',
			'vip_churn_days'              => 60,
			'vip_churn_min_tier'          => 2,
			'vip_churn_coupon'            => 'yes',
			'vip_churn_subject'           => 'دلمان برای شما تنگ شده است',
			'vip_churn_sms_text'          => '{first_name} عزیز، شما از اعضای {vip_tier} ما هستید و مدتی است خریدی نداشته‌اید. کد ویژه‌ی شما: {coupon_code}',
			'vip_churn_email_text'        => "<p>{first_name} عزیز،</p><p>شما از اعضای ارزشمند <strong>{vip_tier}</strong> باشگاه ما هستید و مدتی است شما را ندیده‌ایم.</p><p>کد ویژه‌ی شما: <strong>{coupon_code}</strong></p>",

			// --- تولد مشتری ---
			'bd_enabled'                  => 'no',
			'bd_days_before'              => 0,
			'bd_channel'                  => 'sms',
			'bd_coupon'                   => 'yes',
			'bd_coupon_type'              => 'percent',
			'bd_coupon_amount'            => 20,
			'bd_coupon_days'              => 7,
			'bd_field_enabled'            => 'yes',
			'bd_subject'                  => 'تولدتان مبارک!',
			'bd_sms_text'                 => '{first_name} عزیز، تولدتان مبارک! کد تخفیف {coupon_code} هدیه‌ی {site_title} به شماست.',
			'bd_email_text'               => "<p>{first_name} عزیز،</p><p>تولدتان مبارک! به همین مناسبت کد تخفیف <strong>{coupon_code}</strong> را برای شما فعال کردیم.</p><p>اعتبار تا {coupon_expiry}</p>",

			// --- اطلاع‌رسانی وضعیت سفارش ---
			'os_enabled'                  => 'no',
			'os_channel'                  => 'sms',
			'os_admin_new_order'          => 'no',
			'os_admin_phone'              => '',
			'os_admin_text'               => 'سفارش جدید #{order_number} به مبلغ {order_total} ثبت شد.',
			'os_statuses'                 => array(
				'processing' => array(
					'active' => 'yes',
					'text'   => '{first_name} عزیز، سفارش #{order_number} شما ثبت و در حال پردازش است. {site_title}',
				),
				'completed'  => array(
					'active' => 'yes',
					'text'   => '{first_name} عزیز، سفارش #{order_number} شما تکمیل شد. از خرید شما سپاسگزاریم. {site_title}',
				),
				'cancelled'  => array(
					'active' => 'no',
					'text'   => '{first_name} عزیز، سفارش #{order_number} شما لغو شد.',
				),
				'refunded'   => array(
					'active' => 'no',
					'text'   => '{first_name} عزیز، مبلغ سفارش #{order_number} بازگردانده شد.',
				),
				'on-hold'    => array(
					'active' => 'no',
					'text'   => '{first_name} عزیز، سفارش #{order_number} شما در انتظار بررسی است.',
				),
			),

			// --- هوش مصنوعی ---
			'ai_enabled'                  => 'no',
			'ai_provider'                 => 'openai',
			'ai_api_key'                  => '',
			'ai_model'                    => 'gpt-4o-mini',
			'ai_base_url'                 => '',
			'ai_tone'                     => 'صمیمی و حرفه‌ای',
			'ai_language'                 => 'fa',
			'ai_max_tokens'               => 800,
			'ai_business_context'         => '',

			// --- کمپین ---
			'campaign_batch_size'         => 50,
			'campaign_interval'           => 5,
		);
	}

	/**
	 * دریافت همه‌ی تنظیمات.
	 *
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved = get_option( self::OPTION, array() );
			if ( ! is_array( $saved ) ) {
				$saved = array();
			}
			self::$cache = array_merge( self::defaults(), $saved );
		}
		return self::$cache;
	}

	/**
	 * اعمال مقادیر موقت برای همین درخواست.
	 *
	 * در دیتابیس چیزی ذخیره نمی‌شود؛ صرفاً برای آزمودن اطلاعات واردشده و ذخیره‌نشده
	 * در فرم تنظیمات استفاده می‌شود.
	 *
	 * @param array $values مقادیر.
	 */
	public static function set_runtime_overrides( array $values ) {
		self::$overrides = array_merge( self::$overrides, $values );
	}

	/**
	 * پاک کردن مقادیر موقت.
	 */
	public static function clear_runtime_overrides() {
		self::$overrides = array();
	}

	/**
	 * دریافت یک تنظیم.
	 *
	 * @param string $key     کلید.
	 * @param mixed  $default مقدار پیش‌فرض.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		if ( array_key_exists( $key, self::$overrides ) ) {
			return self::$overrides[ $key ];
		}

		$all = self::all();
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		return $default;
	}

	/**
	 * بررسی فعال بودن یک گزینه‌ی بله/خیر.
	 *
	 * @param string $key کلید.
	 * @return bool
	 */
	public static function is( $key ) {
		return 'yes' === self::get( $key );
	}

	/**
	 * ذخیره‌ی مجموعه‌ای از تنظیمات.
	 *
	 * @param array $values مقادیر.
	 */
	public static function update( array $values ) {
		$all = self::all();
		$all = array_merge( $all, $values );
		update_option( self::OPTION, $all );
		self::$cache = $all;

		// نسخه‌ی پشتیبان تا اگر افزونه پاک و دوباره نصب شد، تنظیمات برگردد.
		if ( class_exists( 'WCMA_Install' ) ) {
			WCMA_Install::backup_settings( $all );
		}
	}

	/**
	 * پاک کردن کش.
	 */
	public static function flush() {
		self::$cache = null;
	}
}
