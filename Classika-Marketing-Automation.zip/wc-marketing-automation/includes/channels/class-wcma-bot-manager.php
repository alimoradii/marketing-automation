<?php
/**
 * مدیریت ربات تلگرام و بله: منوی دکمه‌ها و دنباله‌ی پیام‌های چندروزه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Manager
 */
class WCMA_Bot_Manager {

	const MAX_BUTTONS         = 12;
	const MAX_DAYS            = 30;
	const MAX_DAY_BUTTONS     = 3;
	const MAX_MESSAGES        = 20;
	const MAX_MESSAGE_BUTTONS = 6;

	/**
	 * پیشوند داده‌ی دکمه‌های شیشه‌ای که یک پیام آماده را باز می‌کنند.
	 */
	const CALLBACK_PREFIX = 'wcma:m:';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_bot_started', array( __CLASS__, 'on_start' ), 10, 2 );
		add_action( 'wcma_bot_message', array( __CLASS__, 'on_message' ), 5, 2 );
		add_action( 'wcma_bot_contact', array( __CLASS__, 'on_contact' ), 10, 3 );
		add_action( 'wcma_bot_callback', array( __CLASS__, 'on_callback' ), 10, 2 );
		add_action( 'wcma_process_queue', array( __CLASS__, 'run_sequence' ) );
		add_action( 'wcma_daily_scan', array( __CLASS__, 'run_sequence' ) );
	}

	/**
	 * نام جدول مشترکان.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_bot_subs';
	}

	/**
	 * آیا مدیریت ربات روشن است؟
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return WCMA_Settings::is( 'tg_bot_enabled' );
	}

	/**
	 * پیام‌رسانی که ربات روی آن کار می‌کند.
	 *
	 * @return string
	 */
	public static function channel() {
		$channel = WCMA_Settings::get( 'tg_bot_channel', 'telegram' );

		return in_array( $channel, array( 'telegram', 'bale' ), true ) ? $channel : 'telegram';
	}

	/**
	 * کارهایی که یک دکمه‌ی منو می‌تواند انجام دهد.
	 *
	 * @return array
	 */
	public static function button_actions() {
		return array(
			'reply'   => 'ارسال یک متن',
			'message' => 'ارسال یک پیام آماده (با رسانه و دکمه)',
			'phone'   => 'درخواست شماره موبایل',
			'link'    => 'نمایش لینک',
			'day'     => 'ارسال پیام یک روز مشخص از دنباله',
			'stop'    => 'لغو دریافت پیام‌های روزانه',
			'restart' => 'شروع دوباره‌ی دنباله از روز یک',
		);
	}

	/**
	 * دکمه‌های منوی ربات.
	 *
	 * @return array
	 */
	public static function menu() {
		$menu = WCMA_Settings::get( 'tg_menu', array() );
		$menu = is_array( $menu ) ? $menu : array();
		$out  = array();

		foreach ( $menu as $item ) {
			if ( ! is_array( $item ) || empty( $item['label'] ) ) {
				continue;
			}

			$out[] = array(
				'label'   => (string) $item['label'],
				'action'  => isset( $item['action'], self::button_actions()[ $item['action'] ] ) ? $item['action'] : 'reply',
				'value'   => (string) ( $item['value'] ?? '' ),
				'message' => self::clean_message_id( $item['message'] ?? '' ),
			);
		}

		return $out;
	}

	/**
	 * شمار دکمه‌های منو در هر ردیف کیبورد.
	 *
	 * @return int
	 */
	public static function menu_columns() {
		return max( 1, min( 3, (int) WCMA_Settings::get( 'tg_menu_cols', 2 ) ) );
	}

	/**
	 * پیام‌های آماده: محتوایی که یک بار ساخته می‌شود و هم با دکمه‌های منو،
	 * هم با دکمه‌های شیشه‌ای و هم با ارسال گروهی فرستاده می‌شود.
	 *
	 * @return array شناسه ⇐ پیام.
	 */
	public static function messages() {
		$raw   = WCMA_Settings::get( 'tg_messages', array() );
		$raw   = is_array( $raw ) ? $raw : array();
		$types = WCMA_Messengers::content_types();
		$out   = array();

		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$id   = self::clean_message_id( $item['id'] ?? '' );
			$text = (string) ( $item['text'] ?? '' );
			$file = (string) ( $item['file'] ?? '' );

			if ( '' === $id || isset( $out[ $id ] ) || ( '' === trim( $text ) && '' === trim( $file ) ) ) {
				continue;
			}

			$type = isset( $item['type'], $types[ $item['type'] ] ) ? $item['type'] : 'text';

			// پیام متنیِ بی‌متن چیزی برای فرستادن ندارد؛ فایلش دست‌کم به‌شکل فایل برود.
			if ( 'text' === $type && '' === trim( $text ) ) {
				$type = 'document';
			}

			$out[ $id ] = array(
				'id'      => $id,
				'title'   => (string) ( $item['title'] ?? '' ),
				'type'    => $type,
				'text'    => $text,
				'file'    => $file,
				'cols'    => 2 === (int) ( $item['cols'] ?? 1 ) ? 2 : 1,
				'buttons' => self::message_buttons( $item ),
			);

			if ( count( $out ) >= self::MAX_MESSAGES ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * یک پیام آماده.
	 *
	 * @param string $id شناسه.
	 * @return array|null
	 */
	public static function get_message( $id ) {
		$id       = self::clean_message_id( $id );
		$messages = self::messages();

		return ( '' !== $id && isset( $messages[ $id ] ) ) ? $messages[ $id ] : null;
	}

	/**
	 * نام نمایشی یک پیام آماده.
	 *
	 * @param array $message پیام.
	 * @return string
	 */
	public static function message_title( array $message ) {
		$title = trim( (string) ( $message['title'] ?? '' ) );

		if ( '' !== $title ) {
			return $title;
		}

		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) ( $message['text'] ?? '' ) ) ) );

		if ( '' !== $text ) {
			return mb_substr( $text, 0, 40 );
		}

		// پیام بی‌متن با نام فایلش شناخته می‌شود تا در فهرست‌ها از بقیه جدا باشد.
		$file = wp_basename( (string) wp_parse_url( (string) ( $message['file'] ?? '' ), PHP_URL_PATH ) );

		return '' !== $file ? 'فایل ' . $file : 'پیام بی‌نام';
	}

	/**
	 * شناسه‌ی پاک‌شده‌ی یک پیام آماده.
	 *
	 * شناسه در داده‌ی دکمه‌ی شیشه‌ای می‌نشیند که تلگرام آن را به ۶۴ بایت محدود
	 * می‌کند، پس کوتاه و فقط از حروف و رقم لاتین است.
	 *
	 * @param string $id ورودی.
	 * @return string
	 */
	public static function clean_message_id( $id ) {
		return substr( strtolower( (string) preg_replace( '/[^a-zA-Z0-9]/', '', (string) $id ) ), 0, 20 );
	}

	/**
	 * شناسه‌ی تازه برای پیام آماده.
	 *
	 * @return string
	 */
	public static function new_message_id() {
		return 'm' . strtolower( wp_generate_password( 8, false, false ) );
	}

	/**
	 * کارهایی که یک دکمه‌ی شیشه‌ایِ زیر پیام آماده می‌تواند بکند.
	 *
	 * @return array
	 */
	public static function message_button_kinds() {
		return array(
			'url'     => 'باز کردن لینک',
			'message' => 'نمایش یک پیام آماده‌ی دیگر',
		);
	}

	/**
	 * دکمه‌های شیشه‌ای یک پیام آماده.
	 *
	 * @param array $item پیام.
	 * @return array
	 */
	public static function message_buttons( array $item ) {
		$raw = isset( $item['buttons'] ) && is_array( $item['buttons'] ) ? $item['buttons'] : array();
		$out = array();

		foreach ( $raw as $button ) {
			if ( ! is_array( $button ) ) {
				continue;
			}

			$label   = trim( (string) ( $button['label'] ?? '' ) );
			$kind    = 'message' === ( $button['kind'] ?? 'url' ) ? 'message' : 'url';
			$url     = trim( (string) ( $button['url'] ?? '' ) );
			$message = self::clean_message_id( $button['message'] ?? '' );

			if ( '' === $label || ( 'url' === $kind && '' === $url ) || ( 'message' === $kind && '' === $message ) ) {
				continue;
			}

			$out[] = array(
				'label'   => $label,
				'kind'    => $kind,
				'url'     => 'url' === $kind ? $url : '',
				'message' => 'message' === $kind ? $message : '',
			);

			if ( count( $out ) >= self::MAX_MESSAGE_BUTTONS ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * کیبورد شیشه‌ای یک پیام آماده.
	 *
	 * @param array $message پیام.
	 * @return array|null
	 */
	public static function message_markup( array $message ) {
		$buttons = isset( $message['buttons'] ) && is_array( $message['buttons'] ) ? $message['buttons'] : array();

		if ( ! $buttons ) {
			return null;
		}

		$known = self::messages();
		$cols  = 2 === (int) ( $message['cols'] ?? 1 ) ? 2 : 1;
		$rows  = array();
		$row   = array();

		foreach ( $buttons as $button ) {
			if ( 'message' === $button['kind'] ) {
				// دکمه‌ای که به پیامِ پاک‌شده اشاره می‌کند، فقط کاربر را سردرگم می‌کرد.
				if ( ! isset( $known[ $button['message'] ] ) ) {
					continue;
				}

				$row[] = array(
					'text'          => $button['label'],
					'callback_data' => self::CALLBACK_PREFIX . $button['message'],
				);
			} else {
				$row[] = array(
					'text' => $button['label'],
					'url'  => $button['url'],
				);
			}

			if ( count( $row ) >= $cols ) {
				$rows[] = $row;
				$row    = array();
			}
		}

		if ( $row ) {
			$rows[] = $row;
		}

		return $rows ? array( 'inline_keyboard' => $rows ) : null;
	}

	/**
	 * فرستادن یک پیام آماده به یک چت.
	 *
	 * @param array      $message   پیام آماده.
	 * @param string     $messenger پیام‌رسان.
	 * @param string     $chat_id   شناسه‌ی چت.
	 * @param array|null $sub       مشترک (برای متغیرها و کیبورد).
	 * @return array{success:bool,message:string}
	 */
	public static function send_message( array $message, $messenger, $chat_id, $sub = null ) {
		$sub    = is_array( $sub ) ? $sub : self::guest_sub( $messenger, $chat_id );
		$markup = self::message_markup( $message );

		return WCMA_Messengers::send_content(
			$messenger,
			$chat_id,
			array(
				'type'         => $message['type'],
				'text'         => self::personalize( $message['text'], $sub ),
				'file'         => $message['file'],
				// پیامی که دکمه‌ی شیشه‌ای ندارد، منوی اصلی را دوباره می‌آورد.
				'reply_markup' => $markup ? $markup : self::keyboard( true, $sub ),
			)
		);
	}

	/**
	 * مشترکِ یک چت، یا یک ردیف خالی برای چتی که هنوز مشترک نیست.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   شناسه‌ی چت.
	 * @return array
	 */
	public static function guest_sub( $messenger, $chat_id ) {
		global $wpdb;

		if ( WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			$table = self::table();
			$row   = $wpdb->get_row( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s", $messenger, (string) $chat_id ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);

			if ( $row ) {
				return $row;
			}
		}

		return array(
			'id'         => 0,
			'channel'    => $messenger,
			'chat_id'    => (string) $chat_id,
			'user_id'    => 0,
			'name'       => '',
			'username'   => '',
			'phone'      => '',
			'status'     => 'active',
			'day_sent'   => 0,
			'sent_count' => 0,
			'started_at' => current_time( 'mysql' ),
			'phone_at'   => '',
		);
	}

	/**
	 * ارسال آزمایشی یک پیام آماده به یک شناسه‌ی چت.
	 *
	 * @param string $chat_id شناسه‌ی چت.
	 * @param string $id      شناسه‌ی پیام.
	 * @return array
	 */
	public static function test_message( $chat_id, $id ) {
		$chat_id = trim( (string) $chat_id );

		if ( '' === $chat_id ) {
			return array( 'success' => false, 'message' => 'شناسه‌ی چت را وارد کنید.' );
		}

		$message = self::get_message( $id );

		if ( ! $message ) {
			return array( 'success' => false, 'message' => 'این پیام آماده پیدا نشد. اگر همین حالا ساخته‌اید، چند لحظه صبر کنید تا ذخیره شود.' );
		}

		$result = self::send_message( $message, self::channel(), $chat_id );

		return array(
			'success' => ! empty( $result['success'] ),
			'message' => ! empty( $result['success'] )
				? sprintf( 'پیام «%s» فرستاده شد.', self::message_title( $message ) )
				: ( $result['message'] ?? 'ارسال ناموفق بود.' ),
		);
	}

	/**
	 * دنباله‌ی پیام‌های روزانه، مرتب بر پایه‌ی شماره‌ی روز.
	 *
	 * @return array
	 */
	public static function sequence() {
		$days = WCMA_Settings::get( 'tg_sequence', array() );
		$days = is_array( $days ) ? $days : array();
		$out  = array();

		foreach ( $days as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$day = max( 1, min( self::MAX_DAYS, (int) ( $item['day'] ?? 0 ) ) );

			// روزی که نه متن دارد نه فایل، چیزی برای فرستادن ندارد.
			if ( empty( $item['text'] ) && empty( $item['file'] ) ) {
				continue;
			}

			$mode = ( isset( $item['mode'] ) && 'date' === $item['mode'] ) ? 'date' : 'offset';
			$date = self::clean_date( $item['date'] ?? '' );

			// حالت «تاریخ مشخص» بدون تاریخ معتبر، به حالت روزشمار برمی‌گردد.
			if ( 'date' === $mode && '' === $date ) {
				$mode = 'offset';
			}

			$out[ $day ] = array(
				'day'          => $day,
				'active'       => ! empty( $item['active'] ),
				'mode'         => $mode,
				'date'         => $date,
				'time'         => self::clean_time( $item['time'] ?? '' ),
				'type'         => isset( $item['type'], WCMA_Messengers::content_types()[ $item['type'] ] ) ? $item['type'] : 'text',
				'text'         => (string) ( $item['text'] ?? '' ),
				'file'         => (string) ( $item['file'] ?? '' ),
				'button_label' => (string) ( $item['button_label'] ?? '' ),
				'button_url'   => (string) ( $item['button_url'] ?? '' ),
				'buttons'      => self::day_buttons( $item ),
			);
		}

		ksort( $out );

		return $out;
	}

	/**
	 * ساعت معتبر به‌شکل HH:MM.
	 *
	 * @param string $time ورودی.
	 * @return string
	 */
	public static function clean_time( $time ) {
		$time = WCMA_Date::to_latin_digits( (string) $time );

		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', trim( $time ), $m ) ) {
			return sprintf( '%02d:%02d', min( 23, (int) $m[1] ), min( 59, (int) $m[2] ) );
		}

		return (string) WCMA_Settings::get( 'tg_seq_time', '10:00' );
	}

	/**
	 * تاریخ میلادیِ معتبر (Y-m-d) از ورودی کاربر.
	 *
	 * ورودیِ برگه به تقویم سایت است (معمولاً شمسی)، پس از همان موتور تاریخِ
	 * افزونه رد می‌شود تا «۱۴۰۴/۰۷/۰۱» هم پذیرفته شود.
	 *
	 * @param string $date ورودی.
	 * @return string
	 */
	public static function clean_date( $date ) {
		$date = trim( (string) $date );

		if ( '' === $date ) {
			return '';
		}

		// parse() رشته‌ی میلادیِ Y-m-d برمی‌گرداند، نه timestamp.
		return (string) WCMA_Date::parse( $date );
	}

	/**
	 * ساخت کیبورد ربات از روی دکمه‌های تعریف‌شده.
	 *
	 * @param bool $with_phone افزودن دکمه‌ی اشتراک شماره.
	 * @return array|null
	 */
	public static function keyboard( $with_phone = false, $sub = null ) {
		$rows = array();

		/*
		 * دکمه‌ی شماره تا وقتی مشترک شماره نداده روی کیبورد می‌ماند، نه فقط در
		 * پیام شروع؛ کاربری که بار اول ردش کرده بود، دیگر راهی برای دادن شماره
		 * نداشت.
		 */
		if ( is_array( $sub ) && ! empty( $sub['phone'] ) ) {
			$with_phone = false;
		} elseif ( is_array( $sub ) ) {
			$with_phone = true;
		}

		if ( $with_phone && WCMA_Settings::is( 'tg_ask_phone' ) ) {
			$label = trim( (string) WCMA_Settings::get( 'tg_phone_button', '' ) );

			// برچسب خالی، کل کیبورد را از نگاه تلگرام نامعتبر می‌کرد.
			if ( '' === $label ) {
				$label = '📱 اشتراک‌گذاری شماره‌ی من';
			}

			$rows[] = array(
				array(
					'text'            => $label,
					'request_contact' => true,
				),
			);
		}

		$buttons = self::menu();
		$cols    = self::menu_columns();
		$pair    = array();

		foreach ( $buttons as $button ) {
			if ( 'phone' === $button['action'] ) {
				$rows[] = array( array( 'text' => $button['label'], 'request_contact' => true ) );
				continue;
			}

			$pair[] = array( 'text' => $button['label'] );

			// شمار دکمه‌های هر ردیف را مدیر انتخاب می‌کند؛ پیش‌فرض دو تاست تا روی موبایل خوانا بماند.
			if ( count( $pair ) >= $cols ) {
				$rows[] = $pair;
				$pair   = array();
			}
		}

		if ( $pair ) {
			$rows[] = $pair;
		}

		if ( ! $rows ) {
			return null;
		}

		return array(
			'keyboard'        => $rows,
			'resize_keyboard' => true,
			'is_persistent'   => true,
		);
	}

	/**
	 * دکمه‌ی شیشه‌ای زیر یک پیام دنباله.
	 *
	 * @param array $item روز.
	 * @return array|null
	 */
	protected static function inline_button( array $item ) {
		$buttons = ! empty( $item['buttons'] ) ? $item['buttons'] : self::day_buttons( $item );

		if ( ! $buttons ) {
			return null;
		}

		$rows = array();

		// هر دکمه در ردیف خودش، تا برچسب‌های فارسی بریده نشوند.
		foreach ( $buttons as $button ) {
			$rows[] = array(
				array(
					'text' => $button['label'],
					'url'  => $button['url'],
				),
			);
		}

		return array( 'inline_keyboard' => $rows );
	}

	/**
	 * دکمه‌های شیشه‌ای یک روز.
	 *
	 * ساختار قدیمی (button_label/button_url) هم پشتیبانی می‌شود تا تنظیمات
	 * ذخیره‌شده‌ی کاربر از بین نرود.
	 *
	 * @param array $item روز.
	 * @return array
	 */
	public static function day_buttons( array $item ) {
		$out = array();
		$raw = isset( $item['buttons'] ) && is_array( $item['buttons'] ) ? $item['buttons'] : array();

		if ( ! empty( $item['button_label'] ) && ! empty( $item['button_url'] ) ) {
			$legacy = array( 'label' => (string) $item['button_label'], 'url' => (string) $item['button_url'] );
			$dupe   = false;

			/*
			 * sequence() خودش buttons را می‌سازد، پس این متد ممکن است روی خروجیِ
			 * خودش دوباره اجرا شود؛ بدون این بررسی، دکمه‌ی ساختار قدیمی دو بار
			 * در فهرست می‌آمد و در ربات هم دوتایی دیده می‌شد.
			 */
			foreach ( $raw as $button ) {
				if (
					is_array( $button )
					&& (string) ( $button['label'] ?? '' ) === $legacy['label']
					&& (string) ( $button['url'] ?? '' ) === $legacy['url']
				) {
					$dupe = true;
					break;
				}
			}

			if ( ! $dupe ) {
				array_unshift( $raw, $legacy );
			}
		}

		foreach ( $raw as $button ) {
			if ( ! is_array( $button ) || empty( $button['label'] ) || empty( $button['url'] ) ) {
				continue;
			}

			$out[] = array(
				'label' => (string) $button['label'],
				'url'   => (string) $button['url'],
			);

			if ( count( $out ) >= self::MAX_DAY_BUTTONS ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * ثبت یا به‌روزرسانی مشترک.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده‌ی پیام.
	 * @return array|null
	 */
	public static function touch( $messenger, array $parsed ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return null;
		}

		$chat_id = trim( (string) ( $parsed['chat_id'] ?? '' ) );

		if ( '' === $chat_id ) {
			return null;
		}

		$table = self::table();
		$now   = current_time( 'mysql' );

		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s", $messenger, $chat_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( $row ) {
			$update = array();

			// کسی که پیام می‌دهد، ربات را دوباره باز کرده است؛ پس دیگر «بسته» نیست.
			if ( 'blocked' === $row['status'] ) {
				$update['status'] = 'active';
			}

			if ( ! empty( $parsed['name'] ) && empty( $row['name'] ) ) {
				$update['name'] = sanitize_text_field( $parsed['name'] );
			}

			if ( ! empty( $parsed['username'] ) && empty( $row['username'] ) ) {
				$update['username'] = sanitize_text_field( $parsed['username'] );
			}

			if ( $update ) {
				$wpdb->update( $table, $update, array( 'id' => (int) $row['id'] ) ); // phpcs:ignore WordPress.DB
				$row = array_merge( $row, $update );
			}

			return $row;
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			$table,
			array(
				'channel'    => $messenger,
				'chat_id'    => $chat_id,
				'user_id'    => (int) WCMA_Bot_Link::user_for_chat( $messenger, $chat_id ),
				'name'       => sanitize_text_field( (string) ( $parsed['name'] ?? '' ) ),
				'username'   => sanitize_text_field( (string) ( $parsed['username'] ?? '' ) ),
				'phone'      => WCMA_SMS_Gateways::normalize_phone( (string) ( $parsed['phone'] ?? '' ) ),
				'status'     => 'active',
				'day_sent'   => 0,
				'started_at' => $now,
			)
		);

		return $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $wpdb->insert_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
	}

	/**
	 * واکنش به دستور شروع.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده.
	 */
	public static function on_start( $messenger, array $parsed ) {
		if ( ! self::is_enabled() || self::channel() !== $messenger ) {
			return;
		}

		$sub = self::touch( $messenger, $parsed );

		if ( ! $sub ) {
			return;
		}

		$welcome = trim( (string) WCMA_Settings::get( 'tg_welcome_text', '' ) );

		if ( '' === $welcome ) {
			$welcome = sprintf( 'به ربات %s خوش آمدید.', get_bloginfo( 'name' ) );
		}

		WCMA_Messengers::send_content(
			$messenger,
			$parsed['chat_id'],
			array(
				'type'         => WCMA_Settings::get( 'tg_welcome_type', 'text' ),
				'text'         => self::personalize( $welcome, $sub ),
				'file'         => WCMA_Settings::get( 'tg_welcome_file', '' ),
				'reply_markup' => self::keyboard( true, $sub ),
			)
		);

		// روز یک فقط برای کسی که هنوز چیزی نگرفته؛ وگرنه با هر بار زدن /start تکرار می‌شد.
		if (
			WCMA_Settings::is( 'tg_seq_enabled' )
			&& WCMA_Settings::is( 'tg_seq_first_now' )
			&& (int) $sub['day_sent'] < 1
			&& 'active' === $sub['status']
		) {
			self::send_day( $sub, 1 );
		}
	}

	/**
	 * واکنش به پیام‌های معمولی: دکمه‌های منو.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده.
	 */
	public static function on_message( $messenger, array $parsed ) {
		if ( ! self::is_enabled() || self::channel() !== $messenger ) {
			return;
		}

		$text = trim( (string) ( $parsed['text'] ?? '' ) );

		if ( '' === $text ) {
			return;
		}

		$sub = self::touch( $messenger, $parsed );

		if ( ! $sub ) {
			return;
		}

		$plain = WCMA_Chatbot::normalize( $text );
		$loose = self::loose( $text );
		$menu  = self::menu();
		$match = null;

		// اول تطبیق دقیق.
		foreach ( $menu as $button ) {
			if ( WCMA_Chatbot::normalize( $button['label'] ) === $plain ) {
				$match = $button;
				break;
			}
		}

		/*
		 * بعد تطبیق آسان‌گیر: برچسب‌ها معمولاً ایموجی و نیم‌فاصله دارند و اگر مدیر
		 * بعداً ایموجی را عوض کند یا کاربر از کیبورد قدیمی بزند، تطبیق دقیق شکست
		 * می‌خورد و دکمه «کار نمی‌کرد».
		 */
		if ( ! $match && '' !== $loose ) {
			foreach ( $menu as $button ) {
				if ( self::loose( $button['label'] ) === $loose ) {
					$match = $button;
					break;
				}
			}
		}

		if ( ! $match ) {
			return;
		}

		self::run_action( $messenger, $sub, $match );

		WCMA_Logger::add(
			array(
				'workflow'    => 'bot_menu',
				'step'        => $match['action'],
				'channel'     => $messenger,
				'recipient'   => $sub['chat_id'],
				'subject'     => sprintf( 'دکمه‌ی «%s»', $match['label'] ),
				'status'      => 'sent',
				'object_type' => 'bot_sub',
				'object_id'   => (int) $sub['id'],
			)
		);

		// جلوی پاسخ خودکار چت‌بات گرفته می‌شود تا دو پیام همزمان نرود.
		add_filter( 'wcma_chatbot_skip', '__return_true' );
	}

	/**
	 * شکل ساده‌شده‌ی یک برچسب: بدون ایموجی، نشانه و فاصله.
	 *
	 * @param string $text متن.
	 * @return string
	 */
	public static function loose( $text ) {
		$text = WCMA_Chatbot::normalize( (string) $text );

		// هرچه حرف یا رقم نیست کنار می‌رود؛ ایموجی‌ها هم همین‌جا حذف می‌شوند.
		$text = preg_replace( '/[^\p{L}\p{N}]+/u', '', $text );

		return (string) $text;
	}

	/**
	 * اجرای کار یک دکمه.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $sub       مشترک.
	 * @param array  $button    دکمه.
	 */
	protected static function run_action( $messenger, array $sub, array $button ) {
		global $wpdb;

		$chat_id = $sub['chat_id'];

		switch ( $button['action'] ) {
			case 'phone':
				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array(
						'text'         => $button['value'] ? $button['value'] : 'لطفاً شماره‌ی خود را با دکمه‌ی زیر بفرستید.',
						// این دکمه صریحاً برای گرفتن شماره است، پس حتی اگر شماره داشته باشد باز می‌آید.
						'reply_markup' => self::keyboard( true ),
					)
				);
				break;

			case 'link':
				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array(
						'text'         => $button['label'],
						'reply_markup' => array(
							'inline_keyboard' => array(
								array( array( 'text' => $button['label'], 'url' => $button['value'] ) ),
							),
						),
					)
				);
				break;

			case 'message':
				$message = self::get_message( $button['message'] ?? '' );

				if ( $message ) {
					self::send_message( $message, $messenger, $chat_id, $sub );
					break;
				}

				WCMA_Logger::add(
					array(
						'workflow'      => 'bot_menu',
						'step'          => 'missing_message',
						'channel'       => $messenger,
						'recipient'     => $chat_id,
						'subject'       => sprintf( 'دکمه‌ی «%s» پیام آماده ندارد', $button['label'] ),
						'status'        => 'failed',
						'object_type'   => 'bot_sub',
						'object_id'     => (int) $sub['id'],
						'error_message' => 'در برگه‌ی «ربات تلگرام»، برای این دکمه یک پیام آماده انتخاب کنید.',
					)
				);

				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array(
						'text'         => sprintf( 'برای «%s» هنوز پاسخی تنظیم نشده است.', $button['label'] ),
						'reply_markup' => self::keyboard( true, $sub ),
					)
				);
				break;

			case 'day':
				self::send_day( $sub, (int) $button['value'], true );
				break;

			case 'stop':
				$wpdb->update( self::table(), array( 'status' => 'stopped' ), array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB
				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array( 'text' => $button['value'] ? $button['value'] : 'دیگر پیام روزانه‌ای برایتان فرستاده نمی‌شود.' )
				);
				break;

			case 'restart':
				$wpdb->update( // phpcs:ignore WordPress.DB
					self::table(),
					array( 'status' => 'active', 'day_sent' => 0, 'started_at' => current_time( 'mysql' ) ),
					array( 'id' => (int) $sub['id'] )
				);
				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array( 'text' => $button['value'] ? $button['value'] : 'دنباله از روز یک دوباره آغاز شد.' )
				);
				break;

			default:
				$reply = trim( self::personalize( $button['value'], $sub ) );

				/*
				 * دکمه‌ای که متن پاسخ ندارد، پیش‌تر هیچ کاری نمی‌کرد: send_content
				 * متن خالی را رد می‌کرد و کاربر فکر می‌کرد دکمه خراب است. حالا
				 * دست‌کم منو دوباره می‌آید و خطا در گزارش‌ها ثبت می‌شود.
				 */
				if ( '' === $reply ) {
					$reply = sprintf( 'برای «%s» هنوز پاسخی تنظیم نشده است.', $button['label'] );

					WCMA_Logger::add(
						array(
							'workflow'      => 'bot_menu',
							'step'          => 'empty_reply',
							'channel'       => $messenger,
							'recipient'     => $chat_id,
							'subject'       => sprintf( 'دکمه‌ی «%s» متن پاسخ ندارد', $button['label'] ),
							'status'        => 'failed',
							'object_type'   => 'bot_sub',
							'object_id'     => (int) $sub['id'],
							'error_message' => 'در برگه‌ی «ربات تلگرام»، برای این دکمه متن پاسخ بنویسید.',
						)
					);
				}

				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array(
						'text'         => $reply,
						'reply_markup' => self::keyboard( true, $sub ),
					)
				);
		}
	}

	/**
	 * ثبت شماره‌ی به‌اشتراک‌گذاشته‌شده.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   شناسه‌ی چت.
	 * @param string $phone     شماره.
	 */
	public static function on_contact( $messenger, $chat_id, $phone ) {
		global $wpdb;

		if ( ! self::is_enabled() || ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return;
		}

		$phone = WCMA_SMS_Gateways::normalize_phone( $phone );

		if ( ! $phone ) {
			return;
		}

		$table = self::table();

		$wpdb->update( $table, array( 'phone' => $phone, 'phone_at' => current_time( 'mysql' ) ), array( 'channel' => $messenger, 'chat_id' => (string) $chat_id ) ); // phpcs:ignore WordPress.DB

		$sub = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s AND chat_id = %s", $messenger, (string) $chat_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		if ( ! $sub ) {
			return;
		}

		// پرونده‌ی CRM هم با همین شماره ساخته یا کامل می‌شود.
		$contact_id = WCMA_CRM::upsert(
			array(
				'phone'      => $phone,
				'user_id'    => (int) $sub['user_id'],
				'first_name' => $sub['name'],
				'source'     => 'bot',
			)
		);

		if ( $contact_id ) {
			$wpdb->update( $table, array( 'contact_id' => $contact_id ), array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB
		}

		$thanks = trim( (string) WCMA_Settings::get( 'tg_phone_thanks', '' ) );

		if ( $thanks ) {
			WCMA_Messengers::send_content(
				$messenger,
				$chat_id,
				array(
					'text'         => self::personalize( $thanks, $sub ),
					'reply_markup' => self::keyboard( false, $sub ),
				)
			);
		}
	}

	/**
	 * واکنش به فشردن دکمه‌ی شیشه‌ای «نمایش یک پیام آماده».
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده (شامل callback و callback_id).
	 */
	public static function on_callback( $messenger, array $parsed ) {
		$data = (string) ( $parsed['callback'] ?? '' );

		// دکمه‌های دیگران دست‌نخورده می‌مانند تا خودشان پاسخشان را بدهند.
		if ( 0 !== strpos( $data, self::CALLBACK_PREFIX ) ) {
			return;
		}

		// بدون این پاسخ، تلگرام تا چند ثانیه روی دکمه چرخ‌زنک نشان می‌دهد.
		self::answer_callback( $messenger, (string) ( $parsed['callback_id'] ?? '' ) );

		if ( ! self::is_enabled() || self::channel() !== $messenger ) {
			return;
		}

		$sub = self::touch( $messenger, $parsed );

		if ( ! $sub ) {
			return;
		}

		$message = self::get_message( substr( $data, strlen( self::CALLBACK_PREFIX ) ) );

		if ( ! $message ) {
			WCMA_Messengers::send_content(
				$messenger,
				$sub['chat_id'],
				array(
					'text'         => 'این پیام دیگر در دسترس نیست.',
					'reply_markup' => self::keyboard( true, $sub ),
				)
			);

			return;
		}

		$result = self::send_message( $message, $messenger, $sub['chat_id'], $sub );
		$ok     = ! empty( $result['success'] );

		WCMA_Logger::add(
			array(
				'workflow'      => 'bot_menu',
				'step'          => 'inline_message',
				'channel'       => $messenger,
				'recipient'     => $sub['chat_id'],
				'subject'       => sprintf( 'پیام آماده‌ی «%s»', self::message_title( $message ) ),
				'status'        => $ok ? 'sent' : 'failed',
				'object_type'   => 'bot_sub',
				'object_id'     => (int) $sub['id'],
				'error_message' => $ok ? '' : ( $result['message'] ?? '' ),
			)
		);
	}

	/**
	 * پاسخ به فشردن دکمه‌ی شیشه‌ای.
	 *
	 * @param string $messenger   پیام‌رسان.
	 * @param string $callback_id شناسه‌ی فشردن.
	 * @param string $text        پیام کوتاهی که بالای صفحه نمایان می‌شود.
	 */
	protected static function answer_callback( $messenger, $callback_id, $text = '' ) {
		$base = WCMA_Messengers::api_base( $messenger );

		if ( ! $base || '' === $callback_id ) {
			return;
		}

		$body = array( 'callback_query_id' => $callback_id );

		if ( '' !== $text ) {
			$body['text'] = $text;
		}

		wp_remote_post(
			$base . 'answerCallbackQuery',
			array(
				'timeout' => 8,
				'body'    => $body,
			)
		);
	}

	/**
	 * اجرای دنباله‌ی روزانه برای مشترکانی که نوبتشان رسیده است.
	 *
	 * @param int $limit سقف ارسال در هر اجرا.
	 * @return int شمار پیام‌های فرستاده‌شده.
	 */
	public static function run_sequence( $limit = 40 ) {
		global $wpdb;

		if ( ! self::is_enabled() || ! WCMA_Settings::is( 'tg_seq_enabled' ) ) {
			return 0;
		}

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return 0;
		}

		$sequence = self::sequence();

		if ( ! $sequence ) {
			return 0;
		}

		$table = self::table();

		/*
		 * فیلترِ day_sent < max برداشته شد: با روزهای تاریخ‌دار، اشاره‌گرِ ترتیبی
		 * دیگر نشان نمی‌دهد که چیزی مانده یا نه. وضعیت done همان کار را می‌کند.
		 */
		$subs = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status = 'active' ORDER BY last_sent_at ASC, id ASC LIMIT %d", // phpcs:ignore WordPress.DB
				(int) $limit
			),
			ARRAY_A
		);

		$sent = 0;

		foreach ( (array) $subs as $sub ) {
			if ( self::maybe_send_next( $sub, $sequence ) ) {
				$sent++;
			}
		}

		return $sent;
	}

	/**
	 * اگر نوبت پیام بعدی این مشترک رسیده باشد، آن را می‌فرستد.
	 *
	 * @param array $sub      مشترک.
	 * @param array $sequence دنباله.
	 * @return bool
	 */
	protected static function maybe_send_next( array $sub, array $sequence ) {
		$now = strtotime( current_time( 'mysql' ) );

		// بیش از یک پیام در روز برای هر مشترک نمی‌فرستیم.
		if ( $sub['last_sent_at'] && substr( $sub['last_sent_at'], 0, 10 ) === gmdate( 'Y-m-d', $now ) ) {
			return false;
		}

		$done    = self::sent_days( $sub );
		$pending = false;

		/*
		 * همه‌ی روزها بررسی می‌شوند، نه فقط روزِ بعدی: در حالت «تاریخ مشخص»،
		 * ترتیبِ تاریخ‌ها می‌تواند با ترتیب شماره‌ی روزها یکی نباشد.
		 */
		foreach ( $sequence as $day => $item ) {
			if ( in_array( (int) $day, $done, true ) ) {
				continue;
			}

			if ( empty( $item['active'] ) ) {
				self::mark_sent( $sub, $day, false );

				/*
				 * ردیفِ در دست باید همراه دیتابیس جلو برود؛ وگرنه علامتِ روز بعدی
				 * دوباره از روی همین نسخه‌ی کهنه ساخته می‌شد و روز خاموش را از
				 * فهرست می‌انداخت.
				 */
				$done[]             = (int) $day;
				$sub['sent_days']   = implode( ',', $done );
				$sub['day_sent']    = max( (int) $sub['day_sent'], (int) $day );
				continue;
			}

			$due_at = self::due_at( $sub, $item );

			if ( ! $due_at ) {
				continue;
			}

			if ( $now < $due_at ) {
				$pending = true;
				continue;
			}

			return self::send_day( $sub, $day );
		}

		// چیزی نمانده که در آینده برسد، پس دنباله‌ی این مشترک تمام است.
		if ( ! $pending ) {
			self::finish( $sub );
		}

		return false;
	}

	/**
	 * زمانِ سررسید یک روز برای یک مشترک.
	 *
	 * @param array $sub  مشترک.
	 * @param array $item روز.
	 * @return int timestamp یا ۰ اگر قابل محاسبه نباشد.
	 */
	protected static function due_at( array $sub, array $item ) {
		if ( 'date' === ( $item['mode'] ?? 'offset' ) && ! empty( $item['date'] ) ) {
			return (int) strtotime( $item['date'] . ' ' . $item['time'] . ':00' );
		}

		$started = ! empty( $sub['started_at'] ) ? strtotime( $sub['started_at'] ) : 0;

		if ( ! $started ) {
			return 0;
		}

		// روز اول همان روز عضویت است؛ روز دوم فردای آن و همین‌طور تا آخر.
		$offset = ( (int) $item['day'] - 1 ) * DAY_IN_SECONDS;

		return (int) strtotime( gmdate( 'Y-m-d', $started + $offset ) . ' ' . $item['time'] . ':00' );
	}

	/**
	 * روزهایی که برای این مشترک فرستاده شده‌اند.
	 *
	 * ستون day_sent فقط یک اشاره‌گرِ ترتیبی بود و برای روزهای تاریخ‌دار کافی نیست؛
	 * برای مشترکان قدیمی همان اشاره‌گر به فهرست تبدیل می‌شود تا چیزی دوباره نرود.
	 *
	 * @param array $sub مشترک.
	 * @return array
	 */
	public static function sent_days( array $sub ) {
		$raw  = trim( (string) ( $sub['sent_days'] ?? '' ) );
		$list = array_filter( array_map( 'intval', explode( ',', $raw ) ) );

		if ( $list ) {
			return array_values( array_unique( $list ) );
		}

		/*
		 * فقط ردیف‌های قدیمی که هنوز sent_days ندارند از اشاره‌گر پر می‌شوند.
		 * اگر این کار بی‌قید انجام می‌شد، پس از فرستادن روز ۳، روز ۲ هم «رفته»
		 * حساب می‌شد و هرگز نمی‌رفت.
		 */
		$pointer = (int) ( $sub['day_sent'] ?? 0 );

		for ( $day = 1; $day <= $pointer; $day++ ) {
			$list[] = $day;
		}

		return array_values( array_unique( $list ) );
	}

	/**
	 * ارسال پیام یک روز مشخص.
	 *
	 * @param array $sub    مشترک.
	 * @param int   $day    شماره‌ی روز.
	 * @param bool  $manual ارسال دستی (پیشرفت دنباله را جلو نمی‌برد).
	 * @return bool
	 */
	public static function send_day( array $sub, $day, $manual = false ) {
		$sequence = self::sequence();
		$day      = (int) $day;

		if ( ! isset( $sequence[ $day ] ) ) {
			return false;
		}

		$item   = $sequence[ $day ];
		$markup = self::inline_button( $item );

		$result = WCMA_Messengers::send_content(
			$sub['channel'],
			$sub['chat_id'],
			array(
				'type'         => $item['type'],
				'text'         => self::personalize( $item['text'], $sub, $day ),
				'file'         => $item['file'],
				'reply_markup' => $markup ? $markup : self::keyboard( true, $sub ),
			)
		);

		$ok = ! empty( $result['success'] );

		WCMA_Logger::add(
			array(
				'workflow'    => 'bot_sequence',
				'step'        => 'day_' . $day,
				'channel'     => $sub['channel'],
				'recipient'   => $sub['chat_id'],
				'subject'     => sprintf( 'روز %d دنباله‌ی ربات', $day ),
				'status'      => $ok ? 'sent' : 'failed',
				'object_type' => 'bot_sub',
				'object_id'   => (int) $sub['id'],
				'error_message' => $ok ? '' : ( $result['message'] ?? '' ),
			)
		);

		if ( ! $manual ) {
			self::mark_sent( $sub, $day, $ok );
		}

		return $ok;
	}

	/**
	 * ثبت پیشرفت مشترک در دنباله.
	 *
	 * @param array $sub   مشترک.
	 * @param int   $day   روز.
	 * @param bool  $count آیا در شمارش ارسال بیاید؟
	 */
	protected static function mark_sent( array $sub, $day, $count = true ) {
		global $wpdb;

		$done   = self::sent_days( $sub );
		$done[] = (int) $day;
		$done   = array_values( array_unique( $done ) );
		sort( $done );

		$data = array(
			'sent_days'    => implode( ',', $done ),
			'day_sent'     => max( (int) $sub['day_sent'], (int) $day ),
			'last_sent_at' => current_time( 'mysql' ),
		);

		$sequence = self::sequence();

		// وقتی همه‌ی روزهای تعریف‌شده رفته‌اند، کار این مشترک تمام است.
		if ( $sequence && ! array_diff( array_keys( $sequence ), $done ) ) {
			$data['status'] = 'done';
		}

		$wpdb->update( self::table(), $data, array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB

		// شمارنده در خود دیتابیس زیاد می‌شود تا اگر ردیفِ در دست، کهنه باشد چیزی گم نشود.
		if ( $count ) {
			$table = self::table();

			$wpdb->query( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "UPDATE {$table} SET sent_count = sent_count + 1 WHERE id = %d", (int) $sub['id'] ) // phpcs:ignore WordPress.DB
			);
		}
	}

	/**
	 * پایان دنباله برای یک مشترک.
	 *
	 * @param array $sub مشترک.
	 */
	protected static function finish( array $sub ) {
		global $wpdb;

		$wpdb->update( self::table(), array( 'status' => 'done' ), array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * جایگذاری نام مشترک در متن.
	 *
	 * @param string $text متن.
	 * @param array  $sub  مشترک.
	 * @return string
	 */
	public static function personalize( $text, array $sub, $day = 0 ) {
		if ( '' === trim( (string) $text ) ) {
			return '';
		}

		return WCMA_Placeholders::replace(
			$text,
			array(
				'user' => ! empty( $sub['user_id'] ) ? get_userdata( (int) $sub['user_id'] ) : null,
				'vars' => self::sub_vars( $sub, $day ),
			)
		);
	}

	/**
	 * متغیرهای ویژه‌ی مشترک ربات: تاریخ شمسی و شمارش روزها.
	 *
	 * @param array $sub مشترک.
	 * @param int   $day شماره‌ی روز دنباله (۰ یعنی نامشخص).
	 * @return array
	 */
	public static function sub_vars( array $sub, $day = 0 ) {
		$sequence = self::sequence();
		$total    = $sequence ? max( array_keys( $sequence ) ) : 0;
		$day      = (int) $day;

		// اگر روز داده نشده، روز جاری همان روزِ بعدیِ مشترک است.
		if ( $day < 1 ) {
			$day = max( 1, (int) ( $sub['day_sent'] ?? 0 ) );
		}

		$started = self::valid_date( $sub['started_at'] ?? '' );
		$phoned  = self::valid_date( $sub['phone_at'] ?? '' );

		$vars = array(
			'{first_name}'      => $sub['name'] ?? '',
			'{full_name}'       => $sub['name'] ?? '',
			'{username}'        => $sub['username'] ? '@' . $sub['username'] : '',
			'{phone}'           => WCMA_Date::digits( $sub['phone'] ?? '' ),
			'{day}'             => WCMA_Date::number( $day ),
			'{total_days}'      => $total ? WCMA_Date::number( $total ) : '',
			'{remaining_days}'  => $total ? WCMA_Date::number( max( 0, $total - $day ) ) : '',
			'{sent_count}'      => WCMA_Date::number( (int) ( $sub['sent_count'] ?? 0 ) ),
		);

		if ( $started ) {
			$vars['{start_date}']       = WCMA_Date::mysql( $started, 'date', '' );
			$vars['{start_date_long}']  = WCMA_Date::mysql( $started, 'date_long', '' );
			$vars['{start_weekday}']    = WCMA_Date::mysql( $started, 'day', '' );
			$vars['{days_since_start}'] = WCMA_Date::number( self::day_gap( $started ) );
			$vars['{day_of_journey}']   = WCMA_Date::number( self::day_gap( $started ) + 1 );
		}

		if ( $phoned ) {
			$vars['{phone_date}']       = WCMA_Date::mysql( $phoned, 'date', '' );
			$vars['{phone_date_long}']  = WCMA_Date::mysql( $phoned, 'date_long', '' );
			$vars['{days_since_phone}'] = WCMA_Date::number( self::day_gap( $phoned ) );
		}

		return $vars;
	}

	/**
	 * رشته‌ی تاریخ معتبر یا رشته‌ی خالی.
	 *
	 * @param string $value مقدار.
	 * @return string
	 */
	protected static function valid_date( $value ) {
		$value = (string) $value;

		if ( '' === $value || '0000-00-00' === substr( $value, 0, 10 ) ) {
			return '';
		}

		return $value;
	}

	/**
	 * چند روز از یک تاریخ گذشته است.
	 *
	 * روزها بر پایه‌ی نیمه‌شب شمرده می‌شوند، نه ۲۴ ساعتِ کامل؛ وگرنه پیامی که
	 * ساعت ۲۳ فرستاده شده بود، فردا صبح هنوز «۰ روز» می‌شد. هر دو رشته به وقت
	 * محلی سایت‌اند، پس بدون تبدیل با هم مقایسه می‌شوند.
	 *
	 * @param string $from تاریخ مبدأ (Y-m-d H:i:s).
	 * @return int
	 */
	protected static function day_gap( $from ) {
		$start = strtotime( substr( (string) $from, 0, 10 ) . ' 00:00:00' );
		$today = strtotime( substr( current_time( 'mysql' ), 0, 10 ) . ' 00:00:00' );

		if ( ! $start || ! $today ) {
			return 0;
		}

		return max( 0, (int) round( ( $today - $start ) / DAY_IN_SECONDS ) );
	}

	/**
	 * فهرست مشترکان.
	 *
	 * @param array $args فیلترها.
	 * @return array
	 */
	public static function subscribers( array $args = array() ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return array( 'items' => array(), 'total' => 0 );
		}

		$args = wp_parse_args( $args, array( 'status' => '', 'per_page' => 50, 'page' => 1 ) );

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}

		$clause   = implode( ' AND ', $where );
		$per_page = max( 5, min( 200, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );

		$found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$clause}", $params ) ); // phpcs:ignore WordPress.DB

		$params[] = $per_page;
		$params[] = ( $page - 1 ) * $per_page;

		$items = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE {$clause} ORDER BY id DESC LIMIT %d OFFSET %d", $params ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		return array(
			'items' => $items ? $items : array(),
			'page'  => $page,
			'pages' => (int) ceil( $found / $per_page ),
			'found' => $found,
			'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ), // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * آمار ربات.
	 *
	 * @return array
	 */
	public static function stats() {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return array( 'total' => 0, 'active' => 0, 'done' => 0, 'stopped' => 0, 'blocked' => 0, 'with_phone' => 0, 'sent' => 0 );
		}

		$table = self::table();

		return array(
			'total'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ), // phpcs:ignore WordPress.DB
			'active'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'active'" ), // phpcs:ignore WordPress.DB
			'done'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'done'" ), // phpcs:ignore WordPress.DB
			'stopped'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'stopped'" ), // phpcs:ignore WordPress.DB
			'blocked'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'blocked'" ), // phpcs:ignore WordPress.DB
			'with_phone' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE phone <> ''" ), // phpcs:ignore WordPress.DB
			'sent'       => (int) $wpdb->get_var( "SELECT SUM(sent_count) FROM {$table}" ), // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * ارسال آزمایشی یک روز به یک شناسه‌ی چت.
	 *
	 * @param string $chat_id شناسه.
	 * @param int    $day     روز.
	 * @return array
	 */
	public static function test_day( $chat_id, $day ) {
		$chat_id = trim( (string) $chat_id );

		if ( '' === $chat_id ) {
			return array( 'success' => false, 'message' => 'شناسه‌ی چت را وارد کنید.' );
		}

		$sequence = self::sequence();
		$day      = (int) $day;

		if ( ! isset( $sequence[ $day ] ) ) {
			return array( 'success' => false, 'message' => 'برای این روز محتوایی تعریف نشده است.' );
		}

		$item   = $sequence[ $day ];
		$markup = self::inline_button( $item );

		$result = WCMA_Messengers::send_content(
			self::channel(),
			$chat_id,
			array(
				'type'         => $item['type'],
				'text'         => $item['text'],
				'file'         => $item['file'],
				'reply_markup' => $markup ? $markup : self::keyboard(),
			)
		);

		return array(
			'success' => ! empty( $result['success'] ),
			'message' => ! empty( $result['success'] ) ? 'پیام روز ' . WCMA_Date::number( $day ) . ' فرستاده شد.' : ( $result['message'] ?? 'ارسال ناموفق بود.' ),
		);
	}
}
