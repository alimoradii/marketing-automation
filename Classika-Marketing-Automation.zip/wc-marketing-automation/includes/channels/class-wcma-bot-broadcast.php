<?php
/**
 * ارسال گروهی پیام‌های آماده به مشترکان ربات.
 *
 * فرستادن به صدها مشترک در یک درخواست، به سقف زمانی PHP و محدودیت سرعت
 * تلگرام می‌خورد؛ پس هر ارسال یک «کار» در جدول است که تکه‌تکه جلو می‌رود:
 * تا برگه‌ی ربات باز است با درخواست‌های پیاپی، و پس از بستن آن با کرون.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Broadcast
 */
class WCMA_Bot_Broadcast {

	/**
	 * نام قفل در جدول تنظیمات؛ دو فرایند همزمان یک مشترک را دو بار پیام نمی‌دهند.
	 */
	const LOCK = 'wcma_bot_broadcast_lock';

	/**
	 * قفلی که بیش از این (ثانیه) مانده، از فرایندی است که نیمه‌کاره مرده.
	 */
	const LOCK_TTL = 120;

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		add_action( 'wcma_worker_tick', array( __CLASS__, 'cron' ) );
	}

	/**
	 * نام جدول ارسال‌ها.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'wcma_bot_broadcasts';
	}

	/**
	 * آیا جدول‌های لازم ساخته شده‌اند؟
	 *
	 * @return bool
	 */
	public static function ready() {
		return WCMA_Install::table_exists( 'wcma_bot_broadcasts' ) && WCMA_Install::table_exists( 'wcma_bot_subs' );
	}

	/**
	 * گروه‌های مخاطب.
	 *
	 * @return array
	 */
	public static function audiences() {
		return array(
			'subscribed' => 'همه‌ی مشترکان (به‌جز کسانی که لغو کرده‌اند)',
			'phone'      => 'فقط کسانی که شماره داده‌اند',
			'no_phone'   => 'فقط کسانی که هنوز شماره نداده‌اند',
			'sequence'   => 'کسانی که هنوز دنباله‌ی روزانه را می‌گیرند',
			'done'       => 'کسانی که دنباله را تمام کرده‌اند',
			'all'        => 'همه، حتی کسانی که دریافت روزانه را لغو کرده‌اند',
		);
	}

	/**
	 * شرط SQL هر گروه مخاطب.
	 *
	 * کسی که ربات را بسته در هیچ گروهی نیست؛ تلگرام پیامش را نمی‌رساند.
	 *
	 * @param string $audience گروه.
	 * @return string
	 */
	protected static function audience_where( $audience ) {
		switch ( $audience ) {
			case 'phone':
				return "status NOT IN ('stopped','blocked') AND phone <> ''";
			case 'no_phone':
				return "status NOT IN ('stopped','blocked') AND phone = ''";
			case 'sequence':
				return "status = 'active'";
			case 'done':
				return "status = 'done'";
			case 'all':
				return "status <> 'blocked'";
		}

		return "status NOT IN ('stopped','blocked')";
	}

	/**
	 * وضعیت‌های یک ارسال.
	 *
	 * @return array کلید ⇐ [برچسب، کلاس نشان].
	 */
	public static function statuses() {
		return array(
			'scheduled' => array( 'زمان‌بندی‌شده', 'wcma-badge--amber' ),
			'running'   => array( 'در حال ارسال', 'wcma-badge--blue' ),
			'done'      => array( 'پایان‌یافته', 'wcma-badge--green' ),
			'cancelled' => array( 'لغو شد', 'wcma-badge--gray' ),
			'failed'    => array( 'ناموفق', 'wcma-badge--red' ),
		);
	}

	/**
	 * شمار مشترکان یک گروه.
	 *
	 * @param string $audience گروه.
	 * @param string $channel  پیام‌رسان.
	 * @return int
	 */
	public static function count( $audience, $channel = '' ) {
		global $wpdb;

		if ( ! WCMA_Install::table_exists( 'wcma_bot_subs' ) ) {
			return 0;
		}

		$table   = WCMA_Bot_Manager::table();
		$where   = self::audience_where( $audience );
		$channel = $channel ? $channel : WCMA_Bot_Manager::channel();

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE channel = %s AND {$where}", $channel ) // phpcs:ignore WordPress.DB
		);
	}

	/**
	 * ساختن یک ارسال گروهی.
	 *
	 * محتوای پیام همان لحظه برداشته می‌شود تا ویرایش بعدیِ پیام آماده، ارسالِ
	 * نیمه‌کاره را دوپاره نکند.
	 *
	 * @param array $args message (شناسه‌ی پیام آماده)، audience و start_at (اختیاری، وقت محلی).
	 * @return array{success:bool,message:string,id?:int}
	 */
	public static function start( array $args ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return array( 'success' => false, 'message' => 'جدول‌های ربات ساخته نشده‌اند. در تب «تست ارسال»، «ترمیم جدول‌ها» را بزنید.' );
		}

		$channel = WCMA_Bot_Manager::channel();

		if ( ! WCMA_Messengers::api_base( $channel ) ) {
			return array( 'success' => false, 'message' => sprintf( 'توکن ربات %s وارد نشده است.', WCMA_Messengers::label( $channel ) ) );
		}

		$message = WCMA_Bot_Manager::get_message( $args['message'] ?? '' );

		if ( ! $message ) {
			return array( 'success' => false, 'message' => 'پیام آماده را انتخاب کنید. اگر همین حالا ساخته‌اید، چند لحظه صبر کنید تا ذخیره شود.' );
		}

		$audience = (string) ( $args['audience'] ?? '' );
		$audience = isset( self::audiences()[ $audience ] ) ? $audience : 'subscribed';
		$total    = self::count( $audience, $channel );

		if ( ! $total ) {
			return array( 'success' => false, 'message' => 'هیچ مشترکی در این گروه نیست.' );
		}

		$now   = current_time( 'mysql' );
		$start = (string) ( $args['start_at'] ?? '' );
		$later = '' !== $start && strtotime( $start ) > strtotime( $now ) + MINUTE_IN_SECONDS;

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'channel'    => $channel,
				'title'      => mb_substr( WCMA_Bot_Manager::message_title( $message ), 0, 190 ),
				'message'    => wp_json_encode( $message ),
				'audience'   => $audience,
				'status'     => $later ? 'scheduled' : 'running',
				'total'      => $total,
				'created_by' => get_current_user_id(),
				'start_at'   => $later ? $start : $now,
				'created_at' => $now,
			)
		);

		$id = (int) $wpdb->insert_id;

		if ( ! $id ) {
			return array( 'success' => false, 'message' => 'ارسال ساخته نشد: ' . $wpdb->last_error );
		}

		return array(
			'success' => true,
			'id'      => $id,
			'message' => $later
				? sprintf( 'ارسال برای %s مشترک در %s زمان‌بندی شد.', WCMA_Date::number( $total ), WCMA_Date::mysql( $start ) )
				: sprintf( 'ارسال به %s مشترک آغاز شد.', WCMA_Date::number( $total ) ),
		);
	}

	/**
	 * لغو یک ارسال؛ آنچه رفته برنمی‌گردد ولی بقیه نمی‌روند.
	 *
	 * @param int $id شناسه.
	 * @return bool
	 */
	public static function cancel( $id ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return false;
		}

		$table = self::table();

		return (bool) $wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET status = 'cancelled', finished_at = %s WHERE id = %d AND status IN ('scheduled','running')", // phpcs:ignore WordPress.DB
				current_time( 'mysql' ),
				(int) $id
			)
		);
	}

	/**
	 * یک ارسال.
	 *
	 * @param int $id شناسه.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return null;
		}

		$table = self::table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $row ? $row : null;
	}

	/**
	 * ارسال‌های اخیر.
	 *
	 * @param int $limit شمار.
	 * @return array
	 */
	public static function recent( $limit = 10 ) {
		global $wpdb;

		if ( ! self::ready() ) {
			return array();
		}

		$table = self::table();
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", (int) $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return $rows ? $rows : array();
	}

	/**
	 * شناسه‌ی ارسالی که اکنون در جریان است (برای ادامه‌ی خودکار در برگه).
	 *
	 * @return int
	 */
	public static function running_id() {
		global $wpdb;

		if ( ! self::ready() ) {
			return 0;
		}

		$table = self::table();

		return (int) $wpdb->get_var( "SELECT id FROM {$table} WHERE status = 'running' ORDER BY id ASC LIMIT 1" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * داده‌ی نمایشیِ یک ارسال برای برگه.
	 *
	 * @param array $row ردیف.
	 * @return array
	 */
	public static function view( array $row ) {
		$states  = self::statuses();
		$state   = $states[ $row['status'] ] ?? array( $row['status'], 'wcma-badge--gray' );
		$total   = (int) $row['total'];
		$handled = (int) $row['sent'] + (int) $row['failed'] + (int) $row['blocked'];
		$percent = $total ? min( 100, (int) floor( $handled * 100 / $total ) ) : 100;

		return array(
			'id'       => (int) $row['id'],
			'status'   => (string) $row['status'],
			'label'    => $state[0],
			'badge'    => $state[1],
			'title'    => (string) $row['title'],
			'audience' => self::audiences()[ $row['audience'] ] ?? (string) $row['audience'],
			'total'    => WCMA_Date::number( $total ),
			'sent'     => WCMA_Date::number( (int) $row['sent'] ),
			'failed'   => WCMA_Date::number( (int) $row['failed'] + (int) $row['blocked'] ),
			'percent'  => $percent,
			'progress' => WCMA_Date::number( $percent ) . '٪ از ' . WCMA_Date::number( $total ),
			'start'    => WCMA_Date::mysql( $row['start_at'] ),
			'error'    => (string) $row['last_error'],
			'active'   => in_array( $row['status'], array( 'scheduled', 'running' ), true ),
		);
	}

	/**
	 * پیش بردن ارسال‌ها از کرون، وقتی برگه‌ی ربات باز نیست.
	 */
	public static function cron() {
		self::process( 15, 60 );
	}

	/**
	 * پیش بردن نخستین ارسالِ سررسیده به اندازه‌ی یک تکه.
	 *
	 * @param int $budget سقف زمان این تکه (ثانیه).
	 * @param int $batch  سقف شمار پیام‌های این تکه.
	 * @return int شمار مشترکانی که در این تکه به آن‌ها رسیدیم.
	 */
	public static function process( $budget = 12, $batch = 30 ) {
		if ( ! self::ready() || ! self::lock() ) {
			return 0;
		}

		$handled = 0;

		try {
			$job = self::next_job();

			if ( $job ) {
				$handled = self::run( $job, (int) $budget, (int) $batch );
			}
		} finally {
			self::unlock();
		}

		return $handled;
	}

	/**
	 * نخستین ارسالی که نوبتش رسیده است.
	 *
	 * @return array|null
	 */
	protected static function next_job() {
		global $wpdb;

		$table = self::table();
		$row   = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status IN ('running','scheduled') AND start_at <= %s ORDER BY id ASC LIMIT 1", // phpcs:ignore WordPress.DB
				current_time( 'mysql' )
			),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * فرستادن یک تکه از یک ارسال.
	 *
	 * @param array $job    ارسال.
	 * @param int   $budget سقف زمان (ثانیه).
	 * @param int   $batch  سقف شمار.
	 * @return int
	 */
	protected static function run( array $job, $budget, $batch ) {
		global $wpdb;

		$table  = self::table();
		$subs   = WCMA_Bot_Manager::table();
		$id     = (int) $job['id'];
		$began  = microtime( true );
		$cursor = (int) $job['cursor_id'];

		if ( 'scheduled' === $job['status'] ) {
			$wpdb->update( $table, array( 'status' => 'running' ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
		}

		$message = json_decode( (string) $job['message'], true );

		if ( ! is_array( $message ) || empty( $message['type'] ) ) {
			self::close( $id, 'failed', 'محتوای پیام خوانده نشد.' );

			return 0;
		}

		$where = self::audience_where( $job['audience'] );
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$subs} WHERE channel = %s AND id > %d AND {$where} ORDER BY id ASC LIMIT %d", // phpcs:ignore WordPress.DB
				$job['channel'],
				$cursor,
				max( 1, $batch )
			),
			ARRAY_A
		);

		$handled = 0;

		foreach ( (array) $rows as $sub ) {
			if ( microtime( true ) - $began > $budget ) {
				return $handled;
			}

			// لغو در میانه‌ی کار باید همان لحظه اثر کند، نه در تکه‌ی بعد.
			if ( 'running' !== self::status( $id ) ) {
				return $handled;
			}

			$result = WCMA_Bot_Manager::send_message( $message, $job['channel'], $sub['chat_id'], $sub );
			$ok     = ! empty( $result['success'] );
			$error  = mb_substr( (string) ( $result['message'] ?? '' ), 0, 250 );

			if ( ! $ok ) {
				$wait = self::retry_after( $error );

				/*
				 * تلگرام گفته آهسته‌تر؛ اشاره‌گر جلو نمی‌رود تا همین مشترک دوباره
				 * امتحان شود. این خطا در last_error نمی‌نشیند، چون پیام بعداً می‌رسد
				 * و «نرسید» را با دلیلی نادرست توضیح می‌داد.
				 */
				if ( $wait ) {
					$wpdb->update( // phpcs:ignore WordPress.DB
						$table,
						array( 'start_at' => gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) + $wait ) ),
						array( 'id' => $id )
					);

					return $handled;
				}
			}

			$column = $ok ? 'sent' : ( self::is_blocked( $error ) ? 'blocked' : 'failed' );

			if ( 'blocked' === $column ) {
				// تا خودش ربات را دوباره باز نکند، در ارسال‌ها و دنباله‌ی روزانه نمی‌آید.
				$wpdb->update( $subs, array( 'status' => 'blocked' ), array( 'id' => (int) $sub['id'] ) ); // phpcs:ignore WordPress.DB
			}

			if ( $ok ) {
				$wpdb->query( // phpcs:ignore WordPress.DB
					$wpdb->prepare( "UPDATE {$table} SET cursor_id = %d, sent = sent + 1 WHERE id = %d", (int) $sub['id'], $id ) // phpcs:ignore WordPress.DB
				);
			} else {
				$wpdb->query( // phpcs:ignore WordPress.DB
					$wpdb->prepare( "UPDATE {$table} SET cursor_id = %d, {$column} = {$column} + 1, last_error = %s WHERE id = %d", (int) $sub['id'], $error, $id ) // phpcs:ignore WordPress.DB
				);
			}

			$cursor = (int) $sub['id'];
			$handled++;

			// زیر سقف سی پیام در ثانیه‌ی تلگرام می‌مانیم.
			usleep( 40000 );
		}

		$left = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT id FROM {$subs} WHERE channel = %s AND id > %d AND {$where} LIMIT 1", // phpcs:ignore WordPress.DB
				$job['channel'],
				$cursor
			)
		);

		if ( ! $left ) {
			self::close( $id, 'done' );
		}

		return $handled;
	}

	/**
	 * وضعیت تازه‌ی یک ارسال، مستقیم از دیتابیس.
	 *
	 * @param int $id شناسه.
	 * @return string
	 */
	protected static function status( $id ) {
		global $wpdb;

		$table = self::table();

		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$table} WHERE id = %d", (int) $id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * بستن یک ارسال و ثبت خلاصه‌اش در گزارش‌ها.
	 *
	 * @param int    $id     شناسه.
	 * @param string $status وضعیت پایانی.
	 * @param string $error  دلیل، اگر ناموفق بود.
	 */
	protected static function close( $id, $status, $error = '' ) {
		global $wpdb;

		$table = self::table();
		$data  = array( $status, current_time( 'mysql' ) );
		$sql   = "UPDATE {$table} SET status = %s, finished_at = %s";

		if ( '' !== $error ) {
			$sql   .= ', last_error = %s';
			$data[] = $error;
		}

		$data[] = (int) $id;

		// ارسالی که در این میان لغو شده، لغوشده می‌ماند.
		$changed = $wpdb->query( $wpdb->prepare( $sql . " WHERE id = %d AND status IN ('scheduled','running')", $data ) ); // phpcs:ignore WordPress.DB

		$row = $changed ? self::get( $id ) : null;

		if ( ! $row ) {
			return;
		}

		WCMA_Logger::add(
			array(
				'workflow'      => 'bot_broadcast',
				'step'          => $status,
				'channel'       => $row['channel'],
				'recipient'     => WCMA_Date::number( (int) $row['total'] ) . ' مشترک',
				'subject'       => sprintf(
					'ارسال گروهی «%s»: %s رسید، %s نرسید',
					$row['title'],
					WCMA_Date::number( (int) $row['sent'] ),
					WCMA_Date::number( (int) $row['failed'] + (int) $row['blocked'] )
				),
				'status'        => 'done' === $status ? 'sent' : 'failed',
				'object_type'   => 'bot_broadcast',
				'object_id'     => (int) $id,
				'error_message' => (string) $row['last_error'],
			)
		);
	}

	/**
	 * چند ثانیه باید صبر کرد، اگر تلگرام گفته «آهسته‌تر».
	 *
	 * @param string $error پیام خطا.
	 * @return int صفر یعنی خطا از این نوع نیست.
	 */
	protected static function retry_after( $error ) {
		if ( preg_match( '/retry after (\d+)/i', (string) $error, $m ) ) {
			return max( 1, (int) $m[1] );
		}

		return false !== stripos( (string) $error, 'Too Many Requests' ) ? 30 : 0;
	}

	/**
	 * آیا کاربر ربات را بسته یا حسابش دیگر نیست؟
	 *
	 * @param string $error پیام خطا.
	 * @return bool
	 */
	protected static function is_blocked( $error ) {
		foreach ( array( 'bot was blocked', 'user is deactivated', 'chat not found', "bot can't initiate" ) as $needle ) {
			if ( false !== stripos( (string) $error, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * گرفتن قفل.
	 *
	 * INSERT IGNORE روی کلید یکتای option_name اتمی است؛ add_option این‌طور نیست
	 * و دو درخواست همزمان می‌توانستند هر دو قفل را بگیرند.
	 *
	 * @return bool
	 */
	protected static function lock() {
		global $wpdb;

		$now = time();

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", self::LOCK, (string) $now )
		);

		if ( (int) $wpdb->rows_affected > 0 ) {
			return true;
		}

		$since = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::LOCK )
		);

		if ( ! $since || $now - $since < self::LOCK_TTL ) {
			return false;
		}

		// فقط یکی از مدعیان قفلِ کهنه را برمی‌دارد.
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				(string) $now,
				self::LOCK,
				(string) $since
			)
		);

		return (int) $wpdb->rows_affected > 0;
	}

	/**
	 * رها کردن قفل.
	 */
	protected static function unlock() {
		global $wpdb;

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", self::LOCK ) ); // phpcs:ignore WordPress.DB
	}
}
