<?php
/**
 * تب پرونده‌ی مشتریان (CRM).
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_stages  = WCMA_CRM::stages();
$wcma_sources = WCMA_CRM::sources();
$wcma_stats   = WCMA_CRM::stats();
$wcma_tags    = WCMA_CRM::all_tags();
$wcma_missing = ! WCMA_Install::table_exists( 'wcma_contacts' );

// phpcs:disable WordPress.Security.NonceVerification.Recommended
$wcma_filters = array(
	'search'   => isset( $_GET['c_search'] ) ? sanitize_text_field( wp_unslash( $_GET['c_search'] ) ) : '',
	'stage'    => isset( $_GET['c_stage'] ) ? sanitize_key( wp_unslash( $_GET['c_stage'] ) ) : '',
	'tag'      => isset( $_GET['c_tag'] ) ? sanitize_text_field( wp_unslash( $_GET['c_tag'] ) ) : '',
	'source'   => isset( $_GET['c_source'] ) ? sanitize_key( wp_unslash( $_GET['c_source'] ) ) : '',
	'followup' => isset( $_GET['c_followup'] ) ? sanitize_key( wp_unslash( $_GET['c_followup'] ) ) : '',
	'orderby'  => isset( $_GET['c_orderby'] ) ? sanitize_key( wp_unslash( $_GET['c_orderby'] ) ) : 'updated_at',
	'page'     => isset( $_GET['cpage'] ) ? max( 1, (int) $_GET['cpage'] ) : 1,
	'per_page' => WCMA_Admin::per_page( 'c_per' ),
);

$wcma_open = isset( $_GET['contact'] ) ? (int) $_GET['contact'] : 0;
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$wcma_result  = $wcma_missing ? array( 'items' => array(), 'total' => 0, 'pages' => 0, 'page' => 1 ) : WCMA_CRM::query( $wcma_filters );
$wcma_contact = $wcma_open ? WCMA_CRM::get( $wcma_open ) : null;
$wcma_owners  = get_users( array( 'capability' => 'edit_shop_orders', 'number' => 50, 'fields' => array( 'ID', 'display_name' ) ) );
$wcma_base    = WCMA_Admin::tab_url( 'crm' );
$wcma_sync    = get_option( 'wcma_crm_last_sync', '' );
?>

<?php if ( $wcma_missing ) : ?>
	<div class="wcma-notice wcma-notice--error">
		<span class="dashicons dashicons-warning"></span>
		<span>جدول پرونده‌ی مشتریان هنوز ساخته نشده است. به تب «تست ارسال» بروید و دکمه‌ی «ترمیم جدول‌ها» را بزنید.</span>
	</div>
<?php endif; ?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat">
		<span class="wcma-stat__icon dashicons dashicons-id-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['total'] ) ); ?></span>
			<span class="wcma-stat__label">پرونده‌ی مشتری</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-money-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo wp_kses_post( WCMA_Date::price( $wcma_stats['revenue'] ) ); ?></span>
			<span class="wcma-stat__label">ارزش کل مشتریان</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-clock"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['due'] ) ); ?></span>
			<span class="wcma-stat__label">پیگیری سررسیدشده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-plus-alt"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['new_week'] ) ); ?></span>
			<span class="wcma-stat__label">تازه در هفت روز اخیر</span>
		</div>
	</div>
</div>

<?php
$wcma_due = WCMA_CRM::due_items( array( 'limit' => 30 ) );
$wcma_now = (int) current_time( 'timestamp' );
?>

<?php
WCMA_Admin_Fields::card_start(
	'کارهای امروز' . ( $wcma_due ? ' (' . WCMA_Date::number( count( $wcma_due ) ) . ')' : '' ),
	'یادداشت‌ها، تماس‌ها و جلسه‌هایی که تاریخ پیگیری گرفته‌اند و وقتشان رسیده.',
	'yes-alt',
	'هر کاری که در پرونده‌ی یک مشتری تاریخ بگیرد، همین‌جا می‌آید و سر وقتش برای ثبت‌کننده‌اش یادآوری می‌شود.',
	'today-tasks'
);
?>
	<?php if ( $wcma_due ) : ?>
		<div class="wcma-tasks">
			<?php
			foreach ( $wcma_due as $wcma_task ) :
				$wcma_late = strtotime( (string) $wcma_task['due_at'] ) < strtotime( gmdate( 'Y-m-d', $wcma_now ) );
				?>
				<div class="wcma-task<?php echo $wcma_late ? ' is-late' : ''; ?>" data-note="<?php echo esc_attr( $wcma_task['id'] ); ?>">
					<span class="wcma-task__icon dashicons dashicons-<?php echo esc_attr( WCMA_CRM::note_icon( $wcma_task['type'] ) ); ?>"></span>

					<div class="wcma-task__main">
						<a class="wcma-task__who" href="<?php echo esc_url( add_query_arg( array( 'contact' => (int) $wcma_task['contact_id'] ), $wcma_base ) ); ?>">
							<?php echo esc_html( WCMA_CRM::display_name( $wcma_task ) ); ?>
						</a>
						<span class="wcma-task__body"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( (string) $wcma_task['body'] ), 18, '…' ) ); ?></span>
					</div>

					<span class="wcma-task__when<?php echo $wcma_late ? ' is-late' : ''; ?>">
						<span class="dashicons dashicons-clock"></span>
						<?php echo WCMA_Date::html( $wcma_task['due_at'], 'datetime' ); ?>
						<?php echo $wcma_late ? '<b>— عقب افتاده</b>' : ''; ?>
					</span>

					<?php if ( ! empty( $wcma_task['phone'] ) ) : ?>
						<a class="wcma-task__call" href="tel:<?php echo esc_attr( $wcma_task['phone'] ); ?>" title="تماس">
							<span class="dashicons dashicons-phone"></span>
						</a>
					<?php endif; ?>

					<button type="button" class="wcma-btn wcma-btn--ghost wcma-task__done" data-note="<?php echo esc_attr( $wcma_task['id'] ); ?>">
						<span class="dashicons dashicons-yes"></span>
						انجام شد
					</button>
				</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="wcma-empty">کاری برای امروز نمانده. 🎉</p>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'قیف فروش', 'هر مشتری در کدام مرحله است. با کلیک روی هر مرحله، فهرست همان گروه را می‌بینید.', 'chart-pie', 'مرحله‌ها خودکار از رفتار مشتری تعیین می‌شوند: سرنخ، در حال بررسی، مشتری، وفادار و در خطر ریزش.' ); ?>
	<div class="wcma-pipeline">
		<?php foreach ( $wcma_stages as $wcma_key => $wcma_stage ) : ?>
			<?php
			$wcma_count = (int) ( $wcma_stats['stages'][ $wcma_key ] ?? 0 );
			$wcma_url   = add_query_arg( array( 'c_stage' => $wcma_key ), $wcma_base );
			?>
			<a
				href="<?php echo esc_url( $wcma_url ); ?>"
				class="wcma-pipe <?php echo $wcma_filters['stage'] === $wcma_key ? 'is-active' : ''; ?>"
				style="--pipe-color: <?php echo esc_attr( $wcma_stage['color'] ); ?>"
				title="<?php echo esc_attr( $wcma_stage['desc'] ); ?>"
			>
				<span class="wcma-pipe__count"><?php echo esc_html( WCMA_Date::number( $wcma_count ) ); ?></span>
				<span class="wcma-pipe__label"><?php echo esc_html( $wcma_stage['label'] ); ?></span>
				<span class="wcma-pipe__desc"><?php echo esc_html( $wcma_stage['desc'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>

	<div class="wcma-actions">
		<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-crm-sync">
			<span class="dashicons dashicons-update"></span>
			همگام‌سازی با سفارش‌ها
		</button>
		<a href="<?php echo esc_url( add_query_arg( array( 'wcma_export' => 'crm', '_wpnonce' => wp_create_nonce( 'wcma_export_crm' ) ), $wcma_base ) ); ?>" class="wcma-btn wcma-btn--ghost">
			<span class="dashicons dashicons-download"></span>
			خروجی CSV
		</a>
		<span id="wcma-crm-sync-result" class="wcma-field__desc">
			<?php if ( $wcma_sync ) : ?>
				آخرین همگام‌سازی: <?php echo WCMA_Date::html( $wcma_sync ); ?>
			<?php endif; ?>
		</span>
	</div>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'فهرست مشتریان', 'جستجو، فیلتر و باز کردن پرونده‌ی هر مشتری.', 'groups' ); ?>
	<form method="get" class="wcma-filters is-instant">
		<input type="hidden" name="page" value="wcma" />
		<input type="hidden" name="tab" value="crm" />

		<input type="search" name="c_search" value="<?php echo esc_attr( $wcma_filters['search'] ); ?>" placeholder="نام، ایمیل، موبایل یا شرکت" />

		<select name="c_stage">
			<option value="">همه‌ی مرحله‌ها</option>
			<?php foreach ( $wcma_stages as $wcma_key => $wcma_stage ) : ?>
				<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( $wcma_filters['stage'], $wcma_key ); ?>><?php echo esc_html( $wcma_stage['label'] ); ?></option>
			<?php endforeach; ?>
		</select>

		<select name="c_source">
			<option value="">همه‌ی منابع</option>
			<?php foreach ( $wcma_sources as $wcma_key => $wcma_label ) : ?>
				<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( $wcma_filters['source'], $wcma_key ); ?>><?php echo esc_html( $wcma_label ); ?></option>
			<?php endforeach; ?>
		</select>

		<?php if ( $wcma_tags ) : ?>
			<select name="c_tag">
				<option value="">همه‌ی برچسب‌ها</option>
				<?php foreach ( $wcma_tags as $wcma_tag ) : ?>
					<option value="<?php echo esc_attr( $wcma_tag ); ?>" <?php selected( $wcma_filters['tag'], $wcma_tag ); ?>><?php echo esc_html( $wcma_tag ); ?></option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>

		<select name="c_followup">
			<option value="">بدون فیلتر پیگیری</option>
			<option value="due" <?php selected( $wcma_filters['followup'], 'due' ); ?>>پیگیری سررسیدشده</option>
			<option value="planned" <?php selected( $wcma_filters['followup'], 'planned' ); ?>>پیگیری برنامه‌ریزی‌شده</option>
		</select>

		<select name="c_orderby">
			<option value="updated_at" <?php selected( $wcma_filters['orderby'], 'updated_at' ); ?>>تازه‌ترین تغییر</option>
			<option value="total_spent" <?php selected( $wcma_filters['orderby'], 'total_spent' ); ?>>بیشترین خرید</option>
			<option value="order_count" <?php selected( $wcma_filters['orderby'], 'order_count' ); ?>>بیشترین تعداد سفارش</option>
			<option value="last_order_at" <?php selected( $wcma_filters['orderby'], 'last_order_at' ); ?>>آخرین خرید</option>
			<option value="next_followup_at" <?php selected( $wcma_filters['orderby'], 'next_followup_at' ); ?>>نزدیک‌ترین پیگیری</option>
		</select>

		<button type="submit" class="screen-reader-text">اعمال فیلتر</button>
		<a href="<?php echo esc_url( $wcma_base ); ?>" class="wcma-btn wcma-btn--ghost">پاک کردن</a>
	</form>

	<?php if ( $wcma_result['items'] ) : ?>
		<?php
		WCMA_Admin_Fields::list_bar(
			array(
				'key'     => 'c_per',
				'current' => $wcma_filters['per_page'],
				'total'   => (int) $wcma_result['total'],
			)
		);
		?>

		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>مشتری</th>
						<th>راه تماس</th>
						<th>مرحله</th>
						<th>منبع سرنخ</th>
						<th>سفارش</th>
						<th>مبلغ کل</th>
						<th>آخرین خرید</th>
						<th>پیگیری بعدی</th>
						<th>برچسب‌ها</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_result['items'] as $wcma_row ) : ?>
						<?php
						$wcma_stage_data = $wcma_stages[ $wcma_row['stage'] ?? '' ] ?? array( 'label' => $wcma_row['stage'] ?? '', 'color' => '#94a3b8' );
						$wcma_due        = ! empty( $wcma_row['next_followup_at'] ) && strtotime( $wcma_row['next_followup_at'] ) <= time();
						?>
						<tr class="<?php echo $wcma_open === (int) $wcma_row['id'] ? 'is-open' : ''; ?>">
							<td>
								<a href="<?php echo esc_url( add_query_arg( array( 'contact' => (int) $wcma_row['id'] ), $wcma_base ) ); ?>">
									<strong><?php echo esc_html( WCMA_CRM::display_name( $wcma_row ) ); ?></strong>
								</a>
								<?php if ( ! empty( $wcma_row['company'] ) ) : ?>
									<small><?php echo esc_html( $wcma_row['company'] ?? '' ); ?></small>
								<?php endif; ?>
							</td>
							<td class="wcma-ltr">
								<?php if ( ! empty( $wcma_row['phone'] ) ) : ?>
									<div dir="ltr"><?php echo esc_html( WCMA_Date::digits( $wcma_row['phone'] ?? '' ) ); ?></div>
								<?php endif; ?>
								<?php if ( ! empty( $wcma_row['email'] ) ) : ?>
									<small dir="ltr"><?php echo esc_html( $wcma_row['email'] ?? '' ); ?></small>
								<?php endif; ?>
							</td>
							<td>
								<span class="wcma-badge" style="background: <?php echo esc_attr( $wcma_stage_data['color'] ); ?>1a; color: <?php echo esc_attr( $wcma_stage_data['color'] ); ?>">
									<?php echo esc_html( $wcma_stage_data['label'] ); ?>
								</span>
							</td>
							<td>
								<?php $wcma_src = WCMA_CRM::source_style( (string) ( $wcma_row['source'] ?? '' ) ); ?>
								<span
									class="wcma-source"
									style="color: <?php echo esc_attr( $wcma_src['color'] ); ?>; background: <?php echo esc_attr( $wcma_src['color'] ); ?>1a"
									title="<?php echo esc_attr( 'این مشتری از راه ' . $wcma_src['label'] . ' وارد شده است' ); ?>"
								>
									<span class="dashicons dashicons-<?php echo esc_attr( $wcma_src['icon'] ); ?>"></span>
									<?php echo esc_html( $wcma_src['label'] ); ?>
								</span>
							</td>
							<td><?php echo esc_html( WCMA_Date::number( $wcma_row['order_count'] ?? 0 ) ); ?></td>
							<td class="wcma-nowrap"><?php echo wp_kses_post( WCMA_Date::price( (float) ( $wcma_row['total_spent'] ?? 0 ) ) ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_row['last_order_at'] ?? '', 'date' ); ?></td>
							<td class="wcma-nowrap">
								<?php if ( ! empty( $wcma_row['next_followup_at'] ) ) : ?>
									<span class="<?php echo $wcma_due ? 'wcma-due' : ''; ?>">
										<?php echo WCMA_Date::html( $wcma_row['next_followup_at'] ?? '', 'date' ); ?>
									</span>
								<?php else : ?>
									—
								<?php endif; ?>
							</td>
							<td>
								<?php foreach ( WCMA_CRM::tag_list( $wcma_row['tags'] ?? '' ) as $wcma_tag ) : ?>
									<span class="wcma-badge wcma-badge--soft"><?php echo esc_html( $wcma_tag ); ?></span>
								<?php endforeach; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'cpage',
				'current' => (int) $wcma_result['page'],
				'pages'   => (int) $wcma_result['pages'],
			)
		);
		?>
	<?php else : ?>
		<div class="wcma-empty">
			<span class="dashicons dashicons-id-alt"></span>
			<p>هنوز پرونده‌ای مطابق این فیلترها نیست. دکمه‌ی «همگام‌سازی با سفارش‌ها» را بزنید تا پرونده‌ها از سفارش‌های موجود ساخته شوند.</p>
		</div>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php if ( $wcma_contact ) : ?>
	<?php WCMA_Admin_Fields::card_start( 'پرونده‌ی ' . WCMA_CRM::display_name( $wcma_contact ), 'ویرایش اطلاعات، ثبت پیگیری و یادداشت‌های این مشتری.', 'businessperson' ); ?>
		<div class="wcma-crm-panel" data-contact="<?php echo esc_attr( (int) $wcma_contact['id'] ); ?>">
			<div class="wcma-crm-panel__form">
				<div class="wcma-row">
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_first_name">نام</label>
						<div class="wcma-field__input">
							<input type="text" id="crm_first_name" value="<?php echo esc_attr( $wcma_contact['first_name'] ); ?>" />
						</div>
					</div>
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_last_name">نام خانوادگی</label>
						<div class="wcma-field__input">
							<input type="text" id="crm_last_name" value="<?php echo esc_attr( $wcma_contact['last_name'] ); ?>" />
						</div>
					</div>
				</div>

				<div class="wcma-row">
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_company">شرکت / سازمان</label>
						<div class="wcma-field__input">
							<input type="text" id="crm_company" value="<?php echo esc_attr( $wcma_contact['company'] ); ?>" />
						</div>
					</div>
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_city">شهر</label>
						<div class="wcma-field__input">
							<input type="text" id="crm_city" value="<?php echo esc_attr( $wcma_contact['city'] ); ?>" />
						</div>
					</div>
				</div>

				<div class="wcma-row wcma-row--3">
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_stage">مرحله</label>
						<div class="wcma-field__input">
							<select id="crm_stage">
								<?php foreach ( $wcma_stages as $wcma_key => $wcma_stage ) : ?>
									<option value="<?php echo esc_attr( $wcma_key ); ?>" <?php selected( $wcma_contact['stage'], $wcma_key ); ?>><?php echo esc_html( $wcma_stage['label'] ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_owner">مسئول پیگیری</label>
						<div class="wcma-field__input">
							<select id="crm_owner">
								<option value="0">تعیین نشده</option>
								<?php foreach ( $wcma_owners as $wcma_owner ) : ?>
									<option value="<?php echo esc_attr( $wcma_owner->ID ); ?>" <?php selected( (int) $wcma_contact['owner_id'], (int) $wcma_owner->ID ); ?>><?php echo esc_html( $wcma_owner->display_name ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_tags">برچسب‌ها</label>
						<div class="wcma-field__input">
							<input type="text" id="crm_tags" value="<?php echo esc_attr( implode( '، ', WCMA_CRM::tag_list( $wcma_contact['tags'] ) ) ); ?>" placeholder="عمده‌فروش، تهران، پیگیری ویژه" />
						</div>
						<p class="wcma-field__desc">با ویرگول از هم جدا کنید.</p>
					</div>
				</div>

				<div class="wcma-row">
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_followup">تاریخ پیگیری بعدی</label>
						<div class="wcma-field__input">
							<input type="datetime-local" data-wcma-jalali id="crm_followup" value="<?php echo esc_attr( $wcma_contact['next_followup_at'] ? gmdate( 'Y-m-d\TH:i', strtotime( $wcma_contact['next_followup_at'] ) ) : '' ); ?>" />
						</div>
					</div>
					<div class="wcma-field">
						<label class="wcma-field__label" for="crm_followup_note">موضوع پیگیری</label>
						<div class="wcma-field__input">
							<input type="text" id="crm_followup_note" value="<?php echo esc_attr( $wcma_contact['followup_note'] ); ?>" placeholder="تماس برای پیشنهاد عمده" />
						</div>
					</div>
				</div>

				<div class="wcma-actions">
					<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-crm-save">
						<span class="dashicons dashicons-saved"></span>
						ذخیره‌ی پرونده
					</button>
					<span id="wcma-crm-save-result" class="wcma-field__desc"></span>
				</div>
			</div>

			<div class="wcma-crm-panel__side">
				<div class="wcma-crm-facts">
					<div><span>ایمیل</span><strong dir="ltr"><?php echo esc_html( $wcma_contact['email'] ? $wcma_contact['email'] : '—' ); ?></strong></div>
					<div><span>موبایل</span><strong dir="ltr"><?php echo esc_html( $wcma_contact['phone'] ? WCMA_Date::digits( $wcma_contact['phone'] ) : '—' ); ?></strong></div>
					<div><span>تعداد سفارش</span><strong><?php echo esc_html( WCMA_Date::number( $wcma_contact['order_count'] ) ); ?></strong></div>
					<div><span>مبلغ کل خرید</span><strong><?php echo wp_kses_post( WCMA_Date::price( (float) $wcma_contact['total_spent'] ) ); ?></strong></div>
					<div><span>اولین خرید</span><strong><?php echo WCMA_Date::html( $wcma_contact['first_order_at'], 'date' ); ?></strong></div>
					<div><span>آخرین خرید</span><strong><?php echo WCMA_Date::html( $wcma_contact['last_order_at'], 'date' ); ?></strong></div>
					<div><span>منبع آشنایی</span><strong><?php echo esc_html( $wcma_sources[ $wcma_contact['source'] ] ?? '—' ); ?></strong></div>
					<div><span>آخرین تماس</span><strong><?php echo WCMA_Date::html( $wcma_contact['last_contact_at'] ); ?></strong></div>
				</div>

				<?php if ( WCMA_Wallet::is_on() && $wcma_contact['user_id'] ) : ?>
					<?php $wcma_wallet = WCMA_Wallet::balance( (int) $wcma_contact['user_id'] ); ?>

					<div class="wcma-wallet-box">
						<div class="wcma-wallet-box__head">
							<span>کیف پول</span>
							<strong><?php echo wp_kses_post( WCMA_Date::price( $wcma_wallet ) ); ?></strong>
						</div>

						<form method="post" class="wcma-wallet-box__form">
							<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
							<input type="hidden" name="wcma_action" value="wallet_adjust" />
							<input type="hidden" name="user_id" value="<?php echo esc_attr( (int) $wcma_contact['user_id'] ); ?>" />

							<div class="wcma-row wcma-row--2">
								<input type="text" name="amount" dir="ltr" inputmode="numeric" placeholder="مبلغ (تومان)" required />

								<select name="way">
									<option value="credit">افزودن</option>
									<option value="debit">کم کردن</option>
								</select>
							</div>

							<input type="text" name="note" placeholder="بابت چه؟ (اختیاری)" />

							<button type="submit" class="wcma-btn wcma-btn--secondary" data-confirm="موجودی کیف پول این مشتری تغییر کند؟">
								<span class="dashicons dashicons-money-alt"></span>
								ثبت تغییر
							</button>
						</form>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<h3 class="wcma-subtitle">
			<span class="dashicons dashicons-backup"></span>
			گردش کار مشتری
		</h3>

		<p class="wcma-field__desc">
			همه‌ی رویدادهای این مشتری کنار هم: از لحظه‌ی ورود به پرونده تا سفارش‌ها،
			پیام‌های فرستاده‌شده و گفتگوها.
		</p>

		<h3 class="wcma-subtitle">یادداشت تازه</h3>

		<div class="wcma-note-form">
			<select id="crm_note_type">
				<?php foreach ( WCMA_CRM::note_types() as $wcma_key => $wcma_label ) : ?>
					<?php if ( in_array( $wcma_key, array( 'stage', 'message' ), true ) ) : ?>
						<?php continue; ?>
					<?php endif; ?>
					<option value="<?php echo esc_attr( $wcma_key ); ?>"><?php echo esc_html( $wcma_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<textarea id="crm_note_body" rows="2" placeholder="چه چیزی درباره‌ی این مشتری باید به‌خاطر بماند؟"></textarea>
			<?php
			/*
			 * datetime-local یعنی تقویم، ردیف ساعت و دقیقه را هم نشان بدهد؛
			 * «فردا ساعت ۱۰» یادآوری به‌دردبخوری است، «فردا نیمه‌شب» نه.
			 */
			?>
			<input
				type="datetime-local"
				data-wcma-jalali
				id="crm_note_due"
				title="یادآوری در تاریخ و ساعت"
				placeholder="یادآوری در تاریخ و ساعت"
			/>
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-crm-note">
				<span class="dashicons dashicons-plus-alt"></span>
				ثبت
			</button>
		</div>

		<p class="wcma-hint">
			اگر تاریخ بگذارید، این کار در «کارهای امروز» بالای همین برگه می‌آید و سر وقتش
			یادآوری می‌شود.
		</p>

		<?php $wcma_journey = WCMA_CRM::journey( $wcma_contact ); ?>

		<?php if ( $wcma_journey ) : ?>
			<div class="wcma-journey-filters" role="tablist">
				<?php foreach ( WCMA_CRM::journey_filters() as $wcma_fkey => $wcma_filter ) : ?>
					<button
						type="button"
						class="wcma-journey-filter <?php echo 'all' === $wcma_fkey ? 'is-active' : ''; ?>"
						data-kinds="<?php echo esc_attr( implode( ' ', $wcma_filter['kinds'] ) ); ?>"
					><?php echo esc_html( $wcma_filter['label'] ); ?></button>
				<?php endforeach; ?>
			</div>

			<?php
			/*
			 * فقط یادداشت‌ها ویرایش می‌شوند: سفارش، پیام فرستاده‌شده و گفتگو
			 * ثبتِ چیزی هستند که واقعاً رخ داده و دست بردن در آن‌ها تاریخچه را
			 * دروغ می‌کند.
			 */
			$wcma_can_edit = current_user_can( 'manage_woocommerce' );
			?>

			<div class="wcma-journey" id="wcma-crm-journey">
				<?php foreach ( $wcma_journey as $wcma_event ) : ?>
					<div
						class="wcma-journey__item is-<?php echo esc_attr( $wcma_event['kind'] ); ?>"
						data-kind="<?php echo esc_attr( $wcma_event['kind'] ); ?>"
						<?php echo empty( $wcma_event['note'] ) ? '' : 'data-note="' . esc_attr( (int) $wcma_event['note'] ) . '"'; ?>
					>
						<span class="wcma-journey__dot" style="background: <?php echo esc_attr( $wcma_event['color'] ); ?>1a; color: <?php echo esc_attr( $wcma_event['color'] ); ?>">
							<span class="dashicons dashicons-<?php echo esc_attr( $wcma_event['icon'] ); ?>"></span>
						</span>

						<div class="wcma-journey__body">
							<div class="wcma-journey__head">
								<strong>
									<?php if ( ! empty( $wcma_event['link'] ) ) : ?>
										<a href="<?php echo esc_url( $wcma_event['link'] ); ?>"><?php echo esc_html( $wcma_event['title'] ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $wcma_event['title'] ); ?>
									<?php endif; ?>
								</strong>
								<time><?php echo WCMA_Date::html( $wcma_event['time'] ); ?></time>
							</div>

							<?php if ( ! empty( $wcma_event['detail'] ) ) : ?>
								<span class="wcma-journey__detail"><?php echo esc_html( $wcma_event['detail'] ); ?></span>
							<?php endif; ?>

							<?php if ( ! empty( $wcma_event['author'] ) ) : ?>
								<span class="wcma-journey__author">
									<span class="dashicons dashicons-admin-users"></span>
									نام ثبت‌کننده: <?php echo esc_html( $wcma_event['author'] ); ?>
								</span>
							<?php endif; ?>

							<span class="wcma-journey__author wcma-journey__due<?php echo empty( $wcma_event['done'] ) ? '' : ' is-done'; ?>" <?php echo empty( $wcma_event['due'] ) ? 'hidden' : ''; ?>>
								<span class="dashicons dashicons-<?php echo empty( $wcma_event['done'] ) ? 'clock' : 'yes-alt'; ?>"></span>
								<span class="wcma-journey__due-label"><?php echo empty( $wcma_event['done'] ) ? 'یادآوری: ' : 'انجام شد — سررسید بود: '; ?></span>
								<span class="wcma-journey__due-value"><?php echo $wcma_event['due']; // خروجی WCMA_Date::html، از پیش امن. ?></span>
							</span>

							<?php if ( $wcma_can_edit && ! empty( $wcma_event['note'] ) ) : ?>
								<div class="wcma-journey__tools">
									<button
										type="button"
										class="wcma-journey__tool wcma-note-edit"
										data-note="<?php echo esc_attr( (int) $wcma_event['note'] ); ?>"
										data-type="<?php echo esc_attr( $wcma_event['type'] ?? 'note' ); ?>"
										data-body="<?php echo esc_attr( $wcma_event['raw'] ?? '' ); ?>"
										data-due="<?php echo esc_attr( $wcma_event['dueRaw'] ? gmdate( 'Y-m-d\TH:i', strtotime( $wcma_event['dueRaw'] ) ) : '' ); ?>"
									>
										<span class="dashicons dashicons-edit"></span>
										ویرایش
									</button>

									<button
										type="button"
										class="wcma-journey__tool wcma-note-delete"
										data-note="<?php echo esc_attr( (int) $wcma_event['note'] ); ?>"
										data-confirm="این یادداشت برای همیشه حذف شود؟"
									>
										<span class="dashicons dashicons-trash"></span>
										حذف
									</button>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<p class="wcma-field__desc" id="wcma-journey-empty" hidden>در این دسته رویدادی نیست.</p>
		<?php else : ?>
			<p class="wcma-field__desc">هنوز رویدادی برای این مشتری ثبت نشده است.</p>
		<?php endif; ?>




	<?php WCMA_Admin_Fields::card_end(); ?>
<?php endif; ?>
