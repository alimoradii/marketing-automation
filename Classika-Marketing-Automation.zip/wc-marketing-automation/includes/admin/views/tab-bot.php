<?php
/**
 * تب مدیریت ربات تلگرام و بله.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

$wcma_missing  = ! WCMA_Install::table_exists( 'wcma_bot_subs' );
$wcma_stats    = WCMA_Bot_Manager::stats();
$wcma_menu     = WCMA_Bot_Manager::menu();
$wcma_sequence = WCMA_Bot_Manager::sequence();
$wcma_actions  = WCMA_Bot_Manager::button_actions();
$wcma_types    = WCMA_Messengers::content_types();
$wcma_channel  = WCMA_Bot_Manager::channel();
$wcma_ready    = WCMA_Messengers::is_ready( $wcma_channel );
// همه‌ی روزها رندر می‌شوند ولی روزهای خالی پنهان‌اند و با دکمه‌ی «افزودن روز» باز می‌شوند.
$wcma_rows     = WCMA_Bot_Manager::MAX_DAYS;
$wcma_last     = $wcma_sequence ? max( array_keys( $wcma_sequence ) ) : 0;
$wcma_open     = max( 1, $wcma_last );
?>

<?php if ( $wcma_missing ) : ?>
	<div class="wcma-notice wcma-notice--error">
		<span class="dashicons dashicons-warning"></span>
		<span>جدول مشترکان ربات ساخته نشده است. به تب «تست ارسال» بروید و «ترمیم جدول‌ها» را بزنید.</span>
	</div>
<?php endif; ?>

<?php if ( ! $wcma_ready ) : ?>
	<div class="wcma-notice wcma-notice--warning">
		<span class="dashicons dashicons-info"></span>
		<span>
			توکن ربات <?php echo esc_html( WCMA_Messengers::label( $wcma_channel ) ); ?> وارد نشده است.
			ابتدا در تب <a href="<?php echo esc_url( WCMA_Admin::tab_url( 'sms' ) ); ?>">کانال‌های ارتباطی</a>
			توکن را وارد و وب‌هوک را ثبت کنید.
		</span>
	</div>
<?php endif; ?>

<div class="wcma-stats wcma-stats--compact">
	<div class="wcma-stat">
		<span class="wcma-stat__icon dashicons dashicons-groups"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['total'] ) ); ?></span>
			<span class="wcma-stat__label">کل مشترکان ربات</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--green">
		<span class="wcma-stat__icon dashicons dashicons-controls-play"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['active'] ) ); ?></span>
			<span class="wcma-stat__label">در حال دریافت دنباله</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--amber">
		<span class="wcma-stat__icon dashicons dashicons-smartphone"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['with_phone'] ) ); ?></span>
			<span class="wcma-stat__label">شماره‌ی ثبت‌شده</span>
		</div>
	</div>
	<div class="wcma-stat wcma-stat--purple">
		<span class="wcma-stat__icon dashicons dashicons-paperclip"></span>
		<div>
			<span class="wcma-stat__value"><?php echo esc_html( WCMA_Date::number( $wcma_stats['sent'] ) ); ?></span>
			<span class="wcma-stat__label">پیام دنباله‌ی فرستاده‌شده</span>
		</div>
	</div>
</div>

<form method="post" class="wcma-form">
	<?php wp_nonce_field( 'wcma_save', 'wcma_nonce' ); ?>
	<input type="hidden" name="wcma_action" value="save_settings" />

	<?php WCMA_Admin_Fields::card_start( 'وضعیت ربات', 'با روشن کردن این بخش، ربات منوی دکمه‌ها و دنباله‌ی روزانه را اجرا می‌کند.', 'admin-generic', '', 'bot-status' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'tg_bot_enabled', 'فعال بودن مدیریت ربات', '', 'تا این کلید روشن نباشد، منوی دکمه‌ها و دنباله‌ی روزانه اجرا نمی‌شوند — حتی اگر توکن ربات را وارد کرده باشید.' );

		WCMA_Admin_Fields::select(
			'tg_bot_channel',
			'ربات روی کدام پیام‌رسان؟',
			array(
				'telegram' => 'تلگرام',
				'bale'     => 'بله',
			),
			array( 'description' => 'ایتا و روبیکا از دکمه و رسانه‌ی این‌چنینی پشتیبانی نمی‌کنند.' )
		);
		?>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'سلامت ربات', 'اگر دکمه‌ها در ربات کار نمی‌کنند یا استارت بی‌پاسخ می‌ماند، اینجا را بزنید.', 'shield-alt', 'پیام‌های ورودی از راه «وب‌هوک» به سایت می‌رسند. اگر وب‌هوک ثبت نشده باشد، ربات پیام می‌فرستد ولی هیچ دکمه‌ای کار نمی‌کند.' ); ?>
		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				پیام‌های ورودی از راه «وب‌هوک» به سایت می‌رسند. اگر وب‌هوک ثبت نشده باشد،
				ربات همچنان پیام <em>می‌فرستد</em> و دکمه‌ها روی صفحه دیده می‌شوند، ولی هیچ‌کدام
				کار نمی‌کند؛ چون تلگرام نمی‌تواند فشردن دکمه را به سایت خبر بدهد.
			</div>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--primary" id="wcma-bot-diag">
				<span class="dashicons dashicons-search"></span>
				بررسی وضعیت ربات
			</button>
			<button type="button" class="wcma-btn wcma-btn--secondary wcma-register-hook" data-messenger="<?php echo esc_attr( WCMA_Bot_Manager::channel() ); ?>">
				<span class="dashicons dashicons-update"></span>
				ثبت دوباره‌ی وب‌هوک
			</button>
		</div>

		<div class="wcma-diagnostics" id="wcma-bot-diag-result" hidden></div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'پیام شروع', 'وقتی کاربر /start را می‌زند یا اولین بار وارد ربات می‌شود.', 'controls-play' ); ?>
		<?php
		WCMA_Admin_Fields::select( 'tg_welcome_type', 'نوع پیام خوش‌آمد', wp_list_pluck( $wcma_types, 'label' ) );

		WCMA_Admin_Fields::text(
			'tg_welcome_file',
			'نشانی فایل (برای عکس، ویدیو، صوت یا فایل)',
			array( 'placeholder' => 'https://example.com/intro.mp4', 'description' => 'برای پیام متنی خالی بگذارید. نشانی باید عمومی و مستقیم باشد.' )
		);

		WCMA_Admin_Fields::textarea( 'tg_welcome_text', 'متن خوش‌آمد', array( 'rows' => 3 ) );
		?>

		<?php WCMA_Admin_Fields::placeholder_help( array( 'site_title', 'site_url', 'shop_phone', 'start_date', 'start_weekday' ) ); ?>

		<h3 class="wcma-subtitle">گرفتن شماره موبایل</h3>

		<?php
		WCMA_Admin_Fields::toggle( 'tg_ask_phone', 'نمایش دکمه‌ی «اشتراک‌گذاری شماره» در پیام شروع', '', 'دکمه‌ای که با یک لمس شماره‌ی کاربر را می‌گیرد و در پرونده‌ی مشتریان ثبت می‌کند. تا وقتی کاربر شماره ندهد، این دکمه روی کیبوردش می‌ماند.' );
		WCMA_Admin_Fields::text( 'tg_phone_button', 'متن دکمه‌ی اشتراک شماره' );
		WCMA_Admin_Fields::textarea( 'tg_phone_thanks', 'پیام پس از دریافت شماره', array( 'rows' => 2 ) );
		?>

		<?php
		$wcma_keyboard = WCMA_Bot_Manager::keyboard( true );
		$wcma_has_phone_row = false;

		if ( $wcma_keyboard ) {
			foreach ( $wcma_keyboard['keyboard'] as $wcma_row ) {
				foreach ( $wcma_row as $wcma_key_btn ) {
					if ( ! empty( $wcma_key_btn['request_contact'] ) ) {
						$wcma_has_phone_row = true;
					}
				}
			}
		}
		?>

		<div class="wcma-keyboard-preview">
			<span class="wcma-keyboard-preview__title">
				<span class="dashicons dashicons-visibility"></span>
				کیبوردی که کاربر پس از /start می‌بیند
			</span>

			<?php if ( ! $wcma_keyboard ) : ?>
				<p class="wcma-field__desc">هیچ دکمه‌ای تعریف نشده است.</p>
			<?php else : ?>
				<div class="wcma-keyboard-preview__box">
					<?php foreach ( $wcma_keyboard['keyboard'] as $wcma_row ) : ?>
						<div class="wcma-keyboard-preview__row">
							<?php foreach ( $wcma_row as $wcma_key_btn ) : ?>
								<span class="wcma-keyboard-preview__key <?php echo ! empty( $wcma_key_btn['request_contact'] ) ? 'is-phone' : ''; ?>">
									<?php echo esc_html( $wcma_key_btn['text'] ); ?>
								</span>
							<?php endforeach; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! $wcma_has_phone_row ) : ?>
				<div class="wcma-notice wcma-notice--error">
					<span class="dashicons dashicons-warning"></span>
					<span>دکمه‌ی اشتراک شماره در کیبورد نیست. کلید بالا را روشن کنید و مطمئن شوید متن دکمه خالی نیست.</span>
				</div>
			<?php endif; ?>
		</div>

		<div class="wcma-info">
			<span class="dashicons dashicons-info"></span>
			<div>
				شماره‌ای که کاربر می‌فرستد خودکار در
				<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'crm' ) ); ?>">پرونده‌ی مشتریان</a>
				ثبت می‌شود و اگر با حساب فروشگاه بخواند، به همان کاربر وصل می‌گردد.
			</div>
		</div>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'منوی دکمه‌های ربات', 'این دکمه‌ها زیر کادر تایپ کاربر نمایش داده می‌شوند. هر ردیف یک دکمه است.', 'menu' ); ?>
		<?php
		// ردیف‌های پرشده به‌علاوه‌ی یک ردیف خالی؛ بقیه با دکمه‌ی «افزودن» نمایان می‌شوند.
		$wcma_filled  = count( $wcma_menu );
		$wcma_visible = max( 1, min( WCMA_Bot_Manager::MAX_BUTTONS, $wcma_filled + 1 ) );

		$wcma_icons = array(
			'reply'   => 'format-status',
			'phone'   => 'smartphone',
			'link'    => 'admin-links',
			'day'     => 'calendar-alt',
			'stop'    => 'dismiss',
			'restart' => 'update',
		);
		?>

		<div class="wcma-botmenu" data-max="<?php echo esc_attr( WCMA_Bot_Manager::MAX_BUTTONS ); ?>">
			<?php for ( $wcma_i = 0; $wcma_i < WCMA_Bot_Manager::MAX_BUTTONS; $wcma_i++ ) : ?>
				<?php
				$wcma_button = $wcma_menu[ $wcma_i ] ?? array();
				$wcma_action = $wcma_button['action'] ?? 'reply';
				?>
				<div class="wcma-botmenu__row" data-index="<?php echo esc_attr( $wcma_i ); ?>" <?php echo $wcma_i < $wcma_visible ? '' : 'hidden'; ?>>
					<span class="wcma-botmenu__num"><?php echo esc_html( WCMA_Date::number( $wcma_i + 1 ) ); ?></span>

					<span class="wcma-botmenu__icon dashicons dashicons-<?php echo esc_attr( $wcma_icons[ $wcma_action ] ?? 'format-status' ); ?>"></span>

					<input
						type="text"
						name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][label]"
						value="<?php echo esc_attr( $wcma_button['label'] ?? '' ); ?>"
						placeholder="متن روی دکمه"
						class="wcma-botmenu__label"
					/>

					<select name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][action]" class="wcma-botmenu__action">
						<?php foreach ( $wcma_actions as $wcma_key => $wcma_label ) : ?>
							<option
								value="<?php echo esc_attr( $wcma_key ); ?>"
								data-icon="<?php echo esc_attr( $wcma_icons[ $wcma_key ] ?? 'format-status' ); ?>"
								<?php selected( $wcma_action, $wcma_key ); ?>
							><?php echo esc_html( $wcma_label ); ?></option>
						<?php endforeach; ?>
					</select>

					<input
						type="text"
						name="wcma[tg_menu][<?php echo esc_attr( $wcma_i ); ?>][value]"
						value="<?php echo esc_attr( $wcma_button['value'] ?? '' ); ?>"
						placeholder="متن پاسخ، نشانی لینک یا شماره‌ی روز"
						class="wcma-botmenu__value"
					/>

					<button type="button" class="wcma-botmenu__remove" title="پاک کردن این دستور">
						<span class="dashicons dashicons-trash"></span>
					</button>
				</div>
			<?php endfor; ?>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-add-command">
				<span class="dashicons dashicons-plus-alt2"></span>
				افزودن دستور تازه
			</button>
			<span class="wcma-field__desc" id="wcma-command-count"></span>
		</div>

		<p class="wcma-field__desc">
			دکمه‌ی بدون متن ذخیره نمی‌شود. برای «ارسال پیام یک روز مشخص»، در ستون آخر فقط شماره‌ی روز
			را بنویسید (مثلاً <code>۳</code>). حداکثر
			<?php echo esc_html( WCMA_Date::number( WCMA_Bot_Manager::MAX_BUTTONS ) ); ?>
			دستور می‌توانید تعریف کنید.
		</p>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::card_start( 'دنباله‌ی پیام‌های روزانه', 'هر مشترک از روز عضویتش، هر روز یک پیام در ساعت تعیین‌شده دریافت می‌کند.', 'calendar-alt', 'هر روز یا «چند روز پس از شروعِ هر مشترک» می‌رود، یا «در تاریخ مشخص» که برای همه یکی است. روز خاموش رد می‌شود.' ); ?>
		<?php
		WCMA_Admin_Fields::toggle( 'tg_seq_enabled', 'فعال بودن دنباله‌ی روزانه', '', 'هر مشترک از روز عضویتش، روزی یک پیام می‌گیرد. برای دوره‌های چندروزه و پرورش سرنخ ساخته شده است.' );
		WCMA_Admin_Fields::toggle( 'tg_seq_first_now', 'پیام روز یک بی‌درنگ پس از عضویت فرستاده شود', '', 'اگر خاموش باشد، پیام روز یک تا ساعت تعیین‌شده صبر می‌کند. روشن بودنش تجربه‌ی بهتری می‌دهد چون کاربر بی‌درنگ چیزی دریافت می‌کند.' );

		WCMA_Admin_Fields::text(
			'tg_seq_time',
			'ساعت پیش‌فرض ارسال',
			array( 'type' => 'time', 'description' => 'برای روزهایی که ساعت جداگانه‌ای برایشان تعیین نکرده‌اید.' )
		);
		?>

		<?php
		WCMA_Admin_Fields::placeholder_help(
			array(
				'site_title', 'site_url', 'shop_phone', 'coupon_code',
				'day', 'day_of_journey', 'days_since_start', 'start_date', 'start_date_long', 'start_weekday',
				'phone_date', 'phone_date_long', 'days_since_phone', 'total_days', 'remaining_days',
				'username', 'sent_count',
			)
		);
		?>

		<div class="wcma-days">
			<?php for ( $wcma_d = 1; $wcma_d <= $wcma_rows; $wcma_d++ ) : ?>
				<?php
				$wcma_item = $wcma_sequence[ $wcma_d ] ?? array();
				$wcma_on   = ! empty( $wcma_item['active'] );
				?>
				<div
					class="wcma-day <?php echo $wcma_on ? 'is-active' : ''; ?>"
					data-day="<?php echo esc_attr( $wcma_d ); ?>"
					<?php echo ( $wcma_d > $wcma_open ) ? 'hidden' : ''; ?>
				>
					<div class="wcma-day__head">
						<label class="wcma-switch">
							<input type="hidden" name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][active]" value="" />
							<input
								type="checkbox"
								class="wcma-day__toggle"
								name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][active]"
								value="yes"
								<?php checked( $wcma_on ); ?>
							/>
							<span class="wcma-switch__track"><span class="wcma-switch__thumb"></span></span>
						</label>

						<span class="wcma-day__icon dashicons dashicons-<?php echo esc_attr( $wcma_types[ $wcma_item['type'] ?? 'text' ]['icon'] ?? 'editor-alignright' ); ?>"></span>

						<strong>روز <?php echo esc_html( WCMA_Date::number( $wcma_d ) ); ?></strong>

						<input type="hidden" name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][day]" value="<?php echo esc_attr( $wcma_d ); ?>" />

						<?php $wcma_mode = $wcma_item['mode'] ?? 'offset'; ?>

						<select name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][mode]" class="wcma-day__mode">
							<option value="offset" <?php selected( $wcma_mode, 'offset' ); ?>>روز <?php echo esc_html( WCMA_Date::number( $wcma_d ) ); ?> پس از شروع</option>
							<option value="date" <?php selected( $wcma_mode, 'date' ); ?>>در تاریخ مشخص</option>
						</select>

						<span class="wcma-day__date" <?php echo ( 'date' === $wcma_mode ) ? '' : 'hidden'; ?>>
							<input
								type="date"
								data-wcma-jalali
								name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][date]"
								value="<?php echo esc_attr( $wcma_item['date'] ?? '' ); ?>"
								class="wcma-date-input"
								title="تاریخ ارسال این روز"
							/>
						</span>

						<span class="wcma-day__time">
							ساعت
							<input
								type="time"
								name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][time]"
								value="<?php echo esc_attr( $wcma_item['time'] ?? WCMA_Settings::get( 'tg_seq_time', '10:00' ) ); ?>"
							/>
						</span>

						<button type="button" class="wcma-day__remove" title="برداشتن این روز">
							<span class="dashicons dashicons-trash"></span>
						</button>

						<select name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][type]" class="wcma-day__type">
							<?php foreach ( $wcma_types as $wcma_key => $wcma_type ) : ?>
								<option
									value="<?php echo esc_attr( $wcma_key ); ?>"
									data-icon="<?php echo esc_attr( $wcma_type['icon'] ); ?>"
									<?php selected( $wcma_item['type'] ?? 'text', $wcma_key ); ?>
								><?php echo esc_html( $wcma_type['label'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="wcma-day__body">
						<input
							type="url"
							name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][file]"
							value="<?php echo esc_attr( $wcma_item['file'] ?? '' ); ?>"
							placeholder="نشانی فایل (برای عکس، ویدیو، صوت یا فایل)"
							dir="ltr"
							class="wcma-ltr-input"
						/>

						<textarea
							name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][text]"
							rows="3"
							placeholder="متن پیام یا توضیح زیر رسانه"
						><?php echo esc_textarea( $wcma_item['text'] ?? '' ); ?></textarea>

						<?php
						// ساختار قدیمیِ تک‌دکمه‌ای هم به همین فهرست می‌آید تا چیزی گم نشود.
						$wcma_day_buttons = WCMA_Bot_Manager::day_buttons( $wcma_item );
						$wcma_max_btn     = WCMA_Bot_Manager::MAX_DAY_BUTTONS;
						?>

						<div class="wcma-day__buttons" data-max="<?php echo esc_attr( $wcma_max_btn ); ?>">
							<span class="wcma-day__buttons-title">
								<span class="dashicons dashicons-admin-links"></span>
								دکمه‌های زیر پیام (اختیاری، تا <?php echo esc_html( WCMA_Date::number( $wcma_max_btn ) ); ?> تا)
							</span>

							<?php for ( $wcma_b = 0; $wcma_b < $wcma_max_btn; $wcma_b++ ) : ?>
								<?php
								$wcma_btn  = $wcma_day_buttons[ $wcma_b ] ?? array();
								$wcma_used = ! empty( $wcma_btn['label'] );
								?>
								<div class="wcma-day__button" data-index="<?php echo esc_attr( $wcma_b ); ?>" <?php echo ( $wcma_b > 0 && ! $wcma_used ) ? 'hidden' : ''; ?>>
									<input
										type="text"
										name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][buttons][<?php echo esc_attr( $wcma_b ); ?>][label]"
										value="<?php echo esc_attr( $wcma_btn['label'] ?? '' ); ?>"
										placeholder="متن دکمه"
									/>
									<input
										type="url"
										name="wcma[tg_sequence][<?php echo esc_attr( $wcma_d ); ?>][buttons][<?php echo esc_attr( $wcma_b ); ?>][url]"
										value="<?php echo esc_attr( $wcma_btn['url'] ?? '' ); ?>"
										placeholder="https://example.com/product"
										dir="ltr"
										class="wcma-ltr-input"
									/>
									<button type="button" class="wcma-btn wcma-btn--ghost wcma-day__button-remove" title="حذف این دکمه">
										<span class="dashicons dashicons-no-alt"></span>
									</button>
								</div>
							<?php endfor; ?>

							<button type="button" class="wcma-btn wcma-btn--ghost wcma-day__button-add">
								<span class="dashicons dashicons-plus-alt2"></span>
								افزودن دکمه
							</button>
						</div>
					</div>
				</div>
			<?php endfor; ?>
		</div>

		<div class="wcma-actions">
			<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-add-day">
				<span class="dashicons dashicons-plus-alt2"></span>
				افزودن روز تازه
			</button>
			<span class="wcma-field__desc" id="wcma-day-count"></span>
		</div>

		<p class="wcma-field__desc">
			هر روز می‌تواند «چند روز پس از شروعِ هر مشترک» بفرستد (هر کسی از روز عضویت خودش
			می‌شمارد) یا «در تاریخ مشخص» که برای همه یک روز ثابت است — مثل اطلاعیه یا جشنواره.
			روزی که خاموش باشد رد می‌شود و دنباله به روز بعد می‌رود.
		</p>
	<?php WCMA_Admin_Fields::card_end(); ?>

	<?php WCMA_Admin_Fields::submit(); ?>
</form>

<?php WCMA_Admin_Fields::card_start( 'آزمودن ربات', 'پیام یک روز مشخص را برای یک شناسه‌ی چت بفرستید تا پیش از شروع، از درستی آن مطمئن شوید.', 'controls-play' ); ?>
	<div class="wcma-sim">
		<input type="text" id="wcma-bot-chat" dir="ltr" placeholder="شناسه‌ی چت شما (مثلاً 123456789)" />
		<input type="number" id="wcma-bot-day" min="1" max="<?php echo esc_attr( WCMA_Bot_Manager::MAX_DAYS ); ?>" value="1" />
		<button type="button" class="wcma-btn wcma-btn--secondary" id="wcma-bot-test">
			<span class="dashicons dashicons-controls-play"></span>
			ارسال آزمایشی
		</button>
	</div>
	<div id="wcma-bot-test-result"></div>

	<p class="wcma-field__desc">
		شناسه‌ی چت خود را می‌توانید با فرستادن یک پیام به ربات و دیدن آن در تب
		<a href="<?php echo esc_url( WCMA_Admin::tab_url( 'chat' ) ); ?>">گفتگو</a> پیدا کنید.
	</p>
<?php WCMA_Admin_Fields::card_end(); ?>

<?php WCMA_Admin_Fields::card_start( 'مشترکان ربات', 'کسانی که ربات را شروع کرده‌اند و جایگاهشان در دنباله.', 'groups' ); ?>
	<?php
	$wcma_subs = WCMA_Bot_Manager::subscribers(
		array(
			'per_page' => WCMA_Admin::per_page( 's_per' ),
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'page'     => isset( $_GET['spage'] ) ? max( 1, (int) $_GET['spage'] ) : 1,
		)
	);

	WCMA_Admin_Fields::list_bar(
		array(
			'key'     => 's_per',
			'current' => WCMA_Admin::per_page( 's_per' ),
			'total'   => (int) $wcma_subs['total'],
		)
	);
	?>

	<?php if ( $wcma_subs['items'] ) : ?>
		<div class="wcma-table-wrap">
			<table class="wcma-table">
				<thead>
					<tr>
						<th>نام</th>
						<th>شناسه‌ی چت</th>
						<th>موبایل</th>
						<th>وضعیت</th>
						<th>روز فعلی</th>
						<th>آخرین ارسال</th>
						<th>عضویت</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wcma_subs['items'] as $wcma_sub ) : ?>
						<?php
						$wcma_states = array(
							'active'  => array( 'در حال دریافت', 'wcma-badge--green' ),
							'done'    => array( 'پایان‌یافته', 'wcma-badge--blue' ),
							'stopped' => array( 'لغو شده', 'wcma-badge--gray' ),
						);

						$wcma_state = $wcma_states[ $wcma_sub['status'] ] ?? array( $wcma_sub['status'], 'wcma-badge--gray' );
						?>
						<tr>
							<td>
								<?php echo esc_html( $wcma_sub['name'] ? $wcma_sub['name'] : 'بدون نام' ); ?>
								<?php if ( $wcma_sub['username'] ) : ?>
									<small dir="ltr">@<?php echo esc_html( $wcma_sub['username'] ); ?></small>
								<?php endif; ?>
							</td>
							<td dir="ltr" class="wcma-ltr"><?php echo esc_html( $wcma_sub['chat_id'] ); ?></td>
							<td dir="ltr"><?php echo esc_html( $wcma_sub['phone'] ? WCMA_Date::digits( $wcma_sub['phone'] ) : '—' ); ?></td>
							<td><span class="wcma-badge <?php echo esc_attr( $wcma_state[1] ); ?>"><?php echo esc_html( $wcma_state[0] ); ?></span></td>
							<td><?php echo esc_html( WCMA_Date::number( $wcma_sub['day_sent'] ) ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_sub['last_sent_at'] ); ?></td>
							<td class="wcma-nowrap"><?php echo WCMA_Date::html( $wcma_sub['started_at'], 'date' ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		WCMA_Admin_Fields::pagination(
			array(
				'key'     => 'spage',
				'current' => (int) ( $wcma_subs['page'] ?? 1 ),
				'pages'   => (int) ( $wcma_subs['pages'] ?? 1 ),
			)
		);
		?>
	<?php else : ?>
		<div class="wcma-empty">
			<span class="dashicons dashicons-groups"></span>
			<p>هنوز کسی ربات را شروع نکرده است. لینک ربات را در سایت و شبکه‌های اجتماعی خود بگذارید.</p>
		</div>
	<?php endif; ?>
<?php WCMA_Admin_Fields::card_end(); ?>
