<?php
/**
 * حالت سریع وب‌هوک ربات.
 *
 * برای هر پیامی که کاربر به ربات می‌دهد، وردپرس از صفر بالا می‌آید: همه‌ی
 * افزونه‌ها (صفحه‌ساز، سئو، کش، فرم‌ساز و …) و پوسته بار می‌شوند، در حالی که
 * ربات جز ووکامرس و همین افزونه به هیچ‌کدام نیازی ندارد. روی سایتی با چند ده
 * افزونه، همین بالا آمدن بیشترِ زمانِ پاسخ ربات است.
 *
 * این حالت یک فایل کوچک در mu-plugins می‌گذارد که فقط برای درخواست‌های
 * وب‌هوک ربات، فهرست افزونه‌های فعال را کوتاه می‌کند و functions.php پوسته را
 * بار نمی‌کند. بقیه‌ی سایت هیچ تغییری نمی‌بیند.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Fastlane
 */
class WCMA_Bot_Fastlane {

	/**
	 * نام فایل در mu-plugins.
	 */
	const FILE = 'wcma-bot-fastlane.php';

	/**
	 * نشانه‌ای که فایل را از آنِ همین افزونه می‌داند.
	 */
	const MARK = 'WCMA_FASTLANE_FILE';

	/**
	 * گزینه‌ی آخرین خطای نوشتن فایل.
	 */
	const ERROR = 'wcma_fastlane_error';

	/**
	 * ثبت هوک‌ها.
	 */
	public static function init() {
		// تنظیمات از هر راهی (پیشخوان یا ربات) عوض شود، فایل همگام می‌شود.
		add_action( 'update_option_' . WCMA_Settings::OPTION, array( __CLASS__, 'on_update' ), 20, 2 );
		add_action( 'add_option_' . WCMA_Settings::OPTION, array( __CLASS__, 'on_add' ), 20, 2 );

		// فهرست افزونه‌ها که عوض شود، فهرست نگه‌داشتنی‌ها هم باید تازه شود.
		add_action( 'activated_plugin', array( __CLASS__, 'on_plugins' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'on_plugins' ) );

		// پس از به‌روزرسانی افزونه، فایل با کد تازه نوشته می‌شود.
		add_action( 'admin_init', array( __CLASS__, 'maybe_refresh' ) );
	}

	/**
	 * پس از تغییر تنظیمات.
	 *
	 * @param mixed $old   مقدار پیشین.
	 * @param mixed $value مقدار تازه.
	 */
	public static function on_update( $old, $value ) {
		self::sync( is_array( $value ) ? $value : null );
	}

	/**
	 * پس از فعال یا غیرفعال شدن یک افزونه.
	 *
	 * @param string $plugin افزونه.
	 */
	public static function on_plugins( $plugin ) {
		// غیرفعال شدنِ خودِ این افزونه: فایل نباید دوباره ساخته شود.
		if ( defined( 'WCMA_BASENAME' ) && WCMA_BASENAME === $plugin && 'deactivated_plugin' === current_action() ) {
			self::remove();

			return;
		}

		self::sync();
	}

	/**
	 * پس از ساخته شدن تنظیمات.
	 *
	 * @param string $option نام.
	 * @param mixed  $value  مقدار.
	 */
	public static function on_add( $option, $value ) {
		self::sync( is_array( $value ) ? $value : null );
	}

	/**
	 * مسیر فایل.
	 *
	 * @return string
	 */
	public static function path() {
		$dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';

		return trailingslashit( $dir ) . self::FILE;
	}

	/**
	 * آیا فایلِ همین افزونه در جای خودش است؟
	 *
	 * @return bool
	 */
	public static function installed() {
		$path = self::path();

		return is_readable( $path ) && false !== strpos( (string) file_get_contents( $path ), self::MARK ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * آیا همین درخواست با حالت سریع بالا آمده است؟
	 *
	 * @return bool
	 */
	public static function active_now() {
		return defined( 'WCMA_FASTLANE' ) && WCMA_FASTLANE;
	}

	/**
	 * افزونه‌هایی که در حالت سریع هم بار می‌شوند.
	 *
	 * @param array|null $settings تنظیمات (اگر تازه ذخیره شده و هنوز در کش نیست).
	 * @return string[]
	 */
	public static function keep( $settings = null ) {
		$active = self::active_plugins();
		$keep   = array();

		if ( defined( 'WCMA_BASENAME' ) ) {
			$keep[] = WCMA_BASENAME;
		}

		// ووکامرس هر جا نصب شده باشد (حتی با نام پوشه‌ی دیگر)؛ این افزونه بی آن بار نمی‌شود.
		if ( defined( 'WC_PLUGIN_FILE' ) ) {
			$wc = plugin_basename( WC_PLUGIN_FILE );

			if ( in_array( $wc, $active, true ) ) {
				$keep[] = $wc;
			}
		}

		foreach ( $active as $plugin ) {
			$slug = strtolower( dirname( $plugin ) );

			// خودِ ووکامرس و فارسی‌ساز آن (واحد پول تومان، تاریخ شمسی سفارش‌ها).
			if ( 'woocommerce/woocommerce.php' === $plugin || in_array( $slug, array( 'persian-woocommerce', 'woocommerce-persian', 'parsi-woocommerce' ), true ) ) {
				$keep[] = $plugin;
			}
		}

		$extra = is_array( $settings ) && isset( $settings['tg_fastlane_keep'] ) ? $settings['tg_fastlane_keep'] : WCMA_Settings::get( 'tg_fastlane_keep', array() );

		foreach ( (array) $extra as $plugin ) {
			if ( in_array( $plugin, $active, true ) ) {
				$keep[] = $plugin;
			}
		}

		return array_values( array_unique( $keep ) );
	}

	/**
	 * افزونه‌های فعال سایت (بی‌اثر از خودِ حالت سریع).
	 *
	 * @return string[]
	 */
	public static function active_plugins() {
		global $wpdb;

		// در درخواستِ حالت سریع، get_option فهرست کوتاه‌شده را می‌دهد.
		$raw     = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", 'active_plugins' ) ); // phpcs:ignore WordPress.DB
		$plugins = is_string( $raw ) ? maybe_unserialize( $raw ) : array();
		$plugins = is_array( $plugins ) ? $plugins : array();

		if ( is_multisite() ) {
			$raw     = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key = %s AND site_id = %d", 'active_sitewide_plugins', get_current_network_id() ) ); // phpcs:ignore WordPress.DB
			$network = is_string( $raw ) ? maybe_unserialize( $raw ) : array();
			$plugins = array_merge( $plugins, array_keys( is_array( $network ) ? $network : array() ) );
		}

		return array_values(
			array_filter(
				array_unique( array_map( 'strval', $plugins ) ),
				static function ( $plugin ) {
					return (bool) preg_match( '#^[A-Za-z0-9._\-]+(/[A-Za-z0-9._\-]+)?\.php$#', $plugin );
				}
			)
		);
	}

	/**
	 * همگام کردن فایل با تنظیمات.
	 *
	 * @param array|null $settings تنظیمات تازه.
	 * @return bool آیا وضعیت فایل همان شد که باید؟
	 */
	public static function sync( $settings = null ) {
		$settings = is_array( $settings ) ? $settings : null;
		$want     = $settings ? ( 'yes' === ( $settings['tg_fastlane'] ?? 'no' ) ) : WCMA_Settings::is( 'tg_fastlane' );

		if ( ! $want ) {
			self::remove();
			delete_option( self::ERROR );

			return true;
		}

		$code = self::code( self::keep( $settings ) );
		$path = self::path();

		if ( is_readable( $path ) && (string) file_get_contents( $path ) === $code ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			delete_option( self::ERROR );

			return true;
		}

		// فایلی با همین نام که مال ما نیست، دست نمی‌خورد.
		if ( file_exists( $path ) && ! self::installed() ) {
			update_option( self::ERROR, 'فایلی با نام ' . self::FILE . ' در mu-plugins هست که مال این افزونه نیست.', false );

			return false;
		}

		$dir = dirname( $path );

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// اول در فایل موقت و بعد جابه‌جایی، تا درخواستِ همزمان فایلِ نیمه‌نوشته را بار نکند.
		$tmp     = $path . '.' . wp_generate_password( 6, false, false ) . '.tmp';
		$written = is_dir( $dir ) && is_writable( $dir ) && false !== @file_put_contents( $tmp, $code ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions

		if ( $written && @rename( $tmp, $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
			if ( function_exists( 'opcache_invalidate' ) ) {
				@opcache_invalidate( $path, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}

			delete_option( self::ERROR );

			return true;
		}

		if ( file_exists( $tmp ) ) {
			wp_delete_file( $tmp );
		}

		update_option( self::ERROR, 'پوشه‌ی ' . $dir . ' قابل نوشتن نیست؛ حالت سریع نصب نشد.', false );

		return false;
	}

	/**
	 * پس از به‌روزرسانی افزونه، کد فایل تازه می‌شود.
	 */
	public static function maybe_refresh() {
		if ( WCMA_Settings::is( 'tg_fastlane' ) && get_option( 'wcma_fastlane_version' ) !== WCMA_VERSION ) {
			if ( self::sync() ) {
				update_option( 'wcma_fastlane_version', WCMA_VERSION, false );
			}
		}
	}

	/**
	 * برداشتن فایل (فقط اگر مال همین افزونه باشد).
	 */
	public static function remove() {
		if ( self::installed() ) {
			@unlink( self::path() ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}

		// پس از فعال‌سازی دوباره، فایل از نو ساخته می‌شود.
		delete_option( 'wcma_fastlane_version' );
	}

	/**
	 * آخرین خطا.
	 *
	 * @return string
	 */
	public static function error() {
		return (string) get_option( self::ERROR, '' );
	}

	/**
	 * کد فایل mu-plugin.
	 *
	 * فهرست افزونه‌ها از active_plugins خودِ سایت می‌آید و با الگوی سخت
	 * بررسی شده است؛ هیچ ورودیِ دیگری در کد نوشته نمی‌شود.
	 *
	 * @param string[] $keep افزونه‌هایی که بار می‌شوند.
	 * @return string
	 */
	public static function code( array $keep ) {
		$list = var_export( array_values( $keep ), true ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions

		return <<<PHP
<?php
/**
 * Plugin Name: حالت سریع ربات — اتوماسیون بازاریابی کلاسیکا
 * Description: فقط برای پیام‌هایی که از ربات تلگرام/بله به سایت می‌رسد، افزونه‌های غیرضروری و پوسته بار نمی‌شوند. این فایل را خودِ افزونه ساخته و با خاموش کردن «حالت سریع» یا غیرفعال کردن افزونه پاک می‌شود.
 *
 * @package WCMA
 */

// WCMA_FASTLANE_FILE 1

defined( 'ABSPATH' ) || exit;

if (
	isset( \$_SERVER['REQUEST_METHOD'], \$_SERVER['REQUEST_URI'] )
	&& 'POST' === \$_SERVER['REQUEST_METHOD']
	&& ! isset( \$_GET['wcma_full'] ) // phpcs:ignore WordPress.Security.NonceVerification
	&& false !== strpos( rawurldecode( (string) \$_SERVER['REQUEST_URI'] ), '/wcma/v1/bot/' )
	&& ! defined( 'WP_ADMIN' )
) {
	\$wcma_fastlane_keep = {$list};
	\$wcma_fastlane_ok   = true;

	// اگر یکی از افزونه‌های لازم دیگر سر جایش نیست، حالت سریع کنار می‌رود تا ربات از کار نیفتد.
	foreach ( \$wcma_fastlane_keep as \$wcma_fastlane_plugin ) {
		if ( ! file_exists( WP_PLUGIN_DIR . '/' . \$wcma_fastlane_plugin ) ) {
			\$wcma_fastlane_ok = false;
		}
	}
}

if ( ! empty( \$wcma_fastlane_ok ) ) {
	define( 'WCMA_FASTLANE', true );

	add_filter(
		'option_active_plugins',
		static function ( \$plugins ) use ( \$wcma_fastlane_keep ) {
			return is_array( \$plugins ) ? array_values( array_intersect( \$plugins, \$wcma_fastlane_keep ) ) : \$plugins;
		},
		1
	);

	add_filter(
		'site_option_active_sitewide_plugins',
		static function ( \$plugins ) use ( \$wcma_fastlane_keep ) {
			return is_array( \$plugins ) ? array_intersect_key( \$plugins, array_flip( \$wcma_fastlane_keep ) ) : \$plugins;
		},
		1
	);

	// فهرست کوتاه‌شده هرگز ذخیره نمی‌شود.
	add_filter( 'pre_update_option_active_plugins', static function ( \$value, \$old ) { return \$old; }, 1, 2 );
	add_filter( 'pre_update_site_option_active_sitewide_plugins', static function ( \$value, \$old ) { return \$old; }, 1, 2 );

	/*
	 * functions.php پوسته بار نمی‌شود. مسیر پوسته فقط در همان لحظه‌ی بار شدن
	 * پوسته عوض می‌شود (پس از تعریف TEMPLATEPATH و پیش از after_setup_theme)؛
	 * بقیه‌ی درخواست مسیر واقعی را می‌بیند.
	 */
	\$wcma_fastlane_dir = static function () {
		return WP_CONTENT_DIR . '/wcma-fastlane-no-theme';
	};

	add_filter(
		'locale',
		static function ( \$locale ) use ( \$wcma_fastlane_dir ) {
			if ( defined( 'TEMPLATEPATH' ) && ! did_action( 'after_setup_theme' ) && ! has_filter( 'template_directory', \$wcma_fastlane_dir ) ) {
				add_filter( 'template_directory', \$wcma_fastlane_dir, 1 );
				add_filter( 'stylesheet_directory', \$wcma_fastlane_dir, 1 );
			}

			return \$locale;
		},
		PHP_INT_MAX
	);

	add_action(
		'after_setup_theme',
		static function () use ( \$wcma_fastlane_dir ) {
			remove_filter( 'template_directory', \$wcma_fastlane_dir, 1 );
			remove_filter( 'stylesheet_directory', \$wcma_fastlane_dir, 1 );
		},
		-1000
	);
}

PHP;
	}
}
