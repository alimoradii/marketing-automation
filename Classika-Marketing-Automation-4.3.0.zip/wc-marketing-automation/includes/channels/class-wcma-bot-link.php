<?php
/**
 * اتصال مشتری به ربات پیام‌رسان و نگهداری شناسه‌ی چت او.
 *
 * ربات‌های تلگرام، بله و روبیکا به‌صورت طراحی‌شده اجازه نمی‌دهند ربات اول شروع‌کننده‌ی
 * گفتگو باشد؛ بنابراین با شماره‌ی موبایل نمی‌توان به کاربر پیام داد. راه استاندارد این
 * است که مشتری یک بار ربات را باز کند و پس از آن شناسه‌ی چت او ذخیره شود.
 *
 * این کلاس دو مسیر برای این کار فراهم می‌کند:
 * ۱) لینک اختصاصی هر مشتری با توکن امضاشده (start deep-link).
 * ۲) دکمه‌ی «اشتراک‌گذاری شماره» که مشتری با یک لمس شماره‌اش را می‌فرستد و به حساب
 *    ووکامرس او متصل می‌شود؛ حتی اگر لینک اختصاصی نداشته باشد.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WCMA_Bot_Link
 */
class WCMA_Bot_Link {

	const NAMESPACE_REST = 'wcma/v1';

	/**
	 * راه‌اندازی هوک‌ها.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * پیام‌رسان‌هایی که اتصال تک‌به‌تک مشتری را پشتیبانی می‌کنند.
	 *
	 * ایتا از طریق سرویس ایتایار فقط ارسال به کانال را پشتیبانی می‌کند و رباتی برای
	 * گفتگوی مستقیم با مشتری در اختیار نمی‌گذارد.
	 *
	 * @return array
	 */
	public static function linkable() {
		return array(
			'telegram' => 'https://t.me/%s?start=%s',
			'bale'     => 'https://ble.ir/%s?start=%s',
			'rubika'   => 'https://rubika.ir/%s?start=%s',
		);
	}

	/**
	 * آیا این پیام‌رسان قابلیت اتصال مشتری دارد؟
	 *
	 * @param string $key کلید.
	 * @return bool
	 */
	public static function is_linkable( $key ) {
		return array_key_exists( $key, self::linkable() );
	}

	/**
	 * کلید متای شناسه‌ی چت.
	 *
	 * @param string $key پیام‌رسان.
	 * @return string
	 */
	public static function meta_key( $key ) {
		return 'wcma_' . $key . '_chat_id';
	}

	/**
	 * راز مشترک نشانی وب‌هوک.
	 *
	 * @return string
	 */
	public static function secret() {
		$secret = WCMA_Settings::get( 'bot_webhook_secret' );

		if ( ! $secret ) {
			$secret = wp_generate_password( 24, false, false );
			WCMA_Settings::update( array( 'bot_webhook_secret' => $secret ) );
		}

		return $secret;
	}

	/**
	 * نشانی وب‌هوکی که باید در پنل ربات ثبت شود.
	 *
	 * @param string $key پیام‌رسان.
	 * @return string
	 */
	public static function webhook_url( $key ) {
		return add_query_arg(
			's',
			self::secret(),
			rest_url( self::NAMESPACE_REST . '/bot/' . $key )
		);
	}

	/**
	 * ثبت مسیرهای REST.
	 */
	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_REST,
			'/bot/(?P<messenger>[a-z]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_webhook' ),
				// وب‌هوک از سوی سرور پیام‌رسان می‌آید و کاربر وردپرسی ندارد؛
				// اعتبارسنجی با راز مشترک داخل خود متد انجام می‌شود.
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * ساخت توکن امضاشده برای یک کاربر.
	 *
	 * @param int $user_id شناسه‌ی کاربر.
	 * @return string
	 */
	public static function token_for_user( $user_id ) {
		$user_id = (int) $user_id;

		return $user_id . 'x' . substr( wp_hash( 'wcma_botlink_' . $user_id ), 0, 16 );
	}

	/**
	 * بازیابی کاربر از روی توکن.
	 *
	 * @param string $token توکن.
	 * @return int شناسه‌ی کاربر یا صفر.
	 */
	public static function user_from_token( $token ) {
		$token = trim( (string) $token );

		if ( ! preg_match( '/^(\d+)x([a-f0-9]{16})$/i', $token, $m ) ) {
			return 0;
		}

		$user_id = (int) $m[1];

		if ( ! hash_equals( self::token_for_user( $user_id ), $token ) ) {
			return 0;
		}

		return get_userdata( $user_id ) ? $user_id : 0;
	}

	/**
	 * لینک اتصال مشتری به ربات.
	 *
	 * @param string $key     پیام‌رسان.
	 * @param int    $user_id شناسه‌ی کاربر.
	 * @return string
	 */
	public static function connect_url( $key, $user_id = 0 ) {
		$patterns = self::linkable();

		if ( ! isset( $patterns[ $key ] ) ) {
			return '';
		}

		$username = trim( (string) WCMA_Settings::get( $key . '_bot_username' ) );
		$username = ltrim( $username, '@' );

		if ( ! $username ) {
			return '';
		}

		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		if ( ! $user_id ) {
			return '';
		}

		return sprintf( $patterns[ $key ], rawurlencode( $username ), rawurlencode( self::token_for_user( $user_id ) ) );
	}

	/**
	 * آیا مشتری به این پیام‌رسان متصل است؟
	 *
	 * @param string $key     پیام‌رسان.
	 * @param int    $user_id شناسه‌ی کاربر.
	 * @return bool
	 */
	public static function is_connected( $key, $user_id ) {
		return (bool) get_user_meta( (int) $user_id, self::meta_key( $key ), true );
	}

	/**
	 * شمار مشتریان متصل به یک پیام‌رسان.
	 *
	 * @param string $key پیام‌رسان.
	 * @return int
	 */
	public static function connected_count( $key ) {
		global $wpdb;

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value <> ''",
				self::meta_key( $key )
			)
		);
	}

	/**
	 * پردازش وب‌هوک دریافتی از ربات.
	 *
	 * @param WP_REST_Request $request درخواست.
	 * @return WP_REST_Response
	 */
	public static function handle_webhook( $request ) {
		if ( ! defined( 'WCMA_WEBHOOK_STARTED' ) ) {
			define( 'WCMA_WEBHOOK_STARTED', microtime( true ) );
		}

		$messenger = sanitize_key( $request->get_param( 'messenger' ) );
		$secret    = (string) $request->get_param( 's' );

		// همیشه ۲۰۰ برمی‌گردانیم تا سرور پیام‌رسان درخواست را بی‌وقفه تکرار نکند.
		if ( ! hash_equals( self::secret(), $secret ) ) {
			// کلید عوض شده و نشانی ثبت‌شده در پنل ربات کهنه است.
			self::note_update( $messenger, 'کلید نشانی وب‌هوک کهنه است؛ وب‌هوک را دوباره ثبت کنید' );

			return new WP_REST_Response( array( 'ok' => false ), 200 );
		}

		if ( ! self::is_linkable( $messenger ) ) {
			self::note_update( $messenger, 'پیام‌رسان ناشناخته' );

			return new WP_REST_Response( array( 'ok' => false ), 200 );
		}

		/*
		 * فقط توکن لازم است، نه کلید «فعال بودن» کانال ارتباطی.
		 * پیش‌تر شرط is_ready() بود؛ کسی که ربات را برای منو و دنباله راه انداخته
		 * ولی تلگرام را برای ارسال گروهی روشن نکرده بود، همه‌ی پیام‌های ورودی‌اش
		 * بی‌صدا دور ریخته می‌شد: دکمه‌ها روی صفحه می‌ماندند ولی هیچ‌کدام کار نمی‌کرد.
		 */
		if ( ! WCMA_Messengers::api_base( $messenger ) && ! WCMA_Messengers::is_ready( $messenger ) ) {
			self::note_update( $messenger, 'توکن این ربات وارد نشده است' );

			return new WP_REST_Response( array( 'ok' => false ), 200 );
		}

		$update = $request->get_json_params();

		if ( ! is_array( $update ) ) {
			$update = $request->get_params();
		}

		/*
		 * درخواستِ خودآزمایی: ثابت می‌کند نشانی وب‌هوک از بیرون قابل دسترس است،
		 * کلید درست است و این متد واقعاً اجرا می‌شود. هیچ مشترکی ساخته و هیچ
		 * پیامی فرستاده نمی‌شود.
		 */
		if ( ! empty( $update['wcma_selftest'] ) ) {
			return new WP_REST_Response(
				array(
					'ok'       => true,
					'selftest' => true,
					// چند میلی‌ثانیه طول کشید تا وردپرس برای این درخواست بالا بیاید.
					'boot_ms'  => self::boot_ms(),
				),
				200
			);
		}

		$parsed = self::parse_update( $messenger, $update );

		if ( empty( $parsed['chat_id'] ) ) {
			self::note_update( $messenger, 'به‌روزرسانی بدون شناسه‌ی چت (احتمالاً از نوعی است که ربات به آن کاری ندارد)' );

			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}

		/*
		 * پیام اولی که برای همین کاربر فرستاده می‌شود، همراه پاسخ همین وب‌هوک
		 * برمی‌گردد و کارهای جانبی پس از آن انجام می‌شوند؛ پیش از هر کار کند
		 * (تماس با سرور دیگر) هم پاسخ تلگرام بسته می‌شود تا تلگرام منتظر نماند،
		 * «Connection timed out» نگیرد و پیام را دوباره نفرستد.
		 */
		WCMA_Bot_Reply::begin( $messenger, $parsed );
		WCMA_Bot_Reply::later( array( __CLASS__, 'note_update' ), array( $messenger, '' ), true );

		try {
			self::route_message( $messenger, $parsed );
		} catch ( Throwable $e ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions
			error_log( 'WCMA bot webhook: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine() );
		}

		$body = WCMA_Bot_Reply::end();

		WCMA_Bot_Speed::record( $messenger, $parsed );

		if ( WCMA_Bot_Reply::responded() ) {
			exit;
		}

		return new WP_REST_Response( $body ? $body : array( 'ok' => true ), 200 );
	}

	/**
	 * زمانِ بالا آمدن وردپرس تا رسیدن به پردازش وب‌هوک (میلی‌ثانیه).
	 *
	 * @return float
	 */
	public static function boot_ms() {
		$start = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : 0.0;

		if ( defined( 'WCMA_WEBHOOK_STARTED' ) ) {
			return round( ( WCMA_WEBHOOK_STARTED - $start ) * 1000, 1 );
		}

		return $start ? round( ( microtime( true ) - $start ) * 1000, 1 ) : 0.0;
	}

	/**
	 * ثبت آخرین به‌روزرسانیِ دریافت‌شده از پیام‌رسان.
	 *
	 * بدون این، وقتی وب‌هوک کار نمی‌کرد هیچ نشانه‌ای در پیشخوان دیده نمی‌شد؛
	 * پاسخ همیشه ۲۰۰ است و پیام‌رسان هم چیزی گزارش نمی‌دهد.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $problem   اگر پذیرفته نشد، دلیلش.
	 */
	public static function note_update( $messenger, $problem = '' ) {
		update_option(
			'wcma_bot_last_update',
			array(
				'messenger' => (string) $messenger,
				'time'      => current_time( 'mysql' ),
				'problem'   => (string) $problem,
			),
			false
		);
	}

	/**
	 * آخرین به‌روزرسانیِ دریافت‌شده.
	 *
	 * @return array
	 */
	public static function last_update() {
		$row = get_option( 'wcma_bot_last_update', array() );

		return is_array( $row ) ? $row : array();
	}

	/**
	 * استخراج شناسه‌ی چت، متن و شماره از ساختارهای مختلف به‌روزرسانی.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $update    داده‌ی خام.
	 * @return array
	 */
	public static function parse_update( $messenger, array $update ) {
		$chat_id     = '';
		$text        = '';
		$phone       = '';
		$name        = '';
		$username    = '';
		$callback    = '';
		$callback_id = '';
		$from_id     = '';
		$chat_type   = '';
		$caption     = '';
		$media       = array();
		$foreign     = false;
		$date        = 0;
		$message_id  = 0;

		if ( 'rubika' === $messenger ) {
			// ساختار روبیکا: update.chat_id و update.new_message.text
			$node = $update['update'] ?? $update;

			$chat_id = (string) ( $node['chat_id'] ?? '' );
			$message = $node['new_message'] ?? ( $node['message'] ?? array() );

			if ( is_array( $message ) ) {
				$text  = (string) ( $message['text'] ?? '' );
				$phone = (string) ( $message['contact_message']['phone_number'] ?? '' );
				$name  = trim( (string) ( $message['sender_name'] ?? ( $message['author_title'] ?? '' ) ) );

				if ( ! $chat_id ) {
					$chat_id = (string) ( $message['chat_id'] ?? '' );
				}
			}
		} elseif ( is_array( $update['callback_query'] ?? null ) ) {
			/*
			 * فشردن دکمه‌ی شیشه‌ای. چت از پیامی می‌آید که دکمه زیرش بود و
			 * فرستنده از خود فشردن؛ پیش‌تر این نوع کنار گذاشته می‌شد.
			 */
			$query       = $update['callback_query'];
			$from        = is_array( $query['from'] ?? null ) ? $query['from'] : array();
			$chat_id     = (string) ( $query['message']['chat']['id'] ?? ( $from['id'] ?? '' ) );
			$chat_type   = (string) ( $query['message']['chat']['type'] ?? '' );
			$from_id     = (string) ( $from['id'] ?? '' );
			$callback    = (string) ( $query['data'] ?? '' );
			$callback_id = (string) ( $query['id'] ?? '' );
			$message_id  = (int) ( $query['message']['message_id'] ?? 0 );
			$name        = trim( (string) ( $from['first_name'] ?? '' ) . ' ' . (string) ( $from['last_name'] ?? '' ) );
			$username    = (string) ( $from['username'] ?? '' );
		} else {
			// ساختار تلگرام و بله.
			$message = $update['message'] ?? ( $update['edited_message'] ?? array() );

			if ( is_array( $message ) ) {
				$chat_id  = (string) ( $message['chat']['id'] ?? '' );
				$text     = (string) ( $message['text'] ?? '' );
				$from     = is_array( $message['from'] ?? null ) ? $message['from'] : array();
				$name     = trim( (string) ( $from['first_name'] ?? '' ) . ' ' . (string) ( $from['last_name'] ?? '' ) );
				$username = (string) ( $from['username'] ?? '' );
				$from_id  = (string) ( $from['id'] ?? '' );

				/*
				 * فقط شماره‌ی خودِ فرستنده پذیرفته می‌شود. از منوی پیوست می‌شود
				 * کارت تماسِ هر کسی را فرستاد؛ بدون این بررسی، هر کس با فرستادن
				 * شماره‌ی دیگری به نام او شناخته می‌شد، نامِ ثبت‌شده‌ی آن شماره را
				 * می‌دید و حتی می‌توانست با شماره‌ی مدیر، مدیر ربات شود. دکمه‌ی
				 * «اشتراک‌گذاری شماره» در تلگرام و بله همیشه user_id خودِ فرستنده را دارد.
				 */
				if ( is_array( $message['contact'] ?? null ) && ! empty( $message['contact']['phone_number'] ) ) {
					$owner = (string) ( $message['contact']['user_id'] ?? '' );

					if ( '' !== $owner && '' !== $from_id && $owner === $from_id ) {
						$phone = (string) $message['contact']['phone_number'];
					} else {
						$foreign = true;
					}
				}

				$chat_type = (string) ( $message['chat']['type'] ?? '' );
				$caption   = (string) ( $message['caption'] ?? '' );
				$media     = self::parse_media( $message );
				// زمان فرستادن پیام؛ برای سنجش تأخیر رسیدنش به سایت.
				$date      = (int) ( $message['date'] ?? 0 );
			}
		}

		return array(
			'chat_id'     => trim( $chat_id ),
			'text'        => trim( $text ),
			'phone'       => trim( $phone ),
			'name'        => trim( $name ),
			'username'    => ltrim( trim( $username ), '@' ),
			'callback'    => trim( $callback ),
			'callback_id' => trim( $callback_id ),
			'from_id'     => trim( $from_id ),
			'chat_type'   => trim( $chat_type ),
			'caption'     => trim( $caption ),
			'media'       => $media,
			'foreign'     => $foreign,
			'date'        => $date,
			'message_id'  => $message_id,
		);
	}

	/**
	 * رسانه‌ی یک پیام تلگرام یا بله: نوع، شناسه‌ی فایل و (برای فایل) نام آن.
	 *
	 * شناسه‌ی فایل را خودِ همین ربات دوباره می‌تواند بفرستد؛ پس پیامی که مدیر
	 * در ربات می‌فرستد، بی‌آنکه جایی بارگذاری شود برای همه فرستاده می‌شود.
	 *
	 * @param array $message پیام.
	 * @return array
	 */
	protected static function parse_media( array $message ) {
		if ( ! empty( $message['photo'] ) && is_array( $message['photo'] ) ) {
			// تلگرام چند اندازه می‌فرستد؛ آخری بزرگ‌ترین است.
			$photo = end( $message['photo'] );

			return is_array( $photo ) && ! empty( $photo['file_id'] )
				? array( 'type' => 'photo', 'file_id' => (string) $photo['file_id'], 'name' => '', 'size' => (int) ( $photo['file_size'] ?? 0 ) )
				: array();
		}

		// پویانمایی هم کلید document دارد و همان‌جا به‌شکل فایل برداشته می‌شود.
		foreach ( array( 'video', 'audio', 'voice', 'document' ) as $type ) {
			if ( ! empty( $message[ $type ]['file_id'] ) ) {
				return array(
					'type'    => $type,
					'file_id' => (string) $message[ $type ]['file_id'],
					'name'    => (string) ( $message[ $type ]['file_name'] ?? '' ),
					'size'    => (int) ( $message[ $type ]['file_size'] ?? 0 ),
				);
			}
		}

		return array();
	}

	/**
	 * آیا پاسخِ وب‌هوک پیش از پردازش بسته شده است؟
	 *
	 * وقتی بسته شده، کار طولانی (مثل آغاز ارسال گروهی) را می‌شود همین‌جا
	 * پیش برد بی‌آنکه پیام‌رسان منتظر بماند و درخواست را دوباره بفرستد.
	 *
	 * @return bool
	 */
	public static function is_detached() {
		return WCMA_Bot_Reply::detach();
	}

	/**
	 * تصمیم‌گیری درباره‌ی پیام دریافتی.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param array  $parsed    داده‌ی استخراج‌شده.
	 */
	protected static function route_message( $messenger, array $parsed ) {
		$chat_id = $parsed['chat_id'];

		// ۰) فشردن دکمه‌ی شیشه‌ای؛ نه متن دارد نه شماره و نباید به چت‌بات برسد.
		if ( '' !== ( $parsed['callback'] ?? '' ) ) {
			/**
			 * کاربر یک دکمه‌ی شیشه‌ای را فشرد.
			 *
			 * @param string $messenger پیام‌رسان.
			 * @param array  $parsed    داده (callback و callback_id).
			 */
			do_action( 'wcma_bot_callback', $messenger, $parsed );

			return;
		}

		// کارت تماسِ کسی دیگر: شماره‌اش پذیرفته نمی‌شود.
		if ( ! empty( $parsed['foreign'] ) ) {
			$notice = 'برای ثبت شماره، لطفاً دکمه‌ی «📱 اشتراک‌گذاری شماره‌ی من» را بزنید؛ فقط شماره‌ی خودتان پذیرفته می‌شود.';

			// منوی ربات (و دکمه‌ی پنل مدیریت) جای خود می‌ماند، نه اینکه یک دکمه‌ی تنها جایش را بگیرد.
			if ( self::manager_owns( $messenger ) ) {
				$sub = WCMA_Bot_Manager::guest_sub( $messenger, $chat_id );

				WCMA_Messengers::send_content(
					$messenger,
					$chat_id,
					array(
						'text'         => $notice,
						'reply_markup' => WCMA_Bot_Manager::keyboard( true, $sub ),
					)
				);
			} else {
				self::reply( $messenger, $chat_id, $notice, true );
			}

			return;
		}

		// ۱) مشتری شماره‌اش را به اشتراک گذاشته است.
		if ( $parsed['phone'] ) {
			/**
			 * مشتری شماره‌اش را فرستاد.
			 *
			 * @param string $messenger پیام‌رسان.
			 * @param string $chat_id   شناسه‌ی چت.
			 * @param string $phone     شماره.
			 */
			do_action( 'wcma_bot_contact', $messenger, $chat_id, $parsed['phone'] );

			$user_id = self::find_user_by_phone( $parsed['phone'] );

			if ( $user_id ) {
				self::link( $messenger, $user_id, $chat_id );
				self::reply( $messenger, $chat_id, self::success_text( $messenger, $user_id ) );

				return;
			}

			/*
			 * مشترکِ ربات لازم نیست مشتری فروشگاه باشد. وقتی مدیریت ربات روشن است،
			 * خودش پیام تشکر و کیبورد را می‌فرستد؛ پیام «شماره پیدا نشد» فقط
			 * کاربر تازه را سردرگم می‌کرد.
			 */
			if ( self::manager_owns( $messenger ) ) {
				return;
			}

			self::reply(
				$messenger,
				$chat_id,
				'شماره‌ی شما در فروشگاه پیدا نشد. لطفاً همان شماره‌ای را بفرستید که با آن خرید کرده‌اید.'
			);

			return;
		}

		// ۲) شروع با توکن اختصاصی.
		if ( 0 === stripos( $parsed['text'], '/start' ) ) {
			$parts = preg_split( '/\s+/', $parsed['text'], 2 );
			$token = isset( $parts[1] ) ? trim( $parts[1] ) : '';

			if ( $token ) {
				$user_id = self::user_from_token( $token );

				if ( $user_id ) {
					self::link( $messenger, $user_id, $chat_id );
					self::reply( $messenger, $chat_id, self::success_text( $messenger, $user_id ) );
					return;
				}
			}

			/**
			 * ربات با دستور شروع باز شد.
			 *
			 * @param string $messenger پیام‌رسان.
			 * @param array  $parsed    داده‌ی پیام.
			 */
			do_action( 'wcma_bot_started', $messenger, $parsed );

			/**
			 * آیا بخش دیگری (مثل لینک دعوت مدیر) به این /start پاسخ داده است؟
			 *
			 * @param bool   $handled   پاسخ داده شده.
			 * @param string $messenger پیام‌رسان.
			 * @param array  $parsed    پیام.
			 */
			$handled = (bool) apply_filters( 'wcma_bot_start_handled', false, $messenger, $parsed );

			// اگر مدیریت ربات پیام خوش‌آمد خودش را فرستاده باشد، دوباره نمی‌فرستیم.
			if ( $handled || self::manager_owns( $messenger ) ) {
				return;
			}

			// بدون توکن معتبر: خوش‌آمد و درخواست شماره.
			$welcome = trim( (string) WCMA_Settings::get( 'chat_welcome_text', '' ) );

			if ( ! $welcome || ! WCMA_Settings::is( 'chat_enabled' ) ) {
				$welcome = sprintf(
					'به ربات %s خوش آمدید. برای دریافت پیگیری سفارش‌ها و تخفیف‌های اختصاصی، شماره‌ی موبایل خود را با دکمه‌ی زیر به اشتراک بگذارید.',
					get_bloginfo( 'name' )
				);
			}

			self::reply( $messenger, $chat_id, $welcome, true );

			return;
		}

		/**
		 * پیام‌های دیگر مشتری در ربات.
		 *
		 * @param string $messenger پیام‌رسان.
		 * @param array  $parsed    داده.
		 */
		do_action( 'wcma_bot_message', $messenger, $parsed );
	}

	/**
	 * نشانی وب‌هوک با کلیدِ پوشانده‌شده.
	 *
	 * @param string $url نشانی.
	 * @return string
	 */
	protected static function masked_url( $url ) {
		return (string) preg_replace_callback(
			'/([?&]s=)([^&]+)/',
			static function ( $m ) {
				return $m[1] . substr( $m[2], 0, 4 ) . str_repeat( '•', 8 );
			},
			(string) $url
		);
	}

	/**
	 * آزمودن نشانی وب‌هوک از بیرون، دقیقاً مثل کاری که تلگرام می‌کند.
	 *
	 * بیشتر خرابی‌ها بیرون از کد افزونه‌اند: افزونه‌های امنیتی که REST را
	 * می‌بندند، پیوندهای یکتای «ساده»، فایروال میزبان یا SSL ناقص. این آزمون
	 * همان مسیر را می‌پیماید و نتیجه را می‌گوید.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return array
	 */
	public static function self_test( $messenger ) {
		$url = self::webhook_url( $messenger );

		$response = wp_remote_post(
			$url,
			array(
				// کوتاه نگه داشته می‌شود تا مجموع دو درخواستِ عیب‌یابی، صفحه را معطل نکند.
				'timeout'   => 12,
				'sslverify' => true,
				'headers'   => array( 'Content-Type' => 'application/json' ),
				'body'      => wp_json_encode( array( 'wcma_selftest' => true ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'      => false,
				'label'   => 'آزمون نشانی وب‌هوک',
				'value'   => 'نشانی وب‌هوک از بیرون باز نشد: ' . $response->get_error_message()
					. ' — معمولاً یعنی گواهی SSL ناقص است یا میزبان اجازه‌ی درخواست به خودِ سایت را نمی‌دهد.',
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 === $code && ! empty( $body['selftest'] ) ) {
			return array(
				'ok'    => true,
				'label' => 'آزمون نشانی وب‌هوک',
				'value' => 'نشانی وب‌هوک باز است و افزونه پیام را گرفت. پس مشکل از سمت سایت نیست.',
			);
		}

		if ( 200 === $code && is_array( $body ) && array_key_exists( 'ok', $body ) ) {
			return array(
				'ok'    => false,
				'label' => 'آزمون نشانی وب‌هوک',
				'value' => 'نشانی باز شد ولی افزونه درخواست را نپذیرفت؛ کلید نشانی کهنه است. «ثبت دوباره‌ی وب‌هوک» را بزنید.',
			);
		}

		$hint = '';

		if ( in_array( $code, array( 401, 403 ), true ) ) {
			$hint = ' — یک افزونه‌ی امنیتی یا فایروال، REST API وردپرس را برای مهمان‌ها بسته است. مسیر '
				. self::NAMESPACE_REST . ' را در آن افزونه استثنا کنید.';
		} elseif ( 404 === $code ) {
			$hint = ' — REST API در دسترس نیست. در «تنظیمات ← پیوندهای یکتا» یک‌بار ذخیره کنید و مطمئن شوید حالت «ساده» نیست.';
		} elseif ( $code >= 500 ) {
			$hint = ' — خطای داخلی سرور؛ گزارش خطای میزبان را ببینید.';
		}

		return array(
			'ok'    => false,
			'label' => 'آزمون نشانی وب‌هوک',
			'value' => 'پاسخ نشانی وب‌هوک: کد ' . WCMA_Date::number( $code ) . $hint,
		);
	}

	/**
	 * بررسی سلامت وب‌هوک: هم از سمت سایت، هم از سمت پیام‌رسان.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return array
	 */
	public static function diagnose( $messenger ) {
		$messenger = sanitize_key( $messenger );
		$rows      = array();
		$def       = WCMA_Messengers::get( $messenger );

		if ( ! $def || ! self::is_linkable( $messenger ) ) {
			return array( 'ok' => false, 'rows' => array( array( 'ok' => false, 'label' => 'پیام‌رسان', 'value' => 'این پیام‌رسان وب‌هوک ندارد.' ) ) );
		}

		$token = (string) WCMA_Settings::get( $def['token_key'] );
		$url   = self::webhook_url( $messenger );

		$rows[] = array(
			'ok'    => (bool) $token,
			'label' => 'توکن ربات',
			'value' => $token ? 'وارد شده است.' : 'وارد نشده؛ در «کانال‌های ارتباطی» توکن را بگذارید.',
		);

		$rows[] = array(
			'ok'    => 0 === stripos( $url, 'https://' ),
			'label' => 'نشانی سایت',
			'value' => 0 === stripos( $url, 'https://' ) ? 'HTTPS است.' : 'باید HTTPS باشد؛ تلگرام وب‌هوک روی HTTP نمی‌پذیرد.',
		);

		$rows[] = array(
			'ok'    => true,
			'label' => 'نشانی وب‌هوک',
			// کلید پنهان می‌شود تا در اشتراک‌گذاری تصویرِ صفحه لو نرود.
			'value' => self::masked_url( $url ),
		);

		$manager = class_exists( 'WCMA_Bot_Manager' ) && WCMA_Bot_Manager::is_enabled();

		$rows[] = array(
			'ok'    => $manager,
			'label' => 'مدیریت ربات',
			'value' => $manager ? 'روشن است.' : 'خاموش است؛ منو و دنباله اجرا نمی‌شوند.',
		);

		if ( $manager ) {
			$count  = count( WCMA_Bot_Manager::menu() );
			$rows[] = array(
				'ok'    => $count > 0,
				'label' => 'دکمه‌های منو',
				'value' => $count ? WCMA_Date::number( $count ) . ' دکمه تعریف شده است.' : 'هیچ دکمه‌ای تعریف نشده است.',
			);

			$has_table = WCMA_Install::table_exists( 'wcma_bot_subs' );
			$rows[]    = array(
				'ok'    => $has_table,
				'label' => 'جدول مشترکان',
				'value' => $has_table ? 'ساخته شده است.' : 'ساخته نشده؛ از «تنظیمات عمومی» جدول‌ها را ترمیم کنید.',
			);
		}

		$last = self::last_update();

		if ( empty( $last['time'] ) ) {
			$rows[] = array(
				'ok'    => false,
				'label' => 'آخرین پیام دریافتی',
				'value' => 'تا حالا هیچ پیامی از پیام‌رسان نرسیده است. یعنی وب‌هوک ثبت نشده یا نشانی آن کهنه است.',
			);
		} else {
			$rows[] = array(
				'ok'    => empty( $last['problem'] ),
				'label' => 'آخرین پیام دریافتی',
				'value' => WCMA_Date::mysql( $last['time'] ) . ( empty( $last['problem'] ) ? ' — سالم پردازش شد.' : ' — رد شد: ' . $last['problem'] ),
			);
		}

		$rows[] = self::self_test( $messenger );

		// وضعیت از نگاه خود تلگرام.
		$info = self::webhook_info( $messenger, $token );

		if ( is_array( $info ) ) {
			$registered = (string) ( $info['url'] ?? '' );
			$same       = $registered && $registered === $url;

			$rows[] = array(
				'ok'    => $same,
				'label' => 'نشانی ثبت‌شده در تلگرام',
				'value' => $registered
					? ( $same ? 'با نشانی این سایت یکی است.' : 'با نشانی این سایت فرق دارد؛ دکمه‌ی «ثبت دوباره» را بزنید.' )
					: 'هیچ وب‌هوکی ثبت نشده است؛ دکمه‌ی «ثبت دوباره» را بزنید.',
			);

			if ( ! empty( $info['last_error_message'] ) ) {
				$error = (string) $info['last_error_message'];
				$hint  = '';

				/*
				 * این دو خطا یعنی تلگرام نشانی را دارد ولی سایت به‌موقع پاسخ
				 * نمی‌دهد — نه اینکه وب‌هوک ثبت نشده باشد.
				 */
				if ( false !== stripos( $error, 'timed out' ) || false !== stripos( $error, 'timeout' ) ) {
					$hint = ' — تلگرام نشانی را دارد ولی سایت سرِ وقت جواب نمی‌دهد.'
						. ' معمولاً یعنی میزبان کند است یا فایروالِ سرور جلوی تلگرام را می‌گیرد.'
						. ' یک‌بار «ثبت دوباره‌ی وب‌هوک» را بزنید؛ اگر باز هم تکرار شد، از میزبان بخواهید'
						. ' دسترسی ورودی به نشانی بالا و دسترسی خروجی به api.telegram.org را باز کند.';
				} elseif ( false !== stripos( $error, 'SSL' ) || false !== stripos( $error, 'certificate' ) ) {
					$hint = ' — گواهی SSL سایت برای تلگرام معتبر نیست؛ گواهی کامل (به‌همراه زنجیره) نصب کنید.';
				}

				$rows[] = array(
					'ok'    => false,
					'label' => 'آخرین خطای تلگرام',
					'value' => $error . $hint,
				);
			}

			$pending = (int) ( $info['pending_update_count'] ?? 0 );

			if ( $pending > 0 ) {
				$rows[] = array(
					'ok'    => false,
					'label' => 'پیام‌های معطل',
					'value' => WCMA_Date::number( $pending ) . ' پیام در صف تلگرام مانده و به سایت نرسیده است.'
						. ' با زدن «ثبت دوباره‌ی وب‌هوک» این صف پاک می‌شود تا ده‌ها پیام کهنه یک‌جا برای کاربران نرود.',
				);
			}
		}

		$ok = true;

		foreach ( $rows as $row ) {
			if ( empty( $row['ok'] ) ) {
				$ok = false;
			}
		}

		return array( 'ok' => $ok, 'rows' => $rows );
	}

	/**
	 * گرفتن getWebhookInfo از تلگرام یا بله.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $token     توکن.
	 * @return array|null
	 */
	public static function webhook_info( $messenger, $token = '' ) {
		if ( ! in_array( $messenger, array( 'telegram', 'bale' ), true ) || '' === WCMA_Bot_Api::base( $messenger ) ) {
			return null;
		}

		$body = WCMA_Bot_Api::call( $messenger, 'getWebhookInfo', array(), array( 'timeout' => 10, 'needs_result' => true ) );

		return ! empty( $body['ok'] ) && is_array( $body['result'] ?? null ) ? $body['result'] : null;
	}

	/**
	 * آیا مدیریت ربات، این پیام‌رسان را در دست دارد؟
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return bool
	 */
	protected static function manager_owns( $messenger ) {
		return class_exists( 'WCMA_Bot_Manager' )
			&& WCMA_Bot_Manager::is_enabled()
			&& WCMA_Bot_Manager::channel() === $messenger;
	}

	/**
	 * متن تأیید اتصال.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param int    $user_id   کاربر.
	 * @return string
	 */
	protected static function success_text( $messenger, $user_id ) {
		$user = get_userdata( $user_id );
		$name = $user ? ( $user->first_name ? $user->first_name : $user->display_name ) : '';

		return sprintf(
			'%s حساب شما با موفقیت به %s متصل شد. از این پس پیگیری سفارش‌ها و پیشنهادهای ویژه را همین‌جا دریافت می‌کنید.',
			$name ? $name . ' عزیز،' : 'سلام!',
			get_bloginfo( 'name' )
		);
	}

	/**
	 * یافتن کاربری که این شناسه‌ی چت به او متصل است.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   شناسه‌ی چت.
	 * @return int
	 */
	public static function user_for_chat( $messenger, $chat_id ) {
		global $wpdb;

		$chat_id = trim( (string) $chat_id );

		if ( '' === $chat_id || ! self::is_linkable( $messenger ) ) {
			return 0;
		}

		$user_id = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1", // phpcs:ignore WordPress.DB
				self::meta_key( $messenger ),
				$chat_id
			)
		);

		return (int) $user_id;
	}

	/**
	 * ذخیره‌ی شناسه‌ی چت برای یک کاربر.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param int    $user_id   کاربر.
	 * @param string $chat_id   شناسه‌ی چت.
	 */
	public static function link( $messenger, $user_id, $chat_id ) {
		update_user_meta( (int) $user_id, self::meta_key( $messenger ), (string) $chat_id );
		update_user_meta( (int) $user_id, 'wcma_' . $messenger . '_linked_at', current_time( 'mysql' ) );

		/**
		 * پس از اتصال مشتری به ربات.
		 *
		 * @param string $messenger پیام‌رسان.
		 * @param int    $user_id   کاربر.
		 * @param string $chat_id   شناسه‌ی چت.
		 */
		do_action( 'wcma_bot_linked', $messenger, (int) $user_id, (string) $chat_id );
	}

	/**
	 * قطع اتصال.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param int    $user_id   کاربر.
	 */
	public static function unlink( $messenger, $user_id ) {
		delete_user_meta( (int) $user_id, self::meta_key( $messenger ) );
		delete_user_meta( (int) $user_id, 'wcma_' . $messenger . '_linked_at' );
	}

	/**
	 * یافتن کاربر از روی شماره‌ی موبایل.
	 *
	 * شماره‌ها ممکن است با قالب‌های گوناگون ذخیره شده باشند، بنابراین همه‌ی حالت‌های
	 * رایج بررسی می‌شوند.
	 *
	 * @param string $phone شماره.
	 * @return int
	 */
	public static function find_user_by_phone( $phone ) {
		$normalized = WCMA_SMS_Gateways::normalize_phone( $phone );

		if ( '' === $normalized ) {
			return 0;
		}

		$national = substr( $normalized, 1 );          // 9121234567
		$variants = array_unique(
			array(
				$normalized,                            // 09121234567
				$national,                              // 9121234567
				'98' . $national,                       // 989121234567
				'+98' . $national,                      // +989121234567
				'0098' . $national,                     // 00989121234567
			)
		);

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $variants ), '%s' ) );
		$params       = array_merge( array( 'billing_phone' ), array_values( $variants ) );

		$user_id = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value IN ({$placeholders}) LIMIT 1", // phpcs:ignore WordPress.DB
				$params
			)
		);

		if ( $user_id ) {
			return $user_id;
		}

		// در نبود کاربر ثبت‌نام‌شده، از روی سفارش‌ها جستجو می‌کنیم.
		foreach ( $variants as $variant ) {
			$orders = wc_get_orders(
				array(
					'billing_phone' => $variant,
					'limit'         => 1,
					'orderby'       => 'date',
					'order'         => 'DESC',
				)
			);

			if ( ! empty( $orders[0] ) && $orders[0] instanceof WC_Order ) {
				$customer_id = $orders[0]->get_customer_id();

				if ( $customer_id ) {
					return (int) $customer_id;
				}
			}
		}

		return 0;
	}

	/**
	 * پاسخ ربات به مشتری.
	 *
	 * @param string $messenger       پیام‌رسان.
	 * @param string $chat_id         شناسه‌ی چت.
	 * @param string $text            متن.
	 * @param bool   $request_contact نمایش دکمه‌ی اشتراک شماره.
	 */
	protected static function reply( $messenger, $chat_id, $text, $request_contact = false ) {
		if ( $request_contact && in_array( $messenger, array( 'telegram', 'bale' ), true ) ) {
			self::send_with_contact_button( $messenger, $chat_id, $text );
			return;
		}

		WCMA_Messengers::send( $messenger, $chat_id, $text );
	}

	/**
	 * ارسال پیام همراه با دکمه‌ی «اشتراک‌گذاری شماره».
	 *
	 * @param string $messenger پیام‌رسان.
	 * @param string $chat_id   شناسه‌ی چت.
	 * @param string $text      متن.
	 */
	protected static function send_with_contact_button( $messenger, $chat_id, $text ) {
		WCMA_Bot_Api::call(
			$messenger,
			'sendMessage',
			array(
				'chat_id'      => $chat_id,
				'text'         => $text,
				'reply_markup' => wp_json_encode(
					array(
						'keyboard'          => array(
							array(
								array(
									'text'            => '📱 اشتراک‌گذاری شماره‌ی من',
									'request_contact' => true,
								),
							),
						),
						'resize_keyboard'   => true,
						'one_time_keyboard' => true,
					)
				),
			),
			array( 'timeout' => 25 )
		);
	}

	/**
	 * نوع به‌روزرسانی‌هایی که ربات به آن‌ها پاسخ می‌دهد.
	 *
	 * @return string[]
	 */
	public static function allowed_updates() {
		return array( 'message', 'callback_query' );
	}

	/**
	 * ثبت خودکار وب‌هوک در سرویس پیام‌رسان.
	 *
	 * @param string $messenger پیام‌رسان.
	 * @return array{success:bool,message:string}
	 */
	public static function register_webhook( $messenger ) {
		if ( ! self::is_linkable( $messenger ) ) {
			return array(
				'success' => false,
				'message' => 'این پیام‌رسان اتصال مشتری را پشتیبانی نمی‌کند.',
			);
		}

		$def   = WCMA_Messengers::get( $messenger );
		$token = WCMA_Settings::get( $def['token_key'] );

		if ( ! $token ) {
			return array(
				'success' => false,
				'message' => 'ابتدا توکن ربات را وارد و ذخیره کنید.',
			);
		}

		$url = self::webhook_url( $messenger );

		if ( 0 !== stripos( $url, 'https://' ) ) {
			return array(
				'success' => false,
				'message' => 'نشانی سایت باید HTTPS باشد؛ این پیام‌رسان‌ها وب‌هوک روی HTTP را نمی‌پذیرند.',
			);
		}

		if ( 'rubika' === $messenger ) {
			$response = wp_remote_post(
				'https://botapi.rubika.ir/v3/' . rawurlencode( $token ) . '/updateBotEndpoints',
				array(
					'timeout' => 25,
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => wp_json_encode(
						array(
							'url'  => $url,
							'type' => 'ReceiveUpdate',
						)
					),
				)
			);
		} else {
			$params = array(
				'url'                  => $url,
				/*
				 * پیام‌هایی که در نبودِ وب‌هوکِ سالم در صف تلگرام مانده‌اند
				 * کهنه‌اند؛ بدون این، همه با هم سرازیر می‌شوند و کاربر
				 * ده‌ها پیام تکراری می‌گیرد.
				 */
				'drop_pending_updates' => 'true',
				'max_connections'      => 20,
			);

			/*
			 * فقط پیام و دکمه به سایت می‌آید. ویرایش پیام، عضو شدن در گروه و …
			 * هر کدام یک بار بالا آمدنِ کامل وردپرس بود بی‌آنکه ربات کاری با آن‌ها داشته باشد.
			 */
			if ( 'telegram' === $messenger ) {
				$params['allowed_updates'] = wp_json_encode( self::allowed_updates() );
			}

			$response = WCMA_Bot_Api::call( $messenger, 'setWebhook', $params, array( 'timeout' => 25, 'needs_result' => true ) );
		}

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$body = 'rubika' === $messenger ? json_decode( wp_remote_retrieve_body( $response ), true ) : $response;

		if ( ! empty( $body['ok'] ) || 'OK' === strtoupper( (string) ( $body['status'] ?? '' ) ) ) {
			return array(
				'success' => true,
				'message' => 'وب‌هوک با موفقیت ثبت شد. حالا مشتریان می‌توانند ربات را استارت کنند.',
			);
		}

		return array(
			'success' => false,
			'message' => $body['description'] ?? ( $body['status'] ?? 'ثبت وب‌هوک ناموفق بود.' ),
		);
	}
}
