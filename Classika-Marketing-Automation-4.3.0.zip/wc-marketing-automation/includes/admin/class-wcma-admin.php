<?php
/**
 * پیشخوان مدیریت افزونه.
 *
 * @package WCMA
 */

defined( 'ABSPATH' ) || exit;

require_once WCMA_PATH . 'includes/admin/class-wcma-admin-fields.php';

/**
 * Class WCMA_Admin
 */
class WCMA_Admin {

	/**
	 * پیام‌های اعلان.
	 *
	 * @var array
	 */
	protected $notices = array();

	/**
	 * سازنده.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_init', array( $this, 'handle_post' ) );

		/*
		 * admin_notices پس از admin_head اجرا می‌شود، پس اینجا هنوز فرصت
		 * هست همه‌شان را برداریم؛ همچنین common.js وردپرس هر .notice را به
		 * زیر نخستین <h1> صفحه می‌برد و آن <h1> همان عنوان کارت افزونه است.
		 */
		add_action( 'admin_head', array( $this, 'silence_foreign_notices' ), 1 );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );

		add_action( 'wp_ajax_wcma_test_send', array( $this, 'ajax_test_send' ) );
		add_action( 'wp_ajax_wcma_ai_generate', array( $this, 'ajax_ai_generate' ) );
		add_action( 'wp_ajax_wcma_run_now', array( $this, 'ajax_run_now' ) );
		add_action( 'wp_ajax_wcma_order_action', array( $this, 'ajax_order_action' ) );
		add_action( 'wp_ajax_wcma_preview_audience', array( $this, 'ajax_preview_audience' ) );
		add_action( 'wp_ajax_wcma_register_hook', array( $this, 'ajax_register_hook' ) );
		add_action( 'wp_ajax_wcma_stock_simulate', array( $this, 'ajax_stock_simulate' ) );
		add_action( 'wp_ajax_wcma_repair_tables', array( $this, 'ajax_repair_tables' ) );
		add_action( 'wp_ajax_wcma_vip_recalc', array( $this, 'ajax_vip_recalc' ) );
		add_action( 'wp_ajax_wcma_save_display', array( $this, 'ajax_save_display' ) );
		add_action( 'wp_ajax_wcma_autosave', array( $this, 'ajax_autosave' ) );
		add_action( 'wp_ajax_wcma_crm_sync', array( $this, 'ajax_crm_sync' ) );
		add_action( 'wp_ajax_wcma_crm_save_contact', array( $this, 'ajax_crm_save_contact' ) );
		add_action( 'wp_ajax_wcma_crm_add_note', array( $this, 'ajax_crm_add_note' ) );
		add_action( 'wp_ajax_wcma_crm_task_done', array( $this, 'ajax_crm_task_done' ) );
		add_action( 'wp_ajax_wcma_crm_edit_note', array( $this, 'ajax_crm_edit_note' ) );
		add_action( 'wp_ajax_wcma_crm_delete_note', array( $this, 'ajax_crm_delete_note' ) );
		add_action( 'wp_ajax_wcma_staff_code', array( $this, 'ajax_staff_code' ) );
		add_action( 'wp_ajax_wcma_chat_thread', array( $this, 'ajax_chat_thread' ) );
		add_action( 'wp_ajax_wcma_chat_reply', array( $this, 'ajax_chat_reply' ) );
		add_action( 'wp_ajax_wcma_chat_mode', array( $this, 'ajax_chat_mode' ) );
		add_action( 'wp_ajax_wcma_chat_simulate', array( $this, 'ajax_chat_simulate' ) );
		add_action( 'wp_ajax_wcma_chat_updates', array( $this, 'ajax_chat_updates' ) );
		add_action( 'wp_ajax_wcma_chat_typing', array( $this, 'ajax_chat_typing' ) );
		add_action( 'wp_ajax_wcma_chat_upload', array( $this, 'ajax_chat_upload' ) );
		add_action( 'wp_ajax_wcma_chat_files_purge', array( $this, 'ajax_chat_files_purge' ) );
		add_action( 'wp_ajax_wcma_smtp_test', array( $this, 'ajax_smtp_test' ) );
		add_action( 'wp_ajax_wcma_bot_test', array( $this, 'ajax_bot_test' ) );
		add_action( 'wp_ajax_wcma_bot_diag', array( $this, 'ajax_bot_diag' ) );
		add_action( 'wp_ajax_wcma_bot_speed', array( $this, 'ajax_bot_speed' ) );
		add_action( 'wp_ajax_wcma_bot_message_test', array( $this, 'ajax_bot_message_test' ) );
		add_action( 'wp_ajax_wcma_bot_broadcast', array( $this, 'ajax_bot_broadcast' ) );
		add_action( 'wp_ajax_wcma_bot_broadcast_step', array( $this, 'ajax_bot_broadcast_step' ) );
		add_action( 'wp_ajax_wcma_bot_broadcast_cancel', array( $this, 'ajax_bot_broadcast_cancel' ) );
		add_action( 'wp_ajax_wcma_bot_admin_add', array( $this, 'ajax_bot_admin_add' ) );
		add_action( 'wp_ajax_wcma_bot_admin_remove', array( $this, 'ajax_bot_admin_remove' ) );
		add_action( 'wp_ajax_wcma_bot_admin_invite', array( $this, 'ajax_bot_admin_invite' ) );
		add_action( 'wp_ajax_wcma_sms_balance', array( $this, 'ajax_sms_balance' ) );
		add_action( 'wp_ajax_wcma_lm_setup', array( $this, 'ajax_lm_setup' ) );
	}

	/**
	 * فهرست تب‌ها.
	 *
	 * @return array
	 */
	public static function tabs() {
		return array(
			'dashboard'       => array(
				'title' => 'پیشخوان',
				'icon'  => 'chart-area',
				'group' => 'main',
			),
			'abandoned'       => array(
				'title' => 'سبد رها شده',
				'icon'  => 'cart',
				'group' => 'workflows',
			),
			'review-reminder' => array(
				'title' => 'یادآوری ثبت نظر',
				'icon'  => 'format-status',
				'group' => 'workflows',
			),
			'review-reward'   => array(
				'title' => 'پاداش ثبت نظر',
				'icon'  => 'awards',
				'group' => 'workflows',
			),
			'winback'         => array(
				'title' => 'خرید مجدد',
				'icon'  => 'update',
				'group' => 'workflows',
			),
			'stock'           => array(
				'title' => 'هشدار موجودی',
				'icon'  => 'archive',
				'group' => 'workflows',
			),
			'vip'             => array(
				'title' => 'باشگاه مشتریان',
				'icon'  => 'star-filled',
				'group' => 'workflows',
			),
			'extras'          => array(
				'title' => 'تولد و وضعیت سفارش',
				'icon'  => 'buddicons-activity',
				'group' => 'workflows',
			),
			'crm'             => array(
				'title' => 'پرونده‌ی مشتریان (CRM)',
				'icon'  => 'id-alt',
				'group' => 'crm',
			),
			'chat'            => array(
				'title' => 'گفتگو و چت‌بات',
				'icon'  => 'format-chat',
				'group' => 'crm',
			),
			'app'             => array(
				'title' => 'دسترسی اپلیکیشن',
				'icon'  => 'smartphone',
				'group' => 'crm',
			),
			'leadmagnet'      => array(
				'title' => 'لید مگنت',
				'icon'  => 'megaphone',
				'group' => 'crm',
			),
			'bot'             => array(
				'title' => 'مدیریت ربات تلگرام',
				'icon'  => 'admin-comments',
				'group' => 'crm',
			),
			'tickets'         => array(
				'title' => 'تیکت‌های پشتیبانی',
				'icon'  => 'sos',
				'group' => 'crm',
			),
			'panel'           => array(
				'title' => 'پنل کاربری',
				'icon'  => 'admin-users',
				'group' => 'crm',
			),
			'campaigns'       => array(
				'title' => 'کمپین‌ها',
				'icon'  => 'megaphone',
				'group' => 'tools',
			),
			'ai'              => array(
				'title' => 'محتوای هوشمند (AI)',
				'icon'  => 'lightbulb',
				'group' => 'tools',
			),
			'orders'          => array(
				'title' => 'سفارش‌های اخیر',
				'icon'  => 'list-view',
				'group' => 'tools',
			),
			'reports'         => array(
				'title' => 'گزارش‌ها',
				'icon'  => 'chart-bar',
				'group' => 'tools',
			),
			'test'            => array(
				'title' => 'تست ارسال',
				'icon'  => 'email-alt',
				'group' => 'tools',
			),
			'sms'             => array(
				'title' => 'کانال‌های ارتباطی',
				'icon'  => 'smartphone',
				'group' => 'tools',
			),
			'general'         => array(
				'title'    => 'تنظیمات عمومی',
				'icon'     => 'admin-generic',
				'group'    => 'tools',
				'children' => self::settings_sections(),
			),
		);
	}

	/**
	 * زیرفهرست «تنظیمات عمومی».
	 *
	 * تنظیمات هر بخش در برگه‌ی خود همان بخش می‌ماند — جای درستش همان‌جاست —
	 * ولی از اینجا هم یک‌جا در دسترس است و مستقیم به همان کارت می‌رود.
	 *
	 * @return array
	 */
	public static function settings_sections() {
		return array(
			array(
				'title'  => 'تنظیمات کلی',
				'icon'   => 'admin-generic',
				'tab'    => 'general',
				'anchor' => '',
			),
			array(
				'title'  => 'گفتگو و چت آنلاین',
				'icon'   => 'format-chat',
				'tab'    => 'chat',
				'anchor' => 'chat-widget',
			),
			array(
				'title'  => 'فایل و پیام صوتی گفتگو',
				'icon'   => 'paperclip',
				'tab'    => 'chat',
				'anchor' => 'chat-files',
			),
			array(
				'title'  => 'پاسخ خودکار چت‌بات',
				'icon'   => 'admin-comments',
				'tab'    => 'chat',
				'anchor' => 'chat-rules',
			),
			array(
				'title'  => 'پنل پیامک',
				'icon'   => 'smartphone',
				'tab'    => 'sms',
				'anchor' => 'sms-panel',
			),
			array(
				'title'  => 'ایمیل و سرور SMTP',
				'icon'   => 'email-alt',
				'tab'    => 'sms',
				'anchor' => 'smtp',
			),
			array(
				'title'  => 'ربات تلگرام',
				'icon'   => 'admin-comments',
				'tab'    => 'bot',
				'anchor' => 'bot-status',
			),
			array(
				'title'  => 'لید مگنت',
				'icon'   => 'megaphone',
				'tab'    => 'leadmagnet',
				'anchor' => 'lm-telegram',
			),
			array(
				'title'  => 'پرونده‌ی مشتریان (CRM)',
				'icon'   => 'id-alt',
				'tab'    => 'general',
				'anchor' => 'crm',
			),
			array(
				'title'  => 'یادآوری پیگیری‌ها',
				'icon'   => 'bell',
				'tab'    => 'general',
				'anchor' => 'followups',
			),
			array(
				'title'  => 'دسترسی اپلیکیشن',
				'icon'   => 'smartphone',
				'tab'    => 'app',
				'anchor' => 'app-console',
			),
			array(
				'title'  => 'کنسول کارکنان در ربات',
				'icon'   => 'admin-comments',
				'tab'    => 'app',
				'anchor' => 'staff-bot',
			),
			array(
				'title'  => 'پنل کاربری و ورود با کد',
				'icon'   => 'admin-users',
				'tab'    => 'panel',
				'anchor' => 'panel',
			),
			array(
				'title'  => 'کیف پول',
				'icon'   => 'money-alt',
				'tab'    => 'panel',
				'anchor' => 'wallet',
			),
			array(
				'title'  => 'تیکت پشتیبانی',
				'icon'   => 'sos',
				'tab'    => 'panel',
				'anchor' => 'tickets',
			),
		);
	}

	/**
	 * اندازه‌های ممکن برای هر صفحه از یک فهرست.
	 *
	 * @return array
	 */
	public static function page_sizes() {
		return array( 20, 30, 40, 50, 100 );
	}

	/**
	 * اندازه‌ی صفحه‌ی درخواست‌شده.
	 *
	 * فقط اندازه‌های تعریف‌شده پذیرفته می‌شوند؛ وگرنه یک نشانی دستکاری‌شده
	 * می‌توانست کل جدول را در یک درخواست بیرون بکشد.
	 *
	 * @param string $key نام پارامتر در نشانی.
	 * @return int
	 */
	public static function per_page( $key ) {
		$sizes = self::page_sizes();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$want = isset( $_GET[ $key ] ) ? (int) $_GET[ $key ] : 0;

		return in_array( $want, $sizes, true ) ? $want : $sizes[0];
	}

	/**
	 * شناسه‌ی HTML یک کارت تنظیمات.
	 *
	 * @param string $key کلید.
	 * @return string
	 */
	public static function section_id( $key ) {
		return 'wcma-sec-' . sanitize_html_class( (string) $key );
	}

	/**
	 * نشانی یک زیربخش تنظیمات.
	 *
	 * @param array $child زیربخش.
	 * @return string
	 */
	public static function section_url( array $child ) {
		$url = self::tab_url( $child['tab'] );

		return empty( $child['anchor'] ) ? $url : $url . '#' . self::section_id( $child['anchor'] );
	}

	/**
	 * گروه‌های منو.
	 *
	 * @return array
	 */
	public static function groups() {
		return array(
			'main'      => 'پیکربندی',
			'crm'       => 'مشتریان و گفتگو',
			'workflows' => 'ورک‌فلوهای خودکار',
			'tools'     => 'ابزارها و گزارش',
		);
	}

	/**
	 * ثبت منو.
	 */
	public function register_menu() {
		add_menu_page(
			'اتوماسیون بازاریابی کلاسیکا',
			'اتوماسیون بازاریابی کلاسیکا',
			'manage_woocommerce',
			'wcma',
			array( $this, 'render_page' ),
			'dashicons-megaphone',
			56
		);

		add_submenu_page( 'wcma', 'پیشخوان اتوماسیون بازاریابی کلاسیکا', 'پیشخوان', 'manage_woocommerce', 'wcma', array( $this, 'render_page' ) );
		add_submenu_page( 'wcma', 'مدیریت ارتباط با مشتریان (CRM)', 'مدیریت ارتباط با مشتریان(CRM)', 'manage_woocommerce', 'admin.php?page=wcma&tab=crm' );
		add_submenu_page( 'wcma', 'کمپین‌ها', 'کمپین‌ها', 'manage_woocommerce', 'admin.php?page=wcma&tab=campaigns' );
		add_submenu_page( 'wcma', 'ورک‌فلوهای خودکار', 'ورک‌فلوها', 'manage_woocommerce', 'admin.php?page=wcma&tab=abandoned' );
		add_submenu_page( 'wcma', 'گفتگو و چت‌بات', 'گفتگو', 'manage_woocommerce', 'admin.php?page=wcma&tab=chat' );
		add_submenu_page( 'wcma', 'لید مگنت', 'لید مگنت', 'manage_woocommerce', 'admin.php?page=wcma&tab=leadmagnet' );
		add_submenu_page( 'wcma', 'مدیریت ربات تلگرام', 'ربات تلگرام', 'manage_woocommerce', 'admin.php?page=wcma&tab=bot' );
		add_submenu_page( 'wcma', 'دسترسی اپلیکیشن', 'دسترسی اپلیکیشن', 'manage_woocommerce', 'admin.php?page=wcma&tab=app' );
		add_submenu_page( 'wcma', 'تیکت‌های پشتیبانی', 'تیکت‌ها', 'manage_woocommerce', 'admin.php?page=wcma&tab=tickets' );
		add_submenu_page( 'wcma', 'پنل کاربری', 'پنل کاربری', 'manage_woocommerce', 'admin.php?page=wcma&tab=panel' );
		add_submenu_page( 'wcma', 'گزارش‌ها', 'گزارش‌ها', 'manage_woocommerce', 'admin.php?page=wcma&tab=reports' );
		add_submenu_page( 'wcma', 'کانال‌های ارتباطی', 'کانال‌های ارتباطی', 'manage_woocommerce', 'admin.php?page=wcma&tab=sms' );
		add_submenu_page( 'wcma', 'تنظیمات عمومی', 'تنظیمات عمومی', 'manage_woocommerce', 'admin.php?page=wcma&tab=general' );
	}

	/**
	 * آیا روی یکی از صفحه‌های خود افزونه هستیم؟
	 *
	 * @return bool
	 */
	public static function is_plugin_screen() {
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();

			if ( $screen && is_object( $screen ) && false !== strpos( (string) $screen->id, 'wcma' ) ) {
				return true;
			}
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		return 0 === strpos( $page, 'wcma' );
	}

	/**
	 * افزودن کلاس به <body> صفحه‌های افزونه.
	 *
	 * @param string $classes کلاس‌های موجود.
	 * @return string
	 */
	public function body_class( $classes ) {
		return self::is_plugin_screen() ? trim( $classes . ' wcma-screen' ) : $classes;
	}

	/**
	 * برداشتن اعلان‌های بی‌ربط از صفحه‌های افزونه.
	 *
	 * افزونه‌ها و پوسته‌ها اعلان‌هایشان را روی هر صفحه‌ی پیشخوان چاپ می‌کنند و
	 * وردپرس آن‌ها را زیر نخستین <h1> صفحه می‌نشاند — که اینجا داخل کارت
	 * عنوان افزونه است. اعلان خود افزونه از این راه نمی‌آید (در همان قالب
	 * صفحه چاپ می‌شود)، پس چیزی از دست نمی‌رود.
	 */
	public function silence_foreign_notices() {
		if ( ! self::is_plugin_screen() ) {
			return;
		}

		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
		remove_all_actions( 'network_admin_notices' );
		remove_all_actions( 'user_admin_notices' );
	}

	/**
	 * بارگذاری استایل و اسکریپت.
	 *
	 * @param string $hook صفحه‌ی جاری.
	 */
	public function enqueue_assets( $hook ) {
		$hook = (string) $hook;

		// صفحه‌ی پروفایل کاربر هم فیلد تاریخ تولد دارد و به تقویم شمسی نیاز دارد.
		if ( in_array( $hook, array( 'profile.php', 'user-edit.php' ), true ) ) {
			self::enqueue_datepicker();

			return;
		}

		if ( false === strpos( $hook, 'wcma' ) ) {
			return;
		}

		wp_enqueue_style( 'wcma-font', WCMA_URL . 'assets/css/font.css', array(), WCMA_Plugin::asset_version( 'assets/css/font.css' ) );
		wp_enqueue_style( 'wcma-admin', WCMA_URL . 'assets/css/admin.css', array( 'wcma-font' ), WCMA_Plugin::asset_version( 'assets/css/admin.css' ) );
		wp_enqueue_script( 'wcma-admin', WCMA_URL . 'assets/js/admin.js', array( 'jquery' ), WCMA_Plugin::asset_version( 'assets/js/admin.js' ), true );

		self::enqueue_datepicker();

		wp_enqueue_editor();
		wp_enqueue_media();
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'woocommerce_admin_styles' );

		wp_localize_script(
			'wcma-admin',
			'wcmaAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wcma_admin' ),
				// امکان پیوست، تا رابط دکمه‌ای را نشان ندهد که سرور رد می‌کند.
				'files'   => array(
					'on'     => WCMA_Chat_Files::enabled(),
					'voice'  => WCMA_Chat_Files::voice_enabled(),
					'accept' => WCMA_Chat_Files::accept_attr(),
					'max'    => WCMA_Chat_Files::max_bytes(),
					'label'  => WCMA_Chat_Files::human_size( WCMA_Chat_Files::max_bytes() ),
				),
				'i18n'    => array(
					'sending'   => 'در حال ارسال...',
					'generating'=> 'در حال تولید محتوا...',
					'confirm'   => 'آیا مطمئن هستید؟',
					'error'     => 'خطایی رخ داد. دوباره تلاش کنید.',
				),
			)
		);
	}

	/**
	 * تبدیل زمان واردشده‌ی کمپین (شمسی یا میلادی) به قالب دیتابیس.
	 *
	 * @param string $value ورودی.
	 * @return string|null
	 */
	protected static function parse_schedule( $value ) {
		$parsed = WCMA_Date::parse( $value, 'datetime' );

		return $parsed ? $parsed . ':00' : null;
	}

	/**
	 * بارگذاری تقویم شمسی، هرجا که فیلد تاریخ نمایش داده می‌شود.
	 */
	public static function enqueue_datepicker() {
		wp_enqueue_style( 'wcma-font', WCMA_URL . 'assets/css/font.css', array(), WCMA_Plugin::asset_version( 'assets/css/font.css' ) );
		wp_enqueue_style( 'wcma-jdate', WCMA_URL . 'assets/css/jalali-datepicker.css', array( 'wcma-font' ), WCMA_Plugin::asset_version( 'assets/css/jalali-datepicker.css' ) );
		wp_enqueue_script( 'wcma-jdate', WCMA_URL . 'assets/js/jalali-datepicker.js', array(), WCMA_Plugin::asset_version( 'assets/js/jalali-datepicker.js' ), true );
		wp_localize_script( 'wcma-jdate', 'wcmaDatePicker', WCMA_Date::picker_config() );
	}

	/**
	 * تب جاری.
	 *
	 * @return string
	 */
	public function current_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
		$tabs = self::tabs();

		return isset( $tabs[ $tab ] ) ? $tab : 'dashboard';
	}

	/**
	 * آدرس یک تب.
	 *
	 * @param string $tab تب.
	 * @return string
	 */
	public static function tab_url( $tab ) {
		return admin_url( 'admin.php?page=wcma&tab=' . $tab );
	}

	/**
	 * رندر صفحه.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'شما دسترسی لازم برای مشاهده‌ی این صفحه را ندارید.' );
		}

		$tab      = $this->current_tab();
		$tabs     = self::tabs();
		$groups   = self::groups();
		$notices  = $this->notices;
		$settings = WCMA_Settings::all();

		include WCMA_PATH . 'includes/admin/views/layout.php';
	}

	/**
	 * پردازش فرم‌های ارسالی.
	 */
	public function handle_post() {
		// گزارش رسمی چاپی با پیوند ساده باز می‌شود.
		if ( isset( $_GET['wcma_report'] ) && 'print' === $_GET['wcma_report'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				return;
			}

			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';

			if ( wp_verify_nonce( $nonce, 'wcma_report_print' ) ) {
				$this->render_report();
			}
		}

		// خروجی CSV پرونده‌ی مشتریان با پیوند ساده (GET) گرفته می‌شود.
		if ( isset( $_GET['wcma_export'] ) && 'crm' === $_GET['wcma_export'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				return;
			}

			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';

			if ( ! wp_verify_nonce( $nonce, 'wcma_export_crm' ) ) {
				return;
			}

			$this->export_contacts();
		}

		// فایل نمونه‌ی ورود مخاطبان.
		if ( isset( $_GET['wcma_export'] ) && 'contacts_template' === $_GET['wcma_export'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				return;
			}

			$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';

			if ( wp_verify_nonce( $nonce, 'wcma_contacts_template' ) ) {
				$this->contacts_template();
			}
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST['wcma_action'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$action = sanitize_key( wp_unslash( $_POST['wcma_action'] ) );

		if ( ! isset( $_POST['wcma_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcma_nonce'] ) ), 'wcma_save' ) ) {
			$this->notices[] = array( 'error', 'اعتبارسنجی امنیتی ناموفق بود. دوباره تلاش کنید.' );
			return;
		}

		switch ( $action ) {
			case 'save_settings':
				$this->save_settings();
				break;
			case 'save_campaign':
				$this->save_campaign();
				break;
			case 'campaign_start':
				$this->campaign_action( 'start' );
				break;
			case 'campaign_pause':
				$this->campaign_action( 'pause' );
				break;
			case 'campaign_delete':
				$this->campaign_action( 'delete' );
				break;
			case 'ticket_reply':
				$this->ticket_reply();
				break;
			case 'ticket_status':
				$this->ticket_status();
				break;
			case 'wallet_adjust':
				$this->wallet_adjust();
				break;
			case 'clear_logs':
				WCMA_Logger::clear_all();
				$this->notices[] = array( 'success', 'همه‌ی گزارش‌ها پاک شد.' );
				break;
			case 'export_logs':
				$this->export_logs();
				break;
			case 'export_settings':
				$this->export_settings();
				break;
			case 'import_settings':
				$this->import_settings();
				break;
			case 'app_user_save':
				$this->app_user_save();
				break;
			case 'app_user_delete':
				$this->app_user_delete();
				break;
			case 'app_user_revoke':
				$this->app_user_revoke();
				break;
			case 'contacts_import':
				$this->contacts_import();
				break;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * ورود مخاطبان از فایل اکسل یا CSV.
	 */
	protected function contacts_import() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
		$file = $_FILES['wcma_contacts_file'] ?? null;

		if ( ! is_array( $file ) || empty( $file['tmp_name'] ) || UPLOAD_ERR_OK !== (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			$too_big = in_array( (int) ( $file['error'] ?? 0 ), array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true );

			$this->notices[] = array( 'error', $too_big ? 'حجم فایل از سقف بارگذاری سرور بیشتر است.' : 'فایلی انتخاب نشده است.' );

			return;
		}

		$tmp = (string) $file['tmp_name'];

		if ( ! is_uploaded_file( $tmp ) ) {
			$this->notices[] = array( 'error', 'فایل بارگذاری‌شده معتبر نیست.' );

			return;
		}

		$report = WCMA_Contacts_Import::import_file(
			$tmp,
			sanitize_file_name( wp_unslash( (string) $file['name'] ) ),
			array(
				'tag'       => isset( $_POST['wcma_import_tag'] ) ? sanitize_text_field( wp_unslash( $_POST['wcma_import_tag'] ) ) : WCMA_Contacts_Import::DEFAULT_TAG,
				'overwrite' => ! empty( $_POST['wcma_import_overwrite'] ),
			)
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

		if ( ! empty( $report['success'] ) ) {
			WCMA_Contacts_Import::last_report( $report );
		}

		$this->notices[] = array( empty( $report['success'] ) ? 'error' : 'success', (string) $report['message'] );
	}

	/**
	 * دانلود فایل نمونه‌ی ورود مخاطبان.
	 */
	protected function contacts_template() {
		$file = WCMA_Contacts_Import::template();

		nocache_headers();
		header( 'Content-Type: ' . $file['mime'] );
		header( 'Content-Disposition: attachment; filename="' . $file['name'] . '"' );
		header( 'Content-Length: ' . strlen( $file['body'] ) );

		echo $file['body']; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/**
	 * ذخیره‌ی تنظیمات ارسالی.
	 */
	/**
	 * ساخت یا ویرایش حساب کنسول.
	 */
	protected function app_user_save() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$result = WCMA_App_Users::save(
			array(
				'id'       => isset( $_POST['account_id'] ) ? (int) $_POST['account_id'] : 0,
				'username' => isset( $_POST['account_username'] ) ? sanitize_text_field( wp_unslash( $_POST['account_username'] ) ) : '',
				'name'     => isset( $_POST['account_name'] ) ? sanitize_text_field( wp_unslash( $_POST['account_name'] ) ) : '',
				'role'     => isset( $_POST['account_role'] ) ? sanitize_key( wp_unslash( $_POST['account_role'] ) ) : 'agent',
				'active'   => ! empty( $_POST['account_active'] ),
				// رمز عمداً پاک‌سازی نمی‌شود؛ هر نویسه‌ای مجاز است و درهم‌سازی می‌شود.
				'password' => isset( $_POST['account_password'] ) ? (string) wp_unslash( $_POST['account_password'] ) : '',
			)
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$this->notices[] = array( empty( $result['success'] ) ? 'error' : 'success', $result['message'] );
	}

	/**
	 * حذف حساب کنسول.
	 */
	protected function app_user_delete() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['account_id'] ) ? (int) $_POST['account_id'] : 0;

		if ( WCMA_App_Users::delete( $id ) ) {
			$this->notices[] = array( 'success', 'حساب حذف شد.' );
		}
	}

	/**
	 * خروج همه‌ی دستگاه‌های یک حساب.
	 */
	protected function app_user_revoke() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['account_id'] ) ? (int) $_POST['account_id'] : 0;

		$count = WCMA_App_Users::revoke_all( $id );

		$this->notices[] = array( 'success', WCMA_Date::number( $count ) . ' دستگاه از کنسول خارج شد.' );
	}

	protected function save_settings() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$raw = isset( $_POST['wcma'] ) ? wp_unslash( $_POST['wcma'] ) : array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! is_array( $raw ) ) {
			return;
		}

		$clean    = array();
		$defaults = WCMA_Settings::defaults();

		foreach ( $raw as $key => $value ) {
			$key = sanitize_key( $key );

			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}

			$clean[ $key ] = WCMA_Admin_Fields::sanitize_value( $key, $value );
		}

		/*
		 * رمز سرور ایمیل در صفحه چاپ نمی‌شود، پس کادرش همیشه خالی می‌آید.
		 * خالی یعنی «دست نزن»، وگرنه هر بار ذخیره‌ی تنظیمات رمز را پاک می‌کرد.
		 */
		if ( isset( $clean['smtp_pass'] ) && '' === $clean['smtp_pass'] ) {
			unset( $clean['smtp_pass'] );
		}

		// چک‌باکس‌های تیک‌نخورده در POST نمی‌آیند؛ آن‌ها را «no» کنیم.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$submitted = isset( $_POST['wcma_checkboxes'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['wcma_checkboxes'] ) ) : array();

		foreach ( $submitted as $checkbox ) {
			if ( array_key_exists( $checkbox, $defaults ) && ! isset( $clean[ $checkbox ] ) ) {
				$clean[ $checkbox ] = 'no';
			}
		}

		$stale = $this->drop_stale_bot_keys( $raw, $clean );

		WCMA_Settings::update( $clean );
		WCMA_Install::schedule_events();

		$this->notices[] = array( 'success', 'تنظیمات با موفقیت ذخیره شد.' );

		if ( $stale ) {
			$this->notices[] = array( 'warning', 'بخش‌های ربات (منو، پیام‌ها، متن‌ها و دنباله) ذخیره نشدند: در این فاصله یک مدیر از خود تلگرام ربات را ویرایش کرده بود و این برگه نسخه‌ی کهنه را نشان می‌داد. برگه تازه شد؛ دوباره تغییر دهید.' );
		}
	}

	/**
	 * ذخیره‌ی کمپین.
	 */
	protected function save_campaign() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$data = array(
			'id'           => isset( $_POST['campaign_id'] ) ? (int) $_POST['campaign_id'] : 0,
			'title'        => isset( $_POST['campaign_title'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_title'] ) ) : '',
			'channel'      => isset( $_POST['campaign_channel'] ) ? sanitize_key( wp_unslash( $_POST['campaign_channel'] ) ) : 'email',
			'subject'      => isset( $_POST['campaign_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_subject'] ) ) : '',
			'content'      => isset( $_POST['campaign_content'] ) ? wp_kses_post( wp_unslash( $_POST['campaign_content'] ) ) : '',
			'scheduled_at' => isset( $_POST['campaign_scheduled_at'] ) && $_POST['campaign_scheduled_at'] ? self::parse_schedule( sanitize_text_field( wp_unslash( $_POST['campaign_scheduled_at'] ) ) ) : null,
			'status'       => 'draft',
			'audience'     => array(
				'type'          => isset( $_POST['audience_type'] ) ? sanitize_key( wp_unslash( $_POST['audience_type'] ) ) : 'all_customers',
				'product_ids'   => isset( $_POST['audience_product_ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['audience_product_ids'] ) ) : array(),
				'category_ids'  => isset( $_POST['audience_category_ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['audience_category_ids'] ) ) : array(),
				'min_spend'     => isset( $_POST['audience_min_spend'] ) ? (float) $_POST['audience_min_spend'] : 0,
				'inactive_days' => isset( $_POST['audience_inactive_days'] ) ? (int) $_POST['audience_inactive_days'] : 60,
				'manual_list'   => isset( $_POST['audience_manual_list'] ) ? sanitize_textarea_field( wp_unslash( $_POST['audience_manual_list'] ) ) : '',
			),
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === $data['title'] ) {
			$this->notices[] = array( 'error', 'عنوان کمپین را وارد کنید.' );
			return;
		}

		$id = WCMA_Campaigns::save( $data );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_POST['campaign_send_now'] ) ) {
			$result          = WCMA_Campaigns::start( $id );
			$this->notices[] = array( $result['success'] ? 'success' : 'error', $result['message'] );
			return;
		}

		$this->notices[] = array( 'success', 'کمپین ذخیره شد.' );
	}

	/**
	 * عملیات روی کمپین.
	 *
	 * @param string $op عملیات.
	 */
	protected function campaign_action( $op ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['campaign_id'] ) ? (int) $_POST['campaign_id'] : 0;

		if ( ! $id ) {
			return;
		}

		switch ( $op ) {
			case 'start':
				$result          = WCMA_Campaigns::start( $id );
				$this->notices[] = array( $result['success'] ? 'success' : 'error', $result['message'] );
				break;
			case 'pause':
				WCMA_Campaigns::set_status( $id, 'paused' );
				WCMA_Queue::cancel_for_object( 'campaign', $id );
				$this->notices[] = array( 'success', 'کمپین متوقف شد و ارسال‌های باقی‌مانده لغو گردید.' );
				break;
			case 'delete':
				WCMA_Campaigns::delete( $id );
				$this->notices[] = array( 'success', 'کمپین حذف شد.' );
				break;
		}
	}

	/**
	 * خروجی همه‌ی تنظیمات به‌شکل یک فایل، برای پشتیبان‌گیری پیش از تغییر میزبان یا نصب دوباره.
	 */
	protected function export_settings() {
		$payload = array(
			'plugin'     => 'wc-marketing-automation',
			'version'    => WCMA_VERSION,
			'exported_at' => current_time( 'mysql' ),
			'site'       => home_url(),
			'settings'   => WCMA_Settings::all(),
		);

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=wcma-settings-' . gmdate( 'Y-m-d' ) . '.json' );

		echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ); // phpcs:ignore WordPress.Security.EscapeOutput

		exit;
	}

	/**
	 * بازگرداندن تنظیمات از فایل پشتیبان.
	 */
	protected function import_settings() {
		if ( empty( $_FILES['wcma_settings_file']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$this->notices[] = array( 'error', 'فایلی انتخاب نشده است.' );

			return;
		}

		$tmp = sanitize_text_field( $_FILES['wcma_settings_file']['tmp_name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( ! is_uploaded_file( $tmp ) ) {
			$this->notices[] = array( 'error', 'فایل بارگذاری‌شده معتبر نیست.' );

			return;
		}

		$size = (int) ( $_FILES['wcma_settings_file']['size'] ?? 0 ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( $size > 512 * KB_IN_BYTES ) {
			$this->notices[] = array( 'error', 'فایل بیش از حد بزرگ است.' );

			return;
		}

		$raw  = file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = json_decode( (string) $raw, true );

		if ( ! is_array( $data ) || empty( $data['settings'] ) || ! is_array( $data['settings'] ) ) {
			$this->notices[] = array( 'error', 'محتوای فایل قابل خواندن نیست. فایلی را انتخاب کنید که از همین افزونه گرفته شده باشد.' );

			return;
		}

		// فقط کلیدهای شناخته‌شده و پس از پاک‌سازی وارد می‌شوند.
		$defaults = WCMA_Settings::defaults();
		$clean    = array();

		foreach ( $data['settings'] as $key => $value ) {
			$key = sanitize_key( $key );

			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}

			$clean[ $key ] = WCMA_Admin_Fields::sanitize_value( $key, $value );
		}

		if ( ! $clean ) {
			$this->notices[] = array( 'error', 'هیچ تنظیم شناخته‌شده‌ای در فایل نبود.' );

			return;
		}

		WCMA_Settings::update( $clean );
		WCMA_Install::schedule_events();

		$this->notices[] = array(
			'success',
			sprintf( '%s تنظیم از فایل بازگردانده شد.', WCMA_Date::number( count( $clean ) ) ),
		);
	}

	/**
	 * گزارش رسمی مدیریت، آماده‌ی چاپ و ذخیره به‌شکل PDF.
	 */
	protected function render_report() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$from = isset( $_GET['f_from'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_GET['f_from'] ) ) ) : '';
		$to   = isset( $_GET['f_to'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_GET['f_to'] ) ) ) : '';
		$auto = ! empty( $_GET['auto'] );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$wcma_report     = WCMA_Logger::range_stats( $from, $to );
		$wcma_labels     = self::workflow_labels();
		$wcma_channels   = WCMA_Sender::channels();
		$wcma_back       = self::tab_url( 'reports' );
		$wcma_auto_print = $auto;
		$wcma_logo       = '';

		// نشان سایت، اگر در سفارشی‌سازی وردپرس تعیین شده باشد.
		$logo_id = (int) get_theme_mod( 'custom_logo' );

		if ( $logo_id ) {
			$logo = wp_get_attachment_image_src( $logo_id, 'medium' );

			if ( $logo ) {
				$wcma_logo = $logo[0];
			}
		}

		nocache_headers();

		include WCMA_PATH . 'includes/admin/views/report-print.php';

		exit;
	}

	/**
	 * نام فارسی ورک‌فلوها، یک‌جا برای گزارش‌ها و خروجی‌ها.
	 *
	 * @return array
	 */
	public static function workflow_labels() {
		return array(
			'abandoned_cart'  => 'سبد رها شده',
			'review_reminder' => 'یادآوری ثبت نظر',
			'review_reward'   => 'پاداش ثبت نظر',
			'winback'         => 'خرید مجدد',
			'stock_alert'     => 'هشدار موجودی',
			'vip_club'        => 'باشگاه مشتریان',
			'birthday'        => 'تبریک تولد',
			'order_status'    => 'وضعیت سفارش',
			'campaign'        => 'کمپین',
			'chatbot'         => 'چت‌بات',
			'livechat'        => 'چت آنلاین',
			'crm'             => 'پرونده‌ی مشتریان',
			'bot_sequence'    => 'دنباله‌ی ربات',
			'bot_menu'        => 'دکمه‌ی ربات',
			'bot_broadcast'   => 'ارسال گروهی ربات',
			'lead_magnet'     => 'لید مگنت',
			'test'            => 'تست',
		);
	}

	/**
	 * خروجی CSV پرونده‌ی مشتریان، با همان فیلترهای صفحه.
	 */
	protected function export_contacts() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$args = array(
			'search'   => isset( $_GET['c_search'] ) ? sanitize_text_field( wp_unslash( $_GET['c_search'] ) ) : '',
			'stage'    => isset( $_GET['c_stage'] ) ? sanitize_key( wp_unslash( $_GET['c_stage'] ) ) : '',
			'tag'      => isset( $_GET['c_tag'] ) ? sanitize_text_field( wp_unslash( $_GET['c_tag'] ) ) : '',
			'source'   => isset( $_GET['c_source'] ) ? sanitize_key( wp_unslash( $_GET['c_source'] ) ) : '',
			'followup' => isset( $_GET['c_followup'] ) ? sanitize_key( wp_unslash( $_GET['c_followup'] ) ) : '',
		);
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=wcma-contacts-' . gmdate( 'Y-m-d' ) . '.csv' );

		echo WCMA_CRM::to_csv( $args ); // phpcs:ignore WordPress.Security.EscapeOutput

		exit;
	}

	/**
	 * خروجی CSV گزارش‌ها.
	 */
	protected function export_logs() {
		// همان فیلترهای صفحه‌ی گزارش‌ها اعمال می‌شود تا خروجی با آنچه می‌بینید یکی باشد.
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$args = array(
			'per_page' => 10000,
			'workflow' => isset( $_POST['f_workflow'] ) ? sanitize_key( wp_unslash( $_POST['f_workflow'] ) ) : '',
			'channel'  => isset( $_POST['f_channel'] ) ? sanitize_key( wp_unslash( $_POST['f_channel'] ) ) : '',
			'status'   => isset( $_POST['f_status'] ) ? sanitize_key( wp_unslash( $_POST['f_status'] ) ) : '',
			'search'   => isset( $_POST['f_search'] ) ? sanitize_text_field( wp_unslash( $_POST['f_search'] ) ) : '',
			'from'     => isset( $_POST['f_from'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_POST['f_from'] ) ) ) : '',
			'to'       => isset( $_POST['f_to'] ) ? WCMA_Date::parse( sanitize_text_field( wp_unslash( $_POST['f_to'] ) ) ) : '',
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$result   = WCMA_Logger::query( $args );
		$report   = WCMA_Logger::range_stats( $args['from'], $args['to'] );
		$labels   = self::workflow_labels();
		$channels = WCMA_Sender::channels();
		$statuses = array( 'sent' => 'موفق', 'failed' => 'ناموفق', 'queued' => 'در صف' );

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=wcma-report-' . gmdate( 'Y-m-d' ) . '.csv' );

		$output = fopen( 'php://output', 'w' );
		fwrite( $output, "\xEF\xBB\xBF" ); // BOM برای نمایش درست فارسی در اکسل.

		// سربرگ گزارش، تا فایل به‌تنهایی هم گویا باشد.
		fputcsv( $output, array( 'گزارش عملکرد اتوماسیون بازاریابی کلاسیکا' ) );
		fputcsv( $output, array( 'فروشگاه', get_bloginfo( 'name' ) ) );
		fputcsv( $output, array( 'تاریخ تهیه', WCMA_Date::format( null, 'datetime_long' ) ) );
		fputcsv(
			$output,
			array(
				'بازه',
				( $args['from'] ? WCMA_Date::mysql( $args['from'] . ' 00:00:00', 'date', '' ) : 'ابتدا' ) .
				' تا ' .
				( $args['to'] ? WCMA_Date::mysql( $args['to'] . ' 00:00:00', 'date', '' ) : 'امروز' ),
			)
		);
		fputcsv( $output, array() );

		fputcsv( $output, array( 'خلاصه' ) );
		fputcsv( $output, array( 'ارسال موفق', $report['sent'] ) );
		fputcsv( $output, array( 'ارسال ناموفق', $report['failed'] ) );
		fputcsv( $output, array( 'خرید در پی پیام', $report['conversions'] ) );
		fputcsv( $output, array( 'درآمد منتسب', $report['revenue'] ) );
		fputcsv( $output, array() );

		fputcsv( $output, array( 'به تفکیک ورک‌فلو' ) );
		fputcsv( $output, array( 'ورک‌فلو', 'ارسال موفق', 'ناموفق', 'خرید', 'نرخ تبدیل (٪)', 'درآمد' ) );

		foreach ( $report['by_workflow'] as $key => $row ) {
			$rate = $row['sent'] > 0 ? round( ( $row['conversions'] / $row['sent'] ) * 100, 1 ) : 0;

			fputcsv( $output, array( $labels[ $key ] ?? $key, $row['sent'], $row['failed'], $row['conversions'], $rate, $row['revenue'] ) );
		}

		fputcsv( $output, array() );
		fputcsv( $output, array( 'ریز ارسال‌ها' ) );
		fputcsv( $output, array( 'شناسه', 'ورک‌فلو', 'مرحله', 'کانال', 'گیرنده', 'موضوع', 'وضعیت', 'کد تخفیف', 'تبدیل', 'درآمد', 'خطا', 'تاریخ' ) );

		foreach ( $result['items'] as $row ) {
			fputcsv(
				$output,
				array(
					$row['id'],
					$labels[ $row['workflow'] ] ?? $row['workflow'],
					$row['step'],
					$channels[ $row['channel'] ] ?? $row['channel'],
					$row['recipient'],
					$row['subject'],
					$statuses[ $row['status'] ] ?? $row['status'],
					$row['coupon_code'],
					$row['converted'] ? 'بله' : 'خیر',
					$row['revenue'],
					$row['error_message'],
					WCMA_Date::mysql( $row['created_at'], 'datetime', '' ),
				)
			);
		}

		fclose( $output );
		exit;
	}

	/**
	 * ایجکس: تست ارسال پیامک/ایمیل.
	 */
	public function ajax_test_send() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : 'email';
		$to      = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';
		$message = isset( $_POST['message'] ) ? wp_kses_post( wp_unslash( $_POST['message'] ) ) : '';
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : 'پیام آزمایشی';

		if ( '' === $to ) {
			wp_send_json_error( array( 'message' => 'گیرنده را وارد کنید.' ) );
		}

		// اعمال اطلاعات ذخیره‌نشده‌ی فرم تنظیمات فقط برای همین درخواست.
		$this->apply_test_overrides();

		$context = array(
			'vars' => array(
				'first_name'   => 'کاربر',
				'coupon_code'  => 'TEST1234',
				'coupon_expiry'=> date_i18n( 'Y/m/d', time() + WEEK_IN_SECONDS ),
				'order_number' => '1001',
				'order_total'  => trim( wp_strip_all_tags( wc_price( 250000 ) ) ),
			),
		);

		if ( '' === trim( wp_strip_all_tags( $message ) ) ) {
			$message = sprintf(
				'این یک پیام آزمایشی از %s است. اگر آن را دریافت کردید، تنظیمات شما درست است.',
				get_bloginfo( 'name' )
			);
		}

		$message = WCMA_Placeholders::replace( $message, $context );

		if ( 'sms' === $channel ) {
			$result = WCMA_Sender::send_sms(
				array(
					'phone' => $to,
					'text'  => WCMA_Placeholders::to_plain( $message ),
					'html'  => '',
				)
			);
		} elseif ( WCMA_Messengers::is_messenger( $channel ) ) {
			$result = WCMA_Sender::send_messenger(
				$channel,
				array(
					'text'             => WCMA_Placeholders::to_plain( $message ),
					'html'             => $message,
					'phone'            => $to,
					'user_id'          => 0,
					'messenger_target' => 'whatsapp' === $channel ? WCMA_Messengers::to_international( $to ) : $to,
				)
			);
		} else {
			$result = WCMA_Sender::send_email(
				array(
					'email'   => $to,
					'subject' => $subject,
					'html'    => $message,
					'text'    => '',
				)
			);
		}

		WCMA_Logger::add(
			array(
				'workflow'      => 'test',
				'step'          => 'manual',
				'channel'       => $channel,
				'object_type'   => 'test',
				'recipient'     => $to,
				'subject'       => $subject,
				'message'       => $message,
				'status'        => $result['success'] ? 'sent' : 'failed',
				'error_message' => $result['success'] ? '' : $result['message'],
			)
		);

		if ( $result['success'] ) {
			wp_send_json_success( array( 'message' => $result['message'] ) );
		}

		wp_send_json_error( array( 'message' => $result['message'] ) );
	}

	/**
	 * کلیدهایی که هنگام تست اتصال می‌توان موقتاً از فرم گرفت.
	 *
	 * @return array
	 */
	protected function test_override_keys() {
		return array(
			'sms_enabled',
			'sms_gateway',
			'sms_api_key',
			'sms_username',
			'sms_password',
			'sms_sender',
			'sms_ippanel_api',
			'sms_custom_url',
			'sms_custom_method',
			'sms_custom_body',
			'sms_custom_headers',
			'telegram_enabled',
			'telegram_bot_token',
			'telegram_channel_id',
			'telegram_bot_username',
			'bale_enabled',
			'bale_bot_token',
			'bale_chat_id',
			'bale_bot_username',
			'eitaa_enabled',
			'eitaa_token',
			'eitaa_chat_id',
			'rubika_enabled',
			'rubika_token',
			'rubika_chat_id',
			'rubika_bot_username',
			'whatsapp_enabled',
			'whatsapp_token',
			'whatsapp_phone_id',
			'whatsapp_api_version',
			'whatsapp_template',
			'whatsapp_template_lang',
			'from_name',
			'from_email',
			'sms_fallback_email',
			'smtp_enabled',
			'smtp_host',
			'smtp_port',
			'smtp_secure',
			'smtp_auth',
			'smtp_user',
			'smtp_pass',
			'smtp_from_email',
			'smtp_from_name',
			'smtp_force_from',
			'smtp_debug',
		);
	}

	/**
	 * ایجکس: آزمودن ارسال ایمیل با SMTP.
	 */
	public function ajax_smtp_test() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';

		// تنظیم ذخیره‌نشده‌ی همین فرم اعمال می‌شود تا نیازی به ذخیره نباشد.
		$this->apply_test_overrides();

		$result = WCMA_SMTP::send_test( $to );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error(
				array(
					'message' => $result['message'],
					'debug'   => array_slice( (array) ( $result['debug'] ?? array() ), -12 ),
				)
			);
		}

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}

	/**
	 * خواندن مقادیر ذخیره‌نشده‌ی فرم و اعمال آن‌ها به‌صورت موقت.
	 *
	 * این کار باعث می‌شود مدیر بتواند بلافاصله پس از وارد کردن کلید API و پیش از
	 * زدن دکمه‌ی ذخیره، اتصال را بیازماید. هیچ مقداری در دیتابیس نوشته نمی‌شود.
	 */
	protected function apply_test_overrides() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$posted = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();

		if ( ! is_array( $posted ) ) {
			return;
		}

		$allowed   = $this->test_override_keys();
		$overrides = array();

		foreach ( $posted as $key => $value ) {
			$key = sanitize_key( $key );

			if ( ! in_array( $key, $allowed, true ) ) {
				continue;
			}

			/*
			 * کادر رمز ایمیل همیشه خالی رندر می‌شود؛ اگر همین خالی را بنشانیم،
			 * آزمون با رمز تهی اجرا می‌شد و همیشه شکست می‌خورد.
			 */
			if ( 'smtp_pass' === $key && '' === trim( (string) $value ) ) {
				continue;
			}

			$overrides[ $key ] = WCMA_Admin_Fields::sanitize_value( $key, $value );
		}

		if ( $overrides ) {
			WCMA_Settings::set_runtime_overrides( $overrides );
		}
	}

	/**
	 * ایجکس: تولید محتوا با هوش مصنوعی.
	 */
	public function ajax_ai_generate() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$template = isset( $_POST['template'] ) ? sanitize_key( wp_unslash( $_POST['template'] ) ) : 'campaign_email';
		$channel  = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : 'email';
		$brief    = isset( $_POST['brief'] ) ? sanitize_textarea_field( wp_unslash( $_POST['brief'] ) ) : '';

		$result = WCMA_AI::generate(
			$template,
			array(
				'channel' => $channel,
				'brief'   => $brief,
			)
		);

		if ( $result['success'] ) {
			wp_send_json_success( array( 'content' => $result['content'] ) );
		}

		wp_send_json_error( array( 'message' => $result['message'] ) );
	}

	/**
	 * ایجکس: اجرای فوری کارگر.
	 */
	public function ajax_run_now() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$result = WCMA_Cron::run_now();
		wp_send_json_success( array( 'message' => $result['message'] ) );
	}

	/**
	 * ایجکس: عملیات روی یک سفارش از تب سفارش‌های اخیر.
	 */
	public function ajax_order_action() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
		$op       = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';

		if ( ! $order_id ) {
			wp_send_json_error( array( 'message' => 'سفارش نامعتبر است.' ) );
		}

		$plugin = WCMA_Plugin::instance();

		if ( 'remind' === $op ) {
			$workflow = $plugin->get_workflow( 'abandoned_cart' );
			if ( $workflow ) {
				$result = $workflow->send_now_for_order( $order_id );
				if ( $result['success'] ) {
					wp_send_json_success( array( 'message' => $result['message'] ) );
				}
				wp_send_json_error( array( 'message' => $result['message'] ) );
			}
		}

		if ( 'stock' === $op ) {
			$workflow = $plugin->get_workflow( 'stock_alert' );

			if ( $workflow ) {
				$result = $workflow->send_now_for_product( $order_id );

				if ( $result['success'] ) {
					wp_send_json_success( array( 'message' => $result['message'] ) );
				}

				wp_send_json_error( array( 'message' => $result['message'] ) );
			}
		}

		if ( 'review' === $op ) {
			$workflow = $plugin->get_workflow( 'review_reminder' );
			if ( $workflow ) {
				$sent = $workflow->send_for_order( $order_id );
				if ( $sent ) {
					wp_send_json_success( array( 'message' => 'یادآوری ثبت نظر ارسال شد.' ) );
				}
				wp_send_json_error( array( 'message' => 'ارسال ناموفق بود؛ گزارش‌ها را بررسی کنید.' ) );
			}
		}

		wp_send_json_error( array( 'message' => 'عملیات نامعتبر است.' ) );
	}

	/**
	 * ایجکس: ثبت خودکار وب‌هوک ربات.
	 */
	public function ajax_register_hook() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$messenger = isset( $_POST['messenger'] ) ? sanitize_key( wp_unslash( $_POST['messenger'] ) ) : '';

		// اجازه‌ی استفاده از توکن ذخیره‌نشده‌ی فرم.
		$this->apply_test_overrides();

		$result = WCMA_Bot_Link::register_webhook( $messenger );

		if ( $result['success'] ) {
			wp_send_json_success( array( 'message' => $result['message'] ) );
		}

		wp_send_json_error( array( 'message' => $result['message'] ) );
	}

	/**
	 * ایجکس: بازمحاسبه‌ی سطوح باشگاه مشتریان.
	 */
	/**
	 * ذخیره‌ی لحظه‌ای یک فرم تنظیمات، بدون زدن دکمه‌ی ذخیره.
	 *
	 * همان مسیر پاک‌سازی فرم عادی را می‌رود، پس هیچ اعتبارسنجی‌ای دور زده نمی‌شود.
	 */
	public function ajax_autosave() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$raw = isset( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! is_array( $raw ) ) {
			wp_send_json_error( array( 'message' => 'داده‌ای برای ذخیره نبود.' ) );
		}

		$defaults = WCMA_Settings::defaults();
		$clean    = array();

		foreach ( $raw as $key => $value ) {
			$key = sanitize_key( $key );

			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}

			$clean[ $key ] = WCMA_Admin_Fields::sanitize_value( $key, $value );
		}

		// چک‌باکس‌های تیک‌نخورده در داده نمی‌آیند؛ آن‌ها را «no» می‌کنیم.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$boxes = isset( $_POST['checkboxes'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['checkboxes'] ) ) : array();

		foreach ( $boxes as $box ) {
			if ( array_key_exists( $box, $defaults ) && ! isset( $clean[ $box ] ) ) {
				$clean[ $box ] = 'no';
			}
		}

		$stale = $this->drop_stale_bot_keys( $raw, $clean );

		if ( ! $clean && ! $stale ) {
			wp_send_json_error( array( 'message' => 'تنظیم شناخته‌شده‌ای در این فرم نبود.' ) );
		}

		if ( $clean ) {
			WCMA_Settings::update( $clean );
			WCMA_Install::schedule_events();
		}

		wp_send_json_success(
			array(
				'message' => 'ذخیره شد',
				'count'   => count( $clean ),
				'time'    => WCMA_Date::format( null, 'time' ),
				'stale'   => $stale,
			)
		);
	}

	/**
	 * ذخیره‌ی بی‌درنگ تنظیم تقویم و ارقام، بدون نیاز به زدن دکمه‌ی ذخیره.
	 */
	public function ajax_save_display() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$allowed = array(
			'date_calendar' => array( 'jalali', 'gregorian' ),
			'date_digits'   => array( 'fa', 'en' ),
		);

		$changed = array();

		foreach ( $allowed as $key => $values ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );

			if ( ! in_array( $value, $values, true ) ) {
				wp_send_json_error( array( 'message' => 'مقدار نامعتبر است.' ) );
			}

			$changed[ $key ] = $value;
		}

		if ( ! $changed ) {
			wp_send_json_error( array( 'message' => 'چیزی برای ذخیره نبود.' ) );
		}

		WCMA_Settings::update( $changed );

		wp_send_json_success(
			array(
				'message' => 'تنظیم تاریخ ذخیره شد.',
				'changed' => $changed,
				'sample'  => WCMA_Date::format( null, 'datetime_long' ),
			)
		);
	}

	/**
	 * دسترسی و نانس مشترک همه‌ی درخواست‌های ایجکس.
	 */
	protected function guard() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}
	}

	/**
	 * همگام‌سازی پرونده‌ی مشتریان با سفارش‌ها و سبدها.
	 */
	public function ajax_crm_sync() {
		$this->guard();

		$result = WCMA_CRM::sync();

		if ( empty( $result['ok'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success( $result );
	}

	/**
	 * ویرایش یک پرونده.
	 */
	public function ajax_crm_save_contact() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['contact_id'] ) ? (int) $_POST['contact_id'] : 0;

		if ( ! $id ) {
			wp_send_json_error( array( 'message' => 'پرونده مشخص نشده است.' ) );
		}

		$contact = WCMA_CRM::get( $id );

		if ( ! $contact ) {
			wp_send_json_error( array( 'message' => 'پرونده پیدا نشد.' ) );
		}

		// فیلد پیگیری حالا ساعت هم دارد، پس ساعتِ واردشده نگه داشته می‌شود.
		$followup = isset( $_POST['next_followup_at'] )
			? WCMA_CRM::clean_due( sanitize_text_field( wp_unslash( $_POST['next_followup_at'] ) ) )
			: '';

		$data = array(
			'email'            => $contact['email'],
			'phone'            => $contact['phone'],
			'first_name'       => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
			'last_name'        => isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '',
			'company'          => isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '',
			'city'             => isset( $_POST['city'] ) ? sanitize_text_field( wp_unslash( $_POST['city'] ) ) : '',
			'stage'            => isset( $_POST['stage'] ) ? sanitize_key( wp_unslash( $_POST['stage'] ) ) : '',
			'tags'             => isset( $_POST['tags'] ) ? sanitize_text_field( wp_unslash( $_POST['tags'] ) ) : '',
			'owner_id'         => isset( $_POST['owner_id'] ) ? (int) $_POST['owner_id'] : 0,
			'followup_note'    => isset( $_POST['followup_note'] ) ? sanitize_text_field( wp_unslash( $_POST['followup_note'] ) ) : '',
			'next_followup_at' => $followup,
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$stages = WCMA_CRM::stages();

		if ( $data['stage'] && ! isset( $stages[ $data['stage'] ] ) ) {
			wp_send_json_error( array( 'message' => 'مرحله‌ی انتخابی معتبر نیست.' ) );
		}

		if ( $data['stage'] && $data['stage'] !== $contact['stage'] ) {
			WCMA_CRM::add_note(
				$id,
				sprintf( 'مرحله از «%s» به «%s» تغییر کرد.', WCMA_CRM::stage_label( $contact['stage'] ), WCMA_CRM::stage_label( $data['stage'] ) ),
				'stage'
			);
		}

		WCMA_CRM::upsert( $data );

		wp_send_json_success(
			array(
				'message'  => 'پرونده ذخیره شد.',
				'followup' => $followup ? WCMA_Date::mysql( $followup . ' 09:00:00', 'date' ) : '',
			)
		);
	}

	/**
	 * افزودن یادداشت به پرونده.
	 */
	public function ajax_crm_add_note() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id   = isset( $_POST['contact_id'] ) ? (int) $_POST['contact_id'] : 0;
		$body = isset( $_POST['body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['body'] ) ) : '';
		$type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : 'note';
		$due  = isset( $_POST['due'] ) ? sanitize_text_field( wp_unslash( $_POST['due'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$note_id = WCMA_CRM::add_note( $id, $body, $type, 0, '', $due );

		if ( ! $note_id ) {
			wp_send_json_error( array( 'message' => 'یادداشت ثبت نشد؛ متن را بررسی کنید.' ) );
		}

		$user  = wp_get_current_user();
		$clean = WCMA_CRM::clean_due( $due );

		wp_send_json_success(
			array(
				'message' => $clean ? 'یادداشت ثبت شد و یادآوری‌اش تنظیم شد.' : 'یادداشت ثبت شد.',
				'note'    => array(
					'type'   => WCMA_CRM::note_types()[ $type ] ?? 'یادداشت',
					'body'   => $body,
					'author' => $user ? $user->display_name : '',
					'date'   => WCMA_Date::format( null, 'datetime' ),
					'icon'   => WCMA_CRM::note_icon( $type ),
					'due'    => $clean ? WCMA_Date::mysql( $clean, 'datetime' ) : '',
				),
			)
		);
	}

	/**
	 * پاسخ پشتیبانی به یک تیکت.
	 */
	protected function ticket_reply() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$ticket_id = isset( $_POST['ticket_id'] ) ? (int) $_POST['ticket_id'] : 0;
		$body      = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( $_POST['body'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$done = WCMA_Tickets::reply(
			$ticket_id,
			array( 'body' => $body, 'author' => 'staff' ),
			get_current_user_id()
		);

		$this->notices[] = array(
			empty( $done['success'] ) ? 'error' : 'success',
			(string) $done['message'],
		);
	}

	/**
	 * بستن یا باز کردن تیکت.
	 */
	protected function ticket_status() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$ticket_id = isset( $_POST['ticket_id'] ) ? (int) $_POST['ticket_id'] : 0;
		$status    = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'open';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( WCMA_Tickets::set_status( $ticket_id, $status ) ) {
			$this->notices[] = array( 'success', 'closed' === $status ? 'تیکت بسته شد.' : 'تیکت دوباره باز شد.' );

			return;
		}

		$this->notices[] = array( 'error', 'تیکت پیدا نشد.' );
	}

	/**
	 * کم و زیاد کردن دستی کیف پول.
	 */
	protected function wallet_adjust() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$user_id = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
		$raw     = isset( $_POST['amount'] ) ? WCMA_Date::to_latin_digits( sanitize_text_field( wp_unslash( $_POST['amount'] ) ) ) : '';
		$note    = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';
		$way     = isset( $_POST['way'] ) ? sanitize_key( wp_unslash( $_POST['way'] ) ) : 'credit';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$amount = (float) preg_replace( '/[^0-9.]/', '', $raw );
		$actor  = wp_get_current_user();

		$done = 'debit' === $way
			? WCMA_Wallet::debit( $user_id, $amount, 'manual', array( 'note' => $note, 'actor' => $actor->display_name ) )
			: WCMA_Wallet::credit( $user_id, $amount, 'manual', array( 'note' => $note, 'actor' => $actor->display_name ) );

		$this->notices[] = array(
			empty( $done['success'] ) ? 'error' : 'success',
			empty( $done['success'] )
				? (string) $done['message']
				: sprintf( 'انجام شد. موجودی تازه: %s', WCMA_Date::price_text( (float) $done['balance'] ) ),
		);
	}

	/**
	 * ویرایش یک یادداشت در گردش کار.
	 */
	public function ajax_crm_edit_note() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$note_id = isset( $_POST['note_id'] ) ? (int) $_POST['note_id'] : 0;
		$body    = isset( $_POST['body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['body'] ) ) : '';
		$type    = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';
		$due     = isset( $_POST['due'] ) ? sanitize_text_field( wp_unslash( $_POST['due'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( '' === trim( $body ) ) {
			wp_send_json_error( array( 'message' => 'متن یادداشت خالی است.' ) );
		}

		if ( ! WCMA_CRM::update_note( $note_id, $body, $type, $due ) ) {
			wp_send_json_error( array( 'message' => 'این یادداشت پیدا نشد.' ) );
		}

		$note  = WCMA_CRM::note( $note_id );
		$clean = $note ? (string) ( $note['due_at'] ?? '' ) : '';

		wp_send_json_success(
			array(
				'message' => 'یادداشت ویرایش شد.',
				'note'    => array(
					'body' => $body,
					'type' => WCMA_CRM::note_types()[ $note['type'] ?? 'note' ] ?? 'یادداشت',
					'icon' => WCMA_CRM::note_icon( $note['type'] ?? 'note' ),
					'due'  => $clean ? WCMA_Date::html( $clean, 'datetime' ) : '',
					'done' => $note ? ! empty( $note['done'] ) : false,
				),
			)
		);
	}

	/**
	 * حذف یک یادداشت از گردش کار.
	 */
	public function ajax_crm_delete_note() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$note_id = isset( $_POST['note_id'] ) ? (int) $_POST['note_id'] : 0;

		if ( ! WCMA_CRM::delete_note( $note_id ) ) {
			wp_send_json_error( array( 'message' => 'این یادداشت پیدا نشد.' ) );
		}

		wp_send_json_success( array( 'message' => 'یادداشت حذف شد.' ) );
	}

	/**
	 * ساخت کد اتصال ربات برای یک حساب کنسول.
	 */
	public function ajax_staff_code() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$drop = isset( $_POST['unlink'] ) && '1' === (string) $_POST['unlink'];

		if ( ! $id ) {
			wp_send_json_error( array( 'message' => 'حساب مشخص نیست.' ) );
		}

		if ( $drop ) {
			WCMA_Bot_Staff::unlink( $id );

			wp_send_json_success( array( 'message' => 'اتصال این حساب به ربات باز شد.', 'unlinked' => true ) );
		}

		$code = WCMA_Bot_Staff::new_code( $id );

		if ( ! $code ) {
			wp_send_json_error( array( 'message' => 'حساب پیدا نشد.' ) );
		}

		/*
		 * کد به حساب گره می‌خورد، نه به پیام‌رسان؛ همکار می‌تواند آن را در
		 * هر رباتی که سایت روشن کرده بزند. پس پیوند مستقیم برای همه‌شان
		 * ساخته می‌شود.
		 */
		$links = array();

		foreach ( WCMA_Bot_Staff::channels() as $key => $label ) {
			$url = WCMA_Bot_Staff::deep_link( $code, $key );

			if ( $url ) {
				$links[] = array( 'label' => $label, 'url' => $url );
			}
		}

		wp_send_json_success(
			array(
				'message' => 'کد ساخته شد؛ تا ۲۴ ساعت معتبر است.',
				'code'    => $code,
				'links'   => $links,
				'command' => '/start ' . WCMA_Bot_Staff::START_PREFIX . $code,
			)
		);
	}

	/**
	 * بستن یا باز کردن یک کار پیگیری.
	 */
	public function ajax_crm_task_done() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$note_id = isset( $_POST['note_id'] ) ? (int) $_POST['note_id'] : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$done = ! isset( $_POST['done'] ) || '0' !== (string) $_POST['done'];

		if ( ! $note_id || ! WCMA_CRM::mark_done( $note_id, $done ) ) {
			wp_send_json_error( array( 'message' => 'این کار پیدا نشد.' ) );
		}

		wp_send_json_success(
			array(
				'message' => $done ? 'کار بسته شد.' : 'کار به فهرست برگشت.',
				'left'    => WCMA_CRM::due_count(),
			)
		);
	}

	/**
	 * خواندن یک گفتگو.
	 */
	/**
	 * ارسال آزمایشی یک روز از دنباله‌ی ربات.
	 */
	public function ajax_bot_test() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$chat = isset( $_POST['chat'] ) ? sanitize_text_field( wp_unslash( $_POST['chat'] ) ) : '';
		$day  = isset( $_POST['day'] ) ? (int) $_POST['day'] : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$result = WCMA_Bot_Manager::test_day( $chat, $day );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}

	/**
	 * ارسال آزمایشی یک پیام آماده به یک شناسه‌ی چت.
	 */
	public function ajax_bot_message_test() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$chat    = isset( $_POST['chat'] ) ? sanitize_text_field( wp_unslash( $_POST['chat'] ) ) : '';
		$message = isset( $_POST['message'] ) ? sanitize_key( wp_unslash( $_POST['message'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$result = WCMA_Bot_Manager::test_message( $chat, $message );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}

	/**
	 * آغاز (یا زمان‌بندی) ارسال گروهی یک پیام آماده.
	 */
	public function ajax_bot_broadcast() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$message  = isset( $_POST['message'] ) ? sanitize_key( wp_unslash( $_POST['message'] ) ) : '';
		$audience = isset( $_POST['audience'] ) ? sanitize_key( wp_unslash( $_POST['audience'] ) ) : '';
		$when     = isset( $_POST['start_at'] ) ? sanitize_text_field( wp_unslash( $_POST['start_at'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$start_at = '' !== $when ? self::parse_schedule( $when ) : '';

		if ( '' !== $when && ! $start_at ) {
			wp_send_json_error( array( 'message' => 'زمان ارسال خوانده نشد.' ) );
		}

		$result = WCMA_Bot_Broadcast::start(
			array(
				'message'  => $message,
				'audience' => $audience,
				'start_at' => (string) $start_at,
			)
		);

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		$row = WCMA_Bot_Broadcast::get( $result['id'] );

		wp_send_json_success(
			array(
				'message' => $result['message'],
				'job'     => $row ? WCMA_Bot_Broadcast::view( $row ) : null,
			)
		);
	}

	/**
	 * فرستادن تکه‌ی بعدیِ یک ارسال گروهی و گزارش پیشرفت آن.
	 */
	public function ajax_bot_broadcast_step() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;

		WCMA_Bot_Broadcast::process( 12, 30 );

		$row = WCMA_Bot_Broadcast::get( $id );

		if ( ! $row ) {
			wp_send_json_error( array( 'message' => 'این ارسال پیدا نشد.' ) );
		}

		wp_send_json_success( array( 'job' => WCMA_Bot_Broadcast::view( $row ) ) );
	}

	/**
	 * لغو یک ارسال گروهی.
	 */
	public function ajax_bot_broadcast_cancel() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;

		if ( ! WCMA_Bot_Broadcast::cancel( $id ) ) {
			wp_send_json_error( array( 'message' => 'این ارسال دیگر در جریان نیست.' ) );
		}

		$row = WCMA_Bot_Broadcast::get( $id );

		wp_send_json_success(
			array(
				'message' => 'ارسال لغو شد؛ پیام‌هایی که رفته‌اند برنمی‌گردند.',
				'job'     => $row ? WCMA_Bot_Broadcast::view( $row ) : null,
			)
		);
	}

	/**
	 * افزودن مدیر ربات، با شماره، شناسه‌ی چت یا از فهرست مشترکان.
	 */
	public function ajax_bot_admin_add() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$who  = isset( $_POST['who'] ) ? sanitize_text_field( wp_unslash( $_POST['who'] ) ) : '';
		$chat = isset( $_POST['chat'] ) ? sanitize_text_field( wp_unslash( $_POST['chat'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// دکمه‌ی جدول مشترکان شناسه‌ی چتِ دقیق می‌فرستد و نباید شماره خوانده شود.
		$found = '' !== $chat ? WCMA_Bot_Admin::resolve_chat( $chat ) : WCMA_Bot_Admin::resolve( $who );

		if ( empty( $found['success'] ) ) {
			wp_send_json_error( array( 'message' => $found['message'] ) );
		}

		if ( WCMA_Bot_Admin::is_admin( WCMA_Bot_Manager::channel(), $found['chat_id'] ) ) {
			wp_send_json_error( array( 'message' => 'این حساب از پیش مدیر ربات است.' ) );
		}

		WCMA_Bot_Admin::add( WCMA_Bot_Manager::channel(), $found['chat_id'], $found['name'], true, $found['telegram'] ?? '' );

		wp_send_json_success(
			array(
				'message' => $found['known']
					? sprintf( '«%s» (در تلگرام: %s) مدیر ربات شد و منوی مدیریت برایش فرستاده شد.', $found['name'], $found['telegram'] )
					: 'این شناسه مدیر ربات شد. چون هنوز ربات را باز نکرده، پیامی برایش نرفت؛ کافی است ربات را باز کند و /admin بزند.',
			)
		);
	}

	/**
	 * برداشتن مدیر ربات.
	 */
	public function ajax_bot_admin_remove() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$key = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';

		if ( ! WCMA_Bot_Admin::remove( $key ) ) {
			wp_send_json_error( array( 'message' => 'این مدیر پیدا نشد.' ) );
		}

		wp_send_json_success( array( 'message' => 'دسترسی مدیریت برداشته شد.' ) );
	}

	/**
	 * ساختن لینک دعوتِ یک‌بارمصرف برای مدیر تازه.
	 */
	public function ajax_bot_admin_invite() {
		$this->guard();

		$invite = WCMA_Bot_Admin::new_invite();

		wp_send_json_success(
			array(
				'link'    => $invite['link'],
				'command' => '/start ' . WCMA_Bot_Admin::START_PREFIX . $invite['code'],
				'expires' => WCMA_Date::format( $invite['expires'], 'datetime' ),
			)
		);
	}

	/**
	 * سنجش سرعت ربات.
	 */
	public function ajax_bot_speed() {
		$this->guard();

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 90 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}

		$result = WCMA_Bot_Speed::check( WCMA_Bot_Manager::channel() );

		wp_send_json_success(
			array(
				'api'     => $result['api'],
				'api_v4'  => $result['api_v4'],
				'webhook' => $result['webhook'],
				'pending' => is_array( $result['info'] ) ? (int) ( $result['info']['pending_update_count'] ?? 0 ) : null,
				'server'  => $result['server'],
				'advice'  => $result['advice'],
			)
		);
	}

	/**
	 * اگر برگه‌ی ربات پیش از ویرایشی از تلگرام باز شده بود، تنظیم‌های ربات
	 * از این ذخیره کنار می‌روند تا ویرایش تلگرام برنگردد.
	 *
	 * @param array $raw   ورودی خام فرم.
	 * @param array $clean مقدارهای پاک‌شده.
	 * @return bool آیا چیزی کنار رفت؟
	 */
	protected function drop_stale_bot_keys( array $raw, array &$clean ) {
		if ( ! isset( $raw['_bot_rev'] ) || (int) $raw['_bot_rev'] === WCMA_Bot_Editor::rev() ) {
			return false;
		}

		$dropped = false;

		foreach ( WCMA_Bot_Editor::keys() as $key ) {
			if ( array_key_exists( $key, $clean ) ) {
				unset( $clean[ $key ] );
				$dropped = true;
			}
		}

		return $dropped;
	}

	/**
	 * بررسی سلامت وب‌هوک ربات.
	 */
	public function ajax_bot_diag() {
		$this->guard();

		$result = WCMA_Bot_Link::diagnose( WCMA_Bot_Manager::channel() );

		wp_send_json_success( $result );
	}

	/**
	 * استعلام لحظه‌ای اعتبار پنل پیامک.
	 */
	public function ajax_sms_balance() {
		$this->guard();

		// مقادیر ذخیره‌نشده‌ی فرم هم اعمال می‌شوند تا پیش از ذخیره هم بشود استعلام گرفت.
		$this->apply_test_overrides();

		$result = WCMA_SMS_Gateways::balance();

		WCMA_Settings::clear_runtime_overrides();

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success(
			array(
				'amount' => $result['amount'],
				'unit'   => $result['unit'],
				'time'   => WCMA_Date::format( time(), 'time' ),
			)
		);
	}

	/**
	 * راه‌اندازی سریع مسیر لید مگنت روی ربات تلگرام.
	 */
	public function ajax_lm_setup() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$topic = isset( $_POST['topic'] ) ? sanitize_text_field( wp_unslash( $_POST['topic'] ) ) : '';

		$result = WCMA_Lead_Magnet::setup_telegram( $topic );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}

	/**
	 * فهرست تازه‌ی گفتگوها برای به‌روزرسانی خودکار صندوق.
	 */
	public function ajax_chat_updates() {
		$this->guard();

		// هر بار که این درخواست می‌رسد یعنی اپراتوری پای پیشخوان است.
		WCMA_LiveChat::mark_agent_seen();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$open = isset( $_POST['chat_id'] ) ? (int) $_POST['chat_id'] : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$since = isset( $_POST['since'] ) ? (int) $_POST['since'] : 0;

		$chats = WCMA_Chatbot::chats( array( 'status' => 'open', 'per_page' => 50 ) );
		$items = array();

		foreach ( $chats['items'] as $chat ) {
			$items[] = array(
				'id'      => (int) $chat['id'],
				'name'    => $chat['name'] ? $chat['name'] : 'مهمان',
				'channel' => WCMA_Chatbot::channel_label( $chat['channel'] ),
				'preview' => mb_substr( (string) $chat['last_message'], 0, 70 ),
				'unread'  => (int) $chat['unread'],
				'mode'    => $chat['mode'],
				'online'  => WCMA_LiveChat::visitor_online( $chat ),
				'date'    => WCMA_Date::mysql( $chat['last_message_at'], 'datetime', '' ),
			);
		}

		$fresh = array();

		if ( $open ) {
			foreach ( WCMA_Chatbot::recent_messages( $open, 30 ) as $message ) {
				if ( (int) $message['id'] <= $since ) {
					continue;
				}

				$fresh[] = array(
					'id'        => (int) $message['id'],
					'direction' => $message['direction'],
					'sender'    => $message['sender'],
					'rule'      => $message['rule'],
					'status'    => $message['status'],
					'body'      => $message['body'],
					'date'      => WCMA_Date::mysql( $message['created_at'], 'datetime' ),
				);
			}

			$fresh = array_reverse( $fresh );
		}

		$chat = $open ? WCMA_Chatbot::chat( $open ) : null;

		wp_send_json_success(
			array(
				'chats'   => $items,
				'unread'  => WCMA_Chatbot::unread_count(),
				'fresh'   => $fresh,
				'typing'  => $chat && ! empty( $chat['visitor_typing_at'] ) && ( time() - strtotime( $chat['visitor_typing_at'] ) ) < 8,
				'visitor' => $chat ? WCMA_LiveChat::visitor_online( $chat ) : false,
			)
		);
	}

	/**
	 * اعلام تایپ اپراتور به بازدیدکننده.
	 */
	public function ajax_chat_typing() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$chat_id = isset( $_POST['chat_id'] ) ? (int) $_POST['chat_id'] : 0;

		if ( $chat_id ) {
			WCMA_LiveChat::agent_typing( $chat_id );
		}

		wp_send_json_success( array( 'ok' => true ) );
	}

	public function ajax_chat_thread() {
		$this->guard();

		WCMA_LiveChat::mark_agent_seen();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$chat_id = isset( $_POST['chat_id'] ) ? (int) $_POST['chat_id'] : 0;
		$chat    = WCMA_Chatbot::chat( $chat_id );

		if ( ! $chat ) {
			wp_send_json_error( array( 'message' => 'گفتگو پیدا نشد.' ) );
		}

		global $wpdb;

		$wpdb->update( WCMA_Chatbot::chats_table(), array( 'unread' => 0 ), array( 'id' => $chat_id ) ); // phpcs:ignore WordPress.DB

		$messages = array_reverse( WCMA_Chatbot::recent_messages( $chat_id, 100 ) );
		$refs     = array();

		foreach ( $messages as $message ) {
			if ( ! empty( $message['reply_to'] ) ) {
				$refs[] = (int) $message['reply_to'];
			}
		}

		$quotes = $refs ? WCMA_Chatbot::quotes( $refs ) : array();
		$out    = array();

		foreach ( $messages as $message ) {
			$ref = (int) ( $message['reply_to'] ?? 0 );

			$out[] = array(
				'id'        => (int) $message['id'],
				'direction' => $message['direction'],
				'sender'    => $message['sender'],
				'rule'      => $message['rule'],
				'status'    => $message['status'],
				'body'      => $message['body'],
				'file'      => WCMA_Chat_Files::shape( $message ),
				'reply'     => ( $ref && isset( $quotes[ $ref ] ) ) ? array_merge( array( 'id' => $ref ), $quotes[ $ref ] ) : null,
				'date'      => WCMA_Date::mysql( $message['created_at'], 'datetime' ),
			);
		}

		$contact = ! empty( $chat['contact_id'] ) ? WCMA_CRM::get( (int) $chat['contact_id'] ) : null;

		wp_send_json_success(
			array(
				'chat'     => array(
					'id'      => (int) $chat['id'],
					'name'    => $chat['name'] ? $chat['name'] : ( WCMA_LiveChat::CHANNEL === $chat['channel'] ? 'مهمان سایت' : 'مشتری' ),
					'channel' => WCMA_Chatbot::channel_label( $chat['channel'] ),
					'phone'   => WCMA_Date::digits( $chat['phone'] ),
					'email'   => $chat['email'] ?? '',
					'mode'    => $chat['mode'],
					'status'  => $chat['status'],
					'web'     => WCMA_LiveChat::CHANNEL === $chat['channel'],
					'online'  => WCMA_LiveChat::visitor_online( $chat ),
					'rating'  => (int) ( $chat['rating'] ?? 0 ),
					'facts'   => array_values(
						array_filter(
							array(
								! empty( $chat['page_title'] ) ? 'صفحه: ' . $chat['page_title'] : '',
								! empty( $chat['page_url'] ) ? $chat['page_url'] : '',
								! empty( $chat['referrer'] ) ? 'ورود از: ' . $chat['referrer'] : '',
								! empty( $chat['browser'] ) ? $chat['browser'] . ( ! empty( $chat['device'] ) ? ' — ' . $chat['device'] : '' ) : '',
								! empty( $chat['ip'] ) ? 'IP: ' . $chat['ip'] : '',
								! empty( $chat['created_at'] ) ? 'شروع: ' . WCMA_Date::mysql( $chat['created_at'], 'datetime', '' ) : '',
							)
						)
					),
				),
				'contact'  => $contact ? array(
					'id'    => (int) $contact['id'],
					'name'  => WCMA_CRM::display_name( $contact ),
					'stage' => WCMA_CRM::stage_label( $contact['stage'] ),
					'url'   => add_query_arg( array( 'contact' => (int) $contact['id'] ), self::tab_url( 'crm' ) ),
				) : null,
				'messages' => $out,
			)
		);
	}

	/**
	 * پاسخ دستی اپراتور.
	 */
	public function ajax_chat_reply() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$chat_id = isset( $_POST['chat_id'] ) ? (int) $_POST['chat_id'] : 0;
		$text    = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reply_to = isset( $_POST['reply'] ) ? (int) $_POST['reply'] : 0;
		$result   = WCMA_Chatbot::send( $chat_id, $text, 'human', '', $reply_to );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success(
			array(
				'message' => $result['message'],
				'date'    => WCMA_Date::format( null, 'datetime' ),
			)
		);
	}

	/**
	 * ارسال فایل یا پیام صوتی از سوی اپراتور.
	 */
	public function ajax_chat_upload() {
		$this->guard();

		if ( ! WCMA_Chat_Files::enabled() ) {
			wp_send_json_error( array( 'message' => 'ارسال فایل در گفتگو خاموش است.' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$chat_id = isset( $_POST['chat_id'] ) ? (int) $_POST['chat_id'] : 0;
		$caption = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$duration = isset( $_POST['duration'] ) ? (int) $_POST['duration'] : 0;
		$saved    = WCMA_Chat_Files::store( isset( $_FILES['file'] ) ? $_FILES['file'] : null, $duration ); // phpcs:ignore WordPress.Security

		if ( is_wp_error( $saved ) ) {
			wp_send_json_error( array( 'message' => $saved->get_error_message() ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reply_to = isset( $_POST['reply'] ) ? (int) $_POST['reply'] : 0;
		$result   = WCMA_Chatbot::send_file( $chat_id, $saved, $caption, $reply_to );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		wp_send_json_success(
			array(
				'message' => $result['message'],
				'date'    => WCMA_Date::format( null, 'datetime' ),
			)
		);
	}

	/**
	 * پاک کردن دستی همه‌ی فایل‌های گفتگو.
	 */
	public function ajax_chat_files_purge() {
		$this->guard();

		$removed = WCMA_Chat_Files::purge_all();
		$usage   = WCMA_Chat_Files::usage();

		wp_send_json_success(
			array(
				'message' => sprintf( '%s فایل پاک شد.', WCMA_Date::number( $removed ) ),
				'count'   => WCMA_Date::number( $usage['count'] ),
				'size'    => WCMA_Chat_Files::human_size( $usage['bytes'] ),
			)
		);
	}

	/**
	 * تغییر حالت یا وضعیت گفتگو.
	 */
	public function ajax_chat_mode() {
		$this->guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$chat_id = isset( $_POST['chat_id'] ) ? (int) $_POST['chat_id'] : 0;
		$mode    = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : '';
		$status  = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( $mode && ! WCMA_Chatbot::set_mode( $chat_id, $mode ) ) {
			wp_send_json_error( array( 'message' => 'تغییر حالت انجام نشد.' ) );
		}

		if ( $status ) {
			WCMA_Chatbot::set_status( $chat_id, $status );
		}

		wp_send_json_success(
			array(
				'message' => 'human' === $mode
					? 'گفتگو در دست شماست؛ ربات دیگر خودکار پاسخ نمی‌دهد.'
					: ( 'closed' === $status ? 'گفتگو بسته شد.' : 'پاسخ خودکار ربات دوباره فعال شد.' ),
			)
		);
	}

	/**
	 * آزمودن پاسخ ربات بدون ارسال واقعی.
	 */
	public function ajax_chat_simulate() {
		$this->guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';

		if ( '' === trim( $text ) ) {
			wp_send_json_error( array( 'message' => 'یک پیام آزمایشی بنویسید.' ) );
		}

		wp_send_json_success( WCMA_Chatbot::simulate( $text ) );
	}

	public function ajax_vip_recalc() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$workflow = WCMA_Plugin::instance()->get_workflow( 'vip_club' );

		if ( ! $workflow ) {
			wp_send_json_error( array( 'message' => 'ورک‌فلو باشگاه مشتریان در دسترس نیست.' ) );
		}

		$result = $workflow->recalculate_now();

		wp_send_json_success( array( 'message' => $result['message'] ) );
	}

	/**
	 * ایجکس: شبیه‌سازی قدم‌به‌قدم هشدار موجودی.
	 */
	public function ajax_stock_simulate() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$workflow = WCMA_Plugin::instance()->get_workflow( 'stock_alert' );

		if ( ! $workflow ) {
			wp_send_json_error( array( 'message' => 'ورک‌فلو هشدار موجودی در دسترس نیست.' ) );
		}

		// متن آزاد می‌پذیریم: شناسه، نام، کد محصول، لینک یا نامک.
		$product_ref = isset( $_POST['product_id'] ) ? sanitize_text_field( wp_unslash( $_POST['product_id'] ) ) : '';
		$contact     = isset( $_POST['contact'] ) ? sanitize_text_field( wp_unslash( $_POST['contact'] ) ) : '';

		wp_send_json_success( $workflow->simulate( $product_ref, $contact ) );
	}

	/**
	 * ایجکس: ساخت دوباره‌ی جدول‌های نداشته.
	 */
	public function ajax_repair_tables() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		$still_missing = WCMA_Install::missing_tables( true );

		if ( $still_missing ) {
			wp_send_json_error(
				array(
					'message' => 'ساخت این جدول‌ها ناموفق بود: ' . implode( '، ', $still_missing ) . ' — دسترسی کاربر دیتابیس برای CREATE TABLE را بررسی کنید.',
				)
			);
		}

		wp_send_json_success( array( 'message' => 'همه‌ی جدول‌ها موجود هستند.' ) );
	}

	/**
	 * ایجکس: پیش‌نمایش تعداد مخاطبان کمپین.
	 */
	public function ajax_preview_audience() {
		check_ajax_referer( 'wcma_admin', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$audience = array(
			'type'          => isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : 'all_customers',
			'product_ids'   => isset( $_POST['product_ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['product_ids'] ) ) : array(),
			'category_ids'  => isset( $_POST['category_ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['category_ids'] ) ) : array(),
			'min_spend'     => isset( $_POST['min_spend'] ) ? (float) $_POST['min_spend'] : 0,
			'inactive_days' => isset( $_POST['inactive_days'] ) ? (int) $_POST['inactive_days'] : 60,
			'manual_list'   => isset( $_POST['manual_list'] ) ? sanitize_textarea_field( wp_unslash( $_POST['manual_list'] ) ) : '',
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$recipients = WCMA_Campaigns::resolve_recipients( $audience );

		$with_email = 0;
		$with_phone = 0;

		foreach ( $recipients as $recipient ) {
			if ( ! empty( $recipient['email'] ) ) {
				$with_email++;
			}
			if ( ! empty( $recipient['phone'] ) ) {
				$with_phone++;
			}
		}

		wp_send_json_success(
			array(
				'total' => count( $recipients ),
				'email' => $with_email,
				'phone' => $with_phone,
			)
		);
	}
}
